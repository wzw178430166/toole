<?php
return array (
  0 => 
  array (
    'id' => '7',
    'catid' => '6',
    'title' => '234',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=7',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482398587',
    'status' => '99',
  ),
  1 => 
  array (
    'id' => '6',
    'catid' => '6',
    'title' => '234',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=6',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482398517',
    'status' => '99',
  ),
  2 => 
  array (
    'id' => '5',
    'catid' => '6',
    'title' => '234',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=5',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482398484',
    'status' => '99',
  ),
  3 => 
  array (
    'id' => '4',
    'catid' => '6',
    'title' => '234',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=4',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482397954',
    'status' => '99',
  ),
  4 => 
  array (
    'id' => '3',
    'catid' => '6',
    'title' => '2016秋冬男装纯棉加厚牛津纺长袖衬衫男士纯色商务打底白衬衣',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=3',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482395796',
    'status' => '99',
  ),
  5 => 
  array (
    'id' => '2',
    'catid' => '6',
    'title' => '2016秋冬男装纯棉加厚牛津纺长袖衬衫男士纯色商务打底白衬衣',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=2',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482395632',
    'status' => '99',
  ),
  6 => 
  array (
    'id' => '1',
    'catid' => '6',
    'title' => '2016秋冬男装纯棉加厚牛津纺长袖衬衫男士纯色商务打底白衬衣',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=1',
    'username' => '13719515575',
    'sysadd' => '0',
    'inputtime' => '1482395462',
    'status' => '99',
  ),
);
?>