<?php
return array (
  0 => 
  array (
    'id' => '3',
    'catid' => '7',
    'title' => '公告二',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=7&id=3',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1484100725',
    'status' => '99',
  ),
  1 => 
  array (
    'id' => '2',
    'catid' => '7',
    'title' => '公告一',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=7&id=2',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1484100691',
    'status' => '99',
  ),
  2 => 
  array (
    'id' => '9',
    'catid' => '6',
    'title' => '让人',
    'url' => 'index.php?m=content&c=index&a=show&catid=6&id=9',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1486988350',
    'status' => '99',
  ),
  3 => 
  array (
    'id' => '8',
    'catid' => '6',
    'title' => '猿人圆领白色T恤',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=8',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1484123733',
    'status' => '99',
  ),
  4 => 
  array (
    'id' => '3',
    'catid' => '6',
    'title' => '2016秋冬男装纯棉加厚牛津纺长袖衬衫男士纯色商务打底白衬衣',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=3',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1484018749',
    'status' => '99',
  ),
  5 => 
  array (
    'id' => '2',
    'catid' => '6',
    'title' => '2016秋冬男装纯棉加厚牛津纺长袖衬衫男士纯色商务打底白衬衣',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=6&id=2',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1482395632',
    'status' => '1',
  ),
  6 => 
  array (
    'id' => '1',
    'catid' => '10',
    'title' => '香港品牌 锦华什锦西饼礼盒 500g',
    'url' => 'http://shop.weiweibb.com/index.php?m=content&c=index&a=show&catid=10&id=1',
    'username' => 'bb4',
    'sysadd' => '0',
    'inputtime' => '1484734231',
    'status' => '99',
  ),
);
?>