<?php
return array (
  7 => '7',
  8 => '0',
  9 => '0',
);
?>