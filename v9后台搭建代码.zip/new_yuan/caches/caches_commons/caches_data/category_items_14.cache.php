<?php
return array (
  6 => '190',
  11 => '0',
);
?>