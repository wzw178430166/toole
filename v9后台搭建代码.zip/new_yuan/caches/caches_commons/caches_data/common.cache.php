<?php
return array (
  'admin_email' => 'phpcms@phpcms.cn',
  'maxloginfailedtimes' => '8',
  'minrefreshtime' => '2',
  'mail_type' => '1',
  'mail_server' => 'smtp.qq.com',
  'mail_port' => '25',
  'category_ajax' => '0',
  'mail_user' => 'phpcms.cn@foxmail.com',
  'mail_auth' => '1',
  'mail_from' => 'phpcms.cn@foxmail.com',
  'mail_password' => '',
  'errorlog_size' => '20',
);
?>