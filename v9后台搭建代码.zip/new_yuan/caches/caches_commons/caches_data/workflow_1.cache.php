<?php
return array (
  1 => 
  array (
    'workflowid' => '1',
    'siteid' => '1',
    'steps' => '1',
    'workname' => '一级审核',
    'description' => '审核一次',
    'setting' => '',
    'flag' => '0',
  ),
  2 => 
  array (
    'workflowid' => '2',
    'siteid' => '1',
    'steps' => '2',
    'workname' => '二级审核',
    'description' => '审核两次',
    'setting' => '',
    'flag' => '0',
  ),
  3 => 
  array (
    'workflowid' => '3',
    'siteid' => '1',
    'steps' => '3',
    'workname' => '三级审核',
    'description' => '审核三次',
    'setting' => '',
    'flag' => '0',
  ),
  4 => 
  array (
    'workflowid' => '4',
    'siteid' => '1',
    'steps' => '4',
    'workname' => '四级审核',
    'description' => '四级审核',
    'setting' => '',
    'flag' => '0',
  ),
);
?>