<?php
return array (
  10 => '0',
);
?>