<?php
return array (
  'member' => '会员',
  'special' => '专题',
  'content' => '内容模块',
  'comment' => '评论',
);
?>