<?php
return array(
'pc_version' => 'V9.5.8',	//drcms 版本号
'pc_release' => '20140929',	//drcms 更新日期
);
?>