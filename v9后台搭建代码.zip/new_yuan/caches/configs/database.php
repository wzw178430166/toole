<?php

return array (
	'default' => array (
		'hostname' => 'localhost:33061',
		'database' => 'sea_amoy',
		'username' => 'gameUsers',
		'password' => 'e8online>',
		'tablepre' => 'sa_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
	'sms' => array (
		'hostname' => 'localhost:33061',
		'database' => 'sms_shortMessage',
		'username' => 'gameUsers',
		'password' => 'e8online>',
		'tablepre' => 'ss_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
	'ku' => array (
		'hostname' => 'localhost:33061',
		'database' => 'ku',
		'username' => 'gameUsers',
		'password' => 'e8online>',
		'tablepre' => 'ku_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>