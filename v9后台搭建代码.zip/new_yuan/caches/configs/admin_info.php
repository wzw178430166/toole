<?php
return array (
  'admin_userid' => '6',
  'admin_username' => '15920477863',
  'shopType' => 'b2c',
);
?>