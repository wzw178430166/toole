<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<meta name="description" content="<?php echo $SEO['description'];?>">
<noscript>
<meta  http-equiv="refresh"   content ="0; url=<?php echo PATH;?>noscript.php" >
</noscript>

<link type="text/css" href="<?php echo SPATH;?>diy/css/style.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo SPATH;?>diy/css/h_style.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo CSS_PATH;?>table_form.css" rel="stylesheet"/>
<script src="<?php echo PATH;?>tag/auth.php"></script>
<script src="<?php echo SPATH;?>diy/js/login.js" type="text/javascript"></script>
<script src="<?php echo SPATH;?>diy/js/cookie.fun.js" type="text/javascript"></script>
<script src="<?php echo SPATH;?>js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script>
//__check2();
</script>
</head>
<body>
<div class="con">
  <div class="top">
    <div class="top_l">
      <div class="logo fl">
        <a href=""  style="float:left;"><img src="<?php echo SPATH;?>diy/images/logo2.jpg" style=" padding-top:5px; " /></a>
      </div>
    </div>
    <div class="top_r"  style="width:700px;">
      <div class="top_t">
        <div class="ban fl" style=" margin-top:10px; height:60px;">
          <script language="javascript" src="<?php echo APP_PATH;?>caches/poster_js/13.js"></script>
        </div>
        <div class="top_mini fl">
          欢迎 <?php echo $_username;?>
          <?php include template("tag","renshu"); ?>
          <li class="li2" style="display:block; *float:none; height:16px; line-height:16px; color:#FF0000; font-size:16px; font-weight:bold;">020-81533173</li>
        </div>
      </div>
      <div class="top_b">
        <ul>
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d093ea4b0f3c2b34dc76ab48b7810e66&action=category&siteid=1&catid=55\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'category')) {$data = $content_tag->category(array('siteid'=>'1','catid'=>'55','num'=>'20','limit'=>'20',));}?>
        <?php $cat_id=0;?>
        <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
        <li>
        	<?php if($cat_id==0) { ?>
          <a href="<?php echo PATH;?>" id="t<?=++$cat_id?>"><?php echo $r['catname'];?></a>
          <?php } else { ?>
          <a href="<?php echo $r['url'];?>&t=<?=++$cat_id?>" id="t<?=$cat_id?>"><?php echo $r['catname'];?></a>
          <?php } ?>
        </li>
        <?php $n++;}unset($n); ?>
        <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
         <!--<li>
          <a id="t7" href="http://rw.e8sunwukong.com/">任务中心</a>
        </li>-->
        </ul>
        <div class="cl">
        </div>
      </div>
    </div>
    <div class="cl">
    </div>
  </div>
</div>
<script>
var t = GetQueryString("t");
if(t){  document.getElementById("t"+t).className="on";}
else{ document.getElementById("t1").className="on"; };
</script>