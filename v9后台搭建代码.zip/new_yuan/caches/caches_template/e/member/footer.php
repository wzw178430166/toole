<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="foot">
<div class="area2">
    <a  target="_blank">关于巴巴优品分销平台</a>
    |
    <?php $liakname="商务合作"?>
    <?php include template("tag","tag_zaixian"); ?>
    |
    <?php $liakname="联系我们"?>
    <?php include template("tag","tag_zaixian"); ?> 
     
    | 本站不良信息24小时举报电话：020-81580156<br>
    <p style="color:#0078bd;"></p>
    <a href="http://www.e8online.com" target="_blank">广州唐剑科技有限公司</a>
    版权所有&nbsp;
    <a href="http://www.miibeian.gov.cn/" target="_blank">粤ICP备16024208号</a>
    <script src="http://s19.cnzz.com/stat.php?id=3518445&web_id=3518445&show=pic1" language="JavaScript"></script>

    <style>
.approve a { display: inline-block; width: 65px; height: 45px; padding: 5px 5px 0 50px; line-height: 20px; position: relative; border: 1px solid #D2D2D2; margin: 5px 5px 50px; border-image: initial; }
.approve a s { display: block; width: 50px; height: 50px; position: absolute; top: 0; left: 0; background: url('<?php echo SPATH;?>diy/images/bgs.gif') no-repeat -56px -120px; }
.approve a.a2 s { background-position: -56px -170px; }
.approve a.a3 s { background-position: -56px -220px; }
    </style>
    
  </div>
</div>

  

<script>__check();</script>
<DIV id=divStay style="POSITION: absolute">
  <TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
    <TBODY>
      <TR>
        <TD vAlign=top width="7%">　</TD>
      </TR>
    </TBODY>
  </TABLE>
</DIV>
<SCRIPT language=javascript>
function picsize(obj,MaxWidth){
  img=new Image();
  img.src=obj.src;
  if (img.width>MaxWidth)
  {
    return MaxWidth;
  }
  else
  {
    return img.width;
  }
}
function CloseQQ()
{
divStayTopleft.style.display="none";
return true; 
}
var online= new Array();
</SCRIPT>

<SCRIPT type=text/javascript>
function FloatTop()
{
 var startX1 =document.body.offsetWidth-125 ,startY1 = 5;
 var startX2 =0,startY2 = 95;
 var ns = (navigator.appName.indexOf("Netscape") != -1);
 var d = document;
 
 window.stayTopLeft=function()
 {
  var pY = ns ? pageYOffset : document.body.scrollTop;
  ftlObj.y += (pY + startY1 - ftlObj.y)/8;
  ftlObj1.y += (pY + startY2 - ftlObj1.y)/8;
  ftlObj.sP(document.body.scrollLeft+document.body.offsetWidth-125, ftlObj.y);
  ftlObj1.sP(ftlObj1.x, ftlObj1.y);
  setTimeout("stayTopLeft()", 30);
 }
//  ftlObj = ml("divStay",document.body.scrollLeft+document.body.offsetWidth-125,0);
//  ftlObj1 = ml("divStayTopLeft",0,30);
 ftlObj = ml("divStay",(document.body.scrollLeft+document.body.offsetWidth)/2+379,0);
 ftlObj1 = ml("divStayTopLeft",(document.body.scrollLeft+document.body.offsetWidth)/2+379,30);
 stayTopLeft();
}
FloatTop();
</SCRIPT> 

<!--End: QQ在线客服 --> 