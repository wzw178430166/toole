<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<?php $titlename= $_GET['title'] ? $_GET['title'] : "个人设置";?>
</head>
<style>
body { background-color: #edecec; }
.base-info {
	padding: 0 10px;
    background-color: #fff;	
}
.base-info-item {
	padding: 12px 0;
    border-bottom: 1px #f4f2f2 solid;	
}
.member-btn {
	width: 95%;
    margin: 0 auto;
    margin-top: 25px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    font-size: 0.9rem;
    background-color: #fff;
    border-radius: 4px;
    color: #c70a1e;	
}
.item-icon { float:right; display:block; width:20px; height:20px; background:url('statics/images/icon/un_color/arrow_r_icon.png') no-repeat center; background-size:80%;}
</style>
<body>
	<?php include template("e","header","e"); ?>
<div style="height:45px;"></div>
<div class="base-info">
	<a href="index.php?m=wb_shop&a=baseinfo_edit">
        <div class="base-info-item">
            <span>个人信息</span>
            <i class="item-icon"></i>
        </div>
    </a>
    <a href="index.php?m=member&a=account_manage_password&om=1">
        <div class="base-info-item">
            <span>密码修改</span>
            <i class="item-icon"></i>
        </div>
    </a>
</div>
<div class="member-btn" onClick="window.location.href='index.php?m=member&c=index&a=logout'">更换账号</div>
    <?php include template("e","footer","e"); ?>
</body>
</html>
