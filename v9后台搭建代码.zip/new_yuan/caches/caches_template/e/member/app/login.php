<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<style>
body{ background-color:#edecec;}
.login{ width:100%; background-size:100%;}
.login_mess{ width:100%; overflow:hidden; text-align:center; background-color:#fff; padding-bottom:5px;}
.login_mess p{ padding-top:5px;}
.login_box{ width:100%; overflow:hidden; border-top:1px solid #edecec; background-color:#fff;}
.login_box .login_{ width:90%; overflow:hidden; border-bottom:1px solid #edecec; margin:0px auto; padding:10px 0px;}
.login_box .login_:last-child{ border-bottom:none;}
.login_ .login_l{ width:10%;}
.login_l img{ width:30px; height:30px;}
.login_ .login_r{ width:88%;}
.login_r .login_r_{ width:100%; height:30px;}
.login_more{ width:90%; overflow:hidden; margin:0px auto; display:block;}
.login_more a{ height:40px; line-height:40px; font-size:12px;}
.login_more .fl{ color:#646363;}
.login_more .fl{ color:#616060;}
.login_go{ width:90%; height:40px; line-height:40px; display:block; margin:0 auto; background-color:#f3571c; text-align:center; border-radius:5px; color:#fff; letter-spacing:2px;}
.login_other1{ width:100%; overflow:hidden;}
.login_other{ width:90%; overflow:hidden; margin:1% auto;}
.login_other .login_other_h{ width:100%; overflow:hidden;}
.login_other_h .login_other_h_{ background: url(statics/member/app/images_/tb.png)center repeat-x; text-align:center; height:40px; line-height:40px;}
.login_other_h_ span{ width:100px; display: inline-block; background-color:#edecec; color:#747373;}
.login_other .login_other_f{ width:25%; overflow:hidden; margin:0 auto; text-align:center; font-size:12px; color:#747373;}
.login_other_f img{ width:40px; height:40px;}
</style>
<body>
	<img src="<?php echo SPATH;?>member/app/images_/login_bg_fx.jpg" class="login">
    <div class="login_mess">
    	<p style="color:#f3571c; font-size:25px; font-weight:bold;">登录账号</p>
        <p style="font-size:12px;">请使用作为代理商的账号登录</p>
    </div>
    <form method="post" action="" onSubmit="loginsend();" id="myform">
        <input type="hidden" name="forward" id="forward" value="<?php echo $forward;?>">
        <input type="hidden" name="dosubmit" id="dosubmit" value="<?php echo L('login');?>">
        <div class="login_box">
            <div class="login_">
                <div class="login_l fl">
                    <img src="<?php echo SPATH;?>member/app/images_/mobile.png">
                </div>
                <div class="login_r fr">
                    <input type="text" placeholder="请输入您的手机号码" class="login_r_ nobd" name="username" id="username" >
                </div>
            </div>
            <div class="login_">
                <div class="login_l fl">
                    <img src="<?php echo SPATH;?>member/app/images_/exchange_line_l3.png">
                </div>
                <div class="login_r fr">
                    <input type="password" placeholder="请输入您的密码" class="login_r_ nobd" name="password" id="password">
                </div>
            </div>
        </div>
        <font class="login_more">
            <a href="index.php?m=member&c=index&a=register<?php if(isset($_GET['k']) && $_GET['k']) { ?><?php echo $_GET['k'];?><?php } ?>" class="fl">立即成为会员</a>
            <a href="/index.php?m=member&c=index&a=public_forget_password" class="fr">忘记密码？</a>
        </font>
        <input type="submit" value="立即登录" class="login_go nobd">
    </form>
    <div class="login_other1">
        <div class="login_other">
            <div class="login_other_h">
                <div class="login_other_h_">
                    <span>第三方登录</span>
                </div>
            </div>
            <div class="login_other_f" onClick="javascript:;">
                <img src="<?php echo SPATH;?>member/app/images_/shape_go2.png">
                <p>微信登录</p>
            </div>
        </div>
    </div>
</body>
<script>
function loginsend(){
	if(!$('#username').val()){
		alert("账号不能为空");
		return false;
	}else if(!$('#password').val()){
		alert("密码不能为空");
		return false;
	}

	var url = '/index.php?m=member&a=login&ajax=1&ifram=1';
	$.post(url,{ 'username':$('#username').val(),'password':$('#password').val(),'modelid':$('#modelid').val(),'wd':$('#wd').val(),'forward':$('#forward').val(),'dosubmit':'dosubmit','ajax':'1'},function(data){
		try{
			if(data.status==1){
				 loginseccess(data.forward_);
			}else{
				layer.msg(data.msg);
			}
		}catch(err){
			layer.msg(data.msg);
		}
	
	},'json');
	return false;
}
function loginseccess(forward_){
	var wpm = "<?php echo $_GET['wpm'];?>";
	//console.log(forward_);return;
	var url = forward_ != '' ? forward_ : (wpm == 1 ? 'index.php?m=wpm' :'index.php');
	//console.log(url);return;
	window.location.href = url;
}
</script>