<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("member","header","e"); ?>
	<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>diy/css/globe_v.3.css">
    <link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>diy/css/login_v.3.css">
	
<style type="text/css">
body{ background:url(../../../../statics/diy/images/bg2.jpg) repeat-x left top #f8f8f8}
	body fieldset{border:0}
</style>

<div id="page">
<!-- wrap -->
<div class="wrap login_box" style="margin-top:2%;">
	<!--= col_main -->
	<div class="col_main"  >
		<!--== login -->
		<div class="login1">
			<!--=== statement -->
			<!--<p class="statement">如果没有帐号，请先<a href="<?php echo APP_PATH;?>index.php?m=member&c=index&a=register&siteid=<?php echo $siteid;?>">免费注册</a></p>-->
            
            <p class="statement">如果没有帐号，请先<a href="index.php?m=member&c=index&a=register<?php if(isset($_GET['k']) && $_GET['k']) { ?><?php echo $_GET['k'];?><?php } ?>">免费注册</a></p>
			<form method="post" id="myform" name="myform" action="" onsubmit="save_username();">
            	<input type="hidden" name="forward" id="forward" value="<?php echo $forward;?>">
                <input type="hidden" name="dosubmit" id="dosubmit" value="<?php echo L('login');?>">
				<fieldset>
					<ul class="login_input">
						<li>
							<label for="username">手机号码：</label>
							<input type="text" tabindex="1" name="username" id="username" class="inp_txt" style="width:250px; height:25px;">
						</li>
						<li>
							<label for="password">密　　码：</label>
							<input type="password" tabindex="2" name="password" id="password" class="inp_txt"style="width:250px; height:25px;">
						</li>
						<li class="auto">
							<input type="checkbox" name="cookietime" value="2592000" id="cookietime">
							<label for="autoLogin"><?php echo L('remember');?><?php echo L('username');?></label>
                            <a href="/index.php?m=member&c=index&a=public_forget_password" style="text-decoration:underline; color:#F00;">找回密码</a>				
						</li>
						<li class="btn"><input type="submit" class="btn_login" tabindex="43" value="登录"></li>
					</ul>
				</fieldset>
			</form>
		</div>
		<!--== app_account -->
		<!-- 
		<div class="app_account">
			<h2>您也可以使用人人网帐号登录</h2>
			<p><a class="btn_renren" onclick="renren_connent();return false;" href="javascript:;"><img src="http://www.56.com/app/img/rrconnect.png"></a></p>
		</div>
 		-->
 		
 		
 		

	</div><!--=/ col_main -->
	<!--= col_side -->
	<div class="col_side">
		
		<div class="apply">
			<h2>会员的四大特权</h2>
			<dl>
				<dt class="ap1">获得分销获利的权利</dt>
				<dd>通过领取推广链接、微信分享进行渠道用户绑定，渠道用户消费可获得分红。</dd>
				<dt class="ap2">免费参与平台举办的活动</dt>
				<dd>台会不定时举办同城浪漫派对，以及线下用户体验交流等活动.</dd>
				<dt class="ap3">免费参与平台抽奖</dt>
				<dd>平台定期会举办大型抽奖活动，人人有机会，人人不落空，丰富礼品抱回家.</dd>
				<dt class="ap4">分销获取积分、消费优惠</dt>
				<dd>参与分销推广达到一定条件即可获得积分，指定商城内进行消费亦可获优惠，积分可以用于积分商城进行商品兑换</dd>
                
			</dl>
		</div>
	</div><!--=/ col_side -->
</div>
</div>
</div>

<?php include template("member","footer","e"); ?>