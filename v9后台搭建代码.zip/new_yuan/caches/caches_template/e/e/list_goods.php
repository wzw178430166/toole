<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title = '会员中心';?>
<?php include template('e',"header"); ?>
<link type="text/css" href="<?php echo SPATH;?>diy/css/fh2.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo SPATH;?>diy/css/178.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo SPATH;?>diy/css/fh_JianXi.css" rel="stylesheet"/>
<script src="/statics/js/jquery-1.8.3.min.js"></script>
<script src="/statics/js/layer/1.9.3/layer.js"></script>
<script src="/statics/html2canvas/dist/html2canvas.min.js"></script>
<script src="/statics/js/clipboard.min.js"></script>
<script src="/statics/js/jquery.qrcode.min.js"></script>
<style>
#zhezhao {
width:100%;height:250%;background-color:#000;position:absolute;top:0;left:0;z-index:2;opacity:.3;filter:alpha(opacity=30);display:none;
}
</style>
<div id="zhezhao" onClick="gb_zhe()"></div>
<div class="h_con">
  <?php include template('e',"lefter"); ?>
  <div class="h_r">
    <?php include template("tag","tag_gamelist"); ?>
    <div style="padding-left:0px; margin:0px; width:780px" class="fh_right">
      <div id="Tab0_Content19">
        <div class="TabContent_top">
          <div class="jiantou jiantou5">
          </div>
        </div>
        <div class="TabContent_body smzt">
          <div class="yqzq">
            <h2 class="smzt_h2 yxwz_h2"><?php echo $catname;?></h2>
            <p class="xq"> <?php include template("tag","tag_zaixian"); ?> </p>
          </div>
          <div class="tishi">
            <div class="tishi_top">
            </div>
            <div class="tishi_body lineh">
              <p class="p1_ezio"> <?php echo $description;?> </p>
            </div>
            <div class="tishi_bottom">
            </div>
          </div>
          <div class="zqgj">
            <div class="zqgj_title">
              <h2 class="zqgj_h2">商品列表</h2>
            </div>

            <div class="zqgj_body2 sm_list">
              <ul>
                
                <!--<li>总人数：<strong class="red hide"><?php echo $n_recharge;?> 人</strong></li>
               
                <li>总分红金额：<strong class="red hide">
                  <?php echo number_format($dividends,2);?>
                  元</strong></li>-->
              </ul>
            </div>
            <div class="zqgj_body3">
              <table cellspacing="0" cellpadding="0" border="0" width="100%" class="fh_tc_table">
                <thead>
                  <tr class="dn_tr">
                    <!--<td width="20%">分红期数</td>
                    <td width="15%">推广用户数量</td>
                    <td width="15%">有消费总人数</td>
                    <td width="15%">消费总金额</td>
                    <td width="15%">本期分红金额</td>
                    <td width="15%">状态</td>-->
                    <td width="15%">商品主图</td>
                    <td width="25%">商品名称</td>
                    <td width="8%">分销价格</td>
                    <td width="8%">分成</td>
                    <!--<td width="15%">库存</td>-->
                    <td width="15%">更新时间</td>
                    <td width="15%">分享</td>
                  </tr>
                </thead>
                <tbody>
 
                <?php $n=1;if(is_array($datalist)) foreach($datalist AS $r) { ?>
                <?php
                	$r['turl'].= '&i='.$this->_uid;
                	if($r['fencheng']<=0){
                		$r['fencheng'] = '15%';
                	}else{
                		$r['fencheng'] = ($r['fencheng']).'%';
                	}
                ?>
                <tr>
					<td><a class="lsrc_<?php echo $r['id'];?>" href="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" target="_blank"><img style="max-width:50%" src="<?php echo $r['thumb'];?>" class="c_thumb"/></a><div style="display:none;position: absolute;margin-left: 10%;box-shadow: 3px 2px 3px 2px #CCC;" class="dd_thumb"><img src="<?php echo $r['thumb'];?>"/></div></td>
                  <td><?php echo $r['title'];?></td>
                  <td><?php echo $r['jiage'];?></td>
                  <td><?php echo $r['fencheng'];?></td>
                  <!--<td><?php echo $r['kc'];?></td>-->
                  <td><?php echo date("Y-m-d H:i:s",$r['updatetime']);?></td>
                <td>
                <div class="qrcode_wrapper">
				  <img src="/statics/images/qrcode_26.png" alt="二维码" class="xiao_er" data-id="<?php echo $r['id'];?>"/>
				  <div class="qrcodes_<?php echo $r['id'];?>" id="qrcodes_<?php echo $r['id'];?>" style="display: none;width: 128px;height: 128px;position: absolute;margin-left: -6.5%;background: #FFF;"></div>
				</div>
				<div>
             		<a href="javascript:dow_er(<?php echo $r['id'];?>);">下载</a>
              		<span class="copy_lsrc" data-clipboard-text="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" style="cursor:pointer" onClick="fuzhi(this)">复制链接</span>
					<div style="display:none;position:absolute;border: 1px solid #CCC;width: 300px;height: 55px;background: #FFF;line-height: 55px;right:13%;z-index:3" id="fuzhi" class="fuzhi"><div style="text-align:center;">链接地址 : <input type="text" value="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" style="width:123px;"/><input type="button" value="点击复制" onClick="fuzhi_(this)" style="align:center;margin-top:6px"/></div></div>
                </div>
                </td>
                  <!--<td> <?php if($r[title]) { ?><?php echo $r['title'];?>
                    <?php } else { ?><?php echo date("Y年m月",$r[time]);?>
                    <?php } ?> </td>
                  <td><?php echo $r['n_expand'];?></td>
                  <td><?php echo $r['n_recharge'];?></td>
                  <td><?php echo $r['recharge'];?></td>
                  <td><?php echo $r['dividends'];?></td>
                  <td> <?php if($r['status']==0) { ?>
                    <a href="" >点击兑现</a>
                    <?php } else { ?>
                    已兑现
                    <?php } ?> </td>-->
                </tr>
                <?php $n++;}unset($n); ?>
              </table>
              <div style="clear: both"></div>
              <div class="cell_page">
              <?php echo $pages;?>
              </div>
            </div>
          </div>
        </div>
        <div class="TabContent_bottom">
        </div>
      </div>
    </div>
  </div>
  <div class="cl">
  </div>
</div>
<div id="ggg" style="width:128px"></div>
<script>
$(".c_thumb").hover(function(){
	var dataIndex = $(this).attr('data-index');
	$(".dd_thumb").css("display","none");
	$(this).parent().next().css("display","block");
},function(){
	var dataIndex = $(this).attr('data-index');
	$(".dd_thumb").css("display","none");
});
$(".xiao_er").hover(function(){
	var dataIndex = $(this).attr('data-id');
	var lsrc = $(".lsrc_"+dataIndex).attr("href");
	$(".qrcodes_"+dataIndex).html("");
	jQuery('#qrcodes_'+dataIndex).qrcode({width: 128,height: 128,correctLevel: 0,text: lsrc});
	$(".qrcodes_"+dataIndex).css("display","block");
},function(){
	$(".qrcodes_"+dataIndex).html("");
	var dataIndex = $(this).attr('data-id');
	$(".qrcodes_"+dataIndex).css("display","none");
});
var clipboard = new Clipboard('.copy_lsrc');
clipboard.on('success', function(e) {
	//layer.msg("复制分享链接成功~");
});
clipboard.on('error', function(e) {
	$(".fuzhi").css("display","none");
	$("#fuzhi").css("display","block");
	layer.msg("您的浏览器暂不支持一键复制,<br/>请手动复制.")
	console.log(e);
});
function fuzhi_(obj){
	layer.msg("复制分享链接完成~<br/>Mac的用户需要手动复制");
	$(".fuzhi").css("display","none");
	$("#zhezhao").css("display","none")
}
function fuzhi(obj){
	$(".fuzhi").css("display","none");
	$("#zhezhao").css("display","none")
	$(obj).next().css("display","block");
	$("#zhezhao").css("display","block")
}
function gb_zhe(){
	$("#zhezhao").css("display","none");
	$(".fuzhi").css("display","none");
}
function dow_er(id){
	var lsrc = $(".lsrc_"+id).attr("href");
	$("#ggg").html("");
	jQuery('#ggg').qrcode({width: 128,height: 128,correctLevel: 0,text: lsrc});
	html2canvas($("#ggg"), {
		onrendered: function (canvas) {
			var url = canvas.toDataURL();
			var triggerDownload = $("<a>").attr("href", url).attr("download", "分享二维码.png").appendTo("body");
			triggerDownload[0].click();
			triggerDownload.remove();
		}
	});
	$("#ggg").html("");
}
</script>
<?php include template('e',"footer"); ?> 