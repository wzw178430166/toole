<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="h_l" id="d_lefter">
  <div id="lm_tg1" class="lm_tg" style="display:block">
    <p class="glcd"></p>
    <p class="lm_gm"> <a href="<?php echo siteurl(3);?>" >管理后台首页</a> </p>
    <p class="lm_gm"> <a href="index.php?m=member&c=index&a=logout">安全退出</a> </p>
  </div>
  <div id="lm_tg2" class="lm_tg" style="display:block">
    <p class="gl_tou"><span>数据查询</span></p> 
    <p class="lm_gm"> <a href="?m=e&a=zcmx"> 注册用户明细</a> </p>
    <p class="lm_gm"> <a href="?m=e&a=czmx"> 我的推广分红</a> </p>
    <p class="lm_gm"> <a href="?m=e&a=fhjs"> 月度分红结算</a> </p>
  </div>
  
  <div id="lm_tg3" class="lm_tg" style="display:block">
    <p class="gl_tou"><span>下级会员管理</span></p>
    <p class="lm_gm"> <a href="?m=e&a=tjmd"> 下级会员推荐名单</a> </p>
    <p class="lm_gm"> <a href="?m=e&a=glfh"> 下级会员推广管理分红</a> </p>
  </div>

  <div id="lm_tg5" class="lm_tg" style="display:block">
    <p class="gl_tou"><span>推广内容</span></p>
    <p class="lm_gm"> <a href="?m=e&a=goods"> 商品列表</a> </p>
    <p class="lm_gm"> 
    <a href="http://www.weiweibb.com/index.php?m=content&a=lists&catid=68&f=e_barbar8" target="_blank"> 活动推广</a> 
    <!--<a href="?m=e&a=hds"> 活动推广</a> -->
    </p>
  </div>
  <div id="lm_tg4" class="lm_tg" style="display:block">
    <p class="gl_tou"><span>个人管理区</span></p>
    <p class=" guanli">
    <div class="fh_yonghu"> 
      <!--ri_select-->
      <div class="person "> 
        
        <!--已登录-->
        <div id="ctl00_ContentPlaceHolder1_divLogin" class="person_right">
          <div class="fh_name"> 欢迎您！<?php echo $_username;?><br>
            <span class="zl"> <a href="index.php?m=member&c=index&a=account_manage_info&t=3">个人信息</a>&nbsp;&nbsp;&nbsp;<a href="index.php?m=member&c=index&a=account_manage_password">修改密码</a> </span><br>
            <span >
            <p class="item"> <span class="action"> <span class="num"> 
            <strong><?php echo $f->memberinfo["point"]?></strong>礼券</span> <a class="cell_btn" href="">使用</a> </span> 我的礼券： </p>
            </span> </div>
        </div>
        <div > <img src="<?php echo SPATH;?>diy/images/dibian.jpg" style=" margin-left:-28px;" /> </div>
        <!--已登录--> 
        
      </div>
      <!--推广链接-->
      <div id="ctl00_ContentPlaceHolder1_spLogin" class="cell_side">
        <h3 class="title">店铺推广链接 </h3>
        <p>
          <input type="text" id="ctl00" class="text" value="http://www.barbar8.com/?i=<?=$this->_uid;?>">
          &nbsp; <a class="cell_btn" href="javascript:copyStr('','ctl00');">复制</a> </p>
        <p class="tips">复制推广链接发送给好友</p>
        <!--<p>
          <a href="" target="_blank">什么叫游戏推广?</a>
          <a href="" target="_blank"> 什么叫会员推广?</a>
        </p>--> 
      </div>
      
      <!--推广链接-->
      <div > <img src="<?php echo SPATH;?>diy/images/dibian.jpg" /> </div>
      <!--我的帐户-->
      <div class="cell_side">
        <h3 class="title">我的账户 </h3>
        <div  style="clear:both"> </div>
        <div class="passport">
          <p class="item"> <span class="action"> <span class="num"> <strong>0</strong>元 </span> <a onclick="return checkLogin();"  class="cell_btn" href="">领取</a> </span> 可领取分红： </p>
        </div>
      </div>
      <!--/我的帐户-->
      <div > <img src="<?php echo SPATH;?>diy/images/dibian.jpg" style=" margin-left:-28px;" /> </div>
      <!--消息中心-->
      <div class="cell_side">
        <h3 class="title">消息中心</h3>
        <div  style="clear:both"> </div>
        <div class="msg">
          <p class="item_1">系统消息：<strong> <a href=""> 0</a> </strong>条</p>
          <p class="item_2">用户站内留言：<strong> <a href="">0</a> </strong>条</p>
        </div>
      </div>
      <!--/消息中心--> 
    </div>
  </div>
  <p class="glcd_wei"></p>
</div>
