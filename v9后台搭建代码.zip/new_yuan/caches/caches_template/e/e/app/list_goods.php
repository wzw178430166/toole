<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<?php $titlename= $_GET['title'] ? $_GET['title'] : "产品列表";?>
<link rel="stylesheet" type="text/css" href="<?php echo SPATH;?>member/app/css/supply.css">
<style>
.black_bg{position:fixed;top:0;z-index:9;width:100%;height:100%;background:#000;opacity:.7; display: none;}
.jjj{float:left;top:43px;width:100%;height:100%;background-size:100%;z-index:99999;position:fixed;display:none}
.list_b .cur{     border-top: 2px solid #FB8A78; border-bottom: 2px solid #FB8A78; border-left: 1px solid #FB8A78; border-right: 1px solid #FB8A78;}
/*.bg-color { position:fixed; left:0; top:0; z-index:11}*/
.list_h { border:0; top:45px;}
</style>
<body>
	<?php include template("e","header","e"); ?>
    <div style="height:105px;"></div>
	<div class="list_h">
    	<ul>
        	<li class="cur" onClick="get_fenlei(-1)">全部</li>
            <li onClick="get_fenlei(1)">药妆护肤</li>
            <li onClick="get_fenlei(2)">健身减肥</li>
            <li onClick="get_fenlei(5)">生活用品</li>
            <li onClick="get_fenlei(7)">婴儿用品</li>
            <li onClick="get_fenlei(9)">女性养护</li>
        </ul>
    </div>
    <div style="height:40px;"></div>
    <div class="list_b" id="list_b">
      
       <template id="list_b_con">
        <div class="list_b_box" onClick="list_b_show(this)">
        	<div class="list_b_box_">
                <div class="list_b_">
                    <div class="list_b_l fl">
                        <img src="<$thumb$>">
                    </div>
                    <div class="list_b_r fl">
                        <p class="title"><$title$></p>
                       <!-- <del>市场参考价：¥<$jiage$>元</del>-->
                        <p>分销价：¥<$jiage$>元</p>
                        <p class="profit fr">利润：¥<$lirun$>元</p>
                    </div>
                </div>
            </div>
            <div class="list_b_show"> 
                <ul data-thumb="<$thumb$>" data-title="<$title$>" data-url="<?php echo siteurl(1);?>/index.php?m=wb_shop&a=show&catid=<$catid$>&id=<$id$>&i=<?=$this->_uid?>" data-description="<$goods_des$>">
                    <li onClick="goos('?m=wb_shop&a=show&catid=<$catid$>&id=<$id$>&i=<?=$this->_uid?>')" >
                        <div class="list_b_show_">
                            <img src="<?php echo SPATH;?>member/app/images_/look.png">
                            <p>预览</p>
                        </div>
                    </li>
                    <li onClick="copy(this)" data-clipboard-text="<?php echo siteurl(1);?>/?m=wb_shop&a=show&catid=<$catid$>&id=<$id$>&i=<?=$this->_uid?>">
                        <div class="list_b_show_ list_b_show_line" >
                            <img src="<?php echo SPATH;?>member/app/images_/line.png">
                            <p>复制链接</p>
                        </div>
                    </li>
                    <li onClick="copy_ok2(this)" data-thumb="<$thumb$>" data-title="<$title$>">
                        <div class="list_b_show_ list_b_show_adv">
                            <img src="<?php echo SPATH;?>member/app/images_/adv.png">
                            <p>二维码推广</p>
                        </div>
                    </li>
                    <li onClick="list_b_show_shape(this)">
                        <div class="list_b_show_ list_b_show_shape">
                            <img src="<?php echo SPATH;?>member/app/images_/shape.png">
                            <p style="color:#c6101f;">分享</p>
                        </div>
                    </li>
                </ul>
        	</div>
        </div>
        </template>
        
    </div>

    <!---二维码推广--->
    <div class="copy_ok2">
    	<div class="copy_ok2_h">
        	<div class="copy_ok2_h1">
            	<img src="<?php echo SPATH;?>member/app/images_/adv_logo.png" class="adv_logo">
                <img src="<?php echo SPATH;?>member/app/images_/adv_del.png" class="adv_del fr">
            </div>
            <div class="title"></div>
            <div class="copy_ok2_pic">
            	<img src="">
            </div>
            <div class="copy_ok2_h4">
            	<div class="copy_ok2_h4l fl">
                	<img src="<?php echo SPATH;?>member/app/images_/copy_ok2_h4l.png">
                    <p>长按或扫描二维码查看详情</p>
                </div>
                <div class="copy_ok2_h4r fr">
                	<img src="<?php echo SPATH;?>member/app/images_/copy_ok2_h4r.png">
                </div>
            </div>
        </div>
        <div class="copy_ok2_f">
        	<p>分享至：</p>
            <ul>
            	<li>
                	<img src="<?php echo SPATH;?>member/app/images_/shape_go1.png">
                </li>
                <li>
                	<img src="<?php echo SPATH;?>member/app/images_/shape_go2.png">
                </li>
                <li onClick="downimg()">
                	<img src="<?php echo SPATH;?>member/app/images_/code_down.png">
                </li>
            </ul>
        </div>
    </div>
    <!---分享--->
    <div class="list_b_show_shape_">
    	<div class="list_b_show_shape_go">
        	<div class="shape_go_box">
                <p>通过社交软件分享</p>
                <p>分享才能获得更多的货源</p>
            </div>
            <ul>
                <li onClick="go_share('wx_f')">
                    <div class="shape_go">
                        <img src="<?php echo SPATH;?>member/app/images_/shape_go1.png">
                        <p>朋友圈</p>
                    </div>
                </li>
                <li onClick="go_share('wx')">
                    <div class="shape_go" >
                        <img src="<?php echo SPATH;?>member/app/images_/shape_go2.png">
                        <p>微信好友</p>
                    </div>
                </li>
                <li onClick="javascript:;">
                    <div class="shape_go">
                        <img src="<?php echo SPATH;?>member/app/images_/shape_go3.png">
                        <p>QQ空间</p>
                    </div>
                </li>
                <li onClick="go_share('qq')">
                    <div class="shape_go">
                        <img src="<?php echo SPATH;?>member/app/images_/shape_go4.png">
                        <p>QQ</p>
                    </div>
                </li>
                <li onClick="javascript:;">
                    <div class="shape_go">
                        <img src="<?php echo SPATH;?>member/app/images_/shape_go5.png">
                        <p>微博</p>
                    </div>
                </li>
        	</ul>
        </div>
        
        <div class="list_b_show_shape_del">取消</div>
    </div>
    <div  class="black_bg" id="black_bg"></div>
    <?php include template("e","footer","e"); ?>
    <div class="bg-color"></div>

<div class="jjj" style="background: url(/statics/images/fenx.png) no-repeat;background-size:100%;" id="fenxx"></div>
</body>
</html>
<script src="<?php echo JS_PATH;?>ex/html2canvas.min.js"></script>
<script src="<?php echo JS_PATH;?>ex/canvas2image.js"></script>
<?php
	$pinfo['title'] = '巴巴优库分销平台';
	$pinfo['description'] = '巴巴优库分销平台';
	$pinfo['thumb'] = 'http://e.barbar8.com/statics/ku/app/images/logo_bb.png';
	$pinfo['link'] = 'http://e.barbar8.com/?k='.$this->_uid;
?>
<?php include template("e","jsapi","e"); ?>
<script>
function showform(){ bghide();}
	
var page = 1;
get_data();
function get_data(){
	$.ajax({
		'url':'/?m=e&a=goods_data',
		'data': 'page='+page,
		'success':function(data){
			data = JSON.parse(data);
			var t = $('#list_b_con').html();
			t = mytemplate_list(t,data);
			$('#list_b').append(t);
		}
	});
}
function get_fenlei(fid){
	$.ajax({
		'url':'/?m=e&a=goods_data&fid='+fid,
		'data': 'fid='+fid+'&page='+page,
		'success':function(data){
			$('.list_b_box').remove();
			data = JSON.parse(data);
			var t = $('#list_b_con').html();
			t = mytemplate_list(t,data);
			$('#list_b').append(t);
		}
	});
}
</script>
<script>
//nav
$('.list_h ul li').click(function(){
	$(this).addClass('cur').siblings().removeClass('cur');
	var _index = $(this).index();
	$('.list_b').eq(_index).show().siblings('.list_b').hide();
	});
$('.list_b').eq(0).show().siblings('.list_b').hide();
//下框弹出
function list_b_show(obj){
	$('.list_b_show').hide();
	$('.list_b_box').removeClass('cur');
	$(obj).addClass('cur');
	$(obj).find('.list_b_show').show();
	
	var info = $(obj).children('.list_b_show').children('ul');
	share_title = $(info).data('title');
	share_description = $(info).data('description');
	share_link = $(info).data('url');
	share_thumb = $(info).data('thumb');
	//alert(share_link);
	wx_read();
}
//复制链接
function copy(obj){
	var clipboard = new Clipboard(obj);
	clipboard.on('success', function(e) {
		layer.msg("复制分享链接成功~");
	});
	clipboard.on('error', function(e) {
		layer.msg("您的浏览器暂不支持一键复制,<br/>请手动复制.")
		console.log(e);
	});
}

//分享框
function list_b_show_shape(obj){
	if(is_weixin()){
		$('#fenxx').show();
	}else{
		$('#fenxx').show();
		//$('.list_b_show_shape_').show();
	}
	$('.copy_ok2').hide();
	bgshow();
};
$('.list_b_show_shape_del').click(function(){
	$('.list_b_show_shape_').hide();
	bghide();
});

//预览
function goos(url){
	url += '&forward='+ escape(window.location.href);
	window.location.href = url;
}
//二维码复制
function copy_ok2(obj){
	$('.copy_ok2_pic img').attr('src', $(obj).data('thumb'));
	$('.title').html( $(obj).data('title'));
	$('.copy_ok2').show();
	bgshow();
}
$('.copy_ok2_h1 .adv_del').click(function(){
	$('.copy_ok2').hide();
	bghide()
});
function downimg(){
	html2canvas($('.copy_ok2_h'), {
		onrendered: function(canvas) {
			var data=canvas.toDataURL("image/png");//生成的格式
			var oImgPNG = Canvas2Image.saveAsPNG(canvas, true);

			document.body.appendChild(oImgPNG);
		}
	});
}
//背景
function bgshow(){
	$('#black_bg').show();
}
function bghide(){
	$('#black_bg').hide();
	$('.list_b_show_shape_').hide();
	$('.copy_ok2').hide();
	$('.list_b_show_shape_').hide();
	$('#fenxx').hide();
}
$('#black_bg').click(function(){
	bghide();
});
$('#fenxx').click(function(){
	bghide();
});
	
function go_share(ac){
	window.location.href = 'weixin://';
}
function go_weixin_f(){
	window.location.href = 'weixin://';
}
function go_qq(){
	window.location.href = 'qq://';
}
function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();  
    if(ua.match(/MicroMessenger/i)=="micromessenger") {  
        return true;  
    } else {  
        return false;  
    }  
}
</script>