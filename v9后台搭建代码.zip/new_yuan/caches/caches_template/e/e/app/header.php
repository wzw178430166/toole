<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.header{
	position: fixed;
    top: 0px;
    width: 100%;
    height: 44px;
    background: #ffffff;
	border-bottom:1px solid #c8cacc;
}
.header_box {
    width: 100%;
    height: 44px;
    line-height: 44px;
    text-align: center;
    margin: 0 auto;
    background: #fff;
    position: relative;
	border-bottom: 1px #f4f2f2 solid;
}
.header_fanhui {
    display: inline-block;
    background: url('statics/member/app/images_/hl.png') no-repeat center;
    background-size: 12px auto;
    position: absolute;
    height: 44px;
    top: 0px;
    left: 10px;
    width: 32px;
}
.header_title {
    font-size: 16px;
    color: #333333;
	line-height:inherit;
	border-bottom:1px solid #fff;
}
</style>
<!--public header start-->
<div class="header">
  <div class="header_box">
  <!--<a href="javascript:goback()" class="header_fanhui" id="header_fanhui"></a>-->
  <a href="javascript:window.history.go(-1);" class="header_fanhui" id="header_fanhui"></a>
    <h2 class="header_title "><?php echo $titlename;?></h2>
  </div>
</div>
<!--public header end-->