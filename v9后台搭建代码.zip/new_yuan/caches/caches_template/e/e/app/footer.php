<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
/*底部导航*/
.list_f{ width:100%; overflow:hidden; position:fixed; bottom:0; left:0; background-color:#fff; border-top:1px solid #e5e5e5;}
.list_f li{ float:left; width:25%; text-align:center; padding:10px 0px;}
.list_f .list_f_pic{ width:100%; overflow:hidden;}
.list_f .list_f_pic img{ width:25%; display:block; margin:0px auto;}
</style>
	<div style="height:70px;"></div>
    <div class="list_f">
    	<ul>
        	<li>
            	<a href="<?php echo siteurl(3);?>">
                    <div class="list_f_pic">
                        <img src="<?php echo SPATH;?>member/app/images_/home.png">
                    </div>
                    <p>后台首页</p>
                </a>
            </li>
            <li>
            	<a href="javascript:goo('?m=e&a=my_xiaoxi');">
                    <div class="list_f_pic">
                        <img src="<?php echo SPATH;?>member/app/images_/news.png">
                    </div>
                    <p>消息中心</p>
                </a>
            </li>
            <li>
            	<a href="javascript:goo('?m=e&a=zcmx');">
                    <div class="list_f_pic">
                        <img src="<?php echo SPATH;?>member/app/images_/cus.png">
                    </div>
                    <p>我的客户</p>
                </a>
            </li>
            <li>
            	<a href="index.php?m=member&c=index">
                    <div class="list_f_pic">
                        <img src="<?php echo SPATH;?>member/app/images_/mess.png">
                    </div>
                    <p>个人信息</p>
                </a>
            </li>
        </ul>
    </div>