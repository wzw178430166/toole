<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<?php $titlename= $_GET['title'] ? $_GET['title'] : "我的信息";?>
</head>
<style>
body { background-color: #edecec; }
.mess_box{ width:100%; overflow:hidden;}
.mess_box .mess_line{ width:100%; padding:10px 5%; background-color:#fff; margin-bottom:10px; border-bottom:1px solid #e5e5e5;}
.mess_line .title{ font-size:15px; color:#3f3f3f;}
.mess_line i{ width:10px; height:10px; background-color:#fc9700; border-radius:10px; float:left; margin:5px 5px 0px 0px;}
.mess_line p{ font-size:12px; color:#707070;}
.mess_line span{ color:#e71212; font-weight:bold;}
.mess_line u{ font-size:15px; text-decoration:none;}
.emptyBox {
	text-align: center;
    padding: 5px;
    color: #666;	
}
</style>
<body>
	<?php include template("e","header","e"); ?>
<div style="height:45px;"></div>
	<div class="mess_box">
    	<?php if($message) { ?>
    	<?php $n=1;if(is_array($message)) foreach($message AS $r) { ?>
    	<div class="mess_line">
        	<p class="title"><i></i><?php echo $r['subject'];?></p>
            <p><?php echo date('Y-m-d H:i:s',$r['message_time']);?></p>
            <p><?php echo $r['content'];?></p>
        </div>
        <?php $n++;}unset($n); ?>
        <?php } else { ?>
        <div class="emptyBox">
        	暂无消息
        </div>
        <?php } ?>
        <!--<div class="mess_line">
        	<p class="title"><i></i>通知</p>
            <p>2015-12-20</p>
            <p>亲爱的会员，2017年3月份即将结束，请还没提现的会员加紧时间咯~</p>
        </div>
        <div class="mess_line">
        	<p class="title"><i></i>交易信息</p>
            <p>2015-12-20</p>
            <p>您有一笔新的交易，获得佣金<span>50元</span>。立即查看<u>>></u></p>
        </div>
        <div class="mess_line">
        	<p class="title"><i></i>通知</p>
            <p>2015-12-20</p>
            <p>亲爱的会员，2017年2月份即将结束，请还没提现的会员加紧时间咯~</p>
        </div>-->
    </div>
    <?php include template("e","footer","e"); ?>
</body>
</html>
