<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<style>
body{background-color:#edecec}
.per_man_h{width:100%;overflow:hidden;padding:20px 0 10px 0;background-color:#3980eb;color:#fff;height:160px}
.per_man_h p{font-size:35px;text-align:center;height:30px;margin-top:16px}
.per_man_h_li u,.per_man_h u{width:100%;overflow:hidden;text-align:center;display:block;text-decoration:none;font-size:12px}
.per_man_h_ul{background:#fff;display:block;height:55px}
.per_man_h_li{float:left;width:33.3%;text-align:center;border-right:1px solid #fff;height:55px;padding-top:5px}
.per_man_h_li:last-child{border-right:none}
.per_man_h em{ font-style:normal; position:relative; padding-right:25px; height:25px; line-height:25px; margin:0 auto; width:auto;}
.per_man_h .eyes{ width:20px; height:20px; float:right; right:40%; position:absolute; right:0; top:0}
.eyes img{ width:100%;}
.per_man_adv{width:100%;background-color:#ffc;padding:5px 2%;overflow:hidden;margin-bottom:10px}
.per_man_adv img{width:15px;height:15px;margin-right:5px;float:left;display:block;margin-top:1%}
.per_man_adv p{float:left;width:90%;line-height:21px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;word-break:break-all;font-size:12px}
.per_man_more{width:100%;overflow:hidden;background-color:#fff;padding:5px 0;margin-bottom:10px}
.per_man_more li{float:left;width:25%;overflow:hidden;color:#333}
.per_man_more .per_man_more_{width:100%;overflow:hidden;padding-top:5px}
.per_man_more_ img{width:40px;height:40px;display:block;margin:0 auto}
.per_man_more_ p{text-align:center;margin-top:2px;font-size:12px}
.total_f_ .total_f_3{width:100%;overflow:hidden;background-color:#fff;padding:0 5%}
.total_f_3 .ranking{width:100%;height:40px;line-height:40px;display:block;border-bottom:1px solid #edecec;overflow:hidden;color:#9a9a9a}
.ranking .fr{color:#333}
.ranking i{padding:1px 5px;color:#fff;margin-left:5px;font-style:normal;border-radius:2px;font-size:12px}
</style>
<body>
<div class="per_man_h">
  <?php if($yestCount>0) { ?>
  <p><?php echo number_format($yestCount,2);?></p>
  <?php } else { ?>
  <p style="font-size:20px; font-weight:bold;">暂无交易</p>
  <?php } ?>
  <u style="margin-top:10px;opacity: .8;">昨天佣金额（元）</u>
  <u style="font-size:14px;margin-top:20px;">
  	<em>总金额<font id="eyes" data-eyes="<?php echo number_format($totalCount,2);?>">****</font>元
    	<i class="eyes">
    		<img src="<?php echo SPATH;?>member/app/images_/eyes_open.png" class="eyes_open" style="display:none;">
    		<img src="<?php echo SPATH;?>member/app/images_/eyes_close.png" class="eyes_close">
        </i>
    </em>
  </u>
</div>
<ul class="per_man_h_ul">
    <li class="per_man_h_li" onClick="javascript:goo('?m=e&a=my_xiaoxi');"> <u><?php echo $messCount;?></u> <u>我的消息</u> </li>
    <li class="per_man_h_li" onClick="javascript:goo('?m=e&a=zcmx');"> <u><?php echo $nodeMemeberCount;?></u> <u>我的客户</u> </li>
    <li class="per_man_h_li" onClick="javascript:goo('?m=e&a=czmx');"> <u><?php echo $orderCount;?></u> <u>分红订单数量</u> </li>
  </ul>
<div class="per_man_adv"> <img src="<?php echo SPATH;?>member/app/images_/per_man_adv.png">
  <p>公告：各位亲爱的粉丝，3月份体现须知！</p>
</div>
<div class="per_man_more">
  <ul>
    <li onClick="goo('?m=e&a=goods')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_1.png">
        <p>推广分销</p>
      </div>
    </li>
    <li onClick="goo('?m=e&a=zcmx')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_7.png">
        <p>我的客户</p>
      </div>
    </li>
    <li onClick="goo('?m=e&a=tjmd')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_6.png">
        <p>下级管理</p>
      </div>
    </li>
    <li onClick="goo('?m=e&a=czmx')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_8.png">
        <p>我的推广分红</p>
      </div>
    </li>
    <!--<li onClick="javascript:;">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_5.png" class="copy_lsrc2" data-clipboard-text="http://www.******.com/"> 
        <p><span class="copy_lsrc" data-clipboard-text="http://www.******.com/" style="cursor:pointer">分享推广</span></p>
      </div>
    </li>-->
    <!--<li onClick="goo('?m=e&a=bind_card')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_4.png">
        <p>银行卡绑定</p>
      </div>
    </li>-->
    <!--<li onClick="goo('?m=e&a=sj_count')">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_2.png">
        <p>数据统计</p>
      </div>
    </li>-->
    <!--<li onClick="javascript:;">
      <div class="per_man_more_"> <img src="<?php echo SPATH;?>member/app/images_/per_man_more_3.png">
        <p>活动推广</p>
      </div>
    </li>-->
  </ul>
</div>
<div class="total_f_">
  <div class="total_f_3"> 
  	<font class="ranking"> <span class="fl"><i style="background-color:#ff9393;">昨日</i></span> <span class="fr"><?php echo number_format($yestCount,2);?></span> </font> 
    <font class="ranking"> <span class="fl"><i style="background-color:#85b2ef;">今日</i></span> <span class="fr"><?php echo number_format($dayCount,2);?></span> </font> 
    <font class="ranking"> <span class="fl"><i style="background-color:#f0ab38;">本月</i></span> <span class="fr"><?php echo number_format($monthCount,2);?></span> </font> 
    <font class="ranking"> <span class="fl"><i style="background-color:#F05A38;">今年</i></span> <span class="fr"><?php echo number_format($yearCount,2);?></span> </font> 
    <!--<font class="ranking"> <span class="fl">2017-01-08</span> <span class="fr">12.7万元</span> </font> 
    <font class="ranking"> <span class="fl">2017-01-08</span> <span class="fr">12.7万元</span> </font> -->
  </div>
</div>
<?php include template("e","footer","e"); ?>
</body>
<script>
var clipboard = new Clipboard('.copy_lsrc');
clipboard.on('success', function(e) {
	layer.msg("复制分享链接成功~");
});
clipboard.on('error', function(e) {
	layer.msg("您的浏览器暂不支持一键复制,<br/>请手动复制.")
	console.log(e);
});
var clipboard2 = new Clipboard('.copy_lsrc2');
clipboard2.on('success', function(e) {
	layer.msg("复制分享链接成功~");
});
clipboard2.on('error', function(e) {
	layer.msg("您的浏览器暂不支持一键复制,<br/>请手动复制.")
	console.log(e);
});
</script>
<script>
$('.eyes_open').click(function(){
	$('.eyes_close').show();
	$('.eyes_open').hide();
	$('#eyes').text('****');
	});
$('.eyes_close').click(function(){
	$('.eyes_open').show();
	$('.eyes_close').hide();
	$('#eyes').text($('#eyes').attr('data-eyes'));
	});
</script>
</html>