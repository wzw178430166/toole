<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template("e","header_common","e"); ?>
<?php $titlename= $_GET['title'] ? $_GET['title'] : "我的客户";?>
</head>
<style>
body{ background-color:#edecec;}
.cue_search{ width:100%; overflow:hidden; padding:5px 0px; background-color:#fff;}
.cue_search .search_box{ width:80%; height:30px; border:1px solid #888; border-radius:5px; margin:0 auto;}
.search_box .search_boxl{ width:10%; margin-right:1%}
.search_boxl img{ width:30px; height:30px;}
.search_box .search_boxr{ width:89%;}
.search_boxr .nobd{ width:99%; height:28px; line-height:30px; padding:0;}

.cus_box { width:100%; overflow:hidden;}
.cus_box .cus_boxh{ width:100%; overflow:hidden; background-color:#fff; margin-bottom:10px;}
.cus_boxh li{ float:left; width:33.33%; height:40px; line-height:40px; text-align:center;}
.cus_boxh span{ font-size:12px; margin-left:2px;}
.cus_boxh .cur{ border-bottom:2px solid #1e90ff;}
/**/ 
.cus_box .cus_boxf{ width:100%; overflow:hidden;}
.cus_boxf li{ width:100%; overflow:hidden; background-color:#fff; margin-bottom:3px; padding:10px 0px;}
.cus_boxf .cus_boxf_{ width:90%; overflow:hidden; margin:0 auto;}
.cus_boxf_ .cus_boxf_1{ width:100%; overflow:hidden;}
.cus_boxf_1 p{ float:left; margin-right:10px; font-weight:bold;}
.cus_boxf_1 i{ float:left; margin-right:10px; font-style:normal; padding:1px 3px; border-radius:5px; color:#fff;}
.cus_boxf_ u{ font-size:12px; color:#ed2626; text-decoration:none;}
.cus_boxf_ .record{ width:100%; overflow:hidden; display:block; color:#888; font-size:12px;}
/**/
.header{ background-color:#929190;}
</style>
<body>
	<?php include template("e","header","e"); ?>
    <div style="height:45px;"></div>
	<div class="cue_search">
    	<div class="search_box">
        	<div class="search_boxl fl">
            	<img src="<?php echo SPATH;?>member/app/images_/search_box.png">
            </div>
            <div class="search_boxr fl">
            	<form action="" onSubmit="return sendSearch()">
            	<input type="search" id="sk" placeholder="请输入需要搜索的客户信息" class="nobd">
                </form>
            </div>
        </div>
    </div>
	<div class="cus_box">
    	<div class="cus_boxh">
        	<ul id="search_item">
            	<li class="cur" data-key="default" data-val="1">综合排序<span>↑↓</span></li>
                <li data-key="rd" data-val="1">注册时间<span>↑↓</span></li>
                <li data-key="dl" data-val="1">成交量<span>↑↓</span></li>
                <!--<li>已标记</li>-->
            </ul>
        </div>
        <div class="cus_boxf">
        	<ul id="list_b">
            	<template id="list_b_con">
               	<li>
                	<div class="cus_boxf_" onClick="/*goo('?m=e&a=kehu_xx')*/">
                    	<div class="cus_boxf_1">
                        	<p><$username$></p>
                        	<!--<i style="background-color:#3980eb">成交用户</i>
                        	<i style="background-color:#f29d23;">已标记</i>-->
                        </div>
                        <!--<u>总成交额：¥5000.00元</u>-->
                        <font class="record">
                        	<span class="fl">注册时间：<$regdate$></span>
                            <!--<span class="fr">取消标记</span>-->
                        </font>
                    </div>
                </li>
                </template>
              
            </ul>
        </div>
    </div>
	<?php include template("e","footer","e"); ?>
<div id="template_">
	<template id="list_b_con">
    <li>
        <div class="cus_boxf_" onClick="/*goo('?m=e&a=kehu_xx')*/">
            <div class="cus_boxf_1">
                <p><$username$></p>
            </div>
            <font class="record">
                <span class="fl">注册时间：<$regdate$></span>
            </font>
        </div>
    </li>
    </template>
</div>    
</body>
</html>
<script>
var page = 1;
var url = window.location.href;
$(function (){
	get_data();//get info
	var searchItem = $('#search_item li');
	searchItem.each(function(i) {
        $(searchItem[i]).click(function(){
			var dataKey = $(this).attr('data-key');
			var dataVal = $(this).attr('data-val');
			$(searchItem).removeClass('cur');
			$(this).addClass('cur');
			listorder(dataKey,dataVal);
			history.pushState({}, "页面标题", url);
			dataVal = dataVal==1?2:1;
			$(this).attr('data-val',dataVal);
			get_data();
			//getData();
		});
    });
});
function listorder(orderItemKey,orderItemVal){
	var reg=new RegExp("(^|&|/?)rd=[0-9]*");
	if (url.match(reg)) {
		//console.log(url.match(reg));
		url = url.replace(reg,'');
	}
	var reg=new RegExp("(^|&|/?)dl=[0-9]*");
	if (url.match(reg)) {
		url = url.replace(reg,'');
	}
	var reg=new RegExp("(^|&|/?)k=[0-9]*");
	if (orderItemKey == 'default' && url.match(reg)) {
		url = url.replace(reg,'');
	}
	if (orderItemKey != 'default') {
		url += '&'+orderItemKey+'='+orderItemVal;
	}	
}
function sendSearch(){
	var sk = $('#sk').val();
	if (sk == '') {
		layer.msg('请输入客户信息!');
		return false;
	}
	url += '&k='+sk;
	history.pushState({}, "页面标题", url);
	get_data();
	return false;
}

function get_data(){
	var url="index.php?m=e&a=get_data&ajax=1&action=zcmx";
	var param = 'page='+page;
	if (getUrlParam('rd')) {param += '&rd='+getUrlParam('rd');}
	if (getUrlParam('dl')) {param += '&dl='+getUrlParam('dl');}
	if (getUrlParam('k')) {param += '&k='+encodeURI(getUrlParam('k'));}
	$.ajax({
		'url':url,
		'data': param,
		'success':function(data){
			data = JSON.parse(data);
			var t = $('#list_b_con').html();
			t = mytemplate_list(t,data.data);
			$('#list_b').empty();
			$('#list_b').append($('#template_').html());
			$('#list_b').append(t);
		}
	});
}
</script>