<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('e',"header"); ?>
<!--新添加css-->
<link type="text/css" href="<?php echo SPATH;?>diy/css/fh2.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo SPATH;?>diy/css/178.css" rel="stylesheet"/>
<link type="text/css" href="<?php echo SPATH;?>diy/css/fh_JianXi.css" rel="stylesheet"/>
<script src="/statics/js/jquery-1.8.3.min.js"></script>
<script src="/statics/js/layer/1.9.3/layer.js"></script>
<script src="/statics/html2canvas/dist/html2canvas.min.js"></script>
<script src="/statics/js/clipboard.min.js"></script>
<script src="/statics/js/jquery.qrcode.min.js"></script>
<style>
.hide{display:none}
.DynarchCalendar-titleCont{left:75px}
.settlement-info { margin-bottom: 5px; background-color:#fff; text-align:center; border:1px solid #e8e8e8;}
.settlement-info table{width:100%}
.settlement-info td{ width:25%; text-align:center; padding:25px 0px; border-right:1px solid #e8e8e8;}
.settlement-info td:last-child{ border-right:none;}
.settlement-info dd{ margin-top:5px;}
.settlement-info .income-wrap .money-integer{font-size:24px;font-weight:700; color:#53586b;}
.settlement-info .income-wrap .money-decimal{font-size:18px;font-weight:700}
.table-title-extra{margin-bottom:24px}
.table-title li{float:left;margin-right:30px;position:relative}
.table-title-extra li.selected{margin-top:0}
.table-title h2{margin:0}
.table-title-extra li.selected h2 a,.table-title-extra li.selected h2 span{color:#333;font-size:24px}
.table-container .toolbar{padding:8px 10px;background-color:#ebebeb}
.dropdown{position:relative;-webkit-border-radius:2px;-moz-border-radius:2px;border-radius:2px;border:1px solid #ddd;border-bottom:1px solid #bbb;height:23px;line-height:23px;-webkit-text-size-adjust:none;display:inline-block}
.dropdown{vertical-align:middle;outline:0}
.dropdown .dropdown-hd{color:#333;padding-right:10px;padding-left:10px;display:block;background-color:#f4f4f4;background-image:-moz-linear-gradient(top,#f8f8f8,#eee);background-image:-ms-linear-gradient(top,#f8f8f8,#eee);background-image:-webkit-gradient(linear,0 0,0 100%,from(#f8f8f8),to(#eee));background-image:-webkit-linear-gradient(top,#f8f8f8,#eee);background-image:-o-linear-gradient(top,#f8f8f8,#eee);background-image:linear-gradient(top,#f8f8f8,#eee);background-repeat:repeat-x;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#f8f8f8', endColorstr='#eeeeee', GradientType=0);cursor:default;zoom:1}
.dropdown .dropdown-hd{height:23px;padding-right:22px;overflow:hidden}
.dropdown .icon-arrow-down{font-size:8px;position:absolute;right:8px;top:8px;height:8px;line-height:8px;color:#999}
.dropdown .dropdown-list{display:none;top:24px;left:-1px;position:absolute;border:1px solid #ddd;background:#fff;z-index:999999;list-style-type:none;margin:0;padding:0;-webkit-border-radius:2px 2px 2px 2px;-moz-border-radius:2px 2px 2px 2px;border-radius:2px 2px 2px 2px;-webkit-box-shadow:0 3px 5px rgba(0,0,0,.1);-moz-box-shadow:0 3px 5px rgba(0,0,0,.1);box-shadow:0 3px 5px rgba(0,0,0,.1);overflow:auto}
.dropdown .dropdown-list .dropdown-item{height:25px;overflow:hidden;line-height:25px;text-indent:8px;color:#333;position:relative;padding-right:20px;cursor:default;-moz-user-select:none;-webkit-user-select:none}
.dropdown .dropdown-list .dropdown-item span{height:25px;line-height:25px;overflow:hidden;display:block}
.dropdown .dropdown-list .dropdown-item .icon-ok{font-size:9px;position:absolute;right:6px;top:6px;line-height:12px;visibility:hidden;color:#999;clear:both}
.dropdown .dropdown-list .dropdown-itemselected .icon-ok{visibility:visible}
.iconfont{speak:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
.iconfont{font-family:uxiconfont;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
.table th{background-color:#ebebeb;font-weight:400;padding:7px 5px 6px;color:#999;border-bottom:1px solid #e1e1e1;width:80px;height:16px;float:inherit}
.table .no-data th{color:#ccc}
.table td.left,.table th.left{text-align:left}
.table-container .table th:first-child{padding-left:10px;width:405px}
table{border-collapse:collapse;border-spacing:0}
.table{width:100%;table-layout:auto}
.table{table-layout:fixed;word-wrap:break-word}
.table tbody tr.none_ td{height:175px;font-size:14px;text-align:center;color:#666;background:0}
</style>
<div class="h_con"> <?php include template('e',"lefter"); ?>
  <div class="h_r"> <?php include template("tag","tag_gamelist"); ?>
    <div style="width:100%; overflow:hidden; margin-top:10px;">
      <div id="brix_22889">
        <vframe id="J_vf_os" mx-view="app/views/myunion/overview_settlement">
          <div class="settlement-info" id="brix_23087">
            <table>
              <tbody>
                <tr>
                  <td valign="top"><dl class="income-wrap">
                      <dt>昨日预估收入（元）<!--<span class="iconfont help" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tl','bl']},mouseDelay:0.2,width:300,content:'昨天确认收货的预估收入数据。该收入仅为阿里妈妈过滤前的预估数据展示，非为您的实际收入金额，最终结算金额以月结后您账户内实际收到的金额为准。'}" id="brix_brick_23088" bx-behavior="true">Ũ</span>--></dt>
                      <dd>
                        <span class="money-integer"><?php echo number_format($yestCount,2);?></span>
                        <!--<span class="money-decimal">00</span>
                        <span class="fs12">元</span>-->
                      </dd>
                    </dl></td>
                  <td valign="top"><dl class="income-wrap">
                      <dt>今日预估收入（元）<!--<span class="iconfont help" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,width:300,content:'指上一个自然月的预估收入数据。该收入仅为阿里妈妈过滤前的预估数据展示，非为您的实际收入金额，最终结算金额以月结后您账户内实际收到的金额为准。'}" id="brix_brick_23090" bx-behavior="true">Ũ</span>--></dt>
                      <dd>
                        <span class="money-integer"><?php echo number_format($dayCount,2);?></span>
                        <!--<span class="money-decimal">00</span>
                        <span class="fs12">元</span>-->
                      </dd>
                    </dl></td>
                  <td valign="top"><dl class="income-wrap">
                      <dt>本月预估收入（元）<!--<span class="iconfont help" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tl','bl']},mouseDelay:0.2,width:300,content:'一个自然月内，就是当月1号到昨天为止（不包含今日收入）的已经确认收货的预估收入数据。该收入仅为阿里妈妈过滤前的预估数据展示，非为您的实际收入金额，最终结算金额以月结后您账户内实际收到的金额为准。'}" id="brix_brick_23089" bx-behavior="true">Ũ</span>--></dt>
                      <dd>
                        <span class="money-integer"><?php echo number_format($monthCount,2);?></span>
                        <!--<span class="money-decimal">00</span>
                        <span class="fs12">元</span>-->
                      </dd>
                    </dl></td>
                  <td valign="top"><dl class="income-wrap">
                      <dt>今年预估收入（元）<!--<span class="iconfont help" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,width:300,content:'指上一个自然月的预估收入数据。该收入仅为阿里妈妈过滤前的预估数据展示，非为您的实际收入金额，最终结算金额以月结后您账户内实际收到的金额为准。'}" id="brix_brick_23090" bx-behavior="true">Ũ</span>--></dt>
                      <dd>
                        <span class="money-integer"><?php echo number_format($yearCount,2);?></span>
                        <!--<span class="money-decimal">00</span>
                        <span class="fs12">元</span>-->
                      </dd>
                    </dl></td>
                  
                </tr>
              </tbody>
            </table>
          </div>
        </vframe>
        <vframe id="J_vf_ol" mx-view="app/views/myunion/overview_list">
          <div class="table-container" id="brix_23416">
            <!--<ul class="table-title table-title-extra clearfix">
              <li class="selected">
                <h2>
                  <span>账户近期概况</span>
                </h2>
              </li>
            </ul>-->
            <div class="toolbar clearfix">
            	<p style="float:left; font-size:24px; color:#333; margin-right:35px;">账户近期概况</p>
              <div bx-name="dropdown" style="width:110px;" class="dropdown" id="J_datatype" hidefocus="true" bx-behavior="true" tabindex="0">
                <span class="dropdown-hd">
                <span class="dropdown-text" value="0">昨日</span>
                <!--<i class="iconfont icon-arrow-down">ƕ</i>-->
                </span>
                <ul class="dropdown-list" style="display: none;">
                  <li class="dropdown-item"><span value="0">昨日</span><i class="iconfont icon-ok">~</i></li>
                  <li class="dropdown-item"><span value="3">本周</span><i class="iconfont icon-ok">~</i></li>
                  <li class="dropdown-item"><span value="4">上周</span><i class="iconfont icon-ok">~</i></li>
                  <li class="dropdown-item"><span value="1">本月</span><i class="iconfont icon-ok">~</i></li>
                  <li class="dropdown-item"><span value="2">上月</span><i class="iconfont icon-ok">~</i></li>
                </ul>
              </div>
            </div>
            <table class="table" bx-name="tables" bx-tmpl="list" bx-datakey="list" id="brix_brick_23417" bx-behavior="true">
              <thead>
                <tr class="no-data">
                  <th class="left">产品名称</th>
                  <th class="left" width="100"> 点击数 <!--<i class="iconfont cursor-pointer fontsize-13 ml2" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,width:300,content:'您选择时间段内的点击数，包含到达商品、店铺页面的点击数等。'}" id="brix_brick_23418" bx-behavior="true">Ũ</i>-->
                  </th>
                  <th class="left" width="120"> 付款笔数 <!--<i class="iconfont cursor-pointer fontsize-13 ml2" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,content:'由推广带来的您选择时间段内的付款订单笔数。'}" id="brix_brick_23419" bx-behavior="true">Ũ</i>-->
                  </th>
                  <th class="left" width="120"> 效果预估<!-- <i class="iconfont cursor-pointer fontsize-13 ml2" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,width:300,content:'由推广带来的您选择时间段内付款产生的效果预估数据，非最终实际收入，其作用是便于您了解效果发展的趋势，由于是估算数据，与实际的结算时间有一段差异，是阿里妈妈过滤前的数据，最终收入金额以月结后您账户内实际收到的为准。'}" id="brix_brick_23420" bx-behavior="true">Ũ</i>-->
                  </th>
                  <th class="left" width="100"> 预估收入 <!--<i class="iconfont cursor-pointer fontsize-13 ml2" bx-name="tooltip" bx-config="{closable:false,align:{node:false,points:['tr','br']},mouseDelay:0.2,width:300,content:'此数据是以您选择时间段内所有买家确认收货的订单计算出的预估收入，非最终实际收入，由于是估算数据，是阿里妈妈过滤前的数据， 最终收入金额以月结后您账户内实际收到的为准。'}" id="brix_brick_23421" bx-behavior="true">Ũ</i>-->
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr class="none_ hover">
                  <td colspan="5">暂无数据</td>
                </tr>
              </tbody>
            </table>
          </div>
        </vframe>
        <div class="h_r">
    <?php include template("tag","tag_gamelist"); ?>
    <div style="padding-left:0px; margin:0px; width:780px" class="fh_right">
      <div id="Tab0_Content19">
        <div class="TabContent_top">
          <div class="jiantou jiantou5">
          </div>
        </div>
        <div class="TabContent_body smzt">
          <!--<div class="yqzq">
            <h2 class="smzt_h2 yxwz_h2"><?php echo $catname;?></h2>
            <p class="xq"> <?php include template("tag","tag_zaixian"); ?> </p>
          </div>-->
          <!--<div class="tishi">
            <div class="tishi_top">
            </div>
            <div class="tishi_body lineh">
              <p class="p1_ezio"> <?php echo $description;?> </p>
            </div>
            <div class="tishi_bottom">
            </div>
          </div>-->
          <div class="zqgj">
            <div class="zqgj_title">
              <h2 class="zqgj_h2">商品列表</h2>
              <a style="float:right; color:#d10506;" href="/index.php?m=e&a=goods">点击浏览更多商品>></a>
            </div>

            <div class="zqgj_body2 sm_list">
              <ul>
                
                <!--<li>总人数：<strong class="red hide"><?php echo $n_recharge;?> 人</strong></li>
               
                <li>总分红金额：<strong class="red hide">
                  <?php echo number_format($dividends,2);?>
                  元</strong></li>-->
              </ul>
            </div>
            <div class="zqgj_body3">
              <table cellspacing="0" cellpadding="0" border="0" width="100%" class="fh_tc_table">
                <thead>
                  <tr class="dn_tr">
                    <!--<td width="20%">分红期数</td>
                    <td width="15%">推广用户数量</td>
                    <td width="15%">有消费总人数</td>
                    <td width="15%">消费总金额</td>
                    <td width="15%">本期分红金额</td>
                    <td width="15%">状态</td>-->
                    <td width="15%">商品主图</td>
                    <td width="25%">商品名称</td>
                    <td width="8%">分销价格</td>
                    <!--<td width="8%">代理价格</td>-->
                    <td width="8%">分成</td>
                    <!--<td width="15%">库存</td>-->
                    <td width="15%">更新时间</td>
                    <td width="15%">分享</td>
                  </tr>
                </thead>
                <tbody>
 
                <?php $n=1;if(is_array($datalist)) foreach($datalist AS $r) { ?>
                <?php
                	$r['turl'].= '&i='.$this->_uid;
                	if($r['fencheng']<=0){
                		$r['fencheng'] = '15%';
                	}else{
                		$r['fencheng'] = ($r['fencheng']).'%';
                	}
                ?>
                <tr>
					<td><a class="lsrc_<?php echo $r['id'];?>" href="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" target="_blank"><img style="max-width:50%" src="<?php echo $r['thumb'];?>" class="c_thumb"/></a><div style="display:none;position: absolute;margin-left: 10%;box-shadow: 3px 2px 3px 2px #CCC;" class="dd_thumb"><img src="<?php echo $r['thumb'];?>"/></div></td>
                  <td><?php echo $r['title'];?></td>
                  <td><?php echo $r['jiage'];?></td>
                  <!--<td><?php if(floatval($r['retail_price'])) { ?><?php echo $r['retail_price'];?><?php } ?></td>-->
                  <td><?php echo $r['fencheng'];?></td>
                  <!--<td><?php echo $r['kc'];?></td>-->
                  <td><?php echo date("Y-m-d H:i:s",$r['updatetime']);?></td>
                <td>
                <div class="qrcode_wrapper">
				  <img src="/statics/images/qrcode_26.png" alt="二维码" class="xiao_er" data-id="<?php echo $r['id'];?>"/>
				  <div class="qrcodes_<?php echo $r['id'];?>" id="qrcodes_<?php echo $r['id'];?>" style="display: none;width: 187px;height: 156px;position: absolute;margin-left: -8.5%; padding:20px 10px 0px 0px; border-radius:5px; background-image: url(/statics/images/erweima_bg.png); margin-top:-5.3%;"></div>
				</div>
				<div>
             		<a href="javascript:dow_er(<?php echo $r['id'];?>);">下载</a>
              		<span class="copy_lsrc" data-clipboard-text="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" style="cursor:pointer" onClick="fuzhi(this)">复制链接</span>
					<div style="display:none;position:absolute;border: 1px solid #CCC;width: 300px;height: 55px;background: #FFF;line-height: 55px;right:13%;z-index:3" id="fuzhi" class="fuzhi"><div style="text-align:center;">链接地址 : <input type="text" value="http://www.barbar8.com/index.php?m=wb_shop&a=show&id=<?php echo $r['id'];?>&i=<?=$this->_uid?>" style="width:123px;"/><input type="button" value="点击复制" onClick="fuzhi_(this)" style="align:center;margin-top:6px"/></div></div>
                </div>
                </td>
                  <!--<td> <?php if($r[title]) { ?><?php echo $r['title'];?>
                    <?php } else { ?><?php echo date("Y年m月",$r[time]);?>
                    <?php } ?> </td>
                  <td><?php echo $r['n_expand'];?></td>
                  <td><?php echo $r['n_recharge'];?></td>
                  <td><?php echo $r['recharge'];?></td>
                  <td><?php echo $r['dividends'];?></td>
                  <td> <?php if($r['status']==0) { ?>
                    <a href="" >点击兑现</a>
                    <?php } else { ?>
                    已兑现
                    <?php } ?> </td>-->
                </tr>
                <?php $n++;}unset($n); ?>
              </table>
              <div style="clear: both"></div>
              <div class="cell_page">
              <?php echo $pages;?>
              </div>
            </div>
          </div>
        </div>
        <div class="TabContent_bottom">
        </div>
      </div>
    </div>
  </div>
      </div>
    </div>
    
    <!--<div class="km_content_step">
      <ul class="km_step">
        <li class="">
          <a class="white" href="#"> 复制推广链接，<br>
          发送给好友</a>
        </li>
        <li class="">
          <a class="hese" href="#"> 好友通过链接<br>
          注册通行证</a>
        </li>
        <li>
          <a class="green01"  href="#"> 好友游戏消费<br>
          你来收提成！</a>
        </li>
      </ul>
    </div>-->
    <!--<div class="cl">
    </div>-->
    <!--<div class="">
      <div class="nTab1">
        <div class="TabTitle1">
          <p><strong style="float:left; margin:10px 0 0 10px;">最新播报</strong></p>
          <p>
            <a target="_blank" href="/index.php?m=content&c=index&a=lists&catid=31">更多&gt;&gt;</a>
          </p>
        </div>
        <div class="TabContent1">
          <div id="myTab0_Content0">
            <div class="new_body">
              <ul>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fd4592c94aa70d7201e7ed19e4ffd6e9&action=lists&catid=31&order=id+DESC&num=8\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'31','order'=>'id DESC','num'=>'8','limit'=>'8',));}?>
                <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <li>
                  <a target="_blank" href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>">
                  <span style="float:left"><?php echo $r['title'];?> </span><span style=" float:right"><?php echo date('[m/d]',$r[inputtime]);?></span></a>
                  <div class="cl">
                  </div>
                </li>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
              </ul>
            </div>
          </div>
        </div>
        <div class="cl">
        </div>
      </div>
      
       <div class="nTab2">
        <div class="TabTitle2">
          <p><strong style="float:left; margin:10px 0 0 10px;">最新商品</strong></p>
          <p>
          </p>
        </div>
        <div class="TabContent2">
          <div id="myTab0_Content0">
            <div class="new_body212">
              <table width="270" border="0" cellspacing="0" cellpadding="0" class="tmt">
                <tr style=" background:#EEE;">
                  <td width="155px">商品名称</td>
                  <td>产地</td>
                  <td width="50px">快捷操作</td>
                </tr>
                <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=450b82b2582341b2afd0996b3f8c2d4a&action=lists&catid=1&order=id+DESC&num=7\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'1','order'=>'id DESC','num'=>'7','limit'=>'7',));}?>
                <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
                <tr>
                  <td><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['title'];?></a></td>
                  <td><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['area'];?></a></td>
                  <td><a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>" target="_blank" style="color:#FF0000;">进入</a></td>
                </tr>
                <?php $n++;}unset($n); ?>
                <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
              </table>
            </div>
          </div>
        </div>
        <div class="cl">
        </div>
      </div>
      <div class="cl">
      </div>
    </div>-->
    <div style="width:780px; height:60px;">
      <script language="javascript" src="<?php echo APP_PATH;?>caches/poster_js/16.js"></script>
    </div>
  </div>
  <div class="cl">
  </div>
</div>
<div id="ggg" style="width:128px;"></div>
<script>
$(".c_thumb").hover(function(){
	var dataIndex = $(this).attr('data-index');
	$(".dd_thumb").css("display","none");
	$(this).parent().next().css("display","block");
},function(){
	var dataIndex = $(this).attr('data-index');
	$(".dd_thumb").css("display","none");
});
$(".xiao_er").hover(function(){
	var dataIndex = $(this).attr('data-id');
	var lsrc = $(".lsrc_"+dataIndex).attr("href");
	$(".qrcodes_"+dataIndex).html("");
	jQuery('#qrcodes_'+dataIndex).qrcode({width: 128,height: 128,correctLevel: 0,text: lsrc});
	$(".qrcodes_"+dataIndex).css("display","block");
},function(){
	$(".qrcodes_"+dataIndex).html("");
	var dataIndex = $(this).attr('data-id');
	$(".qrcodes_"+dataIndex).css("display","none");
});
var clipboard = new Clipboard('.copy_lsrc');
clipboard.on('success', function(e) {
	//layer.msg("复制分享链接成功~");
});
clipboard.on('error', function(e) {
	$(".fuzhi").css("display","none");
	$("#fuzhi").css("display","block");
	layer.msg("您的浏览器暂不支持一键复制,<br/>请手动复制.")
	console.log(e);
});
function fuzhi_(obj){
	layer.msg("复制分享链接完成~<br/>Mac的用户需要手动复制");
	$(".fuzhi").css("display","none");
	$("#zhezhao").css("display","none")
}
function fuzhi(obj){
	$(".fuzhi").css("display","none");
	$("#zhezhao").css("display","none")
	$(obj).next().css("display","block");
	$("#zhezhao").css("display","block")
}
function gb_zhe(){
	$("#zhezhao").css("display","none");
	$(".fuzhi").css("display","none");
}
function dow_er(id){
	var lsrc = $(".lsrc_"+id).attr("href");
	$("#ggg").html("");
	jQuery('#ggg').qrcode({width: 128,height: 128,correctLevel: 0,text: lsrc});
	html2canvas($("#ggg"), {
		onrendered: function (canvas) {
			var url = canvas.toDataURL();
			var triggerDownload = $("<a>").attr("href", url).attr("download", "分享二维码.png").appendTo("body");
			triggerDownload[0].click();
			triggerDownload.remove();
		}
	});
	$("#ggg").html("");
}
</script>
<?php include template('e',"footer"); ?>
</body></html>