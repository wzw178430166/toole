<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
$appid = 'wx05e2f54cc35aa253';
$appSecret = 'f6d153eda4756590b38ffa1db8d4b01f';
$title = $pinfo['title'];
$description = $pinfo['description'];
$thumb = $pinfo['thumb'];
$link = $pinfo['link'];

$is_weixin = 1;
if(is_weixin() && $is_weixin && $appid){
	$is_weixin = 1;
    pc_base::load_app_func('global','weixin');
            
    $timestamp = time().''; 
    $wxnonceStr = 'barbar8api'; 
    $jsapi_ticket = wx_get_jsapi_ticket($appid,$appSecret,$name);
    $url = get_url();
    $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s",
      $jsapi_ticket, $wxnonceStr, $timestamp,$url);
    $wxSha1 = sha1($wxOri);	
}
?>
<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>

<?php if($pinfo['isnoshare']==',1,') { ?>
<script>
function onBridgeReady(){
 WeixinJSBridge.call('hideOptionMenu');
}

if (typeof WeixinJSBridge == "undefined"){
    if( document.addEventListener ){
        document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
    }else if (document.attachEvent){
        document.attachEvent('WeixinJSBridgeReady', onBridgeReady); 
        document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
    }
}else{
    onBridgeReady();
}
</script>
<?php } ?>


<script>
var lat,lng;
var isweixin_api = '<?php echo $is_weixin;?>'; 
isweixin_api = Number(isweixin_api);
var callback_=function(){};

var share_title = "'"+'<?php echo $title;?>'+"'";
var share_description = '<?php echo $description;?>';
var share_link = '<?php echo $link;?>';
var share_thumb = '<?php echo $thumb;?>';

// 微信配置 
wx.config({
  debug: false, 
  appId: "<?php echo $appid;?>", 
  timestamp: '<?php echo $timestamp;?>', 
  nonceStr: '<?php echo $wxnonceStr;?>', 
  signature: '<?php echo $wxSha1;?>',
  jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline','onMenuShareQQ']
});

	function wx_read(){
		wx.onMenuShareAppMessage({
			title: share_title, // 分享标题
			desc: share_description, // 分享描述
			link: share_link,//window.location.href, // 分享链接
			imgUrl: share_thumb, // 分享图标
			success: function () {
				showform();
			},
		});
		wx.onMenuShareTimeline({
			title: share_title, // 分享标题
			link: share_link,//window.location.href, // 分享链接
			imgUrl: share_thumb, // 分享图标
			success: function () {
				showform();
			},
		});
		wx.onMenuShareQQ({
			title: share_title, // 分享标题
			desc: share_description, // 分享描述
			link: share_link,//window.location.href, // 分享链接
			imgUrl: share_thumb, // 分享图标
			success: function () {
			   showform();
			},
		});
	}

wx.ready(function(){
	isweixin_api = isweixin_api>0? 1 : 0;
	wx_read();
	
});
  
wx.error(function(res){
	isweixin_api = -1;
	console.log(res.errMsg);
	//alert(res.errMsg); 
  // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。

});

</script>
