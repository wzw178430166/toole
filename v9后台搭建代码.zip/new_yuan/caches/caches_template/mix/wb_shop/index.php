<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common'); ?>
<link rel="stylesheet" type="text/css" href="statics/ku/css/index.css">
<script src="<?php echo SPATH;?>js/slip.js" type="text/javascript"></script>
<style>
#lunbo_ul li { float:left;}
#lunbo_ul li img { width:100%;}
</style>
<body>
<!---header_start--->
<?php include template('wb_shop','header'); ?>
<!---header_end--->
<div class="banner">
	<div class="banner_box">
        <ul id="lunbo_ul">
            <?php $adv=show_ad2(1,28,1,1)?>
            <?php $n=1;if(is_array($adv)) foreach($adv AS $r) { ?>
            <li><a href="<?php if($r['1']['linkurl']) { ?><?php echo $r['1']['linkurl'];?><?php } else { ?>javascript:;<?php } ?>"><img src="<?php echo $r['1']['imageurl'];?>" /></a></li>
            <?php $n++;}unset($n); ?>
        </ul>
    </div>
    <div class="banner_min">
    	<div class="banner_min_box">
        	<div class="banner_min_boxl fl">
            	<?php include template('wb_shop','menu_category'); ?>
            </div>
            <div class="banner_min_boxr fr">
            	<div class="banner_wel">
                	<div class="banner_wel_l fl">
                    	<img src="<?php echo SPATH;?>ku/images/login_man.png" class="login_man">
                        <img src="<?php echo SPATH;?>ku/images/gdfg.jpg" class="login_man_" style="display:none;">
                    </div>
                    <div class="banner_wel_r fl">
                    	<?php
                        	$h = date('G',time());
                        	if ($h<11) {
                            	$greet = '上午';
                            }elseif($h<13){
                            	$greet = '中午';
                            }elseif($h<17){
                            	$greet = '下午好';
                            }else{
                            	$greet = '晚上好';
                            }
                        ?>
                    	<p>HI,<?php echo $greet;?>好！</p>
                        <p>欢迎来到海外巴巴</p>
                    </div>
                </div>
                <div class="banner_login">
                	<?php if(param::get_cookie('_username')) { ?>
                    <a href="index.php?m=member&c=index" style="width:100%;"><img src="<?php echo SPATH;?>ku/images/banner_register.png">会员中心</a>
                    <?php } else { ?>
                	<a href="index.php?m=member&c=index&a=register"><img src="<?php echo SPATH;?>ku/images/banner_register.png">立即注册</a>
                    <a href="index.php?m=member&c=index&a=login"><img src="<?php echo SPATH;?>ku/images/banner_login.png">登录</a>
                    <?php } ?>
                </div>
                <div class="banner_exa">
                	<ul>
                    	<li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box1.png">
                                <p>资源多多</p>
                            </div>
                        </li>
                        <li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box2.png">
                                <p>源头价格</p>
                            </div>
                        </li>
                        <li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box3.png">
                                <p>轻松分销</p>
                            </div>
                        </li>
                        <li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box4.png">
                                <p>诚实保障</p>
                            </div>
                        </li>
                        <li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box5.png">
                                <p>商家认证</p>
                            </div>
                        </li>
                        <li>
                        	<div class="banner_exa_box">
                            	<img src="<?php echo SPATH;?>ku/images/banner_exa_box6.png">
                                <p>交易安全</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="banner_mess">
                	<div class="banner_messt">
                    	<ul>
                        	<li class="active">头条</li>
                            <li>公告</li>
                        </ul>
                    </div>
                    <div class="banner_messb">
                    	<ul>
                        	<li><a href="javascript:;"><span>[曝光]</span>小米小米小米小米小米小米小米小米小米小米小米小米</a></li>
                            <li><a href="javascript:;"><span>[曝光]</span>小米小米小米小米小米小米</a></li>
                            <li><a href="javascript:;"><span>[曝光]</span>小米小米小米小米小米小米</a></li>
                        </ul>
                    </div>
                    <div class="banner_messb" style="display:none;">
                    	<ul>
                        	<li><a href="javascript:;"><span>[曝光]</span>11111小米小米小米小米小米小米小米小米小米</a></li>
                            <li><a href="javascript:;"><span>[曝光]</span>小米小米小米小米小米小米</a></li>
                            <li><a href="javascript:;"><span>[曝光]</span>小米小米小米小米小米小米</a></li>
                        </ul>
                    </div>
                </div>
                <div class="banner_hot">
                	<p>今日爆款</p>
                    <ul>
                    	<li><a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/banner_hot.png"></a></li>
                        <li><a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/banner_hot.png"></a></li>
                        <li><a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/banner_hot.png"></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="body_box">
	<div class="body_min">
    	<div class="body_dis">
        	<font class="title"><img src="<?php echo SPATH;?>ku/images/body_dis.png" class="title_pic">限时折扣<span class="dis">每天限时抢购，折扣低价让利</span></font>
            <div class="body_dis_box">
            	<div class="body_dis_box_t">
                	<ul>
                    	<li class="active">倒计时<em></em></li>
                        <li>下期预告<em></em></li>
                    </ul>
                </div>
                <div class="body_dis_box_b">
                	<div class="body_dis_box_b1">
                    	<ul>
                        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=cb424d5acfd755f12e75226e6574561c&action=lists&catid=%24catid&num=3&order=inputtime+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'order'=>'inputtime DESC','num'=>'3','limit'=>'3',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                            <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                        	<li>
                            	<div class="body_dis_box_b1_">
                                	<div class="body_dis_box_b1_tr">限时抢购</div>
                                    <p class="body_dis_box_b1_pro">
                                    	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                        <!--<img src="<?php echo SPATH;?>ku/images/flag.png">--><?php echo $r['title'];?>
                                        </a>
                                    </p>
                                    <div class="body_dis_box_b1_m">
                                        <div class="body_dis_box_b1_l fl">
                                            <div class="body_dis_box_b1_state">
                                                <u>利润率：20.5%</u>
                                                <u>近30天热销：30件</u>
                                            </div>
                                            <del>市场价：<?php echo number_format($r['yuanjiage'],2);?>元</del>
                                            <p class="body_dis_box_b1_pri">¥<span class="pri"><?php echo number_format($r['retail_price'],2);?></span></p>
                                            <a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>" class="body_dis_box_b1_link">立即去抢购</a>
                                        </div>
                                   	<img class="body_dis_box_b1_r lazy fr" data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif">
                                    </div>
                                </div>
                            </li>
                            <?php $n++;}unset($n); ?>
                            
                        </ul>
                    </div>
                </div>
                <div class="body_dis_box_b" style="display:none;">
                	<div class="body_dis_box_b1">
                    	<ul>
                        	<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                        	<li>
                            	<div class="body_dis_box_b1_">
                                	<div class="body_dis_box_b1_tr">限时抢购</div>
                                    <p class="body_dis_box_b1_pro">
                                    	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                        <!--<img src="<?php echo SPATH;?>ku/images/flag.png">--><?php echo $r['title'];?>
                                        </a>
                                    </p>
                                    <div class="body_dis_box_b1_m">
                                        <div class="body_dis_box_b1_l fl">
                                            <div class="body_dis_box_b1_state">
                                                <u>利润率：20.5%</u>
                                                <u>近30天热销：30件</u>
                                            </div>
                                            <del>市场价：<?php echo number_format($r['yuanjiage'],2);?>元</del>
                                            <p class="body_dis_box_b1_pri">¥<span class="pri"><?php echo number_format($r['retail_price'],2);?></span></p>
                                            <a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>" class="body_dis_box_b1_link">立即去抢购</a>
                                        </div>
                                   	<img class="body_dis_box_b1_r lazy fr" data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif">
                                    </div>
                                </div>
                            </li>
                            <?php $n++;}unset($n); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="body_adv">
        	<ul>
            	<li><a href="javascript:;"><img data-original="<?php echo SPATH;?>ku/images/body_adv.png" src="<?php echo SPATH;?>images/bg_h.gif" class="lazy"></a></li>
                <li><a href="javascript:;"><img data-original="<?php echo SPATH;?>ku/images/body_adv.png" src="<?php echo SPATH;?>images/bg_h.gif" class="lazy"></a></li>
                <li><a href="javascript:;"><img data-original="<?php echo SPATH;?>ku/images/body_adv.png" src="<?php echo SPATH;?>images/bg_h.gif" class="lazy"></a></li>
                <li><a href="javascript:;"><img data-original="<?php echo SPATH;?>ku/images/body_adv.png" src="<?php echo SPATH;?>images/bg_h.gif" class="lazy"></a></li>
            </ul>
        </div>
        <div class="body_new">
        	<div class="body_new_l fl">
            	<div class="body_new_ll fl">
                	<img  data-original="<?php echo SPATH;?>ku/images/body_new_l.png" src="<?php echo SPATH;?>images/bg_h.gif" class="lazy">
                    <div class="body_new_l_b">
                    	<ul>
                        	<?php $n=1;if(is_array($indexCates)) foreach($indexCates AS $r) { ?>
                        	<li><a href="index.php?m=ku_shop&c=index&a=lists&classify=<?php echo $r['catid'];?>"><?php echo $r['catname'];?></a><span>></span></li>
                            <?php $n++;}unset($n); ?>
                            <!--<li><a href="javascript:;">家电家具</a><span>></span></li>
                            <li><a href="javascript:;">进口百货</a><span>></span></li>
                            <li><a href="javascript:;">手袋提包</a><span>></span></li>
                            <li><a href="javascript:;">奢饰品</a><span>></span></li>-->
                        </ul>
                    </div>
                </div>
            	<div class="body_new_lr fl">
                	<ul>
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=8a508ca9a98f1d7768867c394612ac47&action=lists&catid=%24catid&order=inputtime+DESC&num=6&return=news_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$news_data = $content_tag->lists(array('catid'=>$catid,'order'=>'inputtime DESC','num'=>'6','limit'=>'6',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                        <?php $n=1;if(is_array($news_data)) foreach($news_data AS $r) { ?>
                    	<li>
                        	<div class="body_new_lr_box">
                            	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                    <div class="body_new_lr_box_pic">
                                        <img data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif" class="pic lazy">
                                       <!-- <div class="body_new_lr_box_flag">
                                        	<img src="<?php echo SPATH;?>ku/images/flag.png" class="flag">
                                        </div>-->
                                    </div>
                                </a>
                                <a href="javascript:;"><u><?php echo $r['title'];?></u></a>
                                <div class="body_new_lr_box_buy">
                                	<div class="body_new_lr_box_buyl fl">
                                    	<div class="body_new_lr_box_buyl_1">
                                        	<p><span>¥</span><?php echo number_format($r['retail_price'],2);?></p><del>¥<?php echo number_format($r['yuanjiage']);?></del>
                                        </div>
                                        <p>0人购买</p>
                                    </div>
                                    <div class="body_new_lr_box_buyr fr">
                                    	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">立即抢</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php $n++;}unset($n); ?>
                        
                    </ul>
                </div>
            </div>
        	<div class="body_new_r fr">
            	<div class="body_new_r1">
                	<font>我要找货</font>
                    <a href="javscript:;" class="treasure">要找什么货？立即告诉我</a>
                    <p>如果有想要引进的好产品，请留言告诉我们。我们会对产品进行筛选及数据分析，进行产品引进，推荐的用户也会获得奖励哦。</p>
                </div>
                <div class="body_new_r2">
                	<div class="body_new_r2_">
                    	<ul>
                        	<li class="active">推荐</li>
                            <li>团购</li>
                        </ul>
                    </div>
                    <div class="body_new_r2_box">
                    	<div class="body_new_r2_box_">
                        	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/body_new_r2_box_1.png"></a>
                            <p>海外直采，正品低价&nbsp;全球奶粉海淘</p>
                        </div>
                        <div class="body_new_r2_box_">
                        	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/body_new_r2_box_2.png"></a>
                            <p>美妆药妆全球购，精选产品团购1折起</p>
                        </div>
                        <div class="body_new_r2_box_1">
                        	<div class="body_new_r2_box_1l fl">
                            	<div class="body_new_r2_box_1l_num" style="background-color:#ffcc00; color:#fff;">3</div>
                            </div>
                            <div class="body_new_r2_box_1r fr">
                            	<a href="javascript:;">你懂的你懂的你懂的你懂的你懂的你懂的你懂的你懂的</a>
                            </div>
                        </div>
                        <div class="body_new_r2_box_1">
                        	<div class="body_new_r2_box_1l fl">
                            	<div class="body_new_r2_box_1l_num" style="background-color:#eeeeee; color:#666666;">4</div>
                            </div>
                            <div class="body_new_r2_box_1r fr">
                            	<a href="javascript:;">你懂的你懂的你懂的你懂的你懂的你懂的你懂的你懂的</a>
                            </div>
                        </div>
                    </div>
                     <div class="body_new_r2_box" style="display:none;">
                    	<div class="body_new_r2_box_">
                        	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/body_new_r2_box_1.png"></a>
                            <p>123海外直采，正品低价&nbsp;全球奶粉海淘</p>
                        </div>
                        <div class="body_new_r2_box_">
                        	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/body_new_r2_box_2.png"></a>
                            <p>美妆药妆全球购，精选产品团购1折起</p>
                        </div>
                        <div class="body_new_r2_box_1">
                        	<div class="body_new_r2_box_1l fl">
                            	<div class="body_new_r2_box_1l_num" style="background-color:#ffcc00; color:#fff;">3</div>
                            </div>
                            <div class="body_new_r2_box_1r fr">
                            	<a href="javascript:;">你懂的你懂的你懂的你懂的你懂的你懂的你懂的你懂的</a>
                            </div>
                        </div>
                        <div class="body_new_r2_box_1">
                        	<div class="body_new_r2_box_1l fl">
                            	<div class="body_new_r2_box_1l_num" style="background-color:#eeeeee; color:#666666;">4</div>
                            </div>
                            <div class="body_new_r2_box_1r fr">
                            	<a href="javascript:;">你懂的你懂的你懂的你懂的你懂的你懂的你懂的你懂的</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="boby_show">
        	<div class="boby_show_t">
            	<div class="boby_show_tl fl">
                    <img src="<?php echo SPATH;?>ku/images/home_show.png">
                    <p>海淘产品<span>进口大品牌&nbsp;等你来购</span></p>
                </div>
                <div class="boby_show_tr fr"><a href="index.php?m=ku_shop&c=index&a=lists">更多>></a></div>
            </div>
            <div class="boby_show_b">
            	<ul>
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=24e41decbc49bbcfaddd99100a247245&action=lists&catid=%24catid&order=inputtime+DESC&num=10&return=hai_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$hai_data = $content_tag->lists(array('catid'=>$catid,'order'=>'inputtime DESC','num'=>'10','limit'=>'10',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <?php $n=1;if(is_array($hai_data)) foreach($hai_data AS $r) { ?>
                	<li>
                    	<div class="boby_show_b_box">
                        	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                <div class="boby_show_b_pic">
                                    <img data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif" class="pic lazy">
                                    <!--<div class="boby_show_b_flag">
                                        <img src="<?php echo SPATH;?>ku/images/flag.png" class="flag">
                                    </div>-->
                                </div>
                            </a>
                            <u><?php echo $r['title'];?></u>
                            <div class="boby_show_b_box_">
                            	<div class="boby_show_b_box_l fl">
                                	<div class="boby_show_b_box_l1">
                                    	<p><span>¥</span><?php echo number_format($r['retail_price'],2);?></p><del><?php echo number_format($r['yuanjiage'],2);?></del>
                                    </div>
                                    <p>0人已购买</p>
                                </div>
                                <div class="boby_show_b_box_r fr">
                                	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">去购买</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                    
                </ul>
            </div>
        </div>
        <div class="boby_show">
        	<div class="boby_show_t">
            	<div class="boby_show_tl fl">
                    <img src="<?php echo SPATH;?>ku/images/home_show.png">
                    <p>尾货区<span>精品尾货&nbsp;正品低价服务优</span></p>
                </div>
                <div class="boby_show_tr fr"><a href="index.php?m=ku_shop&c=index&a=lists">更多>></a></div>
            </div>
            <div class="boby_show_b">
            	<ul>
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=9bd3a2f723d4b4c3537a0310cfdbf701&action=lists&catid=%24catid&order=inputtime+DESC&num=10&return=wei_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$wei_data = $content_tag->lists(array('catid'=>$catid,'order'=>'inputtime DESC','num'=>'10','limit'=>'10',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <?php $n=1;if(is_array($wei_data)) foreach($wei_data AS $r) { ?>
                	<li>
                    	<div class="boby_show_b_box">
                        	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                <div class="boby_show_b_pic">
                                    <img data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif" class="pic lazy">
                                    <!--<div class="boby_show_b_flag">
                                        <img src="<?php echo SPATH;?>ku/images/flag.png" class="flag">
                                    </div>-->
                                </div>
                            </a>
                            <u><?php echo $r['title'];?></u>
                            <div class="boby_show_b_box_">
                            	<div class="boby_show_b_box_l fl">
                                	<div class="boby_show_b_box_l1">
                                    	<p><span>¥</span><?php echo number_format($r['retail_price'],2);?></p><del><?php echo number_format($r['yuanjiage'],2);?></del>
                                    </div>
                                    <p>0人已购买</p>
                                </div>
                                <div class="boby_show_b_box_r fr">
                                	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">去购买</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                </ul>
            </div>
        </div>
        <div class="boby_show">
        	<div class="boby_show_t">
            	<div class="boby_show_tl fl">
                    <img src="<?php echo SPATH;?>ku/images/home_show.png">
                    <p>国内优品<span>国内特色的优质产品</span></p>
                </div>
                <div class="boby_show_tr fr"><a href="index.php?m=ku_shop&c=index&a=lists">更多>></a></div>
            </div>
            <div class="boby_show_b">
            	<ul>
                	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c8eb8f56710a6f932aa3c1ea6196ae3d&action=lists&catid=%24catid&order=inputtime+DESC&num=10&return=country_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$country_data = $content_tag->lists(array('catid'=>$catid,'order'=>'inputtime DESC','num'=>'10','limit'=>'10',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <?php $n=1;if(is_array($country_data)) foreach($country_data AS $r) { ?>
                	<li>
                    	<div class="boby_show_b_box">
                        	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">
                                <div class="boby_show_b_pic">
                                    <img data-original="<?php echo $r['thumb'];?>" src="<?php echo SPATH;?>images/bg_h.gif" class="pic lazy">
                                    <!--<div class="boby_show_b_flag">
                                        <img src="<?php echo SPATH;?>ku/images/flag.png" class="flag">
                                    </div>-->
                                </div>
                            </a>
                            <u><?php echo $r['title'];?></u>
                            <div class="boby_show_b_box_">
                            	<div class="boby_show_b_box_l fl">
                                	<div class="boby_show_b_box_l1">
                                    	<p><span>¥</span><?php echo number_format($r['retail_price'],2);?></p><del><?php echo number_format($r['yuanjiage'],2);?></del>
                                    </div>
                                    <p>0人已购买</p>
                                </div>
                                <div class="boby_show_b_box_r fr">
                                	<a href="index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>">去购买</a>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php $n++;}unset($n); ?>
                </ul>
            </div>
        </div>
        <div class="boby_show">
        	<div class="boby_show_t">
            	<div class="boby_show_tl fl">
                    <img src="<?php echo SPATH;?>ku/images/home_show.png">
                    <p>营销教学<span>教您迈出您的第一步</span></p>
                </div>
                <div class="boby_show_tr fr"><a href="javascript:;">更多>></a></div>
            </div>
            <div class="boby_show_bb">
            	<div class="boby_show_bb_l fl">
                	<div class="boby_show_bb_ll fl">
                    	<img src="<?php echo SPATH;?>ku/images/boby_show_bb_ll.png">
                    </div>
                    <div class="boby_show_bb_lr fl">
                    	<div class="boby_show_bb_lr_box fl">
                        	<div class="boby_show_bb_lr_box_pic">
                        		<img src="<?php echo SPATH;?>ku/images/boby_show_bb_lr_box.png">
                            </div>
                            <div class="boby_show_bb_lr_box_">
                            	<p>进货入门</p>
                                <ul>
                                	<li><a href="javascript:;">外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;" class="more">更多></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="boby_show_bb_lr_box fr">
                        	<div class="boby_show_bb_lr_box_pic">
                        		<img src="<?php echo SPATH;?>ku/images/boby_show_bb_lr_box1.png">
                            </div>
                            <div class="boby_show_bb_lr_box_">
                            	<p>营销教程</p>
                                <ul>
                                	<li><a href="javascript:;">外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;">外贸</a></li>
                                    <li><a href="javascript:;" class="more">更多></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="boby_show_bb_r fr">
                	<div class="boby_show_bb_r1">
                    	<ul>
                        	<li class="active">商品销售排名</li>
                            <li>用户销售排名</li>
                        </ul>
                    </div>
                    <div class="boby_show_bb_r2">
                    	<ul>
                        	<li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top1</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top1</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top1</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top1</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="boby_show_bb_r2" style="display:none;">
                    	<ul>
                        	<li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top1</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top2</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top3</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                            <li>
                            	<div class="boby_show_bb_r2_">
                                	<div class="boby_show_bb_r2_l fl">
                                    	<a href="javascript:;"><img src="<?php echo SPATH;?>ku/images/boby_show_bb_r2_l_bg.png"></a>
                                        <i>Top4</i>
                                    </div>
                                    <div class="boby_show_bb_r2_r fr">
                                    	<p class="title">苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲苏菲</p>
                                        <p class="num">近30天销售量：30056件</p>
                                        <p class="price"><span>¥</span>108.00<del>¥199.00</del></p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!---footer_start---->
<?php include template('wb_shop','footer'); ?>
<!---footer_end---->
</body>
</html>
<script>
$(function(){
	//首页轮播
	var lonbo_page=1;
	var lunbo_num = $('#lunbo_ul').children('li').length;
	$('#lunbo_ul').width($(window).width()*lunbo_num);
	$('#lunbo_ul li').width($(window).width());
	var slipjs = slip('page', document.getElementById('lunbo_ul'), {
			  num : lunbo_num,  
	  change_time : 5000,
			  loop: false,
		   endFun : function(that){
				var lunbo_point = $('#lunbo_point').children('li');
				for(var i=0;i<lunbo_num;i++){
					i == that['page']? $(lunbo_point[i]).addClass('on') : $(lunbo_point[i]).removeClass('on');
				}
		  },
		lastPageFun:function(){}
	});
	$("img.lazy").lazyload({effect:"fadeIn"});//图片滚动加载
});
</script>
<script>
$('.banner_mess ul li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
	var _index = $(this).index();
	$('.banner_messb').eq(_index).show().siblings('.banner_messb').hide();
	});
$('.banner_messb').eq(0).show().siblings('.banner_messb').hide();
</script>
<script>
$('.body_dis_box_t ul li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
	var _index = $(this).index();
	$('.body_dis_box_b').eq(_index).show().siblings('.body_dis_box_b').hide();
	});
$('.body_dis_box_b').eq(0).show().siblings('.body_dis_box_b').hide();
</script>
<script>
$('.body_new_r2_ ul li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
	var _index = $(this).index();
	$('.body_new_r2_box').eq(_index).show().siblings('.body_new_r2_box').hide();
	});
$('.body_new_r2_box').eq(0).show().siblings('.body_new_r2_box').hide();
</script>
<script>
$('.boby_show_bb_r1 ul li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
	var _index = $(this).index();
	$('.boby_show_bb_r2').eq(_index).show().siblings('.boby_show_bb_r2').hide();
	});
$('.boby_show_bb_r2').eq(0).show().siblings('.boby_show_bb_r2').hide();
</script>