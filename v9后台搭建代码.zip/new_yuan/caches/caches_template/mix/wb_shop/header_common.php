<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="statics/ku/css/common.css">
<link rel="stylesheet" type="text/css" href="statics/ku/css/home.css">
<script src="<?php echo SPATH;?>js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="<?php echo SPATH;?>js/global.js" type="text/javascript"></script>
<script src="<?php echo SPATH;?>js/layer/1.9.3/layer.js" type="text/javascript"></script>
<script src="<?php echo SPATH;?>js/jquery_lazyload/jquery.lazyload.js" type="text/javascript"></script>
<title>海外巴巴</title>
</head>