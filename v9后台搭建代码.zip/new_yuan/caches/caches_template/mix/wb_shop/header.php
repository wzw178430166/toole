<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="header">
    <div class="header_top">
        <div class="header_top_m">
            <div class="header_top_ml fl">海外巴巴,全场会员优惠月</div>
            <div class="header_top_mr fr">
                <ul>
                    <li>您好，<?php if(param::get_cookie('_username')) { ?><?php echo param::get_cookie('_username');?> | <a href="index.php?m=member&a=logout">退出</a><?php } else { ?>请<a href="index.php?m=member&c=index&a=login" class="login">登录</a><a href="index.php?m=member&c=index&a=register">免费注册</a><?php } ?></li>
                    <li><a href="index.php?m=member&c=index">我的账号</a></li>
                    <li>手机客户端</li>
                    <li><a href="javascript:;">帮助中心</a></li>
                    <li>关注我们:<img src="<?php echo SPATH;?>ku/images/home_wechat.png"></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="header_min">
        <div class="header_min_m">
            <a href="<?php echo siteurl(2);?>"><img src="<?php echo SPATH;?>ku/images/home_logo.png"></a>
            <div class="haeder_search_box">
                <div class="header_search">
                    <input type="text" class="search nobd fl" placeholder="海淘">
                    <input type="submit" class="submit nobd fr" value="搜素">
                </div>
                <div class="header_hot">
                    <ul>
                        <li><a href="javascript:;">海淘产品</a></li>
                        <li><a href="javascript:;">进口零食</a></li>
                        <li><a href="javascript:;">果干</a></li>
                        <li><a href="javascript:;">喜庆喜糖</a></li>
                        <li><a href="javascript:;">进口饮料</a></li>
                    </ul>
                </div>
            </div>
            <a href="javascript:;" class="home_che">
                <img src="<?php echo SPATH;?>ku/images/home_che.png">购物车（<span>0</span>）
            </a>
        </div>
    </div>
    <div class="header_bot">
        <div class="header_bot_box">
            <div class="header_bot_boxl fl">
                <p><img src="<?php echo SPATH;?>ku/images/home_type.png">全部商品分类</p>
            </div>
            <div class="header_bot_boxr fl">
                <ul>
                    <li><a href="javascript:;">首页</a></li>
                    <li><a href="javascript:;">国内优品</a></li>
                    <li><a href="index.php?m=ku_shop&c=index&a=lists">海淘区</a></li>
                    <li><a href="javascript:;">尾货区</a></li>
                    <li><a href="javascript:;">限时折扣</a></li>
                    <!--<li><a href="javascript:;">直邮专区</a></li>
                    <li><a href="javascript:;">海淘团购</a></li>-->
                </ul>
            </div>
        </div>
    </div>
</div>