<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="statics/ku/app/css/appstyle.css">
<link rel="stylesheet" type="text/css" href="statics/ku/app/css/app_shop.css">
<script type="text/javascript" src="<?php echo SPATH;?>js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/TouchSlide.1.1.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/global.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<style>
.hd { display:none;}
.hot_sell_pic .hot_sell_flag { display:none;}
.header_search .search { height:28px; padding:0;}
.header_list { font-size:0.9rem; color:#fff;}
.buy-condition {
	position: absolute;
    right: 3px;
    bottom: 3px;
    font-size: 0.7rem;
    padding: 0 7px;
    background-color: rgba(51,51,51,.7);
    color: #fff;
    border-radius: 4px;	
}
</style>
</head>

<body>
<!---header_start--->
<div class="header">
	<div class="header_logo fl" id="sendFriend">
    	<img src="statics/ku/app/images/logo_bb.png">
    </div>
    <div class="header_search fl">
    	<img src="statics/ku/app/images/search.png">
        <form action="index.php" id="myform">
            <input type="hidden" name="m" value="ku_shop">
            <input type="hidden" name="a" value="lists">
            <input type="hidden" name="catid" value="<?php echo $catid;?>">
            <input type="search" placeholder="膳魔师焖烧壶" id="k" name="k" class="search nobd">
        </form>
    </div>
    <!--<div class="header_list fr">
    	<a href="javascript:;"><img src="statics/ku/app/images/home_menber.png"><p>登陆</p></a>
    </div>-->
    <!--<div class="header_list fr" id="shareBtn">-->
    <div class="header_list fr" id="country_ware">
    	日本仓
    	<!--<img src="statics/ku/app/images/home_shape.png">-->
    </div>
</div>
<div style="height:50px;"></div>
<!----header_end--->
<div class="banner">
	<!--轮播 start-->
  <div style="width:100%;">
    <div id="slideBox" class="slideBox">
      <div class="bd">
        <div class="tempWrap" style="overflow:hidden; position:relative;">
          <ul id="lunbo">
            <?php $adv=show_ad2(1,12,1,1)?>
            <?php if(empty($adv)) { ?>
            <li >暂无轮播图,请在后台->商城管理->轮播图片添加轮播</li>
            <?php } else { ?>
            <?php $n=1;if(is_array($adv)) foreach($adv AS $r) { ?>
            	<?php if(empty($r['1']['imageurl'])) { ?>
                <?php continue;?>
                <?php } ?>
            
                <li> <?php if($r['1']['linkurl']) { ?>
                  <a href="<?php echo $r['1']['linkurl'];?>">
                  <?php } ?> 
                  <?php
                  while(strpos($r['1']['imageurl'],'%')!==false){
                        $r['1']['imageurl'] = urldecode($r['1']['imageurl']);
                    }
                  ?>
                  <img style=" width:100%"   src="<?php echo $r['1']['imageurl'];?>"> <?php if($r['1']['linkurl']) { ?>
                  </a>
                  <?php } ?> </li>
                  
             
            <?php $n++;}unset($n); ?>
            <?php } ?>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
      <div class="hd">
        <ul>
         <!--<li class="on">1</li>
          <li class="">2</li>-->
        </ul>
      </div>
    </div>
    <div class="clear"></div>
  </div>
  <!--轮播 end-->
</div>
<div class="home_type">
	<ul>
    	<li onclick="url_header('index.php?m=wb_shop&a=classify')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_1.png">
                <p>商品分类</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=coupon')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_2.png">
                <p>优惠券</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=wlj')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_3.png">
                <p>省钱搭配</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=ku_shop&a=lists&new=1')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_4.png">
                <p>新品推荐</p>
            </div>
        </li>
        <li>
            <div class="home_type_box" onClick="sao_show();">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_5.png">
                <p>扫码找货</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=content&c=index&a=show&catid=7&id=6')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_6.png">
                <p>购物须知</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=wb_shop&c=index&a=lists_xs')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_7.png">
                <p>限时采购</p>
            </div>
        </li>
        <li onclick="url_header('index.php?m=content&c=index&a=show&catid=7&id=7')">
            <div class="home_type_box">
                <img src="<?php echo SPATH;?>ku/app/images/B2B_8.png">
                <p>扫货信息</p>
            </div>
        </li>
    </ul>
	<!--<ul>
    	<li>
        	<a href="index.php?m=wb_shop&a=classify">
                <div class="home_type_box">
                    <img src="statics/ku/app/images/bb_type_box1.png">
                    <p>商品分类</p>
                </div>
            </a>
        </li>
        <li>
        	<a href="javascript:;">
                <div class="home_type_box">
                    <img src="statics/ku/app/images/bb_type_box2.png">
                    <p>海淘专区</p>
                </div>
            </a>
        </li>
        <li>
        	<a href="javascript:;">
                <div class="home_type_box">
                    <img src="statics/ku/app/images/bb_type_box3.png">
                    <p>资费说明</p>
                </div>
            </a>
        </li>
        <li>
        	<a href="javascript:;">
                <div class="home_type_box">
                    <img src="statics/ku/app/images/bb_type_box4.png">
                    <p>限时采购</p>
                </div>
            </a>
        </li>
    </ul>-->
</div>
<!--coupon start-->
<div class="home_coupon" style="display:none;">
	<!--<img src="<?php echo SPATH;?>ku/app/images/B2B_9.png" class="big">-->
    <ul>
    	<li onclick="url_header('index.php?m=coupon&cid=1')"><img src="statics/bar/app/images/coupon1.jpg"></li>
        <li onclick="url_header('index.php?m=coupon&cid=1')"><img src="statics/bar/app/images/coupon2.jpg"></li>
        <li onclick="url_header('index.php?m=coupon&cid=1')"><img src="statics/bar/app/images/coupon3.jpg"></li>
    </ul>
</div>
<!--coupon end-->
<div style="width:100%; overflow:hidden; background-color:#edebec;">
    <div class="home_act">
        <div class="home_act_h">
            <img src="<?php echo SPATH;?>ku/app/images/B2B_10.png">
            <div class="home_act_hr fr" style="display:none;">09:10:11</div>
        </div>
        <div class="home_act_f">
            <ul id="xsBuy">
            	<?php $n=1;if(is_array($posterData)) foreach($posterData AS $r) { ?>
                <li onclick="url_header('index.php?m=ku_shop&c=index&a=show&id=<?php echo $r['id'];?>')">
                    <div class="home_act_f_">
                        <img src="<?php echo $r['thumb'];?>">
                        <p><?php echo $r['title'];?></p>
                        <font class="price"><i style="font-weight:bold; font-style:normal;">¥</i><span><?php echo number_format($r['jiage'],2);?></span></font>
                    </div>
                </li>
                <?php $n++;}unset($n); ?>
                <!--<li>
                    <div class="home_act_f_">
                        <img src="<?php echo SPATH;?>ku/app/images/B2B_11.png">
                        <p>商品名商品名商品名商品名商品名商品名商品名商品名商品名</p>
                        <font class="price"><i style="font-weight:bold; font-style:normal;">¥</i><span>88</span>.00</font>
                    </div>
                </li>-->
            </ul>
        </div>
    </div>
    <!--<div class="home_act">
        <div class="home_act_">
            <ul>
                <li>
                    <div class="home_act_box">
                        <div class="home_act_boxl fl">
                        	<p class="time_"><img src="statics/ku/app/images/home_act_boxl_time_.png">限时采购<span>推荐推荐</span></p>
                            <p class="time">距离开始时间</p>
                            <p class="time_count">09:10:11</p>
                            <p class="price">¥<span>320.</span>00元</p>
                        </div>
                        <div class="home_act_boxr fr">
                            <a href="javascript:;"><img src="statics/ku/app/images/home_act.png"></a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="home_act_point">
        	<ul>
            	<li></li>
                <li></li>
                <li class="active"></li>
            </ul>
        </div>
    </div>-->
    <!--<div class="home_more">
    	<ul>
        	<li><a href="javascript:;"><img src="statics/ku/app/images/home_more.png"></a></li>
            <li><a href="javascript:;"><img src="statics/ku/app/images/home_more1.png"></a></li>
            <li><a href="javascript:;"><img src="statics/ku/app/images/home_more2.png"></a></li>
            <li><a href="javascript:;"><img src="statics/ku/app/images/home_more3.png"></a></li>
        </ul>
    </div>-->
	<img src="statics/ku/app/images/bb_hot.png" class="home_hot">
    <div class="hot_sell">
        <ul id="indexData">
        	<?php $owhere='`is_auth`=1';?>
        	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=89aae268bfc3cea1e0c82aff8c268732&action=lists&catid=%24catid&owhere=%24owhere&order=inputtime+DESC&num=30\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'owhere'=>$owhere,'order'=>'inputtime DESC','num'=>'30','limit'=>'30',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        	<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
            <li>
            	<?php $attrKc = $attributeManage->getShopAttributeKc($r['id'],$r['catid']);$attrKc=$attrKc[$r['id']];?>
            	<?php $goodsurl = 'index.php?m=ku_shop&c=index&a=show&catid='.$r['catid'].'&id='.$r['id'];?>
                <div class="hot_sell_box" onclick="url_header('<?php echo $goodsurl;?>')">
                    <div class="hot_sell_pic">
                        <img src="<?php echo $r['thumb'];?>">
                        <div class="hot_sell_flag"></div>
                        <div class="buy-condition">限量：<?php echo $attrKc;?>件</div>
                    </div>
                    <u><?php echo $r['title'];?></u>
                    <div class="hot_sell_box_">
                        <div class="hot_sell_box_l fl">
                            <p>¥<span><?php echo number_format($r['jiage'],2);?></span></p>
                        </div>
                        <div class="hot_sell_box_r fr">
                            <span class="hot_buy">立即抢购</span>
                        </div>
                    </div>
                </div>
            </li>
            <?php $n++;}unset($n); ?>
            
        </ul>
    </div>
    <div class="home_warm">
        <div class="home_warm_">
            <div class="home_warm_tips">
                <ul>
                    <li><a href="javascript:;"><img src="statics/ku/app/images/header_warm_tips1_.png">网站通知</a></li>
                    <li><a href="javascript:;"><img src="statics/ku/app/images/header_warm_tips2_.png">常见问题</a></li>
                    <li><a href="javascript:;"><img src="statics/ku/app/images/header_warm_tips3_.png">法律声明</a></li>
                    <li><a href="javascript:;"><img src="statics/ku/app/images/header_warm_tips4_.png">客服咨询</a></li>
                </ul>
            </div>
            <div class="home_pay">
                <div class="home_payl fl">
                    <img src="statics/ku/app/images/home_pay1.png">付款方式
                </div>
                <div class="home_payr fl">
                    <ul>
                        <li><img src="statics/ku/app/images/home_pay2.png"></li>
                        <li><img src="statics/ku/app/images/home_pay3.png"></li>
                        <li><img src="statics/ku/app/images/home_pay4.png"></li>
                        <li><img src="statics/ku/app/images/home_pay5.png"></li>
                        <li><img src="statics/ku/app/images/home_pay6.png"></li>
                    </ul>
                </div>
            </div>
            <p>粤ICP备16024208号-2</p>
        </div>
    </div>
</div>
<div style="height:50px;"></div>
<!---footer_start--->
<div class="footer">
	<ul>
    	<li>
        	<div class="footer_box" onclick="url_header('index.php')">
            	<img src="statics/ku/app/images/home_.png">
                <p>首页</p>
            </div>
        </li>
        <li>
        	<div class="footer_box" onclick="url_header('index.php?m=wb_shop&a=classify')">
            	<img src="statics/ku/app/images/type_.png">
                <p>分类</p>
            </div>
        </li>
        <li>
        	<div class="footer_box" onclick="url_header('index.php?m=wb_shop&a=goodscart')">
            	<img src="statics/ku/app/images/shopping_.png">
                <p>进货单</p>
            </div>
        </li>
        <li>
        	<div class="footer_box" onclick="url_header('index.php?m=member')">
            	<img src="statics/ku/app/images/wode_.png">
                <p>我的</p>
            </div>
        </li>
    </ul>
</div>
<!---footer_end--->
<!--share tips start--->
<style>
.shareAlert { position:fixed; width:100%; height:100%; left:0; top:0; z-index:1000000; display:none;}
.shareAlert img { width:100%;}
.shareBlackBox { width:100%; height:100%; background-color:#333; opacity:0.8; position: absolute; left:0; top:0; z-index:-1}
</style>
<div class="shareAlert" id="shareAlert">
<img src="<?php echo SPATH;?>bar/app/images/fenx.png" onClick="hideShare()">
<div class="shareBlackBox" id="shareBlackBox"></div>
</div>
<!--share tips end--->
<?php include template('wb_shop','jsapi','mix'); ?>
<?php include template('wb_shop','tag_sao_index','mix'); ?>
</body>
<script>
$(function(){
	TouchSlide({
		slideCell: "#slideBox",
		titCell: ".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
		mainCell: ".bd ul",
		effect: "leftLoop",
		autoPage: true,//自动分页
		autoPlay: true //自动播放
	});
	setProImgSize();	
	window.onscroll = function() { myscroll(); }
	
	//xsBuy
	var xsItem = $('#xsBuy li');
	var xsLength = xsItem.length;
	var xsWidth = $('#xsBuy li').width()*xsLength;
	//console.log($('#xsBuy li').width()*xsLength);
	$('#xsBuy li').css({"width":$(window).width()/3});
	$('#xsBuy').css({"width":xsWidth+'px'});
	
	//share btn
	$('#shareBtn').click(function(){
		$('#shareAlert').fadeIn();
		$('html').css({"overflow":"hidden"});
		$('body').css({"overflow":"hidden","height":"100%"});
	});
	$('#shareBlackBox').click(function(){hideShare();});
});
var page = 1;
var loaded =0;
function get_infos(ac){
	var gerUrl = 'index.php?m=ku_shop&a=lists_data&position=index';
	page++;
	gerUrl += '&page='+page;
	loaded=1;
	//var index = layer.load(2, {time: 30*1000});
	creatLoading(6*1000);
	$.post(gerUrl,function(da){
		document.getElementById('loadBox').style.display = 'none';
		//layer.close(index);
		if(da.length<=0){
			$('#enddiv').show();		
		}else{
			loaded=0;
			$('#indexData').append(da);
			setProImgSize();
		}
	});	
}

function myscroll(){
	if(loaded!=1){
		var c=document.documentElement.clientHeight || document.body.clientHeight;
		var t=$(window).scrollTop();
		//console.log((t+c)+'---'+$('body').height());
		if(t+c >= ($('body').height())){ 
			loaded=1;
			window.setTimeout("get_infos()",300);
		}
	}

}
function setProImgSize() {
	var hot_width = $('.hot_sell_pic img').width();
	$('.hot_sell_pic img').height(hot_width);
}

//hiden shareAlert
function hideShare(){
	$('#shareAlert').fadeOut();
	$('html').css({"overflow":"auto"});
	$('body').css({"overflow":"auto","height":"auto"});	
}


</script>
</html>