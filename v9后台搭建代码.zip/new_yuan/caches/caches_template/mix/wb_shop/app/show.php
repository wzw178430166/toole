<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $commentid = 'content_'.$catid.'-'.$id.'-1';?>
<?php
$description = '海外巴巴';
$appid = pc_base::load_config('system','wx_appid');
$appSecret = pc_base::load_config('system','wx_appSecret');
//$thumb = siteurl(1).'/statics/d/images/xiaotu.jpg';
$link = siteurl(1).'/index.php?m=wb_shop&a=show&id='.$id.'&i='.param::get_cookie('_userid');
if(is_weixin() && $appid){
    pc_base::load_app_func('global','weixin');
    $timestamp = time().'';
    $wxnonceStr = 'barbar8api';
    $jsapi_ticket = wx_get_jsapi_ticket($appid,$appSecret,'shop');
    $url = get_url();
    //$url = siteurl(1).'/index.php?m=wb_shop&c=index&a=show&catid='.$catid.'&id'.$id;
    $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s",$jsapi_ticket, $wxnonceStr, $timestamp,$url);
    $wxSha1 = sha1($wxOri);
    //var_dump($timestamp.'----'.$wxnonceStr.'------'.$wxSha1.'--------'.$jsapi_ticket.'-------'.$url);
}
?>

<?php include template($this->config['style'],'header_common',$this->style); ?>
<?php $titlename='商品详情'?>
<style>
body{padding-bottom:0!important;background-color:#f2f2f2}
.shopcontent{display:none;transition:top 1s;position:absolute;z-index:10;background:#FFF;width:100%;overflow-y:scroll}
.showb_but{border-top:1px solid #dbdbdb;border-bottom:1px solid #dbdbdb;text-align:center;height:40px;line-height:40px}
#snct_list li{width:48%;float:left;background:#fff;border:1px solid #E4E3E3;margin-bottom:12px}
.act-link{color:#f15353;margin-top:8px;font-size:13px;line-height:18px}
.gds_title{height:100%;width:93%;display:inline-block;font-size:16px;margin-left:15px}
.prod-price{font-size:24px;font-family:Helvetica;color:#f15353;margin-top:10px;font-weight:700}
.gds_title{width:100%;height:100%}
#shopcontent_con{width:94%;margin:0 auto}
#shopcontent_con img{width:100%}
.cptit{height:40px;line-height:40px;background:#EFEDED;text-align:center;font-size:15px}
.pjdd_02{border-bottom:1px solid #dbdbdb;padding-bottom:10px;margin-bottom:5px}
.dianpu_xinxi{width:100%;margin-bottom:13px}
.dp_content{height:82px;background:#FFF;position:relative}
.dp_content p{width:60%;float:left;padding-left:14px}
.banner_xin{position:absolute;right:0;top:12px;width:57px;height:70px;border-left:1px solid #dbdbdb;color:#9b9b9b}
.dp_menu_style{height:20px;line-height:24px;border-bottom:1px solid #dbdbdb;display:block;background:#FFF;position:relative;padding:5px 19px 13px 10px}
.dms_a{display:block;float:left;color:#4F4F4F;font-size:1.2em;text-indent:10px}
.dms_img{float:left}
.xx{font-size:16px}
.spmf_name{line-height:30px}
.gds_title{margin:0;width:auto;padding:0 15px}
.slideBox{border:0}
.fanhui_icon{display:block;width:20px;height:44px;margin-left:5px;float:left;background:url(statics/mix/app/images/fanhui_icon.png) no-repeat center;background-size:20px}
.pro_sel_box{width:70%;float:left;margin-left:30px}
ul.pro_sel_box li{width:33.3%;height:43px;float:left;text-align:center;color:#020202;font-size:13px}
ul.pro_sel_box li.sel_{color:#ffa100;border-bottom:2px #ffa100 solid}
.goods_info_word{padding:0 10px;font-size:15px;background-color:#fff}
.goods_title{margin:0;line-height:1.2;padding:7px 0 10px;border-bottom:1px #eee solid;color:#151515;position:relative}
.goods_title span{position:absolute;right:0;bottom:7px;padding:2px 5px;width:auto;white-space:nowrap;font-size:12px;border-radius:4px;background-color:#ee3356;color:#fff}
.goods_money{padding:10px 0;font-size:13px;color:#ee3356;overflow:hidden;width:100%;float:left;border-bottom:1px solid #f2f2f2}
.money_item{float:left;margin-right:15px; width:100%; overflow:hidden;}
.money_item:first-child{margin-bottom:5px}
.goods_want{padding:10px 0;font-size:13px;color:#afafb1;overflow:hidden;width:35%;float:right}
.want_item{float:right}
.want_item:first-child{margin-bottom:10px}
.goods_want a{width:auto;overflow:hidden;background-color:#f8a025;color:#fff;border-radius:15px;padding:2px 10px}
.money_item span.arrow_icon_{display:block;float:left;padding:0 4px;color:#fff;background-color:#ee3356;font-size:12px;position:relative;margin-right:10px}
.money_item span.arrow_icon_ em.arrow_{display:block;width:15px;height:19px;position:absolute;top:0;right:-13px;background:url(statics/mix/app/images/arrow_r_red.png) no-repeat -6px center;background-size:15px}
.money_item span font{font-size:16px;font-weight:700}
.jhtj{font-size:13px}
.jhtj p{margin:0;padding:10px 0}
.jhtj p font.font-hui{color:#afafaf}
.jhtj p span{margin:0 5px 0 15px;color:#2a2a2a}
.enter_arrow{display:block;float:right;width:15px;height:20px;background:url(statics/mix/app/images/enter_arrow.png) no-repeat center;background-size:15px}
.tu_detail p{margin:0;padding:10px 0}
.stars_{font-size:14px;color:#ffc619}
.dp_info_box{padding:10px 0;border-bottom:1px #eee solid}
.dp_info_box p{margin:0}
.dp_left{width:75%;float:left}
.dp_left p.dp_img{width:60px;height:60px;overflow:hidden;float:left;border-radius:4px;border:1px #eee solid;margin-right:5px}
.dp_left p.dp_img img{width:100%;height:60px}
.dp_info_word{float:left;line-height:1.8}
.dp_info_word p.dp_title{font-size:16px}
.dp_right{float:right;margin-top:5px;text-align:center}
.dp_right p{margin-bottom:5px;line-height:18px}
.dp_right p em{display:block;width:18px;height:18px;float:left;background:url(statics/mix/app/images/gz_icon_.png) no-repeat center;background-size:18px}
.dp_right p em.gzed{background:url(statics/mix/app/images/gz_icon.png) no-repeat center;background-size:18px}
.dp_right span{font-size:12px;padding:1px 8px;background-color:#ee3356;color:#fff;border-radius:4px}
.dp_btn{padding:10px 0}
.dp_btn a{display:block;width:48%;text-align:center;padding:5px 0;border-radius:4px;border:1px #d1d1d1 solid;color:#505050}
.same_goods p{margin-bottom:0}
.same_goods_box{padding:10px 0}
.same_goods_item{width:31%;float:left;font-size:12px;text-align:center}
.same_goods_item p{padding:0 5px}
.same_goods_item p.same_img{width:100%;padding:0;border:1px #eee solid}
.same_goods_item p.same_img img{width:100%}
.same_goods_title{height:40px;overflow:hidden;text-overflow:ellipsis;white-space:normal}
.same_title{padding:10px 0;border-bottom:1px #eee solid}
.qimai_icon{padding:0 5px;background:#ef3356;border-radius:4px;color:#fff}
.other_footer{height:45px;border-top:1px #e1e1e1 solid;z-index:100001}
.other_footer_box{width:100%;height:100%;background-color:#fff}
.other_box_left{width:35%;float:left;opacity:.8}
.other_box_left a{display:block;width:50%;height:45px;float:left;text-align:center}
.other_box_left a i{display:block;width:20px;height:20px;margin:5px auto;margin-bottom:0}
.gz_icon_{background:url(statics/mix/app/images/gz_icon_.png) no-repeat center;background-size:20px}
.gz_icon{background:url(statics/mix/app/images/gz_icon.png) no-repeat center;background-size:20px}
.cart_icon{background:url(statics/mix/app/images/goodscart_icon.png) no-repeat center;background-size:20px}
.other_box_right{width:65%;float:right}
.other_box_right a.send_btn{display:block;width:50%;height:45px;line-height:45px;text-align:center;float:left;color:#fff;font-size:1.3rem}
.other_box_right a.add_cart{background-color:#ffb03f}
.other_box_right a.buying{background-color:#f23030}
.shop_detail{width:100%;position:absolute;top:45px;transition:left .5s;display:none;background-color:#fff;padding-bottom:45px}
.comment_box{width:100%;position:absolute;top:45px;transition:left .5s;display:none;background-color:#fff}
.comment_box_main{padding:10px}
.comment_item{width:100%;margin-bottom:7px;border-bottom:1px #dbdbdb solid;padding-bottom:3px}
.comment_item_content{font-size:14px}
.shop_detail_box{width:100%}
.shop_detail_box img{width:100%}
.empty_data{display:none;text-align:center}
.no_border_bottom{border-bottom:none}
.goods_time{width:100%;height:40px;line-height:40px;border-bottom:1px solid #dbdbdb;font-size:12px}
.goods_time_l{font-weight:700;color:#000}
.goods_time_l i{background:url(statics/mix/app/images/time.png) no-repeat;width:18px;height:18px;display:block;float:left;margin-top:10px;margin-right:5px}
.goods_time_l em{color:#ee3356;font-style:normal}
.goods_time_r{color:#dbdbdb}
.yun_fei_box{padding:5px 0;/*border-top:1px #eee solid;*/font-size:13px}
.send_btn font{display:block;height:17px;line-height:17px}
.goodscart_ac{position:relative}
.cartCount{position:absolute;right:10px;top:0;height:15px;line-height:15px;padding:0 5px;background-color:#D92B2B;border-radius:30px;text-align:center;font-size:.7rem;color:#fff}
.goods_money .goods_moneyl{width:60%}
.goods_money .goods_moneyr{/*width:19%;*/text-align:center;/*border-left:1px solid #e7e7e7;*/ display:none;}
.goods_moneyr img{width:30px;height:30px;display:block;margin:0 auto}
.goods_moneyr i{color:#7c7c7c;font-size:12px}
.goods_des{width:100%;overflow:hidden;background-color:#fff}
.goods_des .des_box{width:auto;overflow:hidden;padding:5px 2%;font-size:13px;color:#999}
body{padding:0!important}
.gotop{width:30px;height:30px;position:fixed;right:5%;bottom:10%;z-index:99999;padding:10px 0 0 10px;cursor:pointer; opacity: .5; display: none;}
.fanhui{width:30px;height:30px;border-radius:20px;opacity:.8}
	.tempWrap{ height:380px;}
</style>
<script type="text/javascript" src="<?php echo SPATH;?>js/TouchSlide.1.1.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/cookie.js"></script>
<body>
<img src="statics/ku/app/images/gotop.png" class="gotop">
<!--template 'app','header'-->
<!--<div class="header">
  <div class="header_box"> <a href="javascript:goback();" class="fanhui_icon"></a>
    <ul class="pro_sel_box" id="pro_sel_box">
      <li class="sel_" data-index="content_box">商品</li>
      <li data-index="shop_detail">详情</li>
      <li data-index="comment_box">评论</li>
    </ul>
  </div>
</div>-->
<div class="main sel_item" > <!--id="content_box"-->
  
  <!--轮播 start-->
  <div style="width:100%;">
    <div id="slideBox" class="slideBox">
      <div class="bd">
        <div class="tempWrap" style="overflow:hidden; position:relative;">
          <ul>
            <?php if($d_cptu) { ?>
            <?php $n=1;if(is_array($d_cptu)) foreach($d_cptu AS $d) { ?>
            <li> <img src="<?php echo SPATH;?>mix/app/images/hui.jpg"  data-src="<?php echo $d['url'];?>" onload="delayimg(this)"/> </li>
            <?php $n++;}unset($n); ?>
            <?php } else { ?>
            <li> <img src="<?php echo SPATH;?>mix/app/images/hui.jpg" data-src="<?php echo $thumb;?>" onload="delayimg(this)"  /> </li>
            <?php } ?>
          </ul>
        </div>
        <a href="javascript:goback();" style="position:absolute; left:10px; top:10px;"><img src="statics/ku/app/images/fanhui.png" class="fanhui"></a>
      </div>
      <?php if($d_cptu) { ?>
      <div class="hd">
        <ul>
          <?php $n=1;if(is_array($d_cptu)) foreach($d_cptu AS $d) { ?>
          <li class="on"><?php echo $n;?></li>
          <?php $n++;}unset($n); ?>
        </ul>
      </div>
      <?php } ?> </div>
    <div class="clear"></div>
  </div>
  <div class="clear"></div>
  <!--轮播 end--> 
  <!--商品标题 start-->
  <div class="goods_info_word">
  	<p class="goods_title">
    	<?php echo $title;?>
    </p>
    <div class="goods_money">
    	<div class="goods_moneyl fl">
            <?php if($retail_price) { ?>
            <div class="money_item">
                <span class="arrow_icon_">会员价<em class="arrow_"></em></span>
                <span style="float:left; height:19px; line-height:19px;">￥<font><?php echo number_format($retail_price, 2);?></font></span>
                <!--<font class="font-hui fr" style="margin-left:5px">(满<?php echo $qimai;?><?php if($unit_) { ?><?php echo $unit_;?><?php } else { ?>件<?php } ?>即可起批)</font>-->
            </div>
            <?php } ?>
            <!--<div class="money_item">
                <span class="arrow_icon_">分销价<em class="arrow_"></em></span>
                <span style="float:left; height:19px; line-height:19px;">￥<font><?php echo number_format($jiage, 2);?></font></span>
            </div>-->
        </div>
        <div class="goods_moneyr fr" style=" display:block; color:#FFA627;">
        	库存：<font><?php echo $attributeKc[$id];?></font>
        </div>
        <!--<div class="goods_moneyr fr" id="shareBtn">
        	<img src="statics/ku/app/images/goods_shape.png">
        	<i>分享赚钱</i>
        </div>-->
    </div>
    <?php if($goods_des) { ?>
    <div class="goods_des">
    	<div class="des_box"><?php echo $goods_des;?></div>
    </div>
    <?php } ?>
    <div style="clear:both;"></div>
    <div class="yun_fei_box">
    	<span class="fl" style="color:#727272;">预估运费:<?php echo $yun_fei;?>元</span>
    	<span class="fr" style="color:#929292;"><?php echo $area;?></span>
    </div>
  </div>
  <!--商品标题 end-->
  <!--<div style="height:10px; background-color:#f2f2f2;"></div>-->
  <!--进口税 start-->
    <?php 
        $jkshui = $this->taxes;
        $jkMoney = round($retail_price*(11.9/100),2);
        $noshui = array(100,150,149,96,125,146,73,147,81,130,128,148,141);
    ?>
  <div class="goods_info_word jhtj" style="display:none;">
  	<p style="border-bottom:1px #eee solid;">
    	<font>进口税</font>
        
    </p>
    <p>
    	<font class="font-hui"><?php if(in_array($id,$noshui)) { ?>商家承担<?php } else { ?>预计<?php echo $jkMoney;?>元(进口税:11.9%)<?php } ?></font>
        <!--<a class="enter_arrow" href="javascript:;"></a>-->
    </p>
  </div>
  <!--进口税 end-->
  <div style="height:10px; background-color:#f2f2f2;"></div>
  <!--进货条件 start-->
  <div class="goods_info_word jhtj" style="border-top:none;">
  	<p style="border-bottom:1px #eee solid;">
    	<font>商品属性</font>
        
    </p>
    <p onClick="show_attr('retail')">
    	<font class="font-hui selectedAtt" id="selectedAtt">选择：颜色分类/套餐类型</font>
        <a class="enter_arrow" href="javascript:;"></a>
    </p>
  </div>
  <!--进货条件 end-->
  <div style="height:10px; background-color:#f2f2f2;"></div>
  <!--产品详情 start-->
  <!--<div class="goods_info_word tu_detail" onClick="show_content('shop_detail', 1);">
  	<p><font>图文详情</font><a href="javascript:;" class="enter_arrow"></a></p>
  </div>-->
  <!--产品详情 end-->
<style>
.goods_more{width:100%;overflow:hidden}
.goods_more .more_line{width:100%;overflow:hidden;margin-bottom:10px; z-index: 9}
.more_line li{float:left;/*width:33.3%;*/width:49.9%;height:40px;line-height:40px;text-align:center;background-color:#fff;font-size:13px}
.more_line .cur{border-bottom:1px solid #ff5000;color:#ff5000}
	.more_line2{     position: fixed;    top: 0;}
.more_box{width:100%;overflow:hidden}
.more_box .more_box_{width:100%;overflow:hidden}
.more_box_ img{width:100%}
.more_box_ li{float:left;width:47%;overflow:hidden;margin-left:2%}
.more_box_ .hot_sell_box{width:100%;overflow:hidden;border-radius:5px;margin-top:5px;background-color:#fff}
.hot_sell_box .hot_sell_pic{width:100%;overflow:hidden;position:relative}
.hot_sell_box .hot_sell_pic img{width:96%;background-size:100%;display:block;margin:10px auto;height:146px}
.hot_sell_box u{width:90%;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-all;margin:0 auto;margin-bottom:5px;text-decoration:none;height:45px;line-height:22px}
.hot_sell_box .hot_sell_box_{width:96%;overflow:hidden;padding:10px 0;margin:0 auto;border-top:1px solid #e8e8e8}
.hot_sell_box_l p{font-size:12px;color:#ff5200;font-weight:700;margin-bottom:inherit}
.hot_sell_box_l span{font-size:15px;margin-left:5px}
.hot_sell_box_r .hot_buy{width:60px;height:25px;line-height:25px;background-color:#db3333;border-radius:5px;text-align:center;color:#fff;display:block;font-size:12px}
</style>
  <div class="goods_more">
  	<div class="more_line">
    	<ul id="pro_sel_box">
        	<li class="cur" data-index="content_box" onClick="targ('1',this)">图文详情</li>
            <li data-index="monthZt" onClick="targ('2',this)">本月主推</li>
            <!--<li data-index="comment_box" onClick="targ('3')">用户评论</li>-->
        </ul>
    </div>
    <div class="more_box">
    	<div class="more_box_ sel_item" id="content_box">
        	<?php echo $content;?>
        </div>
        <div class="more_box_ sel_item" style="background-color:#edecec;" id="monthZt">
        	<p style="height:30px; line-height:30px; border-left:3px solid red; background-color:#fff; margin-bottom:0px; font-size:15px; margin-top:2px;"><span style="padding-left:5px;">本月主推</span></p>
        	<ul id="indexData">
            <?php $owhere = '`is_auth`=1';?>
            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=031bb4cee4c57a7dcb144cbfd0a5e27c&action=lists&catid=%24catid&owhere=%24owhere&order=inputtime+DESC&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'owhere'=>$owhere,'order'=>'inputtime DESC','num'=>'4','limit'=>'4',));}?> <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        	<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
            <li>
            	<?php $goodsurl = 'index.php?m=ku_shop&c=index&a=show&catid='.$r['catid'].'&id='.$r['id'];?>
                <div class="hot_sell_box" onClick="url_header('<?php echo $goodsurl;?>')">
                    <div class="hot_sell_pic">
                        <img src="<?php echo $r['thumb'];?>">
                        <div class="hot_sell_flag"></div>
                    </div>
                    <u><?php echo $r['title'];?></u>
                    <div class="hot_sell_box_">
                        <div class="hot_sell_box_l fl">
                            <p>¥<span><?php echo number_format($r['retail_price'],2);?></span></p>
                        </div>
                        <div class="hot_sell_box_r fr">
                            <span class="hot_buy">立即抢购</span>
                        </div>
                    </div>
                </div>
            </li>
            <?php $n++;}unset($n); ?>
            </ul>
        </div>
        <!---commentBox start-->
        <div class="sel_item comment_box" id="comment_box">
            <input type="hidden" id="comment_url" value="index.php?m=wb_shop&c=index&a=list_comment&commendid=<?php echo $commentid;?>">
            <div class="comment_box_main" id="comment_list">
                
            </div>
            <div class="empty_data" id="empty_data">没有更多评论</div>
        </div>
        <!---commentBox end-->
    </div>
  </div>
  <div style="background-color:#f2f2f2;"></div>
  
  <div style="height:10px; background-color:#f2f2f2;"></div>
 
  <div style="height:10px; background-color:#f2f2f2;"></div>
  
</div>
<div style="height:45px;">
</div>
<!--othder_footer start-->
<div class="other_footer" id="other_footer_one">
  <div class="other_footer_box">
  	<div class="other_box_left">
    	<a class="gz_ac" href="javascript:;" onClick="add_favorite('<?php echo $title;?>', '', this)">
        	<i class="gz_icon_"></i>
            <font>收藏</font>
        </a>
        <a class="goodscart_ac" href="index.php?m=wb_shop&a=goodscart">
            <i class="cart_icon"></i>
            <font>进货单</font>
            <font class="cartCount" data-val="0">0</font>
        </a>
    </div>
    <div class="other_box_right">
    	<a class="send_btn add_cart" onClick="show_attr('retail')">加入进货单</a>
    	<?php if($retail_price) { ?>
        	<!--<a class="send_btn add_cart" onClick="show_attr('retail')"><font style="margin-top:5px;">￥<?php echo $retail_price;?></font><font>单独购买</font></a>-->
            <a href="javascript:;" class="send_btn buying" onClick="show_attr('retail')">自购</a>
        <?php } else { ?>
        	<a href="javascript:;" class="send_btn add_cart" style="background-color:#ccc;">暂未开启</a>
        <?php } ?>
    </div>
    </div>
</div>
<div class="sel_item shop_detail" id="shop_detail">
	<div class="shop_detail_box">
    <?php echo $content;?>
    </div>
</div>
<!--<div class="sel_item comment_box" id="comment_box">
	<input type="hidden" id="comment_url" value="index.php?m=wb_shop&c=index&a=list_comment&commendid=<?php echo $commentid;?>">
	<div class="comment_box_main" id="comment_list">
    	
    </div>
    <div class="empty_data" id="empty_data">没有更多评论</div>
</div>-->
<!--share tips start--->
<style>
.shareAlert { position:fixed; width:100%; height:100%; left:0; top:0; z-index:1000000; display:none;}
.shareAlert img { width:100%;}
.shareBlackBox { width:100%; height:100%; background-color:#333; opacity:0.8; position: absolute; left:0; top:0; z-index:-1}
</style>
<div class="shareAlert" id="shareAlert">
<img src="<?php echo SPATH;?>bar/app/images/fenx.png" onClick="hideShare()">
<div class="shareBlackBox" id="shareBlackBox"></div>
</div>
<!--share tips end--->
<!--template 'app','purchase_goods'-->
<?php include template($this->config['style'],'attr_sel',$this->style); ?>
<!--othder_footer end--> 
<?php include template($this->config['style'],"footer_common",$this->style); ?>
</body>
<?php
	include(('./statics/kefu/app/style1.php'));
?>
</html>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script type="text/javascript">
var scrollTop_;
var scrollindex;
var screen_height;
var screen_width;
var pro_sel_li;

//评论加载
var page = 1;
var loaded = 0;
var st = 0;
	
window.onload = function () {
	console.log(screen.width );
	window.setTimeout(function(){$('.tempWrap').css('height',document.body.clientWidth);},500);
	//首页轮播
	TouchSlide({
		slideCell: "#slideBox",
		titCell: ".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
		mainCell: ".bd ul",
		effect: "leftLoop",
		autoPage: true,//自动分页
		autoPlay: false, //自动播放
	});
	myscroll();
	//get_infos();
	window.onscroll = function() { 
		
		myscroll(); 
	}
	
	//判断是否收藏
	is_favorite();
	is_favorite('add_dp');
	
	
	//share btn
	$('#shareBtn').click(function(){
		$('#shareAlert').fadeIn();
		$('html').css({"overflow":"hidden"});
		$('body').css({"overflow":"hidden","height":"100%"});
	});
	$('#shareBlackBox').click(function(){hideShare();});
};
//hiden shareAlert
function hideShare(){
	$('#shareAlert').fadeOut();
	$('html').css({"overflow":"auto"});
	$('body').css({"overflow":"auto","height":"auto"});	
}
function add_favorite(title, ac, obj) {
	var ajax_url = './api.php?op=add_favorite&title='+encodeURIComponent(title)+'&url='+encodeURIComponent(location.href)+'&pcatid=<?php echo $catid;?>&pid=<?php echo $id;?>';
	if (ac == 'add_dp') {
		ajax_url += '&dp=<?php echo $dp_id;?>';
	}
	var index = layer.load(2);
	$.post(ajax_url, function(data){
		 layer.close(index);
		data = eval('(' + data + ')');
		if(data.status==1 || data.status==2){
			var msg = data.status == 1? '已取消' : '收藏成功';
			layer.msg(msg,{icon:6});
			var class_add = ac == 'add_dp' ? 'gzed' : 'gz_icon';
			var class_glob = ac == 'add_dp' ? '.'+ac+'_gz' : '.gz_icon_';
			
			if (data.status == 1) {
				$(obj).css({"color": "#333"});
				$(class_glob).removeClass(class_add);
			} else {
				$(obj).css({"color": "#F04C6A"});
				$(class_glob).addClass(class_add);
			}
		} else{
			layer.msg('请先登录',{icon:3,time:1500});
			setTimeout(function () {
				var forward_ = "<?php echo urlencode(get_url());?>";
				window.location.href = 'index.php?m=member&a=login&forward='+forward_;
			}, 1500);
		}
	});
}
function is_favorite (ac) {
	var t = ac == 'add_dp' ? 2 : 1;
	$.get('index.php?m=member&a=is_favorite&t='+t+'&pcatid=<?php echo $catid;?>&pid=<?php echo $id;?>',function (data) {
		if (data.status < 0) {
			layer.msg('参数错误');
		} else if(data.status == 1){
			var class_add = ac == 'add_dp' ? 'gzed' : 'gz_icon';
			var class_glob = ac == 'add_dp' ? '.'+ac+'_gz' : '.gz_icon_';
			var word_add = ac == 'add_dp' ? '.dp_right p' : '.gz_ac';
			$(word_add).css({"color": "#F04C6A"});
			$(class_glob).addClass(class_add);
		}
	}, 'json');
}

function show_attr(ac) {
	changeBuyWay(ac);
	scrollTop_ = $(window).scrollTop();
	screen_height = $(window).height();
	$('#black_bg').show();		
	$('#attr_box').css({'bottom':'46px'});
	$('#attr_box').show();
	$('#other_footer_one').hide();
	$('#other_footer_two').show();
	$('body').css({'height':(screen_height-45), 'overflow':'hidden'});
	
	//$('#is_ok').attr('value', 1);
}
//加入购物车
function addCart_ () {
	var index = layer.load(2, {time: 30*1000});
	 $.ajax({
		cache: true,
		type: "POST",
		url:'index.php?m=wb_shop&a=add_cart',
		data:$('#orders_form').serialize().replace(/\&count.*/,'')+'&ajax=1&count='+parseInt($('#pro_num').val()),
		async: false,
		error: function(request) {
			alert("操作失败,请稍后再试");
			return false;
		},
		success: function(data) { 
			layer.close(index);
			var da = data;
			setTimeout(function(da){
				var json_data =  eval('(' + data + ')');
				if(json_data.status==1){
					try{ getgoodscart(); }catch(e){ }
					hide_attr();//关闭进货单
					layer.msg('已加入进货单',{icon:6});
					var tt = Number($('.cartCount').attr('data-val'))+Number($('#combo_2').val());
					
					$('.cartCount').text(tt);
					$('.cartCount').attr('data-val',tt);
				}else if(json_data.status==-1){
					/*try{ show_login(); }catch(e){
						layer.msg('请先登录', {time:2000});
						setTimeout(function () {
							window.location.href='index.php?m=member&a=login&forward=<?php echo urlencode(get_url());?>';	
						}, 2000);
					}*/
					setCartCookie();
					layer.msg('已加入进货单');
					var tt = Number($('.cartCount').attr('data-val')) + Number($('#combo_2').val());
					$('.cartCount').text(tt);
					$('.cartCount').attr('data-val',tt);
				}else{
					layer.msg(json_data.msg);
				}
				return false;
		},300)},
	});	
}
function send_form(ac) {
	var is_ok = $('#is_ok').val();
	var buy_condition = $('#buy_condition').val();
	var unit_ = "<?php echo $unit_;?>";
	if (unit_ == 0) {unit_ = '件';}
	var pro_count = Number($('#pro_count').attr('data-val'));
	var attr_box_height = $('#attr_box').height();
	console.log(is_ok);
	if (is_ok == 2) {
		//已选择属性
		if ($('#pro_count').attr('data-val') <=0){
			layer.msg('库存不足!');
			return;
		}
		if (ac == 'cart') {
			addCart_();
		} else if(ac == 'buy'){
			if (buyCondition==0) {return;}
			if ((pro_count < buy_condition) && buy_way_index == 'pf') {
				layer.msg('该商品需要'+buy_condition+unit_+'才可发货');
				return;
			}
			$('#orders_form').submit();
		}
		
	} else if (is_ok == 1){
		layer.msg('数量不能为空!');
	}
}
function show_content(content, item_) {
	$(pro_sel_li).removeClass('sel_');
	$(pro_sel_li[item_]).addClass('sel_');
	$(window).scrollTop(0);
	$('.sel_item').hide();
	$('#'+content).show();
	$('#'+content).css({'left':'0px'});
	/*if (content == 'comment_box') {
		get_infos();
	}*/ 
}

function hide_attr () {
	$('#black_bg').hide();
	$('#attr_box').css({'bottom':'-' + screen_height+'px'});
	$(window).scrollTop(scrollTop_);
	$('#attr_box').hide();
	$('#other_footer_one').show();
	$('#other_footer_two').hide();
	$('body').css({'overflow':'auto','height':'100%'});
	$('html').css({'overflow':'auto','height':'100%'});
	//$('#is_ok').attr('value', 0);
}
function showb(){
	scrollTop_ = $(window).scrollTop();
	goback =  $('#header_fanhui').attr('href');
	$('#header_fanhui').attr('href','javascript:hideb()');
	$('#shopcontent').css({'top':scrollTop_,'height':window.screen.height-144});
	$('#shopcontent').show();	
	//$(window).scrollTop(0);

	$('#shopcontent').css({'top':'45px'});
	//$('#search_header').css({'top':'0px'}); 
	$('body').css({'height':window.screen.height-144,'overflow':'hidden'});
	$('table').removeAttr('style');
	

	try{ jstojava.mysetgoback('hideb()'); }catch(e){}	

}
function hideb(){
	$('body').css({'height':'auto','overflow':'auto'});
	$('#shopcontent').css({"display":"none"});
	$('#shopcontent').css({'top':$(window).scrollTop(),"display":"none"});
	$('#header_fanhui').removeAttr('href','javascript:hideb()');
	$('#header_fanhui').attr('href','javascript:history.go(-1);');
	$(window).scrollTop(scrollTop_);
	window.setTimeout(function(){ $('#shopcontent').hide(); },300);
	try{ jstojava.mysetgoback('goback_()'); }catch(e){}
}	


function catt(ac){
	if(ac){
		$('#content_box').show();
		$('#attbox').hide();
		$('#orders_form').hide();
	}else{
		$(window).scrollTop(0);
		$('#attbox').show();
		$('#content_box').hide();
		$('#orders_form').show();		
	}	
}
	//详情, 主卖, 评论 nav 滚动事件
function targ(id,obj){
	$('#pro_sel_box').find('li').removeClass('cur');
	switch(id){
		case '1': fid = 'content_box'; tt=10; break;
		case '2': fid = 'monthZt';  tt=-300; break;
		case '3': fid = 'comment_box'; tt=100; break;
	}
	$("#pro_sel_box").find("li:eq("+(id-1)+")").addClass('cur');
	
	if(obj){
		var mian_top = $('body').scrollTop();

		$('body').scrollTop(0);
		var top = document.getElementById(fid).getBoundingClientRect().top;
		top-= tt;
		$('body').scrollTop(mian_top);
		$('body').animate({ scrollTop:(top)});	
	}
	return false;
}
$('.gotop').click(function(){
	$('body').animate({ scrollTop:(0)});	
});
/*wechat if*/
function isWeiXin(){
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) == 'micromessenger'){
        return true;
    }else{
        return false;
    }
}

if(getCookie('show_t')<Date.parse(new Date())-1800000||!getCookie('show_t')){
	setCookie('show_t',Date.parse(new Date()));
	recode();
}	
</script>
<script>
function get_infos(){
	var param = ''; 
	url = $('#comment_url').val();
	url += '&page='+page;
	loaded=1;
	var index = layer.load(2);
	$.post(url,function(data){
		layer.close(index);
		if(data.length<=0){
			if (page == 1) {
				$('#comment_list').empty();
			}
			$('#empty_data').show();		
		}else{
			loaded=0;
			$('#comment_list').append(data);
			$('#empty_data').hide();
		}
	});	
}
function myscroll(){
	var tem_top = $(window).scrollTop()- document.getElementById('content_box').getBoundingClientRect().top;
	if(tem_top >=598.5){
		$('.more_line').addClass('more_line2');
		$('.gotop').show();
	}else{
		$('.more_line').removeClass('more_line2');
		$('.gotop').hide();
	}

	if(document.getElementById('monthZt').getBoundingClientRect().top <= 80){
		targ(2);
	}else {
		targ(1);
	}
	if(loaded!=1){
		var c=document.documentElement.clientHeight || document.body.clientHeight;
		var t=$(window).scrollTop();
		if(t+c >= ($('#comment_box').height()+60)){ 
			loaded=1;
			page ++;
			//window.setTimeout("get_infos()",300);
		}
	}

}
</script>
<script>
wx.config({
  debug: false,
  appId: "<?php echo $appid;?>",
  timestamp: '<?php echo $timestamp;?>',
  nonceStr: '<?php echo $wxnonceStr;?>',
  signature: '<?php echo $wxSha1;?>',
  jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline','onMenuShareQQ']
});
wx.ready(function(){
    wx.onMenuShareAppMessage({//分享给好友
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link;?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
            layer.msg('分享成功!');
			hideShare();
        },
    });
    wx.onMenuShareTimeline({//分享到朋友圈
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link; ?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
            layer.msg('分享成功!');
			hideShare();
        },
    });
    wx.onMenuShareQQ({
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link; ?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
           layer.msg('分享成功!');
		   hideShare();
        },
    });
});
//初始化jsapi接口 状态
wx.error(function (res) {
  alert("调用微信jsapi返回的状态:"+res.errMsg);
});

$('#shareBtn').click(function(){
	
});
</script>
<script language="JavaScript" src="<?php echo APP_PATH;?>api.php?op=count&id=<?php echo $id;?>&modelid=<?php echo $modelid;?>"></script>