<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title=$titlename='选择扫码';?>
<style>
body { padding:0;}
.nobd{ border:none;}
.sao_box_main{ background-color:#f5f4f4; width:100%; overflow-x:hidden;  position:absolute; top:0; transition:left .5s; z-index: 99999; display:none; left:100%;}
	.sao_header {
    width: 100%;
    height: 44px;
    background-color: #32dadb;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 9999;
}
	.sao_header_fanhui {
		
		    display: inline-block;
		background: url('<?php echo SPATH;?>shop_tmp/index6/images/hl.png') no-repeat center;
    background-size: 12px auto;
    position: absolute;
    height: 44px;
    top: 0px;
    left: 10px;
    width: 32px;
		
}
	.sao_header_box {
    width: 100%;
    height: 44px;
    line-height: 44px;
    text-align: center;
    margin: 0 auto;
    background: #ffffff;
    position: relative;
}
	.sao_header_title {
    font-size: 16px;
    color: #333333;
}
.sao_box{ background:url(statics/sao/sao_bg.jpg) no-repeat; width:100%; background-size:100%; background-color:#f5c700; height:100%; overflow:hidden;}
.sao_top{ width:90%; overflow:hidden; margin:0 auto; text-align:center; padding-top:55%;}
.sao_photo{ width:80px; height:80px; background:url(statics/sao/IMG_3568.png) no-repeat; margin:0 auto; background-size:80px; position: relative;}
.sao_top p{ line-height:20px; height:20px; font-size:15px; color:#383838;}
.sao_bot{ width:90%; overflow:hidden; border:3px dashed #ff7200; border-radius:20px; margin:0 auto; background-color:#fff;}
.sao_bot font{ height:35px; line-height:35px;}
.code_check_box{ width:95%; height:40px; border:2px solid #ff7200; border-radius:35px; margin:0px auto 10px auto;}
.code_check{ width:100%; height:35px; line-height:35px; margin: 0px -2px 0 0; }
.code_check input{ width:100%; height:36px; line-height:36px;}
.code_check_box .fl{ width:70%;}
.code_check_box .fr{ width:30%;}
.sao_bot p{ font-size:12px; color:#383838; margin-bottom:inherit; line-height:27px;}
	.invisible_saobutton, .inputbox_ {
    width: 82px !important;
    height: 86px !important;
    position: absolute;
    display: block;
}
</style>
<style>
.my-webuploader-element-invisible{width: 40px;height: 40px;opacity: 0;}
.invisible_saobutton,.inputbox_ {
    width: 82px !important;
    height: 86px !important;
    position: absolute;
    display: block;
}
</style> 
<script type="text/javascript" src="<?php echo JS_PATH;?>diyUpload/js/webuploader.html5only.min.js"></script>
<script src="<?php echo JS_PATH;?>ex/quagga.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/sao.js"></script>

<div id="sao_box_main" class="sao_box_main">
<div class="sao_header">
	<div class="sao_header_box">
    	<a onclick="sao_hide()" id="header_fanhui" class="header_fanhui sao_header_fanhui"></a>
        <h2 class="sao_header_title" style="padding-left:0px; text-align:center;">选择扫码</h2>
    </div>
</div>
<div style=" height:45px"></div>
<div class="sao_box">
	<div class="sao_top">
    	<div class="sao_photo" id="saobutton"></div>
        <p>拍拍找货</p>
    </div>
    <div class="sao_bot">
    	<div style="width:auto; padding:0px 10px;">
            <font>填写条形码查询</font>
            <div class="code_check_box">
            	<form action="/">
                    <input type="hidden" name="m" value="oc" />
                    <input type="hidden" name="c" value="sao" />
                    <input type="hidden" name="a" value="lists" />
                <div class="code_check fl">
                    <input type="text" name="code" placeholder="请输入需要查询的条形码" style="border-radius:35px 0px 0px 35px; padding-left:10px;" class="nobd">
                </div>
                <div class="code_check fr">
                    <input type="submit" value="立即查询" class="nobd" style="border-radius:0px 35px 35px 0px; text-align:center; background-color:#ff7300; color:#fff;">
                </div>
                </form>
            </div>
            <p>温馨提示</p>
            <p>1.点击上方【拍照扫码】,即可打开手机摄像机进行拍照</p>
            <p>2.使用【拍照扫码】时, 请注意要先开启拍照权限哦。</p>
            <p>3.如需手动输入条形码数字搜素,可以在下方填写进行查询</p>
        </div>
    </div>
</div>
</div>

<script>
console.log(is_weixin());
if(!is_weixin()){
	var sao1 = new sao_('saobutton');
	$('.webuploader-pick').next().css({'width':'80px !important','height':'80px !important'});
}
var wintop;
var screen_height = $(window).height();
function sao_show(){
	var w = window.screen.width;
	wintop = $(window).scrollTop();
	$(window).scrollTop(0);
	$('#sao_box_main').css({ 
		'left': w,
		//'top':$(window).scrollTop(), 
		'height': screen_height,
		'display':'block'
	});	
	
	$('.footer').css('z-index','999999');
	window.setTimeout(function(){
		$('#sao_box_main').css({ 
			'left': 0,
		});
		
		$('html').css('overflow-y','hidden');
		$('body').css({'overflow-y':'hidden','height': screen_height-50});			
	},30);
	
}
function sao_hide(){
	$('html').css('overflow-y','auto');
	$('body').css({'overflow-y':'auto','height': 'auto' });
	$('body').scrollTop(wintop);
	$('#sao_box_main').css({ 
			'left': window.screen.width,
	});	
	window.setTimeout(function(){ $('#sao_box_main').hide(); },501);	
}

</script>


