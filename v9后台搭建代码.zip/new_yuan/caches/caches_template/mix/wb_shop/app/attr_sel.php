<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.hide { display:none;}
.black_bg {
	position:fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: #333;
    z-index: 100000;
    opacity: 0.5;	
}
.attr_box { width:100%; background-color:#fff; padding-bottom:20px; display:none; position:fixed; left:0; transition:bottom 0.5s; z-index:100001;}
.attr_title {
	text-align: center;
    font-size: 15px;
    padding: 10px 0;
    position: relative;
    border-top: 1px #f3f3f3 solid;
    border-bottom: 1px #f3f3f3 solid;	
}
.close_icon {
	display: block;
    width: 25px;
    height: 25px;
    position: absolute;
    right: 5px;
    top: 10px;
    background: url(statics/mix/app/images/close_icon.png) no-repeat center;
    background-size: 25px;	
}
.pro_info { padding:10px;}
.pro_info_img {
	width: 60px;
    height: 60px;
    float: left;
    margin-right: 20px;	
}
.pro_info_img img { width:100%;}
.pro_info_money {
	color: #ee3356;
    float: left;	
}
.pro_info_money .money_item {
	float: initial;
	height:20px;	
}
.jhtj_attr,.attrItemBox {
	padding: 10px;
    border-top: 1px #f3f3f3 solid;
    border-bottom: 1px #f3f3f3 solid;
	margin:0;	
}
.attr_sel_main { background-color: #fafafa; border-bottom: 1px #f0f0f0 solid;}
.attr_sel_main ul { overflow:hidden; padding:0 10px;}
.attr_sel_main ul li {
	width: 30%;
    float: left;
    text-align: center;
    padding: 10px 0;	
}
.attr_sel_main ul li.one, .attr_sel_main ul li.two{ width:25%;}
.attr_sel_main ul li.three { width:50%; text-align:right;}
.attr_count {
	width: 30%;
    float: right;
    height: 19px;
    border-radius: 3px;
    border: 2px #d8d8d8 solid;
	margin-top:10px;
}
.combo_ {
	display: block;
    width: 25%;
    height: 100%;
    float: left;	
}
.attr_count span {
	display: block;
    width: 50%;
    float: left;
    height: 19px;
    border-left: 2px #d8d8d8 solid;
    border-right: 2px #d8d8d8 solid;
    margin-left: -2px;	
}
.attr_count span input {
	border: 0;
    text-align: center;
    width: 100%;
    height: 100%;
	float:left;	
}
.sub_icon {
    background: url(statics/mix/app/images/sub_icon.png) no-repeat center;
    background-size: 50%;
}	
.add_icon { 
	background: url(statics/mix/app/images/add_icon.png) no-repeat center;
    background-size: 50%;
	margin-left:-2px;
}
.money_count_box {
	text-align: right;
    padding: 5px 10px;
}
.pro_count {
	font-size: 12px;
    color: #808080;
    margin: 0 15px;	
}
.pro_money_count { font-size:14px;}
.pro_money_count font { color: #ed3a5a;}
.price_sel {
	padding: 0 10px;
    border-top: 1px #eee solid;
    height: 40px;
    line-height: 40px;	
}
.buy_way {
	display: block;
    float: left;
    padding: 0 15px;
    height: 20px;
    line-height: 22px;
    margin-top: 10px;
    border-radius: 4px;
    border: 1px #626262 solid;
	margin: 10px 10px 0;
	font-size:13px;
}
.price_sel a.sel {
	background-color:#F23030;
	border-color:#F23030;
	color:#fff;	
}
.jhtj_attr { display:none;}
.attrItemBox { border-bottom:0; padding:8px 10px;}
.attrItem font { font-size:1.4rem;}
.attrItemVal { margin-top:8px;}
.attrItemVal a {
	display: block;
    float: left;
    padding: 0 8px;
	width:auto;
    height: 25px;
    line-height: 25px;
    background-color: #F3F3F3;
    border-radius: 4px;
    font-size: 1rem;
    margin-right: 10px;	
}
.attrItemVal a.sel{ background-color:#F23030; color:#fff;}
.shopKc,.seledAttr { color:#626262; font-size:1.2rem;}
.shopKc { display:block;}
.seledAttr { margin-top:15px;}
.shopKc em { font-style:normal;}
.taxesTips { position:fixed; left:5%; bottom:20%; width:90%; line-height:20px; font-size:1rem; color:#fff; background-color:#333; text-align:center; padding:5px 0; border-radius:4px; display:none; z-index:100001;}
</style>
<?php if($qimai) { ?>
<?php } else { ?>
    <?php $qimai=0;?>
<?php } ?>
<div class="attr_box" id="attr_box">
<!--<form id="orders_form" method="post" action="index.php?m=wb_shop&a=confim&forward=<?php echo urlencode('index.php?m=app&c=index&a=show&catid='.$catid.'&typeid=1&id='.$id);?>">-->
<form id="orders_form" method="post" action="index.php?m=wb_shop&a=listOfGoods&forward=<?php echo urlencode('index.php?m=wb_shop&a=show&catid='.$catid.'&typeid=1&id='.$id);?>">
    <input type="hidden" name="goodsid" value="<?php echo $id;?>" id="goodsid">
    <input type="hidden" name="goodscatid" value="<?php echo $catid;?>" id="goodscatid">
    <input type="hidden" name="yun_fei" value="<?php echo $yun_fei;?>" id="yun_fei">
     <input type="hidden" name="plat" value="<?php if($dp_id) { ?><?php echo $dp_id;?><?php } else { ?><?php echo $plat;?><?php } ?>" id="dp_id">
	<p class="attr_title">
    	请选择需要购买的商品
        <a class="close_icon" onClick="hide_attr()"></a>
    </p>
    
    <div class="pro_info">
    	<p class="pro_info_img"><img src="<?php echo $thumb;?>"></p>
        <div class="pro_info_money">
        	<div class="money_item">
                <span class="arrow_icon_">价格<em class="arrow_"></em></span>
                <span>￥<font id="price_str"><?php echo number_format($jiage, 2);?></font></span>
            </div>
            <div class="shopKc">库存<em id="shopKc" data-val="0" data-attrid="0"></em><?php if($unit_) { ?><?php echo $unit_;?><?php } else { ?>件<?php } ?></div>
            <div class="seledAttr selectedAtt">请选择</div>
        </div>
    </div>
    <div class="price_sel">
    	<font class="fl">购买方式</font>
    	<a href="javascript:;" class="buy_way" style="display:none" onclick="buy_way(this)" id="retail_btn" data-index="retail" data-val="<?php echo $retail_price;?>">自购</a>
        <a href="javascript:;" class="buy_way sel" style="display:none" onclick="buy_way(this)" id="pf_btn" data-index="pf" data-val="<?php echo $jiage;?>">分享</a>
    </div>
    <p class="jhtj_attr" id="pf_tips">
    	<font>进货条件</font>
        <span><?php echo $qimai;?><?php if($unit_) { ?><?php echo $unit_;?><?php } else { ?>件<?php } ?>起批</span>
    </p>
    <p class="jhtj_attr" id="retail_tips">
    	<font>运费</font>
        <span><?php echo $yun_fei;?>元</span>
    </p>
    <!---attrInfo start-->
    <div class="attrItemBox" id="attrInfo">
    	
    </div>
    <!---attrInfo end-->
    <!---attrCount start-->
    <div class="price_sel">
    	<font class="fl">购买数量</font>
    	<div class="attr_count">
            <a class="combo_ sub_icon" href="javascript:;" onClick="combosub(this)"></a>
            <span><input type="number" min="1" max="" onblur="enterChangeCount(this)" name="" id="combo_2" value="1" data-val="1"></span>
            <a class="combo_ add_icon" href="javascript:;" onClick="comboadd(this)"></a>
        </div>
    </div>
    <!---attrCount end-->
    <!--<div class="money_count_box">
    	<?php if($qimai) { ?>
        <?php } else { ?>
        	<?php $qimai=0;?>
        <?php } ?>
    	<span class="pro_count">共<font id="pro_count" data-val="<?php echo $qimai;?>"><?php echo $qimai;?></font><?php if($unit_) { ?><?php echo $unit_;?><?php } else { ?>件<?php } ?></span>
        <span class="pro_money_count">合计: ￥<font id="pro_money_count"><?php echo number_format($jiage*$qimai);?></font></span>
    </div>-->
    <input type="hidden" id="buy_condition" value="<?php echo $qimai;?>"/>
    <input type="hidden" id="is_ok" value="2">
    <input type="hidden" id="buyWay" name="buyWay" value="retail">
    </form>
</div>
<!--othder_footer start-->
<div class="other_footer" id="other_footer_two" style="display:none;">
  <div class="other_footer_box">
  	<div class="other_box_left">
    	<a class="gz_ac" href="javascript:;" onClick="add_favorite()">
        	<i class="gz_icon_"></i>
            <font>关注</font>
        </a>
        <a class="goodscart_ac" href="index.php?m=wb_shop&a=goodscart">
            <i class="cart_icon"></i>
            <font>进货单</font>
            <font class="cartCount" data-val="0">0</font>
        </a>
    </div>
    <div class="other_box_right">
    	<a class="send_btn add_cart" onClick="send_form('cart')">加入进货单</a>
        <a class="send_btn buying" onClick="send_form('buy')">立即购买</a>
    </div>
    
    </div>
</div>
<div class="black_bg" id="black_bg" style="display:none;"></div>
<script>
var buyCondition = 0;
var initIndex = 0;
getAttrInfo();//初始化属性json
checkBuyCondition();
var total = $('#pro_count').attr('data-val');;
var data_val=qimai = '<?php echo $qimai;?>';
var retail_price = "<?php echo $retail_price;?>";
var single_price = "<?php echo $jiage;?>";
var attrKc_ = 0;
var total_amount = 0;
function combosub(obj){
	var num = Number($('#combo_2').val());
	if(num>1){
		$('#combo_2').attr('value',num-1);
	}
	checkBuyCondition();
}
function comboadd(obj){
	var num = Number($('#combo_2').val());
	var kc = Number($('#shopKc').attr('data-val'));
	var result = num<kc?num+1:num;
	$('#combo_2').attr('value',result);
	checkBuyCondition();
}
//输入修改数量
function enterChangeCount(obj){
	var num = Number($('#combo_2').val());
	var kc = Number($('#shopKc').attr('data-val'));
	var result = num<kc?num:kc;
	$('#combo_2').attr('value',result);
	checkBuyCondition();
}

function checkBuyCondition(){
	var selCount = Number($('#combo_2').val());
	var selMoney = Number(retail_price)*selCount;
	buyCondition = selMoney>=1000?1:0;
	$('.buying').css({"backgroundColor":buyCondition==1?"#f23030":"#C3C3C3"});
	if (buyCondition==0 && initIndex == 1) {
		tipsBox('单笔交易不得低于1000，请继续选购!');
	}
	if (initIndex == 0) {initIndex = 1;}
}

var buy_way_index;
var price_val;
function buy_way(obj){
	//var price_val = $(obj).attr('data-val');
	buy_way_index = $(obj).attr('data-index');
	
	//显示规则
	changeMess(buy_way_index);
	//价格处理
	changeBuyWay(buy_way_index);
}
//切换购买方式
function changeBuyWay(ac){
	$('.buy_way').hide();
	buy_way_index = ac;
	price_val = $('#'+ac+'_btn').attr('data-val');
	$('#price_str').text(price_val);
	single_price = price_val;
	$('#'+ac+'_btn').show();
	//购买方式记录
	$('#buyWay').attr('value',ac);
	changeMess(ac);
}
function changeMess(ac){
	//显示规则
	$('.buy_way').removeClass('sel');
	//$('.jhtj_attr').hide();
	$('#'+ac+'_btn').addClass('sel');
	//$('#'+ac+'_tips').show();
}

//goodscart COOKIE
function setCartCookie(){
	var cartArr = getcookie('cart')?getcookie('cart'):'{}';
	var date = new Date();
	var dp_id = $('#dp_id').val();
	var goodsid = $('#goodsid').val();
	var goodscatid = $('#goodscatid').val();
	var goodstitle = "<?php echo $rs['title'];?>";
	//var yun_fei = $('#yun_fei').val();
	var attrId = $('#shopKc').attr('data-attrid');
	var attrCount = $('#combo_2').attr('value');
	var jsonIndex = goodsid+'_'+attrId;
	var proIndex = goodscatid+'_'+goodsid;
	cartArr = JSON.parse(cartArr);
	var jsonData = {
		"cid":date.getTime(),
		"productid":goodsid,
		"productcatid":goodscatid,
		"producttitle":goodstitle,
		"buyWay":$('#buyWay').val(),
		//"yun_fel":yun_fei,
		"plat":dp_id,
		
	};
	//.attribute[proIndex][attrId]
	if ($.isEmptyObject(cartArr[jsonIndex])) {
		var attrValue = '{"'+proIndex+'":{"'+attrId+'":"'+attrCount+'"}}';
		attrValue = JSON.parse(attrValue);
		jsonData.attribute = attrValue;
		cartArr[jsonIndex] = jsonData;
	} else {
		var attrExist = cartArr[jsonIndex].attribute[proIndex][attrId];
		var cartItem = cartArr[jsonIndex];
		var countResult = Number(attrExist)+Number(attrCount);
		var attrValue = '{"'+proIndex+'":{"'+attrId+'":"'+countResult+'"}}';;
		attrValue = JSON.parse(attrValue);
		cartItem.attribute = attrValue;
		//console.log(cartItem);
	}
	setcookie('cart',JSON.stringify(cartArr));
}

//attriute deal
var AttrJsonData = {};
function getAttrInfo(){
	$.get('index.php?m=wb_shop&c=index&a=getAttributeInfo&gid=<?php echo $id;?>&gcatid=<?php echo $catid;?>',function(data){
		if (data.status == 1) {
			//creathtml
			var attribute_ = data.attribute['attVal'];
			var attrJson = data.attrJson;
			var attText = data.attText;
			var attribute_html = '';
			for(var i in attribute_){
				attribute_html += '<div class="attrItem"><font>'+attText[i]+'</font><div class="attrItemVal" id="attrValue_'+i+'">';
				var attrValue = attribute_[i];
				var nn=1;
				for(var ii in attrValue){
					var sel = nn==1?'sel':'';
					attribute_html += '<a href="javascript:;" class="attrTtem '+sel+'" onClick="setAttr(this,'+i+')" data-val="'+attrValue[ii]+'">'+attrValue[ii]+'</a>';
					nn++;
				}
				attribute_html += '</div>';
			}
			$('#attrInfo').empty();
			$('#attrInfo').append(attribute_html);
			
			if ($.isEmptyObject(AttrJsonData)) {
				//setJson
				for(var i in attrJson){
					AttrJsonData[i] = attrJson[i];
				}
			}
			setAttr();//默认选中属性
			//console.log(AttrJsonData);
		} else {
			layer.msg('网络错误,请刷新再试!');	
		}
	},'json');
}
function setAttr(obj,attId){
	var selItem = '';
	var selText = '';
	var attrInputName = 'attribute[<?php echo $catid;?>_<?php echo $id;?>]';
	$('#attrValue_'+attId+' a').removeClass('sel');
	$(obj).addClass('sel');
	var currAttVal = $(obj).attr('data-val');
	var attItem = $('#attrInfo a.sel');
	attItem.each(function(i) {
        var attVal = $(attItem[i]).attr('data-val');
		selItem += attVal+'|';
		selText += attVal+'、';
    });
	var shopAttId = AttrJsonData[selItem].id;
	attrInputName += '['+shopAttId+']';
	$('#combo_2').attr('name',attrInputName);
	$('#combo_2').attr('max',AttrJsonData[selItem].kc);
	$('#shopKc').attr('data-val',AttrJsonData[selItem].kc);
	//$('#shopKc').attr('data-val',999);
	$('#shopKc').attr('data-attrId',AttrJsonData[selItem].id);
	$('#shopKc').text(AttrJsonData[selItem].kc);
	//$('#shopKc').text(999);
	//$('#selectedAtt').text('已选择: '+selText);
	$('.selectedAtt').text('已选择: '+selText);
	//console.log(shopAttId);
	//alert(shopAttId);
}
countCart();
//countCart
function countCart() {
	$.get('index.php?m=wb_shop&c=index&a=getCartCount&id=<?php echo $id;?>&catid=<?php echo $catid;?>&ajax=1',function(data){
		var dataCount = 0;
		if (data.status == 1 && data.count > 0) {
			$('.cartCount').text(data.count);
			$('.cartCount').attr('data-val',data.count);
		} else {
			var result = countCookieCart();
			$('.cartCount').text(result);
			$('.cartCount').attr('data-val',result);
		}
		
	},'json');
}
function countCookieCart(){
	var cartArr = getcookie('cart')?getcookie('cart'):'{}';
	cartArr = JSON.parse(cartArr);
	var result = 0;
	for(var i in cartArr){
		var attribute = cartArr[i].attribute;
		for(var ii in attribute){
			var att = attribute[ii];
			for(var at in att){
				result += Number(att[at]);
			}
		}
	}
	return result;
}
</script>