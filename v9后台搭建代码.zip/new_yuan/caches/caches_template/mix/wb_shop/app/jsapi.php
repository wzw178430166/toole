<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
$title = '巴巴优库';
$description = '巴巴优库';
$thumb = siteurl(1).'/statics/ku/app/images/logo_bb.png';
$link = siteurl(2);
$appid = pc_base::load_config('system','wx_appid');
$appSecret = pc_base::load_config('system','wx_appSecret');
if(is_weixin() && $appid){
    pc_base::load_app_func('global','weixin');
    $timestamp = time().'';
    $wxnonceStr = 'barbar8api';
    $jsapi_ticket = wx_get_jsapi_ticket($appid,$appSecret,'shop');
    $url = get_url();
    $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s",$jsapi_ticket, $wxnonceStr, $timestamp,$url);
    $wxSha1 = sha1($wxOri);
}
?>

<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script>
var isweixin_api = '<?php echo $is_weixin;?>';
isweixin_api = Number(isweixin_api);
var callback_=function(){};
// 微信配置 
wx.config({
  debug: false ,
  appId: "<?php echo $appid;?>", 
  timestamp: '<?php echo $timestamp;?>', 
  nonceStr: '<?php echo $wxnonceStr;?>', 
  signature: '<?php echo $wxSha1;?>',
  jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline','onMenuShareQQ','getLocation','scanQRCode']
});

wx.ready(function(){
	isweixin_api = isweixin_api>0? 1 : 0;
	
	//$('#sao').unbind('click');
	$('#saobutton').on('click',function () {
		wx.scanQRCode({
		  needResult: 1,
		  desc: 'scanQRCode desc',
		  success: function (res) {
			  if(res.errMsg=='scanQRCode:ok'){
				  var resultStr = res.resultStr.split(",");
				  var code = Number(resultStr[1]);  
				  
				  if(code){
				  	layer.msg('<i class="Hui-iconfont Hui-iconfont-xuanze"></i>识别成功');
				  	window.location.href = 'index.php?m=oc&c=sao&a=lists&code='+code;
					return;
				  }
			  }
			  
			  layer.msg('网络错误, 请稍后再试');
		  },
		  error:function(){
				layer.msg('网络错误, 请稍后再试'); 
			}
		});
	  });
	  
	  	wx.onMenuShareAppMessage({//分享给好友
			title: '<?php echo $description;?>', // 分享标题
			desc: '<?php echo $title;?>', // 分享描述
			link: '<?php echo $link;?>',//window.location.href, // 分享链接
			imgUrl: '<?php echo $thumb;?>', // 分享图标
			success: function () {
				layer.msg('分享成功!');
				hideShare();
			},
		});
		wx.onMenuShareTimeline({//分享到朋友圈
			title: '<?php echo $description;?>', // 分享标题
			desc: '<?php echo $title;?>', // 分享描述
			link: '<?php echo $link; ?>',//window.location.href, // 分享链接
			imgUrl: '<?php echo $thumb;?>', // 分享图标
			success: function () {
				layer.msg('分享成功!');
				hideShare();
			},
		});
		wx.onMenuShareQQ({
			title: '<?php echo $description;?>', // 分享标题
			desc: '<?php echo $title;?>', // 分享描述
			link: '<?php echo $link; ?>',//window.location.href, // 分享链接
			imgUrl: '<?php echo $thumb;?>', // 分享图标
			success: function () {
			   layer.msg('分享成功!');
			   hideShare();
			},
		});
});

wx.error(function(res){
	isweixin_api = -1
	//alert(res.errMsg);
	console.log(res);
  // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。

});

</script>
