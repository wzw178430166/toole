<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php 
	$siteid = get_siteid();
	$SEO = seo($siteid);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<title><?php if(isset($SEO['title']) && !empty($SEO['title'])) { ?><?php echo $SEO['title'];?><?php } ?><?php echo $SEO['site_title'];?></title>
<meta name="description" content="<?php echo $SEO['description'];?>">
<meta name="keywords" content="<?php echo $SEO['keyword'];?>">
<link rel="apple-touch-startup-image" href="<?php echo SPATH;?>/mix/app/images/hui.jpg">
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>mix/app/css/style.css" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>mix/app/css/common.css" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>mix/app/css/index.css" />
<link rel="stylesheet" media="(min-width:640px)" href="<?php echo SPATH;?>mix/app/css/small.css" />
<link href="<?php echo SPATH;?>h_ui/css/H-ui.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="<?php echo SPATH;?>h_ui/css/iconfont.css">
<link href="favicon.ico" rel="shortcut icon">
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>global.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>documentTips.js"></script>
<!--<script type="text/javascript" src="<?php echo JS_PATH;?>slip.js"></script>-->

<style>
html{font-size:62.5% ;} 
@-webkit-keyframes delayimg_
{ from { opacity: 0.1;} to { opacity:1;} }
.delayimg{ -webkit-animation: delayimg_ .5s; }
</style>
<script>
var siteurl = '<?php echo siteurl(1);?>';
try{ jstojava.mysetgoback('goback()'); }catch(e){}

function in_array(search,array){
    for(var i in array){
        if(array[i]==search){
            return true;
        }
    }
    return false;
}
</script>
<script>
function delayimg(obj,callback_){
	var callback = function(data){};
	if(callback_){ callback = callback_;}
	var url = $(obj).attr('data-src');
	var img = new Image();

	img.onload=function(){		
		img.onload = null;
		callback(img);   
	}	
	obj.onload = null;
	obj.src = url;
	$(obj).addClass('delayimg');
}
</script>
</head>