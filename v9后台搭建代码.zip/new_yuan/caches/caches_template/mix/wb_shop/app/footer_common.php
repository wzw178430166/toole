<?php defined('IN_drcms') or exit('No permission resources.'); ?><script>
//$('a').click(function(){ if( $(this).attr('href') && $(this).attr('href')!='' && !$(this).attr('onClick')){ goo(this); } });
</script>

<script type="text/javascript" src="<?php echo JS_PATH;?>layer/1.9.3/layer.js"></script> 
<!--<script type="text/javascript" src="<?php echo SPATH;?>yz/app/js/alert.js"></script>-->
<script>
	
var index;
set_referer();
function appshare(url,title,content,auth,image){
	title = title? title : $(document).attr("title");
	url = url? url : window.location.href;
	try{
		jstojava.share("{'url':'"+url+"','title':'"+title+"','content':'','auth':'','image':''}");	
		//jstojava.share("{'url':'1212','title':'1212','content':'1212','auth':'1212','image':'1212'}");	
	}catch(e){

	}
}
function goback(url){
	var HTTP_REFERER = getCookie('r2')? decodeURIComponent(getCookie('r2')) : '';
	var m = getUrlParam('m');
	var a = getUrlParam('a');
	var c = getUrlParam('c');
	var t = getUrlParam('t');
	var url ='';
	
	try{
		jstojava.hide();
	}catch(e){}

	if(a=='show'){//内容页面跳列表页
		if(document.referrer){
			history.back();
		}else{
			url = siteurl+'/index.php?m=app';
		}
	}
	//alert(window.location.href+'---'+HTTP_REFERER);
	if(window.location.href == HTTP_REFERER || !HTTP_REFERER){
		url = url? url : siteurl+'/index.php?m=app';	
		var index = layer.load(0,{time: 100*1000});
		window.location.href = url;
		
	}else if(m=='number' && c=='yw' && (a=='' || in_array(a,Array('')))){
		
		var index = layer.load(0,{time: 100*1000});
		url = 'index.php?';
		window.location.href = url;
	}else{
		
		if(url!=''){
			var index = layer.load(0,{time: 100*1000});
			window.location.href = url;
		}else{
			
			history.back();
		}
	}
	return false;
}
function goo(url,title,w,h){ 
	
	url =  (typeof url=="object")? url.href : siteurl+'/'+url ;
	 
	w = w? w: '200px';
	h = h? h: '150px';
	title = title? title : '拼命加载中'; 

	var index = layer.load(0,{time: 100*1000});return;

	index = layer.open({
		type: 2,
		title: title,
		content: url,
		area: [w,h],
		//title: false, //不显示标题
	});
	//layer.full(index);
	return false;
}
function set_referer(){
	var r1 = getCookie('r1');
	var r2 = getCookie('r2');
	var url = encodeURIComponent(window.location.href);

	if(r2=='null' || url != r1){
		setCookie('r2',r1);　
		setCookie('r1',url);　	
	}
}
</script>