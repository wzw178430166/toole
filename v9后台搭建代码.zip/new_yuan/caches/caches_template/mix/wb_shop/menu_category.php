<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
	$db = pc_base::load_model('default_model');
    $db->load('pro_category');
    $cates = $db->select('','catid,catname,child,parent,node');
?>
<?php $n=1;if(is_array($cates)) foreach($cates AS $r) { ?>
<?php if($r['parent'] == 0) { ?>
<div class="banner_line">
	<?php 
        $node = explode(',',$r['node']);
        $node = array_filter($node);
    ?>
  <p>
  	<a href="<?php if($r['child']==0) { ?>index.php?m=ku_shop&c=index&a=lists&classify=<?php echo $r['catid'];?><?php } else { ?>javascript:;<?php } ?>">
    <img src="<?php echo SPATH;?>ku/images/banner_line<?php echo $n;?>.png"><?php echo $r['catname'];?>
    </a>
  </p>
  <?php if(!empty($node) && !in_array($r['catid'],$node)) { ?>
  <ul>
  	<?php $n=1;if(is_array($node)) foreach($node AS $rr) { ?>
    <li><a href="index.php?m=ku_shop&c=index&a=lists&classify=<?php echo $rr;?>"><?php echo $cates[$rr]['catname'];?></a></li>
    <?php } ?>
  </ul>
  <?php } ?>
</div>
<?php } ?>
<?php $n++;}unset($n); ?>