<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="footer">
	<div class="footer_top">
    	<div class="footer_top_box">
        	<ul>
            	<li>
                	<div class="footer_top_box_">
                    	<div class="footer_top_box_l fl">正</div>
                        <div class="footer_top_box_r fl">
                        	<p>正品保证</p>
                            <u>品牌授权正品保证，现货直发</u>
                        </div>
                    </div>
                </li>
                <li>
                	<div class="footer_top_box_">
                    	<div class="footer_top_box_l fl">包</div>
                        <div class="footer_top_box_r fl">
                        	<p>满额包邮</p>
                            <u>部分区域订单满一定金额免运费 </u>
                        </div>
                    </div>
                </li>
                <li>
                	<div class="footer_top_box_">
                    	<div class="footer_top_box_l fl">值</div>
                        <div class="footer_top_box_r fl">
                        	<p>增值税专用发票</p>
                            <u>可提供增值税专用发票</u>
                        </div>
                    </div>
                </li>
                <li>
                	<div class="footer_top_box_">
                    	<div class="footer_top_box_l fl">7</div>
                        <div class="footer_top_box_r fl">
                        	<p>7天购买保障</p>
                            <u>放心采购，售后无忧</u>
                        </div>
                    </div>
                </li>
                <li>
                	<div class="footer_top_box_">
                    	<div class="footer_top_box_l fl">货</div>
                        <div class="footer_top_box_r fl">
                        	<p>快捷付款，专人教学</p>
                            <u>线上付款，专人教你营销</u>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="footer_bot">
    	<div class="footer_bot1">
        	<ul>
            	<li><a href="javascript:;">关于我们</a></li>
                <li><a href="javascript:;">联系我们</a></li>
                <li><a href="javascript:;">怎么入驻</a></li>
                <li><a href="javascript:;">加入我们</a></li>
                <li><a href="javascript:;">广告合作</a></li>
            </ul>
        </div>
        <div class="footer_bot2">
        	<ul>
            	<li><a href="http://www.miitbeian.gov.cn">粤ICP备14564654号-8</a></li>
                <li>©&nbsp;版权所有&nbsp;广州唐剑科技有限公司</li>
                <li><a href="http://www.miitbeian.gov.cn">浙公网安备33010402000529号</a></li>
            </ul>
        </div>
        <div class="footer_bot3">
        	<ul>
            	<li><img src="<?php echo SPATH;?>ku/images/footer_bot3_1.png"></li>
                <li><img src="<?php echo SPATH;?>ku/images/footer_bot3_2.png"></li>
                <li><img src="<?php echo SPATH;?>ku/images/footer_bot3_3.png"></li>
                <li><img src="<?php echo SPATH;?>ku/images/footer_bot3_4.png"></li>
                <li><img src="<?php echo SPATH;?>ku/images/footer_bot3_5.png"></li>
            </ul>
        </div>
    </div>
</div>