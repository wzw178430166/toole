<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common2'); ?>
<link href="statics/ot/t_477/css/app_strategy_content.css" rel="stylesheet">
<style>
.strategy_content { padding:0px 10px;}
.news_title { width:100%; text-align:center; font-size:16px; color:#000; line-height:40px; border-bottom:1px solid #333;}
.new_content { font-size:13px; color:#1a1a1a; padding-top:10px;}
.new_content img { width:100%;}
</style>
</head>
<body>
<?php $pro_title = $title;?>
	<?php include template('wb_shop','header'); ?>
    <div style="height:45px;"></div>
	<div class="strategy_content">
    	<!--<div class="news_title"><?php echo $pro_title;?></div>-->
        <!--<img src="statics/bar/app/images/buyKnow.jpg" width="100%" style="margin-top:10px;">-->
        <div class="new_content">
        	<?php echo $content;?>
        </div>
    </div>
</body>
</html>
