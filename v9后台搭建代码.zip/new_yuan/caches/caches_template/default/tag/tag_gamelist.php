<?php defined('IN_drcms') or exit('No permission resources.'); ?><!--<div class="game_lieb">
  <div class="lieb_l">
    <img src="<?php echo SPATH;?>diy/images/yxtg_bt.jpg"/>
  </div>
  <div class="lieb_r">
    <ul>
      <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=d149192c5c1a6bd02c0a63d21281d0cb&action=lists&catid=6&order=id+DESC\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'6','order'=>'id DESC','num'=>'20','limit'=>'20',));}?>
      <?php $n=1; if(is_array($data)) foreach($data AS $n => $r) { ?>
      <li> <?php if($_SESSION['lock']) { ?>
        <a href="javascript:alert('没有权限对此操作');" title="<?php echo $r['title'];?>"> <?php } else { ?>
        <a href="<?php echo $r['url'];?>" title="<?php echo $r['title'];?>">
        <?php } ?> <span style="color:#000000;"><?php echo $r['title'];?></span>&nbsp;&nbsp;<span style="color:#666666;"><?php echo str_replace("|"," ",$r['server']);?></span></a>
      </li>
      <?php $n++;}unset($n); ?>
      <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
      <div class="cl">
      </div>
    </ul>
  </div>
</div>-->
