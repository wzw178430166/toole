<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.li1,.li2{background:none !important; padding:0 !important; display:block; float:right; line-height: 18px; height:18px;}
.li1{color:#999; line-height:23px; height:23px;}
.li2{font-size:16px; font-weight:bold; color:#F00; margin:1px 3px;}
</style>
<div style=" height:20px; line-height:20px;">
<li class="li1">人加入</li>
<li class="li2 contact_ren"></li>
<li class="li1">现在已有</li>
</div>
<script>
contact_ren("225489");
function contact_ren(Num){
var time=new Date().getTime();
time=(time-1490798000000)+"";
for(var i=0,str="",len=time.length-4;i<len;i++)
{
	//str+="<img src=\"<?php echo __PATH;?>statics/sun/images/"+time.substr(i,1)+".jpg\"  width=\"15\" height=\"17\" />";
	str+=time.substr(i,1);
}
$(".contact_ren").html(str);
delete time;
window.setTimeout("contact_ren()",10000);
}
</script>