<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<body>
<style>
.tiao{ margin-bottom:-13px; }
.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
.qrcode_wrapper .qrcode{position:fixed;top:50%;left:50%;z-index:9999;display:none;margin-top:-90px;margin-left:-90px;padding:10px;width:180px;height:180px;background-color:#fff;box-shadow:0 0 5px #aaa;_border:1px solid #eee}
a, a:hover {
  /* text-decoration: none; */
}
.sjia{ margin:0 0 15px 7px; width:200px; height:30px }
.xjtb{font-size:8px}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 商品管理
  <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a>
</nav>
<div class="pd-20">
  	<div class="searchForm">
    <form action="" id="searchForm" method="get">
    	<input type="hidden" name="m" value="wpm">
        <input type="hidden" name="c" value="wb_shop">
        <input type="hidden" name="a" value="init">
        <input type="hidden" name="search" value="1">
    	<div><font>条形码: </font><span><input type="text" name="barCode" id="barCode" value="<?php echo $barCode;?>"></span><input type="button" value="搜索" onClick="send_search()"></div>
    </form>
    </div>
    <div class="cl pd-5 bg-1 bk-gray mt-20 tiao"  >
      <span class="l">
     
        <a class="btn btn-primary radius" href="index.php?m=wpm&c=wb_shop&a=selCategory&wpm=1">
          <i class="Hui-iconfont">&#xe600;</i> 
        发布新商品
        </a>
       <?php if($this->memberinfo['username'] == $this->admin_username) { ?>
        <a class="btn btn-primary radius" href="index.php?m=wpm&c=wb_shop&a=categoryList">
          <i class="Hui-iconfont">&#xe600;</i> 分类管理
        </a>
        <?php } ?>
      </span>
    </div>
    <div class="mt-20">
      <div class="sjia">
        <a class="<?php if(!isset($_GET['t']) || $_GET['t'] == 99) { ?>lse<?php } else { ?>hse<?php } ?>" href="index.php?m=wpm&c=wb_shop&wpm=1&t=99" style="text-decoration:none; ">
        <b>已上架商品</b>
        </a>
        <a class="<?php if($_GET['t'] == 1) { ?>lse<?php } else { ?>hse<?php } ?>" href="index.php?m=wpm&c=wb_shop&wpm=1&t=1" style=" text-decoration:none; margin: 0 0 0 22px;" >
        <b>未上架商品</b>
        </a>
      </div>
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="13%" >商品主图</th>
            <th width="13%">商品名称</th>
            <th width="13%">在售价格</th>
            <th width="13%">库存</th>
            <th width="13%">更新时间</th>
            <th width="13%">分享</th>
            <th width="13%">操作</th>
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($goods)) { ?>
        <tr id="up_nodata"> <?php if($_GET['t']) { ?>
          <td colspan="8">暂无商品</td>
          <?php } else { ?>
          <td colspan="8">暂无上架商品</td>
          <?php } ?> </tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($goods)) foreach($goods AS $r) { ?>
        
        <tr id="order_<?php echo $r['id'];?>" class="text-c" >
          <?php 
          	$url = siteurl(1).'/index.php?m=wb_shop&a=show&catid='.$r['catid'].'&id='.$r['id'];
          ?>
          <td><a href="<?php echo $url;?>" target="_blank">
            <img style=" max-width:50%" src="<?php echo $r['thumb'];?>" alt=""></a></td>
          <td><a href="<?php echo $url;?>" target="_blank"><?php echo $r['title'];?></a></td>
          <td>¥<?php echo $r['jiage'];?> </td>
          <td><?php echo $kcData[$r['id']];?></td>
          <td><span><?php echo date('Y-m-d H:i',$r['inputtime']);?></span></td>
          <td>
          	<div class="qrcode_wrapper">
              <img src="<?php echo SPATH;?>wpm/images/qrcode_26.png" alt="二维码">
              <div class="qrcode" mlink="<?php echo $url;?>"> 
                <canvas width="180" height="180"></canvas>
              </div>
            </div>
            <div>
              <a href="index.php?m=wpm&c=drm&a=create_qrcode&url=<?php echo urlencode($url);?>">下载</a>
              <a tag="copy" href="javascript:void(0)" id="copy_btn_<?php echo $n;?>" class="lnk_copy" data-clipboard-text="<?php echo $url;?>"><i class="icon_file"></i>复制链接</a>
            </div></td>
          <td class="f-14 td-manage"> 
          	<?php if($_GET['t'] == 1) { ?>
            <a style="text-decoration:none" title="上架"  href="javascript:shangjia('<?php echo $r['id'];?>')"><b class="xjtb" > 上架</b></a>
            <?php } else { ?>
            <a style="text-decoration:none" class="ml-5"  onClick="xiajia('<?php echo $r['id'];?>')"  title="下架"><b class="xjtb" > 下架</b></a>
            <?php } ?>
            <a style="text-decoration:none" class="ml-5"  data-status="<?php echo $r['status'];?>" onClick="xjbj(this,'<?php echo $r['id'];?>')" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a>
            <a style="text-decoration:none" class="ml-5" onClick="axjia('index.php?m=wpm&c=wb_shop&a=del&id=<?php echo $r['id'];?>&t=<?php echo $_GET['t'];?>','确定删除该商品')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>    
  <div id="pages">
     <?php echo $pages;?>
  </div>
</div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 

<script type="text/javascript" src="<?php echo SPATH;?>js/ZeroClipboard/ZeroClipboard.js"></script>
<script type="text/javascript">
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
	 background: "#ffffff",
    text: $(qrcodes[i]).attr('mlink')
}); 
}
$(function(){
	$('.qrcode_wrapper').mousemove(function(){
		$(this).find('.qrcode').show();	
	}).mouseout(function(){
		$(this).find('.qrcode').hide();		
	});
	
})

//send search
function send_search(){
	var barCode = $('#barCode').val();
	if (!barCode) {
		layer.msg('请输入条形码!');
		return;
	}
	$('#searchForm').submit();
}

//下架
function xiajia(id) {
	layer.confirm('确定下架商品？', {
			btn: ['下架', '取消'],
	}, function(com) {
		layer.close(com);
		$.get('index.php?m=wpm&c=wb_shop&a=xiajia&ajax=1&status=1&id='+id,function(data){
			try{
				var da = $.parseJSON(data);
				if(da.status==1){
					$('#order_'+id).fadeOut(300);
				}
			}catch(e){ layer.alert('网络错误,请稍后再试'); return false;}	
	});});
}
//上架
function shangjia(id) {
	index = layer.load(2, {time: 30*1000});
	$.get('index.php?m=wpm&c=wb_shop&a=xiajia&ajax=1&status=99&id='+id,function(data){
		layer.close(index);
		try{
			var da = $.parseJSON(data);
			if(da.status==1){
				$('#order_'+id).fadeOut(300);
			}
		}catch(e){ layer.alert('网络错误,请稍后再试'); return false;}	
	});
}
//编辑
function xjbj(obj, id) {
	var status = $(obj).attr('data-status');
	if (status == 1) {
		//alert(222);return false;
		window.location.href = 'index.php?m=wpm&c=wb_shop&a=edit&id=' + id;
	} else if (status == 99) {
		layer.confirm('编辑前请先下架商品', {
			btn: ['下架编辑', '取消'],
		}, function(com) {
			layer.close(com);
			index = layer.load(2, {time: 30*1000});
			$.ajax({url:'index.php?m=wpm&c=wb_shop&a=xiajia&ajax=1&status=1&id='+id,success:function(data){
				layer.close(index);
				try{
					var da = $.parseJSON(data);
					if(da.status==1){
						
						window.location.href = 'index.php?m=wpm&c=wb_shop&a=edit&id=' + id;
					}
				}catch(e){ layer.alert('网络错误,请稍后再试'); return false;}	
			},error:function(){ layer.close(index); layer.alert('网络错误,请稍后再试'); }});
		});
	}
}
function xjia($url,$ts){
    if(confirm($ts)){
	
        window.location = $url;//跳转

    }else{
        return;
    }
}



function axjia($url,$ts){

    layer.confirm($ts,function(){
		window.location = $url;
	})
	
}
</script>
</body>
<script type="text/javascript">
window.onload = function(){
    init();
}
function init(){
	var ln_copy = $('.lnk_copy');
	ln_copy.each(function(i) {
        var clip = new ZeroClipboard.Client(); // 新建一个对象
		clip.setHandCursor( true );
		clip.setText($(ln_copy[i]).attr('data-clipboard-text')); // 设置要复制的文本。
		clip.addEventListener( "mouseUp", function(client) {
			alert("复制成功！");
		});
		// 注册一个 button，参数为 id。点击这个 button 就会复制。
		//这个 button 不一定要求是一个 input 按钮，也可以是其他 DOM 元素。
		clip.glue("copy_btn_" + (i+1)); // 和上一句位置不可调换
    });
    
}
</script>
</html>