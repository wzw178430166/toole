<?php defined('IN_drcms') or exit('No permission resources.'); ?> <?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>h_ui/app/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo SPATH;?>css/table_form.css" rel="stylesheet" type="text/css" />
<?php if(isset($show_validator)) { ?>
<script type="text/javascript" src="statics/js/formvalidator.js" charset="UTF-8"></script>
<script type="text/javascript" src="statics/js/formvalidatorregex.js" charset="UTF-8"></script>
<?php } ?>
<script type="text/javascript">
<!--
	var charset = '<?php echo CHARSET;?>';
	var uploadurl = "<?php echo pc_base::load_config('system','upload_url')?>";
//-->
</script>
<script language="javascript" type="text/javascript" src="statics/js/dialog.js"></script>
<script language="javascript" type="text/javascript" src="statics/js/content_addtop.js"></script>
<link href="<?php echo SPATH;?>wpm/css/admin_index.css" rel="stylesheet" type="text/css" />
<style>
.pd_wz { margin: 0 -1333px 0 0; }
#title { line-height: 24px; border: 1px solid #cccccc; font-family: "微软雅黑"; font-size: 14px; text-indent: 5px; overflow: hidden; }
.input-text { height: 29px; }
#start_time, #end_time { height: 25px; }
.measure-input { height: 25px; }
testarea#description { width: 100%; }
.DynarchCalendar-topCont { width: 30% }
.filed_tips { font-size:14px; margin-left:10px;}
.hide_field { display:none !important;}
.classifyInfo { height:25px; line-height:25px; margin-top:3px;}
.classifyInfo a {
	font-size: 0.8rem;
    color: #5A98DE;
    text-decoration: underline;	
}

.taxes-class-items a {
	display:block;
	float:left;
	padding: 3px 15px;
    margin: 0 10px 15px 0;
    border-radius: 4px;
	background-color: #D2D2D2;
    color: #fff;
}
.taxes-class-items a:hover { color:#fff;}
.taxes-class-items a.active {
	background-color: #FF9638;
}
.taxes-class-items { margin-top:10px;}
</style>

<body>
<div class="bnb_left fl" style="position: absolute; left: 9px; background-color: #FFF; z-index: 6;  <?php if($_GET['modelid']||$_GET['wu']) { ?>  display:none; <?php } ?>" id="zhanshi">
  <div class="item_t2">位置详解:</div>
  <img src="<?php echo SPATH;?>wpm/images/img9.jpg" class="simg" />
  <img src="<?php echo SPATH;?>wpm/images/img10.jpg" class="simg" />
</div>
<div class="bnb_right fl" style="width:76%; margin-left:315px;" id="addbox">
	<?php $hide_filed = array('catid');?>
  <form action="" method="post" class="form form-horizontal" id="form-article-add">
  <div class="row cl">
      <label class="form-label col-2">分类：</label>
      <div class="formControls col-10" <?php if($v['formtype'] == 'oparam') { ?>id="classify"<?php } ?>>
        <div class="classifyInfo">
           <span>
               <?php $nn = 1;?>
               <?php $n=1;if(is_array($shopCate)) foreach($shopCate AS $r) { ?>
                <?php echo $cates[$r]['catname'];?><?php if($nn < count($shopCate)) { ?>&gt;&gt;<?php } ?>
               <?php $nn++;?>
               <?php $n++;}unset($n); ?>
           </span>
           <a href="index.php?m=wpm&c=wb_shop&a=selCategory&wpm=1&forward=<?php echo urlencode('index.php?m=wpm&c=wb_shop&a=edit&id='.$id);?>">切换分类</a>
        </div>
     </div>
    </div>
    <div class="row cl">
      <label class="form-label col-2">关税物品归类：</label>
      <div class="formControls col-10" style="padding-top:7px;">
        <div class="taxes-class-box">
        	<?php include template('wpm','taxesClass'); ?>
        </div>
     </div>
    </div>
    <?php $n=1; if(is_array($forminfos)) foreach($forminfos AS $k => $v) { ?>
    <?php if(!in_array($k,array('classify','taxes_class'))) { ?>
    <div class="row cl <?php if(in_array($k, $hide_filed)) { ?>hide_field<?php } ?>">
      <label class="form-label col-2"><?php echo $v['name'];?>：</label>
      <div class="formControls col-10">
       <?php echo $v['form'];?><?php if($v['tips']) { ?><span class="filed_tips"><?php echo $v['tips'];?></span><?php } ?>
      </div>
    </div>
    <?php } ?>
    <?php $n++;}unset($n); ?> 
    <div class="row cl">
      <div class="col-10 col-offset-2">
        <input type="button" onClick="article_save_submit();" name="dosubmit" value="提交" class="btn btn-primary radius" />
        <button onClick="layer_close();" class="btn btn-default radius" type="button">&nbsp;&nbsp;取消&nbsp;&nbsp;</button>
      </div>
    </div>
    <input type="hidden" name="info[stars]" id="stars_★☆☆☆☆" value="★☆☆☆☆">
    <input name="id" type="hidden" value="<?php echo $id;?>">
    <input name="info[dp_id]" type="hidden" value="<?php echo $this->memberinfo['userid']?>">
    <input name="info[status]" type="hidden" value="99">
    <input type="hidden" name="info[classify]" id="classify_" value="<?php echo $classify;?>">
    <input name="dosubmit" type="hidden" value="1">
    <input type="hidden" name="info[catid]" value="<?php echo $catid;?>" />
    <input name="forward" type="hidden" value="index.php?m=wpm&c=wb_shop">
  </form>
</div>
</body>
<script type="text/javascript">
      
$(function(){
	var a = document.body.clientWidth;	
	if(a<1100){
		window.setTimeout(function(){
			$('#zhanshi').css('left','-330px');
			$('#addbox').css('margin-left','0px');
			window.setTimeout(function(){
				$('#zhanshi').hide();
			},300);
		},2000);	
	}
	
})

function article_save_submit () {
	if ($('.hide_field').css('display') == 'block') {
		var is_empty = false;
		var attr_class = $('.bgblue').find('input[type="text"]');
		
		attr_class.each(function(i) {
			if ($(this).val() == '') {
				is_empty = true;
			}
		});
		
		if (is_empty == true) {
			alert('请填写完整的属性信息!');
			return;
		}
	}
	
	$('#form-article-add').submit();
}
/*var cateLevel = 1;
function getCateItem(obj){
	var pid = $(obj).val();
	if (!pid) {
		layer.msg('参数错误!');
		return;
	}
	setClassInput(pid);
	$.get('index.php?m=wpm&c=wb_shop&a=getCateItem&pid='+pid+'&ajax=1',function(data){
		if (data.status == 1) {
			if ($(obj).attr('data-val') == 1) {
				//reset first cate
				$('#cateItems').empty();
			}
			
			if (cateLevel == $(obj).attr('data-val')) {
				cateLevel+=1;
			} else {
				//重新选择处理
				var currentIndex = $(obj).attr('data-val');
				var emptyTime = cateLevel - currentIndex;
				for(var i=(currentIndex+1);i<=cateLevel;i++){
					$('#classify'+i).remove();
				}
			}
			var html_ = '<select id="classify"'+cateLevel+' data-val="'+cateLevel+'" style="margin-right:5px" onChange="getCateItem(this)"><option value="0">请选择</option>';
			var info = data.info;
			for(var i in info){
				html_+= '<option value="'+info[i].catid+'">'+info[i].catname+'</option>';
			}
			html_ + '</select>';
			if ($('#classify'+cateLevel)) {
				$('#classify'+cateLevel).remove();
			}
			$('#cateItems').append(html_);
		}
	},'json');
}
function setClassInput(val) {
	$('#classify_').attr('value',val);
}*/
</script>
</html>