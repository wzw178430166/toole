<?php defined('IN_drcms') or exit('No permission resources.'); ?><script type="text/javascript" src="statics/h_ui/js/H-ui.js"></script> 
<script type="text/javascript" src="statics/h_ui/js/H-ui.admin.js"></script> 

<script type="text/javascript" src="statics/h_ui/lib/bootstrap-modal/2.2.4/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="statics/h_ui/lib/bootstrap-modal/2.2.4/bootstrap-modal.js"></script>


