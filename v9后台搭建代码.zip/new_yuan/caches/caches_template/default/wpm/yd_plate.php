<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>wpm/css/admin_index.css" rel="stylesheet" type="text/css" />
<style>
.bottom_nav_bar {
    width: 1015px;
}

</style>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 商城管理 <span class="c-gray en">&gt;</span> 店铺装修 
<a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" >
  <i class="Hui-iconfont">&#xe68f;</i>
  </a></nav>

<div class="main_index">
  
  <div class="pd-20">
  <div class="cl pd-5 ">
        <span class="l" style=" margin:0 0 -32px 21px">
        <a class="btn btn-success radius" onClick=""  href="index.php?m=wpm&c=wb_shop&a=ren_pc&wpm=1">
        PC版装修
        </a>
        </span>
      </div>
  </div>
  <div class="bottom_nav_bar">
    <div class="bnb_left fl" style="margin-right:0px;">
      <img src="<?php echo SPATH;?>wpm/images/img12.jpg" class="simg" />
    </div>
    <div class="bnb_right fl">
      <div class="bnb_info_box">
        <div class="yd_div1">
          <div class="yd_line fl">
          </div>
          <div class="yd_link_div fl">
            <a href="index.php?m=wpm&c=wb_shop&a=adv_edit_home&tmp=adv_edit_home&wpm=1&tmp_id=1&dw_id=1" class="yd_btn">添加轮播</a>
          </div>
        </div>
        
        <div class="yd_div2" style=" margin:332px 0 0 0px ">
          <div class="yd_line fl">
          </div>
          <div class="yd_link_div fl">
            <a href="index.php?m=wpm&c=wb_shop&a=adv_edit_home&tmp=adv_edit&wpm=1&tmp_id=1&dw_id=2" class="yd_btn">添加左侧广告位</a>
          </div>
        </div>
        <div class="yd_div2" style=" margin:20px 0 0 0px ">
          <div class="yd_line fl">
          </div>
          <div class="yd_link_div fl">
            <a href="index.php?m=wpm&c=wb_shop&a=adv_edit_home&wpm=1&tmp=adv_edit&tmp_id=1&dw_id=3" class="yd_btn">添加右侧广告位</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>