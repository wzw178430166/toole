<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php defined('IN_ADMIN') or exit('No permission resources.'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"<?php if(isset($addbg)) { ?> class="addbg"<?php } ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>" />
<meta http-equiv="X-UA-Compatible" content="IE=7" />
<title><?php echo L('website_manage');?></title>
<link href="<?php echo CSS_PATH?>reset.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH.SYS_STYLE;?>-system.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH?>table_form.css" rel="stylesheet" type="text/css" />
<link href="<?php echo SPATH;?>h_ui/css/H-ui.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo CSS_PATH?>dialog.css" rel="stylesheet" type="text/css" />

<!--文件上传插件-->
<link href="<?php echo SPATH;?>wpm/css/admin_index.css" rel="stylesheet" type="text/css" />
<link type="text/css" rel="stylesheet" href="<?php echo JS_PATH;?>diyUpload/css/webuploader.css" />
<!---->
<!--文件上传样式-->
<style>
.webuploader-pick img { width: 0; height: 0; }
.parentFileBox ul.fileBoxUl li { margin: 0; }
.block { display: block }
.none { display: none }
.diyCancel { z-index: 9999 !important; display: block !important; }
.parentFileBox { position: absolute; left: 0; top: 0; width: 142px !important; }
.logourl_tip { width: 220px;
    float: left;
    color: #808080;
    margin-top: 70px;
    position: absolute;
    left: 286px; }
</style>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH?>dialog.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo CSS_PATH?>style/<?php echo SYS_STYLE;?>-styles1.css" title="styles1" media="screen" />
<link rel="alternate stylesheet" type="text/css" href="<?php echo CSS_PATH?>style/<?php echo SYS_STYLE;?>-styles2.css" title="styles2" media="screen" />
<link rel="alternate stylesheet" type="text/css" href="<?php echo CSS_PATH?>style/<?php echo SYS_STYLE;?>-styles3.css" title="styles3" media="screen" />
<link rel="alternate stylesheet" type="text/css" href="<?php echo CSS_PATH?>style/<?php echo SYS_STYLE;?>-styles4.css" title="styles4" media="screen" />
<script type="text/javascript" src="statics/js/jquery-1.8.3.min.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH?>content_addtop.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH?>admin_common.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH?>styleswitch.js"></script>
</head>
<body>
<style type="text/css">
	html{_overflow-y:scroll}
</style>
<style>
.question_box_w { line-height: 35px; }
.vm { margin-right: 5px; vertical-align: middle; }
.question_box ul a.list_del { width: 24px; height: 24px; margin: 3px 0 0; color: #f00; font: 22px/24px microsoft yahei; }
.field_tips { font-size:14px; color:red;}
.send_btn a {
	display: block;
    width: 15%;
    text-align: center;
    height: 30px;
    line-height: 30px;
    border-radius: 4px;
    border: 1px #222 solid;
    background-color: #222222;
    color: #fff;
    margin-top: 5px;	
}
</style>

<body>
<div class="pd-10"<div class="pd-10"

<div class="pd-10">
  <form action="" method="post" name="myform" id="myform">
   <input type="hidden" name="dosubmit" value="1"/>
    <table cellpadding="2" cellspacing="1" class="table_form" width="100%">
    <?php $filter_arr = array('coupon','kefu','addtime');?>
    <?php foreach($forminfos as $k=>$v):?>
    	<?php if(!in_array($k,$filter_arr)):?>
		<tr>
			<td width="100"><?php echo $v['name']?></td> 
			<td><?php echo $v['form']?></td>
		</tr>
        <?php endif;?>
	<?php endforeach;?>
    </table>
    <div class="send_btn">
    	<a href="javascript:;" onclick="$('#myform').submit();">保存</a>
    </div>
  </form>
</div>
</div>
<?php include template($this->file,'js_common', 'first'); ?> 
</body>
</html>