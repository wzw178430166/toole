<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8" />
<meta name="renderer" content="webkit|ie-comp|ie-stand" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta name="keywords" content="<?php echo $this->Company['keywords'];?>">
<meta name="description" content="<?php echo $this->Company['description'];?>">
<?php if($nocache) { ?>
<meta http-equiv="Expires" content="0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-control" content="no-cache">
<meta http-equiv="Cache" content="no-cache">
<?php } ?>
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/html5.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/respond.min.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/PIE_IE678.js"></script>
<![endif]-->
<link href="statics/h_ui/css/H-ui.min.css" rel="stylesheet" type="text/css" />
<link href="statics/h_ui/css/H-ui.admin.css" rel="stylesheet" type="text/css" />
<link href="statics/h_ui/skin/default/skin.css" rel="stylesheet" type="text/css" id="skin" />
<link href="statics/h_ui/lib/Hui-iconfont/1.0.1/iconfont.css" rel="stylesheet" type="text/css" />
<link href="statics/h_ui/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="statics/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="statics/js/layer/1.9.3/layer.js"></script> 
<!--[if IE 6]>
<script type="text/javascript" src="stitics/js/PNG.js" ></script>
<script>DD_belatedPNG.fix('*');</script>
<![endif]-->
<title>商家后台</title>
<style>
a:link{ text-decoration:none}
#pages { padding:14px 0 10px;font-family:宋体; text-align:right}
#pages a { display:inline-block; height:22px; line-height:22px; background:#fff; border:1px solid #e3e3e3; text-align:center; color:#333; padding:0 10px}
#pages a.a1 { background:url(statics/images/admin_img/pages.png) no-repeat 0 5px; width:56px; padding:0 }
#pages a:hover { background:#f1f1f1; color:#000; text-decoration:none; }
#pages span { display:inline-block; height:22px;padding:0 10px; line-height:22px; background:#5a85b2; border:1px solid #5a85b2; color:#fff; text-align:center; }
.page .noPage { display:inline-block; height:22px; line-height:22px; background:url(../img/icu/titleBg.png) repeat-x 0 -55px ; border:1px solid #e3e3e3; text-align:center; color:#a4a4a4; }	
</style>
<script>
var siteurl="http://shop.weiweibb.com/";
</script>
</head>
