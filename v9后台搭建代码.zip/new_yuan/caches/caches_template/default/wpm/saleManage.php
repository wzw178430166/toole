<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.fl { float:left;}
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia {margin-bottom: 15px;}
.xjtb{font-size:8px}
.DynarchCalendar-topCont { width:20%;}
.fahuo_box { width:400px; padding:15px 10px; display:none; position:fixed; left:50%; margin-left:-200px; top:50px; z-index:99; background-color:#fff; border-radius:4px;}
.black_box { width:100%; height:100%; position:fixed; left:0; top:0; background-color:#333; opacity:0.3; display:none;}
.fahuo_box p {
	width: 95%;
    height: 35px;
    line-height: 35px;
    margin: 0 auto;
    border: 1px #D8D8D8 solid;
    border-radius: 4px;
    margin-bottom: 10px;	
}
.fahuo_box p input {
	width: 100%;
    height: 100%;
    border: 0;
    float: left;
	text-indent:10px;	
}
.fahuo_box .fahuo_btn a {
	display: block;
    width: 40%;
    /* float: left; */
    height: 35px;
    line-height: 35px;
    /* border: 1px #D8D8D8 solid; */
    text-align: center;
    font-size: 15px;
    background-color: #519151;
    border-radius: 4px;
    color: #fff;	
}
.searchInput {
	margin: 0 10px;
    border: 1px #A0A0A0 solid;
    height: 20px;
    width: 150px;	
}
.searchBox { width:60%; float:left;}
.searchBox select, .searchBox input{ margin:0 10px;}
.searchBox strong {
	width: 90px;
    display: block;
    float: left;
    text-align: right;	
}
.my_btn { margin-top:20px;}
.table-bg thead th { background-color: #F9F9F9; padding:0; padding-top:8px; padding-bottom:8px; vertical-align: top;}
.orderItem {
	margin-top: 5px;
    border: 1px #eee solid;	
}
.itemContent { overflow:hidden; padding:10px 0; font-size:13px;}
.itemTitle {
	padding: 10px;
    border-bottom: 1px #eee solid;
    background-color: rgb(245, 250, 254);
    font-size: 13px;	
}
.itemInfos { width:61.5%; float:left; overflow:hidden; border-right: 1px #eee solid;}
.itemGoods { width:100%; overflow:hidden; }
.itemGoodsImg {
	width: 12%;
    text-align: center;
    float: left;	
}
.itemGoodsImg img { width:80%;}
.itemGoodsInfo {
	width: 58%;
    float: left;	
}
.itemGoodsInfo p { margin:0;}
.itemGoodsInfo p,.itemGoodsInfo p span { font-size:12px;}
.itemGoodsPrice, .itemGoodsCount {
	float: left;
    width: 15%;
    text-align: center;	
}
.itemBuy, .itemPayType { 
	float: left;
    width: 12.7%;
	text-align:center;
	border-right: 1px #eee solid;
}
.itemPayType:last-child { border-right:0; width:12.7%;}
.itemPayType p { margin-bottom:5px;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>发货管理 <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="pd-20">

	<form action="" method="get">
    <input type="hidden" name="m" value="wpm">
    <input type="hidden" name="c" value="wb_shop">
    <input type="hidden" name="a" value="saleManage">
	  <div class="searchBox"> 
      	<p style="overflow:hidden;">
            <strong>订单号：</strong><input type="text" name="orderid" class="searchInput fl" value="<?php echo $orderid;?>">
            <strong>收货人名称：</strong><input type="text" name="contactname" class="searchInput fl" value="<?php echo $contactname;?>">
	    </p>
        <p style="overflow:hidden;">
        <strong>状态：</strong>
        <select name="status" class="fl">
        	<option value="0">全部</option>
            <option value="2" <?php if($status == 2) { ?>selected="selected"<?php } ?>>待发货</option>
            <option value="3" <?php if($status == 3) { ?>selected="selected"<?php } ?>>待收货</option>
        </select>
        <strong>成交时间：</strong>
	    <?php echo form::date('start_time', $start_time)?> - <?php echo form::date('end_time', $end_time)?>
        
	    </p>
	  </div>
      <input class="btn btn-success radius my_btn" type="submit" name="dosubmit" value="搜索" />
	</form>
 	<div style="clear:both;"></div>
    <div class="mt-20">
		<!--<div class="sjia">
		  <a class="<?php if($_GET['status']==2) { ?>lse<?php } else { ?>hse<?php } ?>" href="index.php?m=wpm&c=wb_shop&a=saleManage&wpm=1&status=2"style="  text-decoration:none; margin: 0 0 0 22px;" >  <b>待发货</b> </a>  
		  <a class="<?php if($_GET['status']==3) { ?>lse<?php } else { ?>hse<?php } ?>" href="index.php?m=wpm&c=wb_shop&a=saleManage&wpm=1&status=3"style=" text-decoration:none; margin: 0 0 0 22px;" >  <b>待收货</b> </a>
		</div>-->
      <!--content start-->
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="37%">商品</th>
            <th width="8%">单价</th>
            <th width="8%">数量</th>
            <th width="11%">买家</th>
            <th width="11%">订单状态</th>
            <th width="11%">实收款</th>
          </tr>
        </thead>
        <tbody>
          </tbody>
        
      </table>
      <div class="orderItems">
      	<?php $n=1; if(is_array($goods)) foreach($goods AS $k => $r) { ?>
        <?php 
        	if ($r['info']['status'] == 3) {
            	$wuliuinfo = string2array($r['info']['logistics']);
                $wuliu = $wuliuinfo['wuliu'];
                $wl_order = $wuliuinfo['wl_order'];
            }
            $k = base64_encode($k);
        ?>
      	<div class="orderItem" id="orderItem_<?php echo $k;?>" data-wuliu="<?php echo $wuliu;?>" data-wl_order="<?php echo $wl_order;?>">
        	<div class="itemTitle">
            	<span style=" margin-right:40px;">订单号: <?php echo $r['info']['orderid'];?></span>
                <span>成交时间: <?php echo date('Y-m-d H:i:s',$r['info']['addtime']);?></span>
            </div>
            <div class="itemContent">
            	<div class="itemInfos">
                    <?php $n=1;if(is_array($r['item'])) foreach($r['item'] AS $rr) { ?>
                    <div class="itemGoods">
                        <div class="itemGoodsImg"><img src="<?php echo $snapshot[$rr['id']]['thumb'];?>"></div>
                        <div class="itemGoodsInfo">
                            <p><?php echo $snapshot[$rr['id']]['goodstitle'];?></p>
                            <p>
                                <span><?php echo $snapshot[$rr['id']]['attribute'];?></span>
                            </p>
                        </div>
                        <div class="itemGoodsPrice">￥<?php echo number_format($snapshot[$rr['id']]['jiage'],2);?></div>
                        <div class="itemGoodsCount"><?php echo $rr['count'];?></div>
                    </div>
                    <?php $n++;}unset($n); ?>
               	</div>
                <div class="itemBuy"><?php echo $r['info']['username'];?></div>
                <div class="itemPayType">
                	<?php 
                    	switch($r['info']['status']){
                        	case 1:
                            	$msg = '等待买家付款';
                            	break;
                            case 2:
                            	$msg = '买家已付款';
                            	break;
                            case 3:
                            	$msg = '待收货';
                            	break;
                            case 4:
                            	$msg = '退款退货中';
                            	break;
                            case 5:
                            	$msg = '待评价';
                            	break;
                            case 98:
                            	$msg = '交易关闭';
                            	break;
                            case 99:
                            	$msg = '交易完成';
                            	break;
                        }
                    ?>
                    <p><font style="color:#FF4B00"><?php echo $msg;?></font></p>
                    <p><a href="javascript:;">详情</a></p>
                    <p>
                    	<?php if($r['info']['status'] == 2) { ?><a href="javascript:;" class="actionBtn" onClick="fahuo('<?php echo $k;?>',1)">发货</a><?php } ?>
                        <?php if($r['info']['status'] == 1) { ?><a href="javascrip:;" onClick="updateOrderStatus('<?php echo $k;?>',98);">关闭交易</a><?php } ?>
                    </p>
                </div>
                <div class="itemPayType">
                	￥<?php echo number_format($r['info']['pay_money'],2);?><br/>
                    (含运费:￥<?php echo number_format($r['info']['yun_fei'],2);?>)<br/>
                	<a href="javascript:;">修改价格</a>
                </div>
            </div>
        </div>
      	<?php $n++;}unset($n); ?>
      </div>
      <!--content end-->
    </div>
  <div style=" margin-top:20px; float:left"   id="pages">
  	 <?php echo $pages;?>
  </div>
 
</div>
<div class="fahuo_box" id="fahuo_box">
	<input type="hidden" id="sk" value="">
	<div class="fahuo_main">
    	<p style="border:0;">
        	<font style=" margin-right:10px;">物流渠道</font>
            <select id="wuliu" style=" width:150px;">
            	<option value="0">请选择</option>
                <?php $n=1;if(is_array($user_logist)) foreach($user_logist AS $r) { ?>
                <?php if($r) { ?><option value="<?php echo $logist[$r]['itfname'];?>"><?php echo $logist[$r]['name'];?></option><?php } ?>
                <?php $n++;}unset($n); ?>
            </select>
        <!--<input type="text" id="wuliu" placeholder="请输入物流渠道"/></p>-->
        <p><input type="text" id="wl_order" placeholder="请输入运单号"/></p>
    </div>
    <div class="fahuo_btn">
    	<a href="javascrip:;" onClick="fahuo('',2)" style="float:left; margin-left:20px;">确定</a>
        <a href="javascrip:;" onClick="fahuo('',3)" style="float:right;margin-right:20px; background-color:#D8D8D8">关闭</a>
    </div>
</div>
<div class="black_box" id="black_box"></div>
<?php include template($this->file,'js_common'); ?>
<script>

function updateOrderStatus(sk,st){
	switch(st){
		case 1:
			var tips = '是否关闭该订单?';
			break;
	}
	layer.alert(tips,{btn:['确定','取消']},function(){
		var url = '?m=wpm&c=wb_shop&a=updateOrderStatus&ajax=1&sk='+sk+'&st='+st;
		$.get(url,function(data){
			if (data.status == 1) {
				layer.msg('操作成功',{time:1500});
				setTimeout(function(){
					window.location.reload();	
				},1500);
			}else {
				layer.msg('网络错误,请稍后再试!');	
			}
		},'json');
	});
	
}

//发货
function fahuo(id,ac) {
	if(!ac || ac==1){
		$('#fahuo_box').fadeIn();
		$('#black_box').fadeIn();
		$('#sk').attr('value',id);
	}else if(ac==2){
		index = layer.load(2, {time: 30*1000});
		$.post('index.php?m=wpm&c=wb_shop&a=fahuo&ajax=1&sk='+$('#sk').val(),{'wuliu':$('#wuliu').val(),'wl_order':$('#wl_order').val()},function(data){
			layer.close(index);
			try{
				var da = $.parseJSON(data);
				if(da.status==1){
					layer.msg('保存成功',{time:1500});
					setTimeout(function(){
						window.location.reload();
					},1500);
					
				}
			}catch(e){ layer.alert('网络错误,请稍后再试'); return false;}	
		});
	}else if(ac==3){
		//关闭
		$('#fahuo_box').fadeOut();
		$('#black_box').fadeOut();
	} else if(ac==4){
		//查看物流
		fahuo(id);
		$('#wuliu').attr('value',$('#order_'+id).attr('data-wuliu'));
		$('#wl_order').attr('value',$('#order_'+id).attr('data-wl_order'));
	}
}
</script>
</body>
</html>