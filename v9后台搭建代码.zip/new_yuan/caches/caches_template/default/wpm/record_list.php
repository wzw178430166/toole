<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.fl { float:left;}
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.green { color: #00C00F; }
.gray { color: gray; }
.red { color: red; }
.data_item {
	display: block;
    height: 4px;
	margin-bottom:1px;
}
.tu_item {
	width:90px;
	float:left;
	margin-top:8px;
	margin-left:5px;
}
.tu_desc p { overflow:hidden;}
.tu_desc p font { float:left;}
.ling { background-color:#cacaca;}
.no_use { background-color:#FFC99A}
.use { background-color:#25F351}
.promote_way {
	padding:3px;
	background-color:#32BBEE;
	color:#fff;	
}
.table-bg thead th {
    background-color: #F9F9F9;
    padding: 0;
    padding-top: 8px;
    padding-bottom: 8px;
    vertical-align: top;
}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>优惠券列表 <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="pd-20">
	<?php if(1>3) { ?>
	<form action="" method="get">
    <input type="hidden" name="m" value="wpm">
    <input type="hidden" name="c" value="wb_shop">
    <input type="hidden" name="a" value="shop_order">
	  <div class="searchBox"> 
      	<p style=" overflow:hidden;">
            <strong>订单号：</strong><input type="text" name="orderid" class="searchInput fl" value="<?php echo $orderid;?>">
            <strong>商品名称：</strong><input type="text" name="goodstitle" class="searchInput fl" value="<?php echo $goodstitle;?>">
	    </p> 
        <p style=" overflow:hidden;">
        <strong>交易状态：</strong>
        <select name="status" class="fl">
        	<option value="0">全部</option>
            <option value="1" <?php if($status == 1) { ?>selected="selected"<?php } ?>>待付款</option>
            <option value="2" <?php if($status == 2) { ?>selected="selected"<?php } ?>>待发货</option>
            <option value="3" <?php if($status == 3) { ?>selected="selected"<?php } ?>>待收货</option>
            <option value="4" <?php if($status == 4) { ?>selected="selected"<?php } ?>>退款退货中</option>
            <option value="98" <?php if($status == 98) { ?>selected="selected"<?php } ?>>交易关闭</option>
            <option value="99" <?php if($status == 99) { ?>selected="selected"<?php } ?>>交易成功</option>
        </select>
        <strong>支付方式：</strong>
        <select name="paytype" class="fl">
        	<option value="0">全部</option>
            <option value="alipay" <?php if($paytype == 'alipay') { ?>selected="selected"<?php } ?>>支付宝</option>
            <option value="wechat" <?php if($paytype == 'wechat') { ?>selected="selected"<?php } ?>>微信</option>
        </select>
        </p>
        <p style=" overflow:hidden">
        <strong>成交时间：</strong>
	    <?php echo form::date('start_time', $start_time)?>
	    -
	    <?php echo form::date('end_time', $end_time)?>
	    </p>
	    
	  </div>
      <input class="btn btn-success radius my_btn" type="submit" name="dosubmit" value="搜索" />
	</form>
    <?php } ?>
 	<div style="clear:both;"></div>
    
    <div class="mt-20">
		
      <table width="100%" cellspacing="0" class="table table-border table-bordered table-bg table-hover table-sort">
        <thead>
          <tr class="text-c">
            <th align="center">券号</th>
            <th align="center">来源</th>
            <th align="center">用户名</th>
            <th align="center">类型</th>
            <th align="center">时间</th>
            <th align="center">订单号(使用优惠券)</th>
            <th align="center">操作</th>
          </tr>
        </thead>
        <tbody>
         <?php if(!empty($records)):?>
         <?php foreach($records as $v):?>
          <tr id="coupon_<?php echo $v['id']; ?>">
			<td align="center">
				<?php echo $v['cid'];?>
            </td>
            <td align="center">
				<?php echo $v['origin'];?>
            </td>
            <td align="center">
				<?php echo $v['username'];?>
            </td>
            <td align="center">
            	<?php 
					switch($v['type']){
						case 'get':
							$type = '领取';
							break;
						case 'using':
							$type = '使用中';
							break;
						case 'use':
							$type = '已使用';
							break;
						case 'delete':
							$type = '已删除';
							break;
					}
					echo $type;
				?>
            </td>
            <td align="center">
            	<?php echo date('Y-m-d H:i:s',$v['addtime']);?>
            </td>
            <td align="center"><?php if($v['orderid']){ echo $v['orderid'];}?></td>
         
            <td align="center">
                <a href="javascript:;" class="action_btn" onClick="delete('<?php echo $v['id'];?>')">删除</a>
            </td>
          </tr>
          <?php endforeach;?>
          <?php endif;?>
        </tbody>
      </table>
      
    </div>
  <div style=" margin-top:20px; float:left"   id="pages">
  	 <?php echo $pages;?>
  </div>
</div>
</body>
<script>

</script>
</html>