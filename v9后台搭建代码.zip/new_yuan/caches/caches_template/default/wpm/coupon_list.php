<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.fl { float:left;}
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.green { color: #00C00F; }
.gray { color: gray; }
.red { color: red; }
.data_item {
	display: block;
    height: 4px;
	margin-bottom:1px;
}
.tu_item {
	width:90px;
	float:left;
	margin-top:8px;
	margin-left:5px;
}
.tu_desc p { overflow:hidden;}
.tu_desc p font { float:left;}
.ling { background-color:#cacaca;}
.no_use { background-color:#FFC99A}
.use { background-color:#25F351}
.promote_way {
	padding:3px;
	background-color:#32BBEE;
	color:#fff;	
}
.table-bg thead th {
    background-color: #F9F9F9;
    padding: 0;
    padding-top: 8px;
    padding-bottom: 8px;
}
.data_box { width:200px; height:100px; position: fixed; left:50%; top:50%; margin-left:-100px; margin-top:-50px; display:none; border:1px #ccc solid; border-radius:4px; background-color:#fff;}
.data_box_main {
	padding: 10px;
    width: 180px;
    height: 80px;
    float: left;	
}
.data_box_main p { height:20px; line-height:20px; margin:0;}
.data_box_main span { float:right;}
.table-bordered td { text-align:center;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>优惠券列表 <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="pd-20">
	<?php if(1>3) { ?>
	<form action="" method="get">
    <input type="hidden" name="m" value="wpm">
    <input type="hidden" name="c" value="wb_shop">
    <input type="hidden" name="a" value="shop_order">
	  <div class="searchBox"> 
      	<p style=" overflow:hidden;">
            <strong>订单号：</strong><input type="text" name="orderid" class="searchInput fl" value="<?php echo $orderid;?>">
            <strong>商品名称：</strong><input type="text" name="goodstitle" class="searchInput fl" value="<?php echo $goodstitle;?>">
	    </p> 
        <p style=" overflow:hidden;">
        <strong>交易状态：</strong>
        <select name="status" class="fl">
        	<option value="0">全部</option>
            <option value="1" <?php if($status == 1) { ?>selected="selected"<?php } ?>>待付款</option>
            <option value="2" <?php if($status == 2) { ?>selected="selected"<?php } ?>>待发货</option>
            <option value="3" <?php if($status == 3) { ?>selected="selected"<?php } ?>>待收货</option>
            <option value="4" <?php if($status == 4) { ?>selected="selected"<?php } ?>>退款退货中</option>
            <option value="98" <?php if($status == 98) { ?>selected="selected"<?php } ?>>交易关闭</option>
            <option value="99" <?php if($status == 99) { ?>selected="selected"<?php } ?>>交易成功</option>
        </select>
        <strong>支付方式：</strong>
        <select name="paytype" class="fl">
        	<option value="0">全部</option>
            <option value="alipay" <?php if($paytype == 'alipay') { ?>selected="selected"<?php } ?>>支付宝</option>
            <option value="wechat" <?php if($paytype == 'wechat') { ?>selected="selected"<?php } ?>>微信</option>
        </select>
        </p>
        <p style=" overflow:hidden">
        <strong>成交时间：</strong>
	    <?php echo form::date('start_time', $start_time)?>
	    -
	    <?php echo form::date('end_time', $end_time)?>
	    </p>
	    
	  </div>
      <input class="btn btn-success radius my_btn" type="submit" name="dosubmit" value="搜索" />
	</form>
    <?php } ?>
 	<div style="clear:both;"></div>
    <div class="tu_desc">
        <p><font>已领取: </font><span class="data_item tu_item ling" data-val="user"></span></p>
        <p><font>未使用: </font><span class="data_item tu_item no_use" data-val="user"></span></p>
        <p><font>已使用: </font><span class="data_item tu_item use" data-val="user"></span></p>
     </div>
    <div class="mt-20">
		<a href="javascript:;" onClick="showCouponAdd()">添加优惠券</a>
      <table width="100%" cellspacing="0" class="table table-border table-bordered table-bg table-hover table-sort">
        <thead>
          <tr class="text-c">
            <th align="center">名称</th>
            <th align="center">领取链接</th>
            <th align="center">面额</th>
            <th align="center">时间</th>
            <th align="center">限领/人</th>
            <th align="center">条件</th>
            <th align="center">发行量</th>
            <th align="center">已领取</th>
            <th align="center">使用数据</th>
            <th align="center">
            	<select name="status">
                	<option value="0">全部</option>
                    <option value="ok">领取中</option>
                    <option value="forbidden">已结束</option>
                </select>
            </th>
            <th align="center">操作</th>
          </tr>
        </thead>
        <tbody>
         <?php if(!empty($data)):?>
         <?php foreach($data as $v):?>
          <tr id="coupon_<?php echo $v['id']; ?>">
			<td>
				<?php echo $v['title'];?><br/>
                <span class="promote_way"><?php if ($v['promote_way'] == 'receive'):?>买家领取<?php elseif($v['promote_way'] == 'active'):?>活动参与<?php endif;?></span>
            </td>
            
            <td><input type="text" value="<?php echo siteurl(1);?>/index.php?m=coupon&cid=<?php echo $v['id']?>" style="width:100%;"></td>
            <td><?php echo $v['money'];?>元</td>
            <td>
            	起 <?php echo date('Y-m-d',$v['start_time']);?><br/>
                止 <?php echo date('Y-m-d',$v['end_time']);?>
            </td>
            <td><?php echo $v['limit'];?></td>
            <td><?php if($v['condition']):?>满<?php echo $v['c_money'];?>元<?php else:?>无条件使用<?php endif;?></td>
            <td><?php echo $v['count'];?></td>
            <td><?php echo $record[$v['id']]['get']?></td>
            <td>
            	<?php 
					$get_count = $record[$v['id']]['get'];
					$use_count = $record[$v['id']]['use'];
					$noUse_count = $get_count - ($use_count + $record[$v['id']]['using'] + $record[$v['id']]['delete']);
				?>
            	<span class="data_item" data-val="user" style="width:<?php echo ($use_count/$v['count'])*100;?>%; background-color:#25F351"></span>
                <span class="data_item" data-val="no" style="width:<?php echo ($noUse_count/$v['count'])*100;?>%; background-color:#FFC99A"></span>
                <span class="data_item" data-val="get" style="width:<?php echo ($get_count/$v['count'])*100;?>%; background-color:#cacaca"></span>
            </td>
            <td><?php if($v['status'] == 'ok'):?>领取中<?php else:?>已结束<?php endif;?></td>
            <td>
            	<a href="javascript:;" onClick="showCouponAdd('<?php echo $v['id'];?>')" class="action_btn">修改</a>
                <?php if($v['status'] == 'ok'):?>
                	<a href="javascript:;" class="action_btn" onClick="closeCoupon('<?php echo $v['id'];?>','end')">结束</a>
				<?php elseif($v['status'] == 'no'):?>
                	<a href="javascript:;" class="action_btn" onClick="closeCoupon('<?php echo $v['id'];?>','delete')">删除</a>
				<?php endif;?>
                <a href="index.php?m=coupon&c=coupon&a=couponRecord&id=<?php echo $v['id']?>" class="action_btn" onMouseOver="checkData('<?php echo $v['id']?>')" onMouseOut="$('#data_box').fadeOut()">查看数据</a>
            </td>
          </tr>
          <?php endforeach;?>
          <?php endif;?>
        </tbody>
      </table>
      
    </div>
  <div style=" margin-top:20px; float:left"   id="pages">
  	 <?php echo $pages;?>
  </div>
</div>
<div class="data_box" id="data_box">
	<div class="data_box_main">
    	<p><font>已使用</font><span id="use">0</span></p>
        <p><font>使用中</font><span id="using">0</span></p>
        <p><font>未使用</font><span id="no_use">0</span></p>
        <p><font>已删除</font><span id="delete">0</span></p>
    </div>
</div>
</body>
<script>
function closeCoupon(id,ac){
	var tips = ac == 'end' ? '关闭' : '删除';
	if (confirm('是否要'+tips+'?')) {
		$.get('index.php?m=coupon&c=coupon&a=closeCoupon&ajax=1&id='+id+'&ac='+ac,function(data){
			if (data.status == 1) {
				alert('操作成功!');
				window.location.reload();
			} else {
				alert('操作失败,请稍后再试!');
			}
		},'json');
	}
	
}
function checkData(id){
	if (!id) { alert('参数错误!');}
	$.get('index.php?m=coupon&c=coupon&a=getData&ajax=1&id='+id,function(data){
		if (data.status == 1) {
			var info = data.info;
			$('#use').text(info.use_);
			$('#using').text(info.using_);
			$('#no_use').text(info.no_use_);
			$('#delete').text(info.delete_);
			$('#data_box').fadeIn();
		}	
	},'json');
}
function showCouponAdd(id){
	ac = !id? 'add' : 'edit&id='+id;
	
	var url = 'index.php?m=coupon&c=coupon&a='+ac;
	layer.open({
      type: 2,
      title: !id?'添加':'编辑'+'优惠券',
      shadeClose: true,
      shade: false,
      maxmin: true, //开启最大化最小化按钮
      area: ['707px', '470px'],
      content: url,
	  move: false,
	  scrolling:'no',
	  end: function(){
		  $("body").css("overflow","");
	  }
    });
	$("body").css("overflow","hidden");	
}
</script>
</html>