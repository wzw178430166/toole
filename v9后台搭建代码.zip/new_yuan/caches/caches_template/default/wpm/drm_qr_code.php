<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>

<style>
.tiao { margin-bottom: -13px; }
.lse { color: rgb(90, 152, 222); }
.hse { color: rgb(158, 153, 153); }
.qrcode_wrapper { position: relative; cursor: default; }
.qrcode_wrapper .qrcode { display: none; position: absolute; left: 0; width: 180px; height: 180px; padding: 10px; -webkit-box-shadow: 0 0 5px #aaa; box-shadow: 0 0 5px #aaa; background-color: #fff; _border: 1px solid #eee; }
a, a:hover { /* text-decoration: none; */ }
.xjtb { font-size: 8px }
.template{ display:none;}
.down_img { display:none;}
</style>
<body>
<nav class="breadcrumb">
  <i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 二维码推广
  <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" >
  <i class="Hui-iconfont">&#xe68f;</i>
  </a>
</nav>
<div class="pd-20">
  <div class="cl pd-5 bg-1 bk-gray mt-20 tiao"  >
    <span class="l">
    <a class="btn btn-primary radius" href="index.php?m=wpm&c=drm&a=promote_sale_list&wpm=1">
    <i class="Hui-iconfont">&#xe600;</i> 推广数据
    </a>
    <a class="btn btn-primary radius"  href="index.php?m=wpm&c=drm&a=popu_data_link">
    <i class="Hui-iconfont">&#xe600;</i> 链接推广
    </a>>
    </span>
  </div>
  <form action="" method="post">
    <div class="mt-20">
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead>
          <tr class="text-c">
            <th colspan="2">二维码推广</th>
          </tr>
        </thead>
        <tbody>
          <tr id="up_nodata">
            <td  align="center" style="width:60%;">
            <?php 
            	$qrcode_url = siteurl(1);
            ?>
              <div class="qrcode" mlink="<?php echo $qrcode_url;?>" style="text-align:center">
                <canvas width="180" height="180"></canvas>
              </div>
              <input type="hidden" id="link1" readonly  class="input-text" value="<?php echo $qrcode_url;?>"></td>
            <td>
            	<div style="width:100%;">1.二维码分享介绍：二维码分享介绍</div>
            	<a href="index.php?m=wpm&c=drm&a=create_qrcode&url=<?php echo urlencode($qrcode_url);?>" id="down_qrcode" class="btn btn-success radius">下载</a> 
              <br>
              <br>
              
              <!--<button class="btn btn-success" type="submit"><i class="Hui-iconfont"></i> 复制</button>--></td>
          </tr>
          <!--<tr>
           <td colspan="2">下级推广账号：<input type="text" id="codetext">&nbsp;&nbsp;下级推广密码：<input type="text" id="codepassword">&nbsp;&nbsp;<input type="button" onClick="add_promote()" value=" 生成二维码 "></td>
          </tr>-->

          <tr id="template" class="template codeid_1">
            <td  align="center" style="width:60%;">
            <div id="mlink" mlink="123" style="text-align:center">
            <!--&k=<?php echo $memberinfo['userid'];?>-->
                <canvas width="180" height="180"></canvas>
              </div>
              </td>
            <td><div style="width:100%;" id="keyvalue"></div>
            
              <br>
              <br>
              
              <!--<button class="btn btn-success" type="submit"><i class="Hui-iconfont"></i> 复制</button>--></td>
          </tr>
	
          
          
          
          <tr>
            <td  colspan="2" ><div class="bdsharebuttonbox" style="float:right">
                <a href="#" class="bds_more" data-cmd="more">
                </a>
                <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间">
                </a>
                <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博">
                </a>
                <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博">
                </a>
                <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网">
                </a>
                <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信">
                </a>
              </div>
              <script>window._bd_share_config={ "common":{ "bdSnsKey":{ },"bdText":"唐剑-云掌天下 微信营销方案提供商","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32","bdUrl":"<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>&k=<?php echo $memberinfo['userid'];?>"},"share":{ }};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
</script></td>
          </tr>
        </tbody>
      </table>
    </div>
  </form>
</div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script>
document.getElementById('link1').select();
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
	 background: "#fff",
    text: $(qrcodes[i]).attr('mlink')
}); 
}
$('#down_img').qrcode({ 
    render: "image", //table方式 
     size: 200,
	 background: "#fff",
    text: $(qrcodes[i]).attr('mlink')
}); 
function down_qrcode() {
	$('#qrcode_img').attr('value', $('#down_img img').attr('src'));
	$('#down_form').submit();
}
var codeid =1;
function crcode(codetext){
	
	$('#mlink').attr('mlink','<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>&k='+codetext);
	$('#mlink').qrcode({ 
		render: "image", //table方式 
		 size: 180,
		text: $('#mlink').attr('mlink')
	});
	$('#keyvalue').html(codetext);
	var tpl = '<tr class="codeid_'+(Number(codeid)+1)+'">'+$('#template').html()+'</tr>';	
	//$('.codeid_'+codeid).after(tpl);
	$('.codeid_'+1).after(tpl);
	codeid++;

}

function add_promote () {
	var username = $.trim($('#codetext').val());
	var password = $.trim($('#codepassword').val());
	if (username == '' || password == '') {
		layer.msg('账号和密码都不能为空');	
		return;
	}
	var index = layer.load(2);
	$.post('index.php?m=wpm&c=drm&a=add_promote&ajax=1', {"username":username, "password":password}, function (data) {
		layer.close(index);
		layer.msg(data.msg);
		if (data.status == 1) {
			crcode(username);
		}
	}, 'json');
}
</script>
<script type="text/javascript">
	var get_data = $('#get_data').val();
</script>
</body>
</html>