<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.taxes-class-search-input {
	width: 250px;
    height: 30px;
    border: 1px #dcdcdc solid;
    border-radius: 4px;	
}
.taxes-class-search-input input {
	width: 100%;
    border: 0;
    height: 100%;
}
.taxes-class-search-btn {
	width: 60px;
    height: 30px;
    line-height: 30px;
    border: 1px #FF9638 solid;
    text-align: center;
    background-color: #FF9638;
    color: #fff;
    border-radius: 4px;
    margin-left: 10px;	
}
.desc-content { width:85%; color:#FF9638;}
.tc_rate { color:#FF9638;}
</style>
<div class="taxes-class-item">
	<input type="hidden" name="info[taxes_class]" id="taxesClassInput" value="<?php if($data['taxes_class']) { ?><?php echo $data['taxes_class'];?><?php } else { ?>0<?php } ?>">
	<div class="taxes-class-item-search">
    	<div class="taxes-class-search-input fl"><input  type="text" id="tck"></div>
        <div class="taxes-class-search-btn fl" onclick="taxSearch()">搜索</div>
    </div>
    <div class="taxes-class-items" id="taxesClassBox">
    	
    </div>
    <div class="taxes-class-desc">
    	<div class="taxes-class-desc-content"><span class="fl">物品归类说明: </span><div class="desc-content fr" id="tc_content"></div></div>
        <span><!--关税: <font id="tc_money"></font>-->税率： <font class="tc_rate" id="tc_rate"></font></span>
    </div>
</div>
<script>
var taxJson = {};
var currTaxClass = $('#taxesClassInput').val();
currTaxClass = Number(currTaxClass)>0?currTaxClass:0;

getTaxClass();
function getTaxClass(){
	$.get('index.php?m=wpm&c=wb_shop&a=getTaxClass&ajax=1',function(data){
		if (data.status == 1) {
			taxJson = data.info;
			creatTaxItem();		
		}
	},'json');
}

function creatTaxItem(){
	var html = '';
	for(var i in taxJson){
		var active = '';
		if (currTaxClass==taxJson[i].id) {
			$('#taxesClassInput').attr('value',taxJson[i].id);
			active = 'active';
		}
		if (taxJson[i].tax_rate>0) {
			html += '<a href="javascript:;" class="tc-item '+active+'" data-val="'+taxJson[i].id+'" data-taxId="'+taxJson[i].tax_id+'" onClick="selTaxClass(this,'+taxJson[i].id+')">'+taxJson[i].title+'</a>';
		}
		 
	}
	$('#taxesClassBox').empty();
	$('#taxesClassBox').html(html);
}
function selTaxClass(obj,id){
	$('.taxes-class-items a').removeClass('active');
	$(obj).addClass('active');
	$('#tc_content').html(taxJson[id].description);
	//$('#tc_money').text();
	$('#tc_rate').text(Number(taxJson[id].tax_rate)*100+'%');
	$('#taxesClassInput').attr('value',id);
}
function taxSearch(){
	var tck = $('#tck').val();
	if (1>3 && tck == '') {
		layer.msg('请输入要搜索的分类!');
		return;	
	}
	$.get('index.php?m=wpm&c=wb_shop&a=getTaxClass&ajax&tck='+tck,function(data){
		if (data.status == 1) {
			taxJson = data.info;
			creatTaxItem();
		}
	},'json');
}
</script>