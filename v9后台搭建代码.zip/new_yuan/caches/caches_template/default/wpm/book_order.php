<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<style>
.bigImg { position:fixed; width:40%; left:30%; top:160px; display:none;}
.bigImg img { width:100%;}
</style>
<body>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 商品预订
  <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a>
</nav>
<div class="pd-20">
    <div class="mt-20">
      
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="40%" >商品信息</th>
            <th width="40%">收货信息</th>
            <th width="40%">预订时间</th>
            <th width="20%">操作</th>
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($book)) { ?>
        <tr id="up_nodata"><td colspan="4">暂无预订信息</td></tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($book)) foreach($book AS $r) { ?>
        <tr id="order_<?php echo $r['id'];?>" class="text-c" >
          <td>
          	<div class="goods-info">
            	<span><?php echo $r['goodstitle'];?></span>
            	<?php if($r['goodsimg']) { ?><span onClick="checkBigPic(this)"><img src="<?php echo SPATH;?>images/icon/un_color/check_big_img.png" data-url="<?php echo $r['goodsimg'];?>" width="20px" style=" cursor: pointer;"></span><?php } ?>
                <div class="bigImg"><img src="" id="big_img"></div>
            </div>
          </td>
          <td>
          	<div class="contact-info">
            	<div class="contact-info-item">收货人:<?php echo $r['contacter'];?></div>
                <div class="contact-info-item">身份证:<?php echo $r['id_card'];?></div>
                <div class="contact-info-item">联系方式:<?php echo $r['phone'];?></div>
                <div class="contact-info-item">收货地址:<?php echo $r['address'];?></div>
            </div>
          </td>
          <td><?php echo date('Y-m-d H:i:s',$r['addtime']);?></td>
          <td class="f-14 td-manage"></td>
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>    
  <div id="pages">
     <?php echo $pages;?>
  </div>
</div>
<script type="text/javascript">
	$('#big_img').click(function(){$('.bigImg').hide()});
	
	function checkBigPic(obj) {
		$('#big_img').attr('src','');
		var src = $(obj).find('img').attr('data-url');
		$('#big_img').attr('src',src);
		$('.bigImg').show();
	}
</script>
</body>
</html>