<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wpm','header_common'); ?>
<link href="<?php echo CSS_PATH?>dialog.css" rel="stylesheet" type="text/css" />
<style>
.icon { vertical-align: top; opacity: 0.7; margin: 20px 5px 0px 5px; }
.icon_box { display: inline-block; width: 14px; height: 14px; background: url('<?php echo SPATH;?>wpm/images/ico/glyphicons-halflings.png') no-repeat; }
.icon_home { background-position: 0px -24px; }
.icon_dcgl { background-position: 0px 0px; }
.icon_shop { background-position: -96px -72px; }
.icon_file { background-position: -24px -24px; }
.icon_tuig { background-position: -120px -72px; }
.icon_dzgl { background-position: -72px -48px; }
.icon_hyyy { background-position: 0px -48px; }
.icon_xdsj { background-position: -48px -120px; }
.icon_agent{ background-position: -167px 0px; }
.icon_promte{ background-position: -72px -72px; }
a:hover{ text-decoration:none}

.Hui-header .Hui-aside { left:initial; width:initial; padding-top:0; background-color:initial; border:0; overflow:inherit; top: 144px;}
.Hui-aside .menu_dropdown dd { display:block;}
.logoInfo { width:1200px; height:100px;}
.logoInfo img { margin-top:15px;}
.Hui-header { top:100px;}
.Hui-aside,.Hui-article-box { top:170px;}
.dislpayArrow { display:none;}
</style>
<script language="javascript" type="text/javascript" src="<?php echo JS_PATH;?>dialog.js"></script>

<body style="width:1200px; margin:0 auto; min-height:1200px;">
<?php 
	$db = pc_base::load_model('member_model');
    $db->set_model($this->memberinfo['modelid']);
    $companyinfo = $db->get_one(array('userid'=>$this->userid));
?>
<div class="logoInfo">
	<a href="<?php echo siteurl(1);?>/index.php?m=wpm"><img src="<?php echo SPATH;?>wpm/images/b2c_logo.jpg"></a>
</div>
<header class="Hui-header cl">
  <a class="Hui-logo l"  href="<?php echo $logo_url;?>/index.php?m=wpm"><?php echo $companyinfo['name'];?></a>
  <ul class="Hui-userbar Hui-aside" style="top:0;">
    <li>欢迎 </li>
    <li class="dropDown dropDown_hover menu_dropdown">
      <a href="#" class="dropDown_A"><?php echo $this->memberinfo['username'];?><i class="Hui-iconfont">&#xe6d5;</i></a>
     
      <ul class="dropDown-menu radius box-shadow">
        <li>
          <a _href="index.php?m=company&c=company_f&a=index&wpm=1" href="javascript:void(0);">个人信息</a>
        </li>
        <li>
          <a href="index.php?m=member&c=index&a=logout&type=1&wpm=1">切换账户</a>
        </li>
        <li>
          <a href="index.php?m=member&c=index&a=logout&type=1&wpm=1">退出</a>
        </li>
      </ul>
     
    </li>
    <!--<li id="Hui-msg" class="menu_dropdown">
      <a _href="index.php?m=message&c=index&a=inbox&sj_ht=1" href="javascript:void(0);" title="消息">
          <i class="Hui-iconfont" style="font-size:18px">&#xe68a;</i>
      </a>
    </li>-->
  </ul>
  <a aria-hidden="false" class="Hui-nav-toggle" href="#"></a>
</header>
<div style="height:15px;"></div>
<aside class="Hui-aside">
<span>
  <input runat="server" id="divScrollValue" type="hidden" value="" />
  <div class="menu_dropdown bk_2">
   
    <style>
	.you{  margin:0  0 0 15px}
	
    </style>
   
   <!--交易管理 start-->
   <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>交易管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=wpm&c=wb_shop&a=shop_order&wpm=1" href="javascript:void(0)">已卖出商品</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=wb_shop&a=comment_list&wpm=1" href="javascript:void(0)">评价管理</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=wb_shop&a=book_order&wpm=1" href="javascript:void(0)">商品预订</a>
          </li>
        </ul>
      </dd>
    </dl>
    <!--交易管理 end-->
    <!--物流管理 start-->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>物流管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=wpm&c=wb_shop&a=saleManage&wpm=1" href="javascript:void(0)">发货</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=logistManage&wpm=1" href="javascript:void(0)">物流管理</a>
          </li>
          <!--<li>
            <a id="dpzx" _href="javascript:;" href="javascript:void(0)">物流服务</a>
          </li>-->
        </ul>
      </dd>
    </dl>
    <!--物流管理 end-->
    <!--商品管理 start-->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>商品管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=wpm&c=wb_shop&a=selCategory&wpm=1" href="javascript:void(0)">发布商品</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=wb_shop&t=99&wpm=1" href="javascript:void(0)">出售中的商品</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=wb_shop&t=1&wpm=1" href="javascript:void(0)">未上架商品</a>
          </li>
        </ul>
      </dd>
    </dl>
    <!--商品管理 end-->
    <!--商品管理 start-->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>优惠券管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=coupon&c=coupon&wpm=1" href="javascript:void(0)">优惠券</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=coupon&c=coupon&a=couponRecord&wpm=1" href="javascript:void(0)">记录日志</a>
          </li>
        </ul>
      </dd>
    </dl>
    <!--商品管理 end-->
    <!--客户服务 start-->
    <!--<dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>客户服务<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=wpm&c=wb_shop&a=refundManage&wpm=1" href="javascript:void(0)">退款管理</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=wb_shop&a=customerManage" href="javascript:void(0)">售后管理</a>
          </li>
          <li>
            <a id="dpzx" _href="javascript:;" href="javascript:void(0)">举报管理</a>
          </li>
        </ul>
      </dd>
    </dl>-->
    <!--客户服务 end-->
    <!--客户服务 start-->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>店铺管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
            <a _href="index.php?m=member&c=company&a=index&wpm=1" href="javascript:void(0)">公司介绍</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=news&a=news_gg&ac=news&wpm=1" href="javascript:void(0)">新闻公告</a>
          </li>
          <li>
            <a id="dpzx" _href="index.php?m=wpm&c=wb_shop&a=ren&wpm=1" href="javascript:void(0)">公司店铺管理</a>
          </li>
          <!--<li>
            <a id="dpzx" _href="javascript:;" href="javascript:void(0)">管理相册</a>
          </li>-->
        </ul>
      </dd>
    </dl>
    <!--客户服务 end-->
    <!--其他服务 start-->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>其他服务<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
           <a _href="index.php?m=wpm&c=drm&a=popu_data_link" href="javascript:void(0)"> 链接推广</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=drm&a=qr_code" href="javascript:void(0)"> 二维码推广</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=drm&a=promote_list&wpm=1" href="javascript:void(0)"> 推广员列表</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=drm&a=promote_sale_list&wpm=1" href="javascript:void(0)"> 销售列表</a>
          </li>
        </ul>
      </dd>
    </dl>
    <!--其他服务 end-->
    <?php if($this->isTop) { ?>
    <!--node shang start--->
    <dl class="you">
      <dt style="line-height:52px;"><i class="icon icon_box icon_home"></i>商家管理<i class="Hui-iconfont menu_dropdown-arrow">&#xe6d5;</i></dt>
      <dd>
        <ul>
          <li>
           <a _href="index.php?m=wpm&c=index&a=node_manage&wpm=1" href="javascript:void(0)"> 商家列表</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=index&a=node_sales_list&wpm=1" href="javascript:void(0)"> 销售列表</a>
          </li>
          <li>
            <a _href="index.php?m=wpm&c=index&a=node_goods&wpm=1" href="javascript:void(0)"> 商品列表</a>
          </li>
        </ul>
      </dd>
    </dl>
    <!---node shang end--->
    <?php } ?>
  </div>
  </span>
</aside>

<div class="dislpayArrow">
  <a class="pngfix" href="javascript:void(0);" onClick="displaynavbar(this)"></a>
</div>
<section class="Hui-article-box">
  <div id="Hui-tabNav" class="Hui-tabNav">
    <div class="Hui-tabNav-wp">
      <ul id="min_title_list" class="acrossTab cl">
        <li class="active"><span title="我的首页" data-href="welcome.html">我的首页</span><em></em></li>
      </ul>
    </div>
    <div class="Hui-tabNav-more btn-group">
      <a id="js-tabNav-prev" class="btn radius btn-default size-S" href="javascript:;"><i class="Hui-iconfont">&#xe6d4;</i></a>
      <a id="js-tabNav-next" class="btn radius btn-default size-S" href="javascript:;"><i class="Hui-iconfont">&#xe6d7;</i></a>
    </div>
  </div>
  <div id="iframe_box" class="Hui-article">
    <div class="show_iframe">
      <div style="display:none" class="loading">
      </div>
      <iframe scrolling="yes" frameborder="0" src="index.php?m=wpm&a=index"></iframe>
    </div>
  </div>
</section>
<?php include template($this->file,'js_common'); ?>
</body>
</html>