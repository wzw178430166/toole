<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<style>
.cate-container {
    width: 950px;
    position: relative;
    border: 1px solid #d5e4fa;
    background-color: #F5F9FF;
}
.cate-container {
    margin-top: 23px;
    height: 300px;
    overflow: hidden;
	color:#666;
}
.cate-main {
    float: left;
    padding-top: 10px;
    border-right: 1px solid #d5e4fa;
    width: 725px;
}
#cate-cascading {
    padding: 0 24px;
    height: 290px;
    position: relative;
    z-index: 11;
}
.cc-listwrap {
    border-left: 1px solid #d5e4fa;
    border-right: 1px solid #d5e4fa;
    border-top: 1px solid #d5e4fa;
    position: relative;
    overflow: hidden;
}
.cc-cbox, .cc-list, .cc-list-item, .cc-listwrap, .cc-tree {
    height: 100%;
}
.cc-list {
    width: 2000em;
    position: absolute;
    left: 0;
    top: 0;
	transition: left .5s;
}
.cc-list-item {
    float: left;
    width: 223px;
    border-right: 2px solid #d5e4fa;
    background: #fff;
}
.cc-cbox, .cc-tree {
    overflow-x: hidden;
    overflow-y: auto;
    position: relative;
    left: 0;
    top: 0;
}
.cc-cbox-cont, .cc-tree-cont {
    padding: 0 3px;
    margin-top: 26px;
}
.cc-cbox-group {
    position: relative;
	height: 20px;
    line-height: 20px;
	font-size:0.8rem;
	cursor:pointer;
}
.cc-cbox-cont li.sel { background-color:#dff1fb}
.cc-cbox-group .cc-cbox-icon {
	display: block;
    width: 30px;
    height: 20px;
    float: left;
	background:url('statics/wpm/images/cateIcon.png') no-repeat center;
	background-size:20px;
}
.cc-cbox-group font {
	display: block;
    width: 165px;
    padding-right: 20px;
    float: left;
	background:url('statics/wpm/images/arrowRight.png') no-repeat 100% 0;
	background-size:20px;
}
.cc-nav {
    position: absolute;
    top: 50%;
    margin-top: -41px;
    height: 80px;
    width: 24px;
    display: inline-block;
    line-height: 99em;
    overflow: hidden;
}
#cate-cascading .cc-prev {
    left: 0;
	background:url('statics/wpm/images/moveBtn_l.png') no-repeat center;
	background-size:24px;
}
#cate-cascading .cc-next {
    right: 0;
	background:url('statics/wpm/images/moveBtn_r.png') no-repeat center;
	background-size:24px;
}
.cc-loading {
    background: rgba(255,255,255,.8);
    filter: alpha(opacity=80);
    border: 1px snow;
    height: 298px;
    left: 1px;
    position: absolute;
    top: 1px;
    width: 948px;
    display: none;
    z-index: 13;
}
.cc-loading-content {
    position: relative;
    width: 150px;
    height: 21px;
    margin: 130px auto;
}
.cc-loading-icon {
    float: left;
    margin-right: 5px;
}
.cc-loading-text {
    font-size: 12px;
    display: block;
    float: left;
    margin-left: 5px;
    padding-top: 0;
    color: #f60;
}
.cateBottom {
    text-align: center;
    padding: 5px 0 24px;
	margin-top:20px;
}
.catePublish{
	display:block;
    padding: 0;
    width: 276px;
    height: 37px;
	line-height:37px;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
	background-position: right 0;
    color: #aaa;
    background-color: #f4f4f4;
    cursor: not-allowed;
	margin:auto;
}
.cateBottom span.active {
	background-color: #4096e7;
	color:#fff;
	cursor: pointer;
}
</style>
<body style="font: 12px/1.5 tahoma,arial,'Hiragino Sans GB',"Microsoft Yahei",\5b8b\4f53,sans-serif;">
<nav class="breadcrumb">
	<i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 商品类目选择
  	<a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" >
    	<i class="Hui-iconfont">&#xe68f;</i>
    </a>
</nav>
<div class="pd-20">
	<div class="cate-container">
    	<div class="cate-main">
        	<div id="cate-cascading">
            	<a href="javascript:;" onClick="moveCateList('prev')" class="cc-nav cc-prev"></a>
            	<div class="cc-listwrap">
                	<ol class="cc-list" id="J_OlCascadingList">
                    	<li class="cc-list-item" data-level="1">
                        	<div class="cc-cbox">
                            	<ul class="cc-cbox-cont">
                                	<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                                	<li class="cc-cbox-group" data-val="<?php echo $r['catid'];?>" data-level="<?php echo $r['level'];?>">
                                    <i class="cc-cbox-icon tipicon"></i><font><?php echo $r['catname'];?></font>
                                    </li>
                                    <?php $n++;}unset($n); ?>
                                </ul>
                            </div><!--cc-cbox end-->
                        </li>
                    </ol><!--cc-list end-->
                </div><!--cc-listwrap end-->
                <a href="javascript:;" onClick="moveCateList('next')" class="cc-nav cc-next"></a>
            </div><!--cate-cascading end-->
        </div><!--cate-main end-->
        <div class="cc-loading">
            <div class="cc-loading-content">
                <div class="cc-loading-icon"><img src="<?php echo SPATH;?>wpm/images/load_icon.gif"></div>
                <span class="cc-loading-text">加载中，请稍候...</span>
            </div>
        </div><!--cc-loading end-->
    </div><!--cate-container end-->
    <div class="cateBottom">
    	<span class="catePublish" data-off="0"><?php if(isset($_GET['forward'])) { ?>保存分类<?php } else { ?>发布商品<?php } ?></span>
    </div>
</div>
<input type="hidden" id="classify" value="0">
<input type="hidden" id="forward_" value="<?php echo urldecode($_GET['forward']);?>">
</body>
<script>
var jsonData = {};
$(function(){
	
	//console.log($.isEmptyObject(jsonData));
	var cboxgroup = $('.cc-cbox-group');
	cboxgroup.each(function(i) {
        $(cboxgroup[i]).click(function(){
			getCateItem(this);
		});
    });
	$('.catePublish').bind('click',function(){
		if ($(this).attr('data-off') == 1) {
			var url = !$('#forward_').val() ? 'index.php?m=wpm&c=wb_shop&a=add&wpm=1' : $('#forward_').val();
			//alert(url);return;
			window.location.href = url+'&classify='+$('#classify').val();
		}
	});
});
function getCateItem(obj) {
	/*set Html style*/
	$(obj).parent().find('.cc-cbox-group').removeClass('sel');
	$(obj).addClass('sel');
	$('.catePublish').removeClass('active');
	$('.catePublish').attr('data-off',0);
	
	
	var catid = $(obj).attr('data-val');
	var level = $(obj).attr('data-level');
	var jsonIndex = 'pid_'+catid;
	if ($.isEmptyObject(jsonData[jsonIndex])) {
		$('.cc-loading').show();
		$.get('index.php?m=wpm&c=wb_shop&a=getCateItem&pid='+catid,function(data){
			$('.cc-loading').hide();
			if (data.status == 1) {
				resetCateList(level);
				editJsonData(data.info,catid);//更新json数据
				creatNodeHtml(data.info[jsonIndex]);
			} else if(data.status == -1){
				//have not node
				var emptyJson = {};
				emptyJson[jsonIndex] = [{"catid":"0"}];
				editJsonData(emptyJson,catid);
				$('.catePublish').addClass('active');
				$('.catePublish').attr('data-off',1);
				
			} else {
				layer.msg('获取数据失败!');//netword fail or unlogin
			}
		},'json');
	} else {
		resetCateList(level);
		if (jsonData[jsonIndex][0].catid != 0) {
			creatNodeHtml(jsonData[jsonIndex]);
		} else {
			$('.catePublish').addClass('active');
			$('.catePublish').attr('data-off',1);	
		}
	}
	$('#classify').attr('value',catid);
	
}
function moveCateList(ac){
	var lingListLeft = document.getElementById("J_OlCascadingList").offsetLeft;
	var cc_itemLength = $('.cc-list-item').length;
	if (ac == 'next') {
		//console.log(((cc_itemLength-3)*(-255)));
		if (Number(lingListLeft) > ((cc_itemLength-3)*(-225))) {
			lingListLeft -= 225;
		}
	} else {
		//console.log(Number(lingListLeft) <= (-255));
		if (Number(lingListLeft) <= (-225)) {
			lingListLeft = lingListLeft + 225;
		}
	}
	$('#J_OlCascadingList').css({'left':lingListLeft});
}
function creatNodeHtml(data){
	var html = '<li class="cc-list-item" data-level="'+data[0].level+'"><div class="cc-cbox"><ul class="cc-cbox-cont">';
	for(var i in data){
		html += '<li class="cc-cbox-group" data-val="'+data[i].catid+'" onClick="getCateItem(this)"><i class="cc-cbox-icon tipicon"></i><font>'+data[i].catname+'</font></li>';
	}
	html += '</ul></div></li>';
	$('#J_OlCascadingList').append(html);
	//console.log(data);
}
function editJsonData(data,pid){
	var dataIndex = 'pid_'+pid;
	if ($.isEmptyObject(jsonData[dataIndex])) {
		//jsonData 为空
		jsonData[dataIndex] = data[dataIndex];
	}
	//console.log(jsonData);
}
function resetCateList(level){
	var listItem = $('.cc-list-item');
	$(listItem).each(function(i) {
		if (level < $(listItem[i]).attr('data-level')) {$(listItem[i]).remove();}
	});
}
</script>
</html>