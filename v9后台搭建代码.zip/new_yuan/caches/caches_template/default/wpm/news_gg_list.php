<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<body>
<style>
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia {margin-bottom: 15px;}
.xjtb{font-size:8px}
.add_news_btn_box { margin-bottom:20px; overflow:hidden;}
.add_news_btn_box a {
	width: 100px;
    display: block;
    height: 35px;
    line-height: 35px;
    text-align: center;
    background-color: white;
    border-radius: 4px;
	float: left;
	margin-right:15px;
	background-color:#5a98de;
	color:#fff;	
}
.add_news_btn_box a img { width:18px; height:18px; margin-top: -2px; margin-right: 3px;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>文章列表</nav>
<div class="pd-20">
    <div class="mt-20">
    <div class="add_news_btn_box">
    	<a href="index.php?m=wpm&c=news&a=add&ac=<?php echo $ac;?>"><img src="<?php echo SPATH;?>wpm/images/add_icon.png">文章</a>
       <!-- <a href="index.php?m=wpm&c=news&a=add&catid=61"><img src="<?php echo SPATH;?>wb/wpm/images/add_icon.png">联系我们</a>
        <a href="index.php?m=wpm&c=news&a=add&catid=62"><img src="<?php echo SPATH;?>wb/wpm/images/add_icon.png">新闻资讯</a>-->
    </div>
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead>
          <tr class="text-c">
            <th width="3%"><input type="checkbox" name="" value=""></th>
            <th width="13%" >标题</th>
            <th width="13%">发布时间</th>
            <th width="13%">操作</th>
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($datas)) { ?>
        <tr id="up_nodata">
          <td colspan="9">暂无发布文章</td>
        </tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($datas)) foreach($datas AS $r) { ?>
        <tr  class="text-c" id="news_<?php echo $r['id'];?>">
          <td><input type="checkbox" value="<?php echo $r['id'];?>" name="yc[]"></td>
              <!--$r['trade_sn']-->
          <td><?php echo $r['title'];?> </td>
          <td><?php echo date('Y-m-d H:i', $r['inputtime']);?> </td>
          <td class="f-14 td-manage">
				<a href="index.php?m=wpm&c=news&a=edit&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>" title="编辑">
					<i class="Hui-iconfont">&#xe6df;</i>
				</a> 
                <?php if(!in_array($catid, array(60,61))) { ?>
				<a style="text-decoration:none" class="ml-5" onClick="del('<?php echo $r['id'];?>', '<?php echo $r['catid'];?>')" href="javascript:;" title="删除">
					<i class="Hui-iconfont">&#xe6e2;</i>
				</a>
                <?php } ?>
		   </td>
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>
  <div style=" margin-top:20px; float:left"   id="pages">
  	 <?php echo $pages;?>
  </div>
 
</div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/My97DatePicker/WdatePicker.js"></script> 
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 
</body>
<script>
function del (id, catid) {
	if (confirm('您是否删除该文章?')) {
		var index = layer.load(2);
		$.get('index.php?m=wpm&c=news&a=del&catid='+catid+'&id='+id+'&ajax=1', function (data) {
			layer.close(index);
			layer.msg(data.msg);
			if (data.status == 1) {
				$('#news_'+id).fadeOut();
			}
		}, 'json');
	}
}
</script>
</html>