<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.tiao{ margin-bottom:-13px; }
.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
  z-index: 9999;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia{ margin:0 0 15px 7px; width:200px; height:30px }
.xjtb{font-size:8px}
.order_type {
	padding: 10px 0;
    font-size: 15px;	
}
.order_type select { padding:2px 5px;}
.sk {
	border: 1px #aaa solid;
    padding: 3px 5px;
    height: 19px;
	width:150px;	
}
.DynarchCalendar-topCont { width:20%;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 推广员销售列表</nav>
<div class="pd-20">
    <div class="mt-20">
      <div class="order_type">
      <form action="" method="get" id="sel_form">
      	<input type="hidden" name="m" value="wpm">
        <input type="hidden" name="c" value="drm">
        <input type="hidden" name="a" value="promote_sale_list">
        <input type="hidden" name="wpm" value="1">
        <?php if(isset($_GET['promote']) && $_GET['promote']) { ?>
        <input type="hidden" name="promote" value="1">
        <?php } ?>
        开始时间: 
        <?php echo form::date('start_time', $start_time)?>-
        结束时间: 
        <?php echo form::date('end_time', $end_time)?>
        <?php if(!isset($_GET['promote'])) { ?>
        请选择:
        <select name="search_type" id="search_type">
        	<option value="0">全部</option>
        	<option value="orderid" <?php if($_GET['search_type'] == 'orderid') { ?>selected="selected"<?php } ?>>订单编号</option>
            <option value="k" <?php if($_GET['search_type'] == 'k') { ?>selected="selected"<?php } ?>>推广员</option>
        </select>
        <?php } ?>
        <input type="text" placeholder="请输入搜索关键词" name="sk" value="<?php echo $sk;?>" id="sk" class="sk">
        <input type="button" value="搜索" onClick="send_search_()" style="padding:2px 10px;">
      </form>
      <script>
      	$('#class').change(function () {
			$('#sel_form').submit();	
		});
		function send_search_ () {
			//alert($('#start_time').val());
			var search_type = $('#search_type').val();
			if (search_type != 0) {
				if ($('#sk').val() == '') {
					alert('请输入关键词!');
					return;
				}
			}
			$('#sel_form').submit();
		}
      </script>
      </div>
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
         	<th width="13%">订单编号</th>
            <?php if(!isset($_GET['promote']) && !$_GET['promote']) { ?><th width="13%" >商品</th>
            <th width="13%">金额</th><?php } ?>
            <th width="13%">购买用户</th>
            <th width="13%">姓名</th>
            <th width="13%">手机</th>
            <th width="13%">下单时间</th>
            <th width="13%">订单状态</th>
            <?php if(!isset($_GET['promote']) && !$_GET['promote']) { ?><th width="13%">推广员</th><?php } ?>
            <!--<th width="13%">操作</th>-->
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($datas)) { ?>
        <tr id="up_nodata">
          <td colspan="9">暂无推广订单</td>
        </tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($datas)) foreach($datas AS $r) { ?>
        
        <tr id="order_<?php echo $r['id'];?>" class="text-c" >
          <td><?php echo $r['orderid'];?></td>
           <?php if(!isset($_GET['promote']) && !$_GET['promote']) { ?><td><?php echo $r['goodstitle'];?></td>
          <td><?php echo $r['amount'];?></td><?php } ?>
          <td><?php echo $r['username'];?></td>
          <?php $data_feild = !isset($_GET['class'])?'address':'orderid';?>
		  <?php $templat_name = !isset($_GET['class'])?'contactname':'name';?>
          <td><?php echo $contact_info[$r[$data_feild]][$templat_name];?></td>
          <td><?php echo $contact_info[$r[$data_feild]]['phone'];?></td>
          <td><span><?php echo date('Y-m-d H:i',$r['addtime']);?></span></td>
          <td>
          	<?php if($r['status'] == 1) { ?>
            未付款
            <?php } elseif ($r['status'] == 2) { ?>
            待发货
            <?php } elseif ($r['status'] == 3) { ?>
            待收货
            <?php } elseif ($r['status'] == 4) { ?>
            待评价
            <?php } elseif ($r['status'] == 99) { ?>
            交易完成
            <?php } ?>
          </td>
          <?php if(!isset($_GET['promote']) && !$_GET['promote']) { ?><td><?php echo $promotes[$r['k']]['name'];?>(<?php echo $r['k'];?>)</td><?php } ?>
          <!--<td class="f-14 td-manage">
            <a style="text-decoration:none" class="ml-5" onClick="edit('<?php echo $r['id'];?>')" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a>
            <a style="text-decoration:none" class="ml-5" onClick="del('<?php echo $r['id'];?>')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>-->
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>
    
  <div id="pages">
     <?php echo $pages;?>
  </div>

</div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 

<script type="text/javascript">
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
    text: $(qrcodes[i]).attr('mlink')
}); 
}
$(function(){
	$('.qrcode_wrapper').mousemove(function(){
		$(this).find('.qrcode').show();	
	}).mouseout(function(){
		$(this).find('.qrcode').hide();		
	});	
})

function del (id) {
	if (confirm('是否删除该推广员?')) {
		if (!id) {
			layer.msg('参数错误!');
			return;	
		}
		var index = layer.load(2);
		$.get('index.php?m=wpm&c=drm&a=del_promote&ajax=1&id='+id, function (data) {
			layer.close(index);
			layer.msg(data.msg);
			if (data.status == 1) {
				$('#promote_'+id).fadeOut();
			}
		}, 'json');
	}
}
</script>
</body>
</html>