<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
/*
$db = '';
$db = pc_base::load_model('hits_model');
$r = $db->select(array('dp_id'=>$this->memberinfo['userid']));  

foreach($r as $v){
	$dayviews += $v['dayviews'];
    $weekviews += $v['weekviews'];
    $views += $v['views'];
}*/
?>

<?php include template('wpm','header_common'); ?>
<link href="<?php echo SPATH;?>wpm/css/admin_index.css" rel="stylesheet" type="text/css" />
<style>
.modal {position:absolute;top:50%;left:50%; width:300px;margin-left:-150px;}
.home_main{ margin:0;}
.yd{position:absolute;  left: 106px;
  top: 107px;
}
.mht_rb_side  { margin-right:16px;}
.mh_top_center { margin:0; margin-left:30px;}
</style>
<body>
<div class="main_index" style="margin-left:0px;">
  <div class="mh_top">
  <article class="cl">
    <div class="mh_top_left fl">

      <img src="<?php echo get_memberavatar($memberinfo['userid'],1,90);?>" onerror="this.src='<?php echo SPATH;?>wpm/images/ico/icon_tx.jpg'" class="mht_left_img" />
      <a href="index.php?m=member&c=company&a=index&wpm=1" class="mht_left_edit">修改信息</a>
    </div>
    <div class="mh_top_center fl">
      <p class="mht_center_word1">下午好，<?php if($memberinfo['nickname']) { ?><?php echo $memberinfo['nickname'];?><?php } else { ?><?php echo $memberinfo['username'];?><?php } ?></p>
      <div class="mht_center_wb">
        <div class="mht_cwb_left fl">
          我的店铺名称：
        </div>
        <div class="mht_cwb_right fl">
          <?php echo $companyInfo['name'];?>
        </div>
      </div>
      <div class="mht_center_wb">
        <div class="mht_cwb_left fl">
        
          账户余额：
        </div>
        <div class="mht_cwb_right fl">
          <h1 class="mht_center_word2">￥<?php echo number_format($this->memberinfo['amount'],2);?></h1>
          <h2 class="mht_center_word3">(<a href="index.php?m=wpm&c=wb_shop&a=shop_order&wpm=1">查看交易记录</a>)</h2>
        </div>
      </div>
      <div class="mht_center_wb">
        <div class="mht_cwb_left fl">
          系统版本：
        </div>
        <div class="mht_cwb_right fl"></div>
      </div>
      <div class="mht_center_wb">
        <div class="mht_cwb_left fl">
          上次登录时间：
        </div>
        <div class="mht_cwb_right fl">
          <?php echo date('Y-m-d H:i',$memberinfo['lastdate']);?>
        </div>
      </div>
    </div>
    <div class="mh_top_right fl">
      <div class="mht_right_title">
        快截菜单
      </div>
      <div class="mht_right_box">
        <a href="index.php?m=wpm&c=wb_shop&a=ren&wpm=1" class="mht_rb_side"><i class="mht_rb_icon1"></i><span class="mht_rb_word1">店铺装修</span></a>
        <a href="index.php?m=wpm&c=wb_shop&a=add" class="mht_rb_side"><i class="mht_rb_icon2"></i><span class="mht_rb_word2">我要上货</span></a>
        <a href="index.php?m=wpm&c=wb_shop&a=shop_order&wpm=1" class="mht_rb_side"><i class="mht_rb_icon3"></i><span class="mht_rb_word3">交易管理</span></a>
        <a href="#myModal" class="mht_rb_side" data-toggle="modal"><i class="mht_rb_icon3 mht_rb_icon4"></i><span class="mht_rb_word3 mht_rb_word4">店铺首页</span></a>
      </div>
    </div>
    </article>
  </div>
<?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?> 
  
  <?php $userid=$this->memberinfo['userid'];?>
  <!--店铺地址弹出框-->
  <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <h3 id="myModalLabel">手机扫码访问：</h3>
      <a class="close" data-dismiss="modal" aria-hidden="true" href="javascript:void();">×</a>
    </div>
    <div class="modal-body">
      <div class="fl" style="margin-left:44px">
      <div class="qrcode" mlink="<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $userid;?>">
                    <canvas width="180" height="180"></canvas>
      </div>
      <!--<img src="http://www.weiweibb.com/weiwei/images/qc.png" width="180px" height="180px"/>--></div>
      
    </div>
    <div class="modal-footer">
    	<a href="index.php?m=wb_shop&plat=<?php echo $userid;?>" target="_blank"><input class="btn btn-primary size-M radius" type="button" value="访问pc端商城"></a>
      
      <button class="btn" data-dismiss="modal" aria-hidden="true">关闭</button>
    
 </div>
    </div>
  <!--/* padding:20px;*/-->
  <div class="mh_center" style="width:97%;">
    <div class="mh_center_w1">
      <div class="mhc_title">
        店铺数据概览
      </div>
      <ul class="mhc_box">
        <li class="mhcb_line">
          <p class="mhcb_word1"  style="color:#c70506;"><?php if(empty($dd_shu)) { ?>0<?php } else { ?><?php echo $dd_shu;?><?php } ?></p>
          <p class="mhcb_word2">今日成交订单</p>
        </li>
        <li class="mhcb_line">
          <p class="mhcb_word1"  style="color:#c70506;"><?php if(empty($uv)) { ?>0<?php } else { ?><?php echo $uv;?><?php } ?></p>
          <p class="mhcb_word2">今日访客</p>
        </li>
        <li>
          <p class="mhcb_word1"  style="color:#c70506;">￥<?php if(empty($cj_money)) { ?>0<?php } else { ?><?php echo number_format($cj_money,'2');?><?php } ?></p>
          <p class="mhcb_word2">今日成交金额</p>
        </li>
      </ul>
    </div>
    <div class="mh_center_w1">
      <div class="mhc_title">
        订单管理
      </div>
      <ul class="mhc_box">
        <li class="mhcb_line">
          <p class="mhcb_word1"><font style="color:#c70506;"><?php if(empty($dai_fk_shu)) { ?>0<?php } else { ?><?php echo $dai_fk_shu;?><?php } ?></font><font style="font-size:12px;">&nbsp;&nbsp;单</font></p>
          <p class="mhcb_word2">待付款</p>
        </li>
        <li class="mhcb_line">
          <p class="mhcb_word1"><font style="color:#c70506;"><?php if(empty($dai_fh_shu)) { ?>0<?php } else { ?><?php echo $dai_fh_shu;?><?php } ?></font><font style="font-size:12px;">&nbsp;&nbsp;单</font></p>
          <p class="mhcb_word2">待发货</p>
        </li>
        <li>
          <p class="mhcb_word1"><font style="color:#c70506;"><?php if(empty($dai_sh_shu)) { ?>0<?php } else { ?><?php echo $dai_sh_shu;?><?php } ?></font><font style="font-size:12px;">&nbsp;&nbsp;单</font></p>
          <p class="mhcb_word2">待收货</p>
        </li>
      </ul>
    </div>
    <div class="mh_center_w1">
      <div class="mhc_title">
        商品管理
      </div>
      <ul class="mhc_box">
        <li class="mhcb_line">
          <p class="mhcb_word1"><font style="color:#cc0607;"><?php if(empty($sj_shop)) { ?>0<?php } else { ?><?php echo $sj_shop;?><?php } ?></font><font style="font-size:12px;">&nbsp;&nbsp;件</font></p>
          <p class="mhcb_word2">出售中商品</p>
        </li>
        <li class="mhcb_line">
          <p class="mhcb_word1"><font style="color:#cc0607;"><?php if(empty($xj_shop)) { ?>0<?php } else { ?><?php echo $xj_shop;?><?php } ?></font><font style="font-size:12px;">&nbsp;&nbsp;件</font></p>
          <p class="mhcb_word2">待上架商品</p>
        </li>
        <li>
          <p class="mhcb_word1"><font style="color:#cc0607;">0</font><font style="font-size:12px;">&nbsp;&nbsp;件</font></p>
          <p class="mhcb_word2">未通过商品</p>
        </li>
      </ul>
    </div>
  </div>
</div>


<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo SPATH;?>js/ex/jquery.qrcode.js"></script>
<script>
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
    text: $(qrcodes[i]).attr('mlink')
}); 
}
</script>
</body>
</html>
