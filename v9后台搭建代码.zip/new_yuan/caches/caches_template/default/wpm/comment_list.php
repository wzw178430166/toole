<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia {margin-bottom: 15px;}
.xjtb{font-size:8px}
.DynarchCalendar-topCont { width:20%;}
.fahuo_box { width:400px; padding:15px 10px; display:none; position:fixed; left:50%; margin-left:-200px; top:50px; z-index:99; background-color:#fff; border-radius:4px;}
.black_box { width:100%; height:100%; position:fixed; left:0; top:0; background-color:#333; opacity:0.3; display:none;}
.fahuo_box p {
	width: 95%;
    height: 35px;
    line-height: 35px;
    margin: 0 auto;
    border: 1px #D8D8D8 solid;
    border-radius: 4px;
    margin-bottom: 10px;	
}
.fahuo_box p input {
	width: 100%;
    height: 100%;
    border: 0;
    float: left;
	text-indent:10px;	
}
.fahuo_box .fahuo_btn a {
	display: block;
    width: 40%;
    /* float: left; */
    height: 35px;
    line-height: 35px;
    /* border: 1px #D8D8D8 solid; */
    text-align: center;
    font-size: 15px;
    background-color: #519151;
    border-radius: 4px;
    color: #fff;	
}
p { margin:0;}

</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>评价管理 <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="pd-20"> 
    <div class="mt-20">
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="13%" >评价方(买家)</th>
            <th width="13%">商品信息</th>
            <th width="13%">
            	<select name="grade" data-index="grade" onChange="sendSearch(this)">
                	<option value="0" <?php if(!$_GET['grade']) { ?>selected="selected"<?php } ?>>评价(全部)</option>
                    <option value="5" <?php if($_GET['grade'] == 5) { ?>selected="selected"<?php } ?>>五星</option>
                    <option value="4" <?php if($_GET['grade'] == 4) { ?>selected="selected"<?php } ?>>四星</option>
                    <option value="3" <?php if($_GET['grade'] == 3) { ?>selected="selected"<?php } ?>>三星</option>
                    <option value="2" <?php if($_GET['grade'] == 2) { ?>selected="selected"<?php } ?>>二星</option>
                    <option value="1" <?php if($_GET['grade'] == 1) { ?>selected="selected"<?php } ?>>一星</option>
                </select>
            </th>
            <th width="13%">
            	<select name="content" data-index="content" onChange="sendSearch(this)">
                	<option value="0" <?php if(!$_GET['content']) { ?>selected="selected"<?php } ?>>评论(全部)</option>
                    <option value="1" <?php if($_GET['content'] == 1) { ?>selected="selected"<?php } ?>>有评论内容</option>
                    <option value="2" <?php if($_GET['content'] == 2) { ?>selected="selected"<?php } ?>>无评论内容</option>
                </select>
            </th>
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($comments)) { ?>
        <tr id="up_nodata">
          <td colspan="12">您目前没有收到任何评价,或者无任何符合您筛选的评价记录．</td>
        </tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($comments)) foreach($comments AS $r) { ?>
        <?php 
        	$sk = explode('_',$r['orderid']);
        ?>
        <tr id="cid_<?php echo $r['id'];?>" class="text-c">
          <td><?php if($members[$r['userid']]['nickname']) { ?><?php echo $members[$r['userid']]['nickname'];?><?php } else { ?>用户<?php } ?>(<?php echo $r['username'];?>)</td>
          <td style="text-align:left;">
          	<p>订单号: <?php echo $sk['0'];?></p>
          	<?php $n=1;if(is_array($snapshot[$r['orderid']])) foreach($snapshot[$r['orderid']] AS $rr) { ?>
            <p><?php echo $rr['goodstitle'];?></p>
            <p><?php echo $rr['attribute'];?></p>
          	<?php $n++;}unset($n); ?>
          </td>
          <td><?php echo $r['grade'];?>星</td>
          <td><?php echo $r['content'];?> </td>
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>
  </form>
  <div style=" margin-top:20px; float:left"   id="pages">
  	 <?php echo $pages;?>
  </div>
 
</div>
<?php include template($this->file,'js_common'); ?>
<script>
var url = window.location.href;
function sendSearch(obj){
	var param = $(obj).attr('data-index');
	var reg = new RegExp('&'+param+'=[0-9A-Za-z]*');
	url = url.replace(reg, '');
	if($(obj).val() > 0){
		url += '&'+param+'='+$(obj).val();
	}
	window.location.href = url;
}
</script>
</body>
</html>