<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/My97DatePicker/WdatePicker.js"></script>
<style>
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.xjtb{font-size:8px}

.modal {position:absolute;top:50%;left:50%; width:300px;margin-left:-150px;}
.home_main{ margin:0;}
.yd{position:absolute;  left: 106px;
  top: 107px;
}
</style>
<body>
	<nav class="breadcrumb">
		<i class="Hui-iconfont">&#xe67f;</i> 
		首页 <span class="c-gray en">&gt;</span>
		推广数据 
			<a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" >
			<i class="Hui-iconfont">&#xe68f;</i>
		</a>
	</nav>
<!--public header start-->
<div class="header">
	<div class="header_box">
    	<a href="" onClick="window.history.go(-1);" class="header_fanhui"></a>
        <h2 class="header_title">推广链接</h2>
    </div>
</div>
<!--public header end-->
	<div class="pd-20">
        
	  <div class="cl pd-5 bg-1 bk-gray mt-20 tiao"  >
      <span class="l">
      <a class="btn btn-primary radius" href="index.php?m=wpm&c=drm&a=promote_sale_list&wpm=1"><i class="Hui-iconfont">&#xe600;</i> 推广数据</a>
      
      <a class="btn btn-primary radius" href="index.php?m=wpm&c=drm&a=qr_code" data-toggle="modal"><i class="Hui-iconfont">&#xe600;</i>二维码推广</a>
      </span>
    </div>
	  <form action="" method="post">
		<div class="mt-20">
      <!--店铺地址弹出框-->
  		<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
      <h3 id="myModalLabel">手机扫码访问：</h3>
      <a class="close" data-dismiss="modal" aria-hidden="true" href="javascript:void();">×</a>
    </div>
    <div class="modal-body">
      <div class="fl" style="margin-left:44px">
     	 <div class="qrcode" mlink="<?php echo siteurl(1);?>/index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>">
                    <canvas width="180" height="180"></canvas>
      </div>
    </div>
    <div class="modal-footer">
    	<a href="index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>" target="_blank"><input class="btn btn-primary size-M radius" type="button" value="直接访问"></a>
      
      <button class="btn" data-dismiss="modal" aria-hidden="true">关闭</button>
    
 </div>
    </div>
      </div>
      
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead>
          <tr class="text-c">
            <th colspan="2">推广链接地址</th>
          </tr>
        </thead>
        <tbody>
          <tr id="up_nodata">
            <td>
            <input type="text" id="link1" readonly class="input-text" value="<?php echo siteurl(1);?>">
              <br>
              <br><!--onClick="$('#link1').select()" -->
              <a class="btn btn-success" id="copy_btn" href="javascript:;"><i class="Hui-iconfont"></i> 复制</a></td>
          </tr>
          <tr>
          <td  colspan="2" >

<div class="bdsharebuttonbox" style="float:right"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a></div>
<script>window._bd_share_config={ "common":{ "bdSnsKey":{ },"bdText":"唐剑-云掌天下 微信营销方案提供商","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32","bdUrl":"<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>&k=<?php echo $memberinfo['userid'];?>"},"share":{ }};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
</script>
          </td>
          </tr>
        </tbody>
      </table>
   
    </div>
	  </form>
	</div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo SPATH;?>js/ZeroClipboard/ZeroClipboard.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script>
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
    text: $(qrcodes[i]).attr('mlink')
}); 
}
</script>
<script type="text/javascript">
window.onload = function(){
    init();
}
function init(){
    var clip = new ZeroClipboard.Client(); // 新建一个对象
    clip.setHandCursor( true );
    clip.setText(document.getElementById('link1').value); // 设置要复制的文本。
    clip.addEventListener( "mouseUp", function(client) {
        alert("复制成功！");
    });
    // 注册一个 button，参数为 id。点击这个 button 就会复制。
    //这个 button 不一定要求是一个 input 按钮，也可以是其他 DOM 元素。
    clip.glue("copy_btn"); // 和上一句位置不可调换
}
</script>
</body>
</html>

