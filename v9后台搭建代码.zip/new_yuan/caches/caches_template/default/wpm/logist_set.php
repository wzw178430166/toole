<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<link href="<?php echo SPATH;?>css/table_form.css" type="text/css" rel="stylesheet"/>
<body>
<style>
.tiao{ margin-bottom:-13px; }

.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
a{ text-decoration:none !important}
.qrcode_wrapper .qrcode {
  display: none;
  position: absolute;
  left: 0;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia {margin-bottom: 15px;}
.xjtb{font-size:8px}
.DynarchCalendar-topCont { width:20%;}
.fahuo_box { width:400px; padding:15px 10px; display:none; position:fixed; left:50%; margin-left:-200px; top:50px; z-index:99; background-color:#fff; border-radius:4px;}
.black_box { width:100%; height:100%; position:fixed; left:0; top:0; background-color:#333; opacity:0.3; display:none;}
.fahuo_box p {
	width: 95%;
    height: 35px;
    line-height: 35px;
    margin: 0 auto;
    border: 1px #D8D8D8 solid;
    border-radius: 4px;
    margin-bottom: 10px;	
}
.fahuo_box p input {
	width: 100%;
    height: 100%;
    border: 0;
    float: left;
	text-indent:10px;	
}
.fahuo_box .fahuo_btn a {
	display: block;
    width: 40%;
    /* float: left; */
    height: 35px;
    line-height: 35px;
    /* border: 1px #D8D8D8 solid; */
    text-align: center;
    font-size: 15px;
    background-color: #519151;
    border-radius: 4px;
    color: #fff;	
}
.button {
    vertical-align: middle;
    cursor: pointer;
    display: inline-block;
    border-width: 1px;
    border-style: solid;
    border-color: #b3b3b3 #b3b3b3 #9a9a9a;
    text-align: center;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    border-radius: 3px;
    height: 24px;
    line-height: 23px;
    background-color: #f0f0f0;
    padding: 0 12px;
    color: #444!important;
    background-image: -moz-linear-gradient(top,#fcfcfc,#e4e4e4);
    background-image: -ms-linear-gradient(top,#fcfcfc,#e4e4e4);
    background-image: -webkit-gradient(linear,0 0,0 100%,from(#fcfcfc),to(#e4e4e4));
    background-image: -webkit-linear-gradient(top,#fcfcfc,#e4e4e4);
    background-image: -o-linear-gradient(top,#fcfcfc,#e4e4e4);
    background-image: linear-gradient(top,#fcfcfc,#e4e4e4);
}
.logistItem li{ float:left; width:134px; margin-bottom:10px;}
.keep { display:none; height:24px;}
.logistItem { display:none;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span>物流设置 <a class="btn btn-success radius r mr-20" style="line-height:1.6em;margin-top:3px" href="javascript:location.replace(location.href);" title="刷新" ><i class="Hui-iconfont">&#xe68f;</i></a></nav>
<div class="pd-20">
 
    <div class="mt-20">
		<div class="sjia">
        <!--hse 未选中--->
		  <a class="lse" href="javascript:;"style="  text-decoration:none; margin: 0 0 0 22px;" >  <b>物流公司设置</b> </a>  
		  
		</div>
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="15%" >物流服务</th>
            <th width="75%" style="text-align:left; text-indent:1rem;">默认物流公司</th>
            <th width="10%">操作</th>
          </tr>
        </thead>
        <tbody>
        <tr class="text-c">
          <td>在线下单-快递</td>
          <td style="text-align:left; text-indent:1rem;">
          	<ul class="logistItem user_" id="expressUser" style=" display:block">
            	<?php $n=1;if(is_array($userExpress)) foreach($userExpress AS $r) { ?>
                <li><?php echo $express[$r]['name'];?></li>
                <?php $n++;}unset($n); ?>
            </ul>
          	<ul class="logistItem item_" id="expressItem">
            	<form action="index.php?m=wpm&c=logistManage&a=setLogist" method="post" id="expressForm">
                <input type="hidden" name="type" value="express">
            	<?php $n=1;if(is_array($express)) foreach($express AS $r) { ?>
            	<li>
                	<input type="checkbox" name="companNo" value="<?php echo $r['mark'];?>" <?php if(in_array($r['mark'],$userExpress)) { ?>checked="checked"<?php } ?>>
                    <label><?php echo $r['name'];?></label>
                </li>
                <?php $n++;}unset($n); ?>
                </form>
            </ul>
          </td>
		  <td>
          	<a class="button setting express" href="javascript:;" onClick="showLogist('express')">设置</a>
            <a class="button keep" href="javascript:;" onClick="setLogist('express')">保存</a>
          </td>
        </tr>
        <tr class="text-c">
          <td>在线下单-货运</td>
          <td style="text-align:left; text-indent:1rem;">
          <ul class="logistItem user_" id="freightUser" style="display:block;">
          		<?php $n=1;if(is_array($userFreight)) foreach($userFreight AS $r) { ?>
                <li><?php echo $freight[$r]['name'];?></li>
                <?php $n++;}unset($n); ?>
          </ul>
          	<ul class="logistItem item_" id="freightItem">
            <form action="index.php?m=wpm&c=logistManage&a=setLogist" method="post" id="freightForm">
            <input type="hidden" name="type" value="freight">
            	<?php $n=1;if(is_array($freight)) foreach($freight AS $r) { ?>
            	<li>
                	<input type="checkbox" name="companNo" value="<?php echo $r['mark'];?>" <?php if(in_array($r['mark'],$userFreight)) { ?>checked="checked"<?php } ?>>
                    <label><?php echo $r['name'];?></label>
                </li>
                <?php $n++;}unset($n); ?>
            </form>
            </ul>
          </td>
		  <td>
          	<a class="button setting freight" href="javascript:;" onClick="showLogist('freight')">设置</a>
            <a class="button keep" href="javascript:;" onClick="setLogist('freight')">保存</a>
          </td>
        </tr>
          </tbody>
        
      </table>
    </div>
 
</div>
<?php include template($this->file,'js_common'); ?>
<script>
function showLogist(type){
	$('.logistItem').hide();
	$('.user_').show();
	$('.setting').show();
	$('.keep').hide();
	$('.'+type).hide();
	$('#'+type+'User').hide();
	$('#'+type+'Item').show();
	$('.'+type).parent().find('.keep').show();
}
function setLogist(type){
	var selItem = $('#'+type+'Form').find('input[name="companNo"]:checked');
	var data = '';
	selItem.each(function(i) {
        data += $(selItem[i]).val()+','
    });
	$.post('index.php?m=wpm&c=logistManage&a=setLogist&ajax=1',{'type':type,'info':data},function(data){
		if (data.status == 1) {
			window.location.reload();
		} else {
			layer.msg('网络错误, 请稍候再试!');	
		}
	},'json');
}
</script>
</body>
</html>