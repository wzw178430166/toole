<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php include template($this->config['style'],'header_common',$this->config['file']); ?>
<body>
<style>
.tiao{ margin-bottom:-13px; }
.lse{color:rgb(90, 152, 222);}
.hse{color:rgb(158, 153, 153);}
.qrcode_wrapper {
  position: relative;
  cursor: default;
}
.qrcode_wrapper .qrcode {
 display: none;
  position: absolute;
  left: 160px;
  bottom:-50px;
  width: 180px;
  height: 180px;
  padding: 10px;
  -webkit-box-shadow: 0 0 5px #aaa;
  box-shadow: 0 0 5px #aaa;
  background-color: #fff;
  _border: 1px solid #eee;
  z-index: 9999;
}
a, a:hover {
  /* text-decoration: none; */
}
.sjia{ margin:0 0 15px 7px; width:200px; height:30px }
.xjtb{font-size:8px}
.add_node_box { 
	display:none; 
	position:fixed; 
	z-index:99; 
	background-color:#fff;
	padding: 10px;
    width: 400px;
    border: 4px #eee solid;
    border-radius: 4px;
    left: 50%;
    margin-left: -200px;
    top: 100px;}
.black_bg_box { width:100%; height:100%; background-color:#333; opacity:0.4; position:fixed; left:0; top:0; display:none;}
.add_node_box_item p font input {
	border: 1px #eee solid;
    width: 200px;
    height: 25px;
    margin-left: 10px;
    padding-left: 5px;	
}
.add_node_box_item p font.title_ {
	padding-left:15px;	
}
.send_btn { text-align:center;}
.send_btn input { width:80px; margin-right:15px;}
</style>
<nav class="breadcrumb"><i class="Hui-iconfont">&#xe67f;</i> 首页 <span class="c-gray en">&gt;</span> 推广员管理</nav>
<div class="pd-20">
	<div class="promote_action">
    	下级推广账号：<input type="text" id="codetext">&nbsp;&nbsp;下级推广密码：<input type="text" id="codepassword">&nbsp;&nbsp;<input type="button" onClick="add_promote()" value=" 生成二维码 ">
    </div>
    <div class="mt-20">
      
      <table class="table table-border table-bordered table-bg table-hover table-sort">
        <thead >
          <tr class="text-c">
            <th width="13%" >用户名</th>
            <th width="13%">密码</th>
            <th width="13%">姓名</th>
            <th width="13%">ip</th>
            <th width="13%">添加时间</th>
            <th width="13%">分享</th>
            <th width="13%">操作</th>
          </tr>
        </thead>
        <tbody>
        
        <?php if(empty($datas)) { ?>
        <tr id="up_nodata">
          <td colspan="8">暂无推广员</td>
        </tr>
        <?php } else { ?>
        <?php $n=1;if(is_array($datas)) foreach($datas AS $r) { ?>
        
        <tr id="promote_<?php echo $r['id'];?>" class="text-c" >
          <td><?php echo $r['username'];?></td>
           <td><?php echo $r['password_'];?></td>
           <td><?php echo $r['name'];?></td>
          <td><?php echo $r['ip'];?></td>
          <td><span><?php echo date('Y-m-d H:i',$r['addtime']);?></span></td>
          <td><div class="qrcode_wrapper">
          	  <?php 
              	$qrcode_url = siteurl(3).'/index.php?m=wb_shop&plat='.$memberinfo['userid'].'&k='.$r['username'];
              ?>
              <a href="index.php?m=wpm&c=drm&a=create_qrcode&url=<?php echo urlencode($qrcode_url);?>">下载</a>
              <br>	
              <img src="<?php echo SPATH;?>wpm/images/qrcode_26.png" alt="二维码">
              <div class="qrcode" mlink="<?php echo $qrcode_url;?>">
                <canvas width="180" height="180"></canvas>
              </div>
            </div>
            <div>
              
              <a tag="copy" href="javascript:void(0)" id="copy_btn_<?php echo $n;?>" class="lnk_copy" data-clipboard-text="<?php echo $qrcode_url;?>"><i class="icon_file"></i>复制链接</a>
            </div></td>
          <td class="f-14 td-manage">
            <a style="text-decoration:none" class="ml-5" onClick="edit('<?php echo $r['id'];?>')" title="编辑"><i class="Hui-iconfont">&#xe6df;</i></a>
            <a style="text-decoration:none" class="ml-5" onClick="del('<?php echo $r['id'];?>')" href="javascript:;" title="删除"><i class="Hui-iconfont">&#xe6e2;</i></a></td>
        </tr>
        <?php $n++;}unset($n); ?>
        <?php } ?>
          </tbody>
        
      </table>
    </div>
    
  <div id="pages">
     <?php echo $pages;?>
  </div>

</div>
<div class="add_node_box" id="edit_node_box">
	<div class="add_node_box_item">
    	<p><font class="title_">推广员姓名: </font><font><input type="text" id="name" /></font></p>
        <p><font class="title_">重置密码: </font><font><input type="text" id="edit_password" /></font></p>
        <p class="send_btn"><input type="button" value="确定" onClick="edit()"><input type="button" value="取消" onClick="hide_()"></p>
        <input type="hidden" id="node_id" value="0">
    </div>
</div>
<div class="black_bg_box" id="black_bg_box"></div>
<?php include template($this->file,'js_common'); ?> 
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>h_ui/lib/datatables/1.10.0/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="<?php echo SPATH;?>js/ZeroClipboard/ZeroClipboard.js"></script>
<script type="text/javascript">
var qrcodes = $(".qrcode");
	for(var i=0,len=$(qrcodes).length;i<len;i++){
	$(qrcodes[i]).qrcode({ 
		render: "image", //table方式 
		 size: 180,
		 background: "#ffffff",
		text: $(qrcodes[i]).attr('mlink')
	}); 
}
$(function(){
	$('.qrcode_wrapper').mousemove(function(){
		$(this).find('.qrcode').show();	
	}).mouseout(function(){
		$(this).find('.qrcode').hide();		
	});	
})
function edit(id) {
	if (id) { 
		$('#node_id').attr('value', id);
		$('#edit_node_box').fadeIn();
		$('#black_bg_box').fadeIn();
	} else {
		var node_id = $('#node_id').val();
		var password = $('#edit_password').val();
		var name = $('#name').val();
		if (password == '' && name == '') {
			layer.msg('请填写信息!');
			return;
		}
		
		var index = layer.load(2);
		$.post('index.php?m=wpm&c=drm&a=reset_node_password&ajax=1&userid='+node_id, {"password":password,"name":name}, function (data) {
			layer.close(index);
			layer.msg(data.msg, {time:2000});
			if (data.status == 1) {
				setTimeout(function () {
					window.location.reload();
				}, 2000);
				
			}
		}, 'json');
	}
	
}
function del (id) {
	if (confirm('是否删除该推广员?')) {
		if (!id) {
			layer.msg('参数错误!');
			return;	
		}
		var index = layer.load(2);
		$.get('index.php?m=wpm&c=drm&a=del_promote&ajax=1&id='+id, function (data) {
			layer.close(index);
			layer.msg(data.msg);
			if (data.status == 1) {
				$('#promote_'+id).fadeOut();
			}
		}, 'json');
	}
}
function hide_ () {
	$('#black_bg_box').fadeOut();
	$('#edit_node_box').fadeOut();
	$('#node_id').attr('value', '');
	$('body').css({"overflow":"auto", "height":"auto"});
}

function add_promote () {
	var username = $.trim($('#codetext').val());
	var password = $.trim($('#codepassword').val());
	if (username == '' || password == '') {
		layer.msg('账号和密码都不能为空');	
		return;
	}
	var index = layer.load(2);
	$.post('index.php?m=wpm&c=drm&a=add_promote&ajax=1', {"username":username, "password":password}, function (data) {
		layer.close(index);
		layer.msg(data.msg);
		if (data.status == 1) {
			window.location.reload();
			//crcode(username);
		}
	}, 'json');
}

var codeid =1;
function crcode(codetext){
	
	$('#mlink').attr('mlink','<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $memberinfo['userid'];?>&k='+codetext);
	$('#mlink').qrcode({ 
		render: "image", //table方式 
		 size: 180,
		text: $('#mlink').attr('mlink')
	});
	$('#keyvalue').html(codetext);
	var tpl = '<tr class="codeid_'+(Number(codeid)+1)+'">'+$('#template').html()+'</tr>';	
	//$('.codeid_'+codeid).after(tpl);
	$('.codeid_'+1).after(tpl);
	codeid++;

}
</script>
</body>
<script type="text/javascript">
window.onload = function(){
    init();
}
function init(){
	var ln_copy = $('.lnk_copy');
	ln_copy.each(function(i) {
        var clip = new ZeroClipboard.Client(); // 新建一个对象
		clip.setHandCursor( true );
		clip.setText($(ln_copy[i]).attr('data-clipboard-text')); // 设置要复制的文本。
		clip.addEventListener( "mouseUp", function(client) {
			alert("复制成功！");
		});
		// 注册一个 button，参数为 id。点击这个 button 就会复制。
		//这个 button 不一定要求是一个 input 按钮，也可以是其他 DOM 元素。
		clip.glue("copy_btn_" + (i+1)); // 和上一句位置不可调换
    });
    
}
</script>
</html>