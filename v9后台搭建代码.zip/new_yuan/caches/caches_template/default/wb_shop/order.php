<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename='我的订单';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo SPATH;?>js/layer/1.9.3/layer.js" type="text/javascript"></script>
<style>
.box_1 .userCenterBox .userMenu a { margin-bottom:5px; font-size:14px;}
.news_order table tr td.ac_btn a { width:auto; padding:0 10px; float:left; margin:0;margin-right:5px;}
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 我的订单 </div>
</div>
<div class="blank"></div>
<div class="tt01">
	<div class="tt01_box">
    	<?php include template("member", "member_left"); ?>
        <div class="member_right">
        	<div class="news_order">
                	<p class="order_title"><font>我的订单</font></p>
                    <table border="0" cellspacing="0">
                    	<tbody>
                            <tr>
                                <th align="left">订单号</th>
                                <th align="left" width="350">商品名称</th>
                                <th>价格</th>
                                <th>日期</th>
                                <th>状态</th>
                                <th width="100">操作</th>
                            </tr>
                            <?php if($orderlist) { ?>
                            <?php $nn = 1;?>
                            <?php $n=1; if(is_array($orderlist)) foreach($orderlist AS $orderid => $list) { ?>
                            <?php $kk = 1;?>
                             <?php $n=1;if(is_array($list)) foreach($list AS $r) { ?>
                      <tr class="tr_list <?php if($nn%2 != 0 || $kk%2 == 0) { ?>bg<?php } ?>">
                                <td class="left_al"><?php echo $r['orderid'];?></td>
                                <td class="left_al"><?php echo $r['goodsinfo']['title'];?></td>
                                <td class="red_font">￥<?php echo number_format($r['goodsinfo']['jiage'],'2');?></td>
                                <td><?php echo date('Y-m-d', $r['addtime']);?></td>
                                <td class="red_font">
                                       <?php if($r['status']==99) { ?>
                                         订单成功
                                       <?php } elseif ($r['status']==1) { ?>
                                         未付款
                                       <?php } elseif ($r['status']==2) { ?>
                                         已付款
                                       <?php } elseif ($r['status']==3) { ?>
                                         待收货
                                       <?php } elseif ($r['status']==4) { ?>
                                         退款中
                                       <?php } elseif ($r['status']==5) { ?>
                                         待评价
                                       <?php } elseif ($r['status']==98) { ?>
                                       	 已取消
                                       <?php } ?>
                                </td>
                                <td class="ac_btn">
                                    <?php if($r['status'] == 1) { ?> 
                                    <a href="javascript:;" onClick="cancelOrder('<?php echo $r['id'];?>')">取消</a>
                                    <?php } ?>
                                	<a href="index.php?m=wb_shop&c=index&a=order_details&plat=<?php echo $_GET['plat'];?>&id=<?php echo $r['id'];?>">查看</a>
                          	</td>
                            </tr>
                            <?php $kk++;?>
                            <?php $n++;}unset($n); ?>
                            <?php $nn++;?>
                            <?php $n++;}unset($n); ?>
                            <?php } else { ?>
                            <tr class="tr_list bg">
                            	<td class="left_al" colspan="6">暂无订单</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div><!--news_order end-->
        </div>
    </div>
</div>
<div class="blank"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script>
function cancelOrder(id) {
	layer.alert('是否取消该订单',{btn:['确定','取消']},function(){
		var url = "index.php?m=wb_shop&c=index&a=order_display2&plat=<?php echo $_GET['plat'];?>&id="+id+"&ajax=1";
		$.get(url,function(data){
			var msg = data.status == 1 ? '取消成功' : '取消失败!';
			layer.msg(msg,{time:1500});
			setTimeout(function(){
				window.location.href = "index.php?m=wb_shop&a=order&plat=<?php echo $_GET['plat'];?>";
			},1500);
			
		},'json');	
	
	});
	
}
</script>
</html>