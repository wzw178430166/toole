<?php defined('IN_drcms') or exit('No permission resources.'); ?><!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo $this->Company['keywords'];?>">
<meta name="description" content="<?php echo $this->Company['description'];?>">
<title><?php if($titlename) { ?><?php echo $titlename;?><?php } else { ?><?php echo $thisCompany['name'];?><?php } ?></title>
<link href="statics/wb_shop/tmp_info_pc/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/common.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/jquery.json.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/transport_jquery.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/utils.js"></script>
<style>
.qrcode {
	position: absolute;
    right: 220px;
    top: 10px;
    background-color: #fff;
    width: 130px;
    height: 130px;
}  
.qrcode img { width:120px; height:120px; margin-top:5px;}
.header-logo { width:180px;  padding-top:0; max-height:70px; overflow:hidden; margin-top:35px;}
.header-logo-index img { width:100%; /*max-height:70px;*/ margin-top:-30px}
</style>
</head>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<script type="text/javascript">
common_check_login();
//设为首页 www.ecmoban.com
function SetHome(obj,url){
    try{
        obj.style.behavior='url(#default#homepage)';
       obj.setHomePage(url);
   }catch(e){
       if(window.netscape){
          try{
              netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
         }catch(e){
              alert("抱歉，此操作被浏览器拒绝！\n\n请在浏览器地址栏输入“about:config”并回车然后将[signed.applets.codebase_principal_support]设置为'true'");
          }
       }else{
        alert("抱歉，您所使用的浏览器无法完成此操作。\n\n您需要手动将【"+url+"】设置为首页。");
       }
  }
}
//收藏本站 bbs.ecmoban.com
function AddFavorite(title, url) {
  try {
      window.external.addFavorite(url, title);
  }
catch (e) {
     try {
       window.sidebar.addPanel(title, url, "");
    }
     catch (e) {
         alert("抱歉，您所使用的浏览器无法完成此操作。\n\n加入收藏失败，请使用Ctrl+D进行添加");
     }
  }
}

function common_check_login() {
	var info_ = new Array();
	var html_ = '';
	$.ajax({
		url:'index.php?m=member&a=check_info_ajax&ajax=1',
		type:"GET",
		dataType:"json",
		success: function(data){
			if (data.status == 1) {
				info_ = data.info;
				html_ = '你好，<a href="index.php?m=member&c=index">'+info_['username']+'</a> | <a href="index.php?m=member&a=logout">退出</a> | ';
				$('.header-login-info').empty();
				$('.header-login-info').html(html_);
				
			} 
		}
	});
}
</script>