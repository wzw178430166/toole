<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop', 'header_common'); ?>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/global.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/compare.js"></script>
<body>
<?php include template('wb_shop', 'header'); ?>
<?php 
	$pro_title = '商品列表';
	if ($_GET['new']) {
    	$pro_title = '新品上市';
    }
    if ($_GET['rx']) {
    	$pro_title = '热卖商品';
    }
    if ($_GET['jp']) {
    	$pro_title = '精品推荐';
    }
?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置:
    <a href=".">首页</a>
    <code>&gt;</code> <?php if($_GET['classify']) { ?><?php echo $cates[$_GET['classify']]['catname'];?><?php } else { ?><?php echo $pro_title;?><?php } ?></div>
</div>
<div class="blank"></div>
<div class="block clearfix">
<div class="AreaL">
<?php include template('wb_shop', 'cate_left'); ?>

</div>

<div class="AreaR">
  <div class="box">
    <div class="box_1">
      <ul class="goods_list">
        <span><?php echo $pro_title;?></span>
        <form action="" method="post" class="sort" name="listform" id="sort_form">
       
          <li style="margin-top: -4px;*margin-top: 0;">
            <select name="sort">
              <option value="goods_id" <?php if($_POST['sort'] == 'goods_id') { ?>selected<?php } ?>>按上架时间排序</option>
              <option value="shop_price" <?php if($_POST['sort'] == 'shop_price') { ?>selected<?php } ?>>按价格排序</option>
              <option value="last_update" <?php if($_POST['sort'] == 'last_update') { ?>selected<?php } ?>>按更新时间排序</option>
            </select>
          </li>
          <li style="margin-top: -4px;*margin-top: 0;">
            <select name="order">
              <option value="DESC" <?php if($_POST['order'] == 'DESC') { ?>selected<?php } ?>>倒序</option>
              <option value="ASC" <?php if($_POST['order'] == 'ASC') { ?>selected<?php } ?>>正序</option>
            </select>
          </li>
          <li style="margin-top: -4px;*margin-top: 0;">
            <input type="image" name="imageField" src="statics/wb_shop/tmp_info_pc/images/bnt_go.gif" alt="go"/>
          </li>
          
        </form>
      </ul>
      <form action="compare.php" method="post" name="compareForm" id="compareForm" onSubmit="return compareGoods(this);">
        <div class="clearfix goodsBox" style="border:none; ">
        <?php 
        	$listorder_ = '';
        	$owhere = 'status = 99';
            
            if ($_GET['keywords']) {
            	$owhere .= ' AND `title` like "%' . $_GET['keywords'] . '%"';
            }
            //分类
            if ($_GET['classify']) {
            	$cate = (int)$_GET['classify'];
            	$owhere .= ' AND `classify` =' . $cate;
            }
            if ($_GET['rx']) {
            	$owhere .= ' AND `rexiao` = 1';
            }
            if ($_GET['jp']) {
            	$owhere .= ' AND `jingpin` = 1';
            }
        	if ($_GET['new']) {
            	$listorder_ = '`inputtime` ';
            }
            //搜索
            if ($_POST['sort']) {
            	
            	$sort_ = $_POST['sort'];
                $order_ = $_POST['order'];
            	switch($sort_){
                	case 'goods_id':
                    	$listorder_ = '`inputtime` ';
                    	break;
                    case 'shop_price':
                    	$listorder_ = '`jiage` ';
                    	break;
                    case 'last_update':
                    	$listorder_ = '`updatetime` ';
                    	break;
                }
                $listorder_ .= $order_;
                //var_dump($listorder_);die;
            }
            //var_dump($listorder_);die;
        ?>
        <?php if($_GET['new'] || $_POST['sort']) { ?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=b884e9257b3cb6da7b81d9d43970dad0&action=lists&catid=6&owhere=%24owhere&order=%24listorder_&num=12&return=list_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$list_data = $content_tag->lists(array('catid'=>'6','owhere'=>$owhere,'order'=>$listorder_,'num'=>'12','limit'=>'12',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <?php } else { ?>
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=62f722af2e8ba850f95466b7075bca93&action=lists&catid=6&owhere=%24owhere&num=12&return=list_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$list_data = $content_tag->lists(array('catid'=>'6','owhere'=>$owhere,'num'=>'12','limit'=>'12',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <?php } ?>
        <?php $n=1;if(is_array($list_data)) foreach($list_data AS $r) { ?>
        <?php 
        	$this->goods_db->load('pro_category');
            $cate_item = $this->goods_db->get_one(array('catid'=>$r['classify']));
        ?>
          <div class="goodsItem">
            <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>">
            <img src="<?php echo $r['thumb'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $cate_item['catname'];?>列表_<?php echo $r['title'];?>" class="goodsimg" /></a>
            <br />
            <p style="height: 36px; overflow: hidden;">
              <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" title=""><?php echo $r['title'];?></a>
            </p>
            <?php if($r['jiage']) { ?>本店价：<font class="shop_s">￥<?php echo $r['jiage'];?>元</font><?php } else { ?>暂无价格<?php } ?><br />
          </div>
          <?php $n++;}unset($n); ?>
          
        </div>
      </form>
    </div>
  </div>
  <div class="blank"></div>
  <form name="selectPageForm" action="/mbkaola/search.php" method="get">
    <div id="pager" class="pagebar">
      <span class="f_l " style="margin-right:10px;">总计 <b><?php echo count($list_data);?></b> 个记录</span>
    </div>
  </form>
</div>
</div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
</html>