<?php defined('IN_drcms') or exit('No permission resources.'); ?> <?php $titlename = $title;?>
<?php include template('wb_shop', 'header_common', 'first'); ?>
<script type="text/javascript" src="statics/js/global.js"></script>
<style>
.sh_box {
	padding: 15px;
    font-size: 15px;
    line-height: 40px;
	text-align:left;
}
.picture p {
	float:left;	
}
.picture img { border:1px #fff solid;}
.pro_box h3 { height:inherit;}
#pro_desc img { width:98%; text-align:center}
.box_1 img{ float:left;}
.box_1_{ width:84%; overflow:hidden; margin:0 auto; float:initial;}
.box_1_ div{ margin:inherit !important; float:left;}
.qq {
    position: fixed;
    right: 0;
    top: 30%;
    border: 5px solid #1e90ff;
    width: 80px;
    overflow: hidden;
    z-index: 9999;
    border-radius: 5px;
    background-color: #fff;
}
.qq p {
    font-size: 12px;
    background-color: #1e90ff;
    color: #fff;
    display: block;
    text-align: center;
    margin-bottom: 5px;
}
</style>
<script type="text/javascript">
function $id(element) {
  return document.getElementById(element);
}
</script>
<body>
<?php include template('wb_shop', 'header', 'first'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置:
    <a href=".">首页</a>
    <code>&gt;</code>
    <a href=""><?php echo $cates[$classify]['catname'];?></a>
    <code>&gt;</code> <?php echo $title;?> 
  </div>
</div>
<div class="blank"></div>
<div class="block clearfix">
<div class="AreaL">
<?php include template('wb_shop', 'cate_left', 'first'); ?>
</div>
<div class="AreaR">
  <div id="goodsInfo" class="clearfix">
    <div class="imgInfo">
      <a href="<?php echo $thumb;?>" id="zoom1" class="MagicZoom MagicThumb" title="<?php echo $title;?>" target="_blank">
      <img src="<?php echo $thumb;?>" alt="<?php echo $this->Company['name'];?>_<?php echo $title;?>" width="360px;" height="360px"/>
      </a>
      <div class="blank5"></div>
      <div class="blank"></div>
      <div class="picture">
      	<?php $n=1;if(is_array($d_cptu)) foreach($d_cptu AS $r) { ?>
        <p onClick="sel_img(this)" class="pic_list">
        	<img src="<?php echo $r['url'];?>" alt="<?php echo $title;?>" class="<?php if($n == 1) { ?>onbg<?php } ?>" />
        </p>
        <?php if($n >=5) { ?>
        <?php break;?>
        <?php } ?>
        <?php $n++;}unset($n); ?>
      </div>
      <script>
      	function sel_img(obj) {
			$(obj).attr('href', '');
			$('.onbg').removeClass('onbg');
			var small_img = $(obj).find('img').attr('src');
			$('#zoom1').find('img').attr('src', small_img);
			$(obj).find('img').addClass('onbg');
		}
      </script>
      
    </div>
    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=4976dba22869bb91e2404f45d11ad595&sql=SELECT+%2A+FROM+%60drcms_wb_shop_attribute%60+WHERE+goodsid%3D%24id&return=shop_attribute_\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_wb_shop_attribute` WHERE goodsid=$id LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$shop_attribute_ = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    <?php
    $bianshiid = 1;
    foreach($shop_attribute_ as $k=>$r){
        if(!$shop_attribute[$r['attribute']]){
            $shop_attribute[$r['attribute']]['bianshiid'] = $bianshiid;
            $bianshiid++;
        }
        $shop_attribute[$r['attribute']]['size'][] = $r;
       if ($_GET['me']) {
       		//var_dump($shop_attribute);die;
       }
    }
    $url = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
    $ll_url = $_SERVER['HTTP_REFERER'];
    
    //兼容积分商品
    $point = $is_point ? $jiage : 0;
    $jiage = $is_point ? ($jiage)/100 : $jiage;
   
    ?>
    <div class="textInfo">
      <form action="index.php?m=wb_shop&a=confim&forward=<?php echo urlencode('index.php?m=wb_shop&a=show&catid='.$catid.'&id='.$id);?>" method="post" name="ECS_FORMBUY" id="ECS_FORMBUY" >
      <input type="hidden" name="goodsid" value="<?php echo $id;?>">
    <input type="hidden" name="goodscatid" value="<?php echo $catid;?>">
    <input type="hidden" name="yun_fei" value="<?php echo $yun_fei;?>">
    <input type="hidden" name="plat" value="<?php if($dp_id) { ?><?php echo $dp_id;?><?php } else { ?><?php echo $plat;?><?php } ?>">
        <h1 class="clearfix" > <?php echo $title;?> </h1>
        <ul class="ul2 clearfix">
          <li class="clearfix" style="width:100%">
            <dd>
            <?php if($jiage) { ?>
              <strong>本店售价：</strong>
              <font class="shop" id="ECS_SHOPPRICE" data-money="<?php echo $jiage;?>">
              ￥
              <?php echo number_format($jiage, 2);?>
              元
              </font>
              <?php if($yuanjiage) { ?>
              <font class="market">
              ￥
              <?php echo number_format($yuanjiage, 2);?>
              元
              </font>
              <?php } ?>
            <?php } else { ?>
            暂无价格
            <?php } ?>
            </dd>
          </li>
          <li class="clearfix">
            <dd>
              <strong>商品货号：</strong><?php echo $id;?> </dd>
          </li>
          <li class="clearfix">
            <dd>
              <strong>商品库存：</strong> 
              <em id="pro_kc">获取中...</em> 
            </dd>
          </li>
          
          <li class="clearfix">
            <dd>
              <strong>上架时间：</strong><?php echo date('Y-m-d', strtotime($inputtime));?></dd>
          </li>
          <li class="clearfix">
            <dd>
              <strong>商品点击数：</strong>10 </dd>
          </li>
        </ul>
        <style>
        .attr_dd {
			width:100%;	
		}
		.attr_dd strong { float:left;}
		.attr_dd a.attr_ {
			padding: 0 20px;
			height: 25px;
			display: block;
			line-height: 25px;
			text-align: center;
			text-decoration: blink !important;
			background-color: #fff;
			border: 1px #ededed solid;
			float: left;
			margin:0 5px;	
		}
		.attr_dd a.sattr {
			border: 1px #dd2727 solid;
			color:#dd2727 !important;
		}
		#goodsInfo .textInfo a { color:inherit;}
        </style>
        <ul class="bnt_ul">
        <?php $att_one = 0;?>
        <?php $att_one_kc = 0;?>
        <?php if($shop_attribute) { ?>
        <?php $n=1; if(is_array($shop_attribute)) foreach($shop_attribute AS $k => $r) { ?>
          <li class="clearfix">
            <dd class="attr_dd">
              <strong><?php echo $k;?>：</strong>
              <?php $n=1;if(is_array($r['size'])) foreach($r['size'] AS $r2) { ?>
         		<?php 
                	if ($n == 1) {
                    	if ($att_one != 0) {
                        	if ($r2['kc'] < $att_one_kc) {
                            	$att_one = $r2['id'];
                            }
                        } else {
                        	$att_one = $r2['id'];
                            $att_one_kc = $r2['kc'];
                        }
                    }
                ?>
              <label>
              <a href="javascript:;" class="atpye_<?php echo $r['bianshiid'];?> attr_ <?php if($n == 1 && $r2['kc'] >0) { ?>sattr<?php } ?>" <?php if($r2['kc']>0) { ?>onClick="sel_attr(this, '<?php echo $r2['id'];?>', '<?php echo $r['bianshiid'];?>');"<?php } else { ?>style=" cursor: not-allowed;border: 1px #b3adad dashed; opacity: 0.5"<?php } ?> data-kc="<?php echo $r2['kc'];?>"><?php echo $r2['size'];?></a>
              <input name="attribute[<?php echo $catid;?>_<?php echo $id;?>][<?php echo $r2['id'];?>]" <?php if($n == 1) { ?>checked="checked"<?php } ?> id="attname_<?php echo $r2['id'];?>" style=" opacity:0" type="radio" class="atype_inp_<?php echo $r['bianshiid'];?>" value="1" data-kc="<?php echo $r2['kc'];?>"/>
              </label>
              <?php $n++;}unset($n); ?>
            </dd>
          </li>
         <?php $n++;}unset($n); ?>
          <?php } else { ?>
          <input type="hidden" name="attribute[0][wu]" id="empty_attr" value="1" style="opacity:0; width:0; height:0">
          <?php } ?>
          <?php if($jiage) { ?>
          <li class="clearfix">
            <dd>
              <strong>购买数量：</strong>
              <input type="text" id="number" value="1" size="4" onBlur="changePrice()" style="border:1px solid #ccc; "/>
              <strong>商品总价：</strong><font id="ECS_GOODS_AMOUNT" class="f1">￥<?php echo number_format($jiage, 2);?>元</font>
            </dd>
          </li>
          
          <script>
		  //有属性默认选中第一个
          function sel_attr (obj, id, bsid) {
			  
			  $('.atpye_' + bsid).removeClass('sattr');
			  $(obj).addClass('sattr');
			  $('.atype_inp_'+bsid).prop('checked', false);
			  $('#attname_'+id).prop('checked','checked');
			  get_pro_kc('<?php echo $id;?>', id);
			  
		  }
          </script>
          <li class="padd">
          <?php 
            $url = 'index.php?m=wb_shop&c=index&a=show&catid='.$catid.'&id='.$id . '&plat=' . $_GET['plat'];
            //echo $url;
          	$forward_ = urlencode($url);
            //echo $forward_;
          ?>
            <a  class="btn_pink_138x32" href="javascript:add_cart()" style="color:#FFF;text-decoration:none;">加入购物车</a>
            <a  class="btn_pink_138x32" href="javascript:send_buy()" style="color:#FFF;text-decoration:none;">立即购买</a>
          </li>
          <?php } ?>
        </ul>
      </form>
    </div>
  </div>
  <div class="blank"></div>
  <script>
  	function sel_box(act, obj) {
		$('#com_b').find('h2').removeClass('h2bg').addClass('h2bg');
		$(obj).removeClass('h2bg');
		$('.pro_box').hide();
		$('#com_' + act).show();
	}
	
	//图片预加载 更换正式图片
	function cimgonload () {
		var data_src = '';
		var img_  = $('.pro_box').find('img');
		img_.each(function(i) {
			data_src = $(this).attr('data-src');
			$(this).attr('src', data_src);
		});
	}
  </script>
  
  <div class="box">
    <div style="padding:0 0px;">
      <div id="com_b" class="history clearfix">
        <h2 onClick="sel_box('h', this)">商品描述</h2>
        <h2 class="h2bg" onClick="sel_box('sh', this)">售后服务</h2>
       <!--<h2 class="h2bg">商品标签</h2>
        <h2 class="h2bg">相关商品</h2>-->
      </div>
    </div>
    <div class="box_1" >
      <div id="com_v" class="  " style="padding:6px; display:none;"></div>
      <div id="com_h" class="pro_box">
        <blockquote>
        </blockquote>
        <blockquote>
          <table class="table" width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#dddddd">
          </table>
        </blockquote>
        <blockquote>
          <div class="box">
            <div class="box_1" id="pro_desc">
            	<div class="box_1_">
           	<?php echo $content;?>
              
            </div>
          </div>
          </div>
          <div class="blank5"></div>
        </blockquote>
        <blockquote>
        </blockquote>
      </div>
      <!--售后-->
      <div id="com_sh" class="pro_box" style="display:none;">
        <blockquote>
        </blockquote>
        <blockquote>
          <table class="table" width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#dddddd">
          </table>
        </blockquote>
        <blockquote>
          <div class="box">
          	
            <div class="box_1 sh_box">
            <p>售后保障：</p>
            <p>1、客户在收货时无论外包装箱是否破损，都需开箱检查并根据随货批发清单核对货品总数，确认总数无误后进行逐一验收。</p>
            <p>2、收货2天内（以运单签收日期为准），及时反馈产品信息和收货信息，逾期不予处理。作假虚报的情况一经核实不予受理。</p>
            <p>3、若有产品因运输问题产生破损等情况，请让相关运输公司出具盖章证明，并将此证明提供给我们，由我们来协助客户进行索赔。</p>
            <p>4、破损商品的补损流程：收货2天内联系区域客服人员，提供破损商品照片（正面全图，破损配件特写），区域客服人员审核属实予以补发破损配件。为了降低运输过程破损概率，原则上配件在下一次订单出货时一并发出。</p>
            <p>5、客户对产品颜色或款式有指定要求的，请在备注栏注明颜色和款式，未说明的我们将随机发货。</p>
            <p>6、未按要求收货的，我们将不承担相关责任。</p>
            </div>
          </div>
          <div class="blank5"></div>
        </blockquote>
        <blockquote>
        </blockquote>
      </div>
    </div>
  </div>
  <div class="blank"></div>
</div>
</div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer', 'first'); ?>
</body>
<script type="text/javascript" src="<?php echo JS_PATH;?>layer/1.9.3/layer.js"></script>
<script type="text/javascript">
window.onload = function ()　{
	AutoImage('pro_desc', 850, 0);
	cimgonload();
}

function changePrice()
{
	
  //var attr = getSelectedAttributes(document.forms['ECS_FORMBUY']);
  var result = 0;
  var money = "<?php echo $jiage;?>";
  var qty = document.forms['ECS_FORMBUY'].elements['number'].value;
  //alert(isNaN(qty));return;
  if (parseInt(qty) <= 0 || isNaN(qty)) {
	  $('#number').prop('value', 1);
	  $('.attr_dd').find('input[type="radio"]:checked').attr('value', 1);
	  document.getElementById('ECS_GOODS_AMOUNT').innerHTML = '￥' + $('#ECS_SHOPPRICE').attr('data-money') + '元';
	  return;
  }
  $('.attr_dd').find('input[type="radio"]:checked').attr('value', qty);
  result = '￥' + money * qty + '元';
  document.getElementById('ECS_GOODS_AMOUNT').innerHTML = result;
}

//加入购物车
function add_cart(){
	var is_empty = false;
	var attred = $('.attr_dd').find('input[type="radio"]:checked');
	attred.each(function(i) {
        if ($(this).attr('data-kc') == 0) {
			is_empty = true;
		}
    });
	if (is_empty == true) {
		layer.msg('库存不足!');
		return;
	}
	var forward_ = "<?php echo $forward_;?>"; 
	//alert(forward_);die;
	//var f = 'index.php?m=wb_shop&a=show&catid=1&id=115&plat=3';
	//var index = layer.load(2);
	var index = layer.load(1, {shade: [0.1,'#fff'] });
	$.ajax({
		cache: true,
		type: "POST",
		url:'index.php?m=wb_shop&a=add_cart',
		data:$('#ECS_FORMBUY').serialize().replace(/\&count.*/,'')+'&ajax=1&count='+parseInt($('#pro_num').val()),
		async: false,
		error: function(request) {
			layer.close(index);
			layer.msg('操作失败,请稍后再试');
			return false;
		},
		success: function(data) {
			 
			var da = data;
			setTimeout(function(da){
				layer.close(index);
				var json_data =  eval('(' + data + ')');
				if(json_data.status==1){
					try{ getgoodscart(); }catch(e){ }
					//layer.msg('已加入购物车');
					alert('已加入购物车');
				}else if(json_data.status==-1){
					try{ show_login(); }catch(e){
						
						window.location.href='index.php?m=member&a=login&plat=<?php echo $plat;?>&forward='+forward_;	
					}
				}else{
					//layer.msg(json_data.msg);
					alert(json_data.msg);
				}
				return false;
		},300)},
	});	
	return false;
}

//浏览历史(只对商品)
function ll_lishi(){
	$.post('?m=wb_shop&a=ll_lishi&ajax=1',{'plat':'<?php echo $_GET["plat"];?>','catid':'<?php echo $_GET["catid"];?>','id':'<?php echo $_GET["id"];?>'},function(data){
          
		/*if(data==0){
		layer.msg('记录浏览历史失败');
			}*/
		})
}
ll_lishi();

get_pro_kc('<?php echo $id;?>', '<?php echo $att_one;?>');
//获取商品库存
function get_pro_kc (id, attid) {
	var info_ = new Array();
	var url = 'index.php?m=wb_shop&c=index&a=getProKc&ajax=1&id=' + id + '&att_id=' + attid;
	$.get(url, function (data) {
		
		if (data.status == 1) {
			info_ = data.info;
			$('#pro_kc').text(info_.attr_1);
			//if (info_.attr_1 <= 0) {
				//$('#attname_' + attid).css({cursor:"not-allowed", border:"1px #b3adad dashed"});
			//}
		} else if (data.status == 2) {
			$('#pro_kc').text(data.info)
		} 
	}, 'json');
}

function send_buy () {
	var is_empty = false;
	var attred = $('.attr_dd').find('input[type="radio"]:checked');
	attred.each(function(i) {
        if ($(this).attr('data-kc') == 0) {
			is_empty = true;
		}
    });
	if (is_empty == true) {
		layer.msg('库存不足!');
		return;
	}
	
	$('#ECS_FORMBUY').submit()	
}
</script>
</html>