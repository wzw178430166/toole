<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo $this->Company['keywords'];?>">
<meta name="description" content="<?php echo $this->Company['description'];?>">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<meta content="yes" name="apple-mobile-web-app-capable">
<meta content="black" name="apple-mobile-web-app-status-bar-style">
<meta content="telephone=no" name="format-detection">
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/style6.css?<?php echo SYS_TIME;?>" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>shop_tmp/index6/css/style6.css?<?php echo SYS_TIME;?>" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/shop2.css" />
<link rel="stylesheet" media="(min-width:640px)" href="<?php echo SPATH;?>wb_shop/css/small.css" />
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>global.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>documentTips.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>cookie.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/TouchSlide.1.1.js"></script>

<title><?php echo $title;?></title>
<style>
@-webkit-keyframes delayimg_
{ from { opacity: 0.1;} to { opacity:1;} }
.delayimg{ -webkit-animation: delayimg_ .5s; }
</style>
</head>
<script>
var siteurl = '<?php echo siteurl(1);?>';
try{ jstojava.mysetgoback('goback()'); }catch(e){}

function in_array(search,array){
    for(var i in array){
        if(array[i]==search){
            return true;
        }
    }
    return false;
}
</script>