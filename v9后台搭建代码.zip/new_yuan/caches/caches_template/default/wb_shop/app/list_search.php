<?php defined('IN_drcms') or exit('No permission resources.'); ?><!--<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>yz/app/css/number.css" />-->
<link href="<?php echo SPATH;?>js/mobiscroll/mobiscroll.2.13.2.css" rel="stylesheet" type="text/css">
<style>
.jiage{
    width: 76px;
    text-align: center;
    height: 33px;
    color: #D86062;
    font-size: 20px;
	border: 1px solid #dbdbdb;
}
</style>
<div class="header " id="search_header" style="display:none">
  <div class="header_box">
    <a href="javascript:hideb()" class="Hui-iconfont Hui-iconfont-arrow2-left header_fanhui">
    </a>
    <h2 class="header_title">分类筛选</h2>
  </div>
</div>
<div class="sele_num search_box hide" id="search_box" style="background:#FFF;">
  
  <div id="item1"  class="searitem" data-typeid="14">
    <div class="gsd_search">
      <p class="gsds_p1"style=" margin:0 0 0 6px">价格范围</p>
      <div style="margin-left: 17px;" class="gsds_list" >
        <input class="jiage" type="text" onChange="jiage(this,1)" value="<?php if($_GET['ks']) { ?><?php echo $_GET['ks'];?><?php } else { ?>0<?php } ?>">
        <span> &nbsp;—&nbsp; </span>
        <input class="jiage" onChange="jiage(this,2)" type="text" value="<?php if($_GET['js']) { ?><?php echo $_GET['js'];?><?php } else { ?>0<?php } ?>">
        <!--<a onClick="qc('ks','jiage','0','js')" name="jiage" class="history2 <?php if(!$_GET['ks']&&!$_GET['js']) { ?>history3<?php } ?>">
        全部
        </a>-->

      </div>
    </div>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=2ed5f07884fd77491a039f605604e6ab&sql=SELECT+%2A+FROM+%60drcms_pro_category%60&return=categoryinfo\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_pro_category` LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$categoryinfo = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
 <?php if($categoryinfo) { ?>
    <div class="gsd_search">
      <p class="gsds_p1"style=" margin:0 0 0 6px">分类</p>
      <div class="gsds_list">
        <?php $n=1;if(is_array($categoryinfo)) foreach($categoryinfo AS $p) { ?>
        <a onClick="cat(this)" cat="<?php echo $p['catid'];?>" style=" font-size:17px; background-color:#EE8C8E; border:none"  name="jiage" class="	history2 history3">
          <?php echo $p['catname'];?>
        </a>
        <?php $n++;}unset($n); ?>
      </div>
    </div>
  <?php } ?>  
  </div>

<div class="ana_bottom_" style=" position:fixed; bottom:0px; width:100%; height:50px; background:##e3383b;">
    <a  class="ana_bottom_btn" href="javascript:;" onClick="hideb();get_infos('reset');">按条件开始筛选</a>
</div>
<script>
//$('.ana_bottom_btn').attr('href',window.location.href);
//var url = window.location.href;
function cat(obj){
  	$('.history2').removeClass('hong');$(obj).addClass('hong');
 	//var url = $('.ana_bottom_btn').attr('href');
  	var reg = new RegExp("class=[0-9a-z]*|\&class=[0-9a-z]*");
	url = url.replace(reg,'');
	url = url+'&class='+ $(obj).attr('cat');
	window.history.pushState({status:'watting'},'',url);
	//$('.ana_bottom_btn').attr('href',url); 
}
function jiage(obj,yn){
  $(obj).val(Number($(obj).val())); 
  //var url = $('.ana_bottom_btn').attr('href');
  if(yn==1){
	   if(Number($(obj).next().next().val())>0){
			if($(obj).val()<=0){
			  $(obj).val(0);
			}else if(Number($(obj).val())>Number($(obj).next().next().val())){ 
			  $(obj).val($(obj).next().next().val());
			}	
	    }
		//qc('ks','jiage','0','js');
	    var reg = new RegExp("ks=[0-9a-z]*|\&ks=[0-9a-z]*");
	    url = url.replace(reg,'');
		url = url+'&ks='+ $(obj).val();
		//$('.ana_bottom_btn').attr('href',url); 
		
   }else{
	    if(Number($(obj).val())<Number($(obj).prev().prev().val())){
	    $(obj).val($(obj).prev().prev().val()); 
	    }
	    var reg = new RegExp("js=[0-9a-z]*|\&js=[0-9a-z]*");
	    url = url.replace(reg,'');
		url = url+'&js='+ $(obj).val();
		//$('.ana_bottom_btn').attr('href',url); 
   }
   window.history.pushState({status:'watting'},'',url);
}
</script>
