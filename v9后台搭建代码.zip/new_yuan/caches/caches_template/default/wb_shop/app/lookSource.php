<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title = '商品预订';?>
<?php include template($this->config['style'],'header_common2'); ?>
<link type="text/css" rel="stylesheet" href="statics/js/diyUpload/css/diyUpload.css" />
<link type="text/css" rel="stylesheet" href="statics/js/diyUpload/css/webuploader.css" />
<style>
.nobd{ width:100%; line-height:30px; height:30px; border:1px solid #bababa; border-radius:5px; padding-left:5px;}
.buy_write{ width:100%; overflow:hidden; font-size:0.7rem;}
form{ width:100%; overflow:hidden;}
.buy_writer{ width:90%; margin:15px auto 0 auto; height:40px; line-height:40px;}
.buy_writer_l{ width:22%; line-height:30px; height:30px;}
.buy_writer_l span{ float:right;}
.buy_writer_r{ width:74%;}
.sumbit{ width:50%; height:40px; line-height:40px; /*margin:20px auto;*/ background-color:#ff7300; color: #fff; border:none; display:block; border-radius:5px; border-bottom:5px solid red; font-weight:bold; float:left;}
.my-webuploader-element-invisible {
    position: absolute !important;
    clip: rect(1px 1px 1px 1px);
}
.webuploader-container { width: 100%;}
.parentFileBox { position:absolute; top:0; height:100%;}
.parentFileBox>.fileBoxUl {
    width: 100%;
    height: 100%;
    padding-bottom: 0;
}
.parentFileBox>.fileBoxUl>li {
    margin: 0;
    width: 100%;
    height: 100%;
}
.inputbox_ { width:100% !important; height:100% !important;}
.form-btn { width: 75%; margin:20px auto;}
.contact-cs {
	width: 40%;
    float: right;
    line-height: 40px;
    height: 40px;
    background-color: #009f95;
    text-align: center;
    color: #fff;
    border-radius: 5px;	
}
</style>
<script>
try{ jstojava.mysetgoback('window.history.go(-1);'); }catch(e){}	
</script>
<body>
<?php include template($this->config['style'],'header'); ?>
<div style="height: 45px;"></div>
<div class="main">
    <img src="<?php echo SPATH;?>bar/app/images/app_buy.png" style="width:100%; background-size:100%; overflow:hidden; display:block;">
    <div class="buy_write">
        <form action="" method="post" id="myform">
        <input type="hidden" name="dosubmit" value="1">
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>商品名称：</span></div>
                <div class="buy_writer_r fl">
                	<input type="text" class="nobd" placeholder="请输入预订产品" name="info[goodstitle]" id="goodstitle">
                </div>
            </div>
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>商品图片：</span></div>
                <div class="buy_writer_r fl" style="position:relative; width:42%;">
                	<div id="pro_img"></div>
                    <div id="pro_img__"></div>
                </div>
            </div>
            <div style="clear:both;"></div>
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>联系人：</span></div>
                <div class="buy_writer_r fl">
                	<input type="text" class="nobd" placeholder="请输入联系人" name="info[contacter]" id="contacter">
                </div>
            </div>
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>身份证：</span></div>
                <div class="buy_writer_r fl">
                	<input type="text" class="nobd" placeholder="请输入身份证号码" name="info[id_card]" id="id_card">
                </div>
            </div>
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>联系方式：</span></div>
                <div class="buy_writer_r fl">
                	<input type="text" class="nobd" placeholder="请输入手机号" name="info[phone]" id="phone">
                </div>
            </div>
           <div class="buy_writer">
                <div class="buy_writer_l fl"><span>地址：</span></div>
                <div class="buy_writer_r fl">
                	<input type="text" class="nobd" placeholder="请输入详细的收获地址" name="info[address]" id="address">
                </div>
            </div>
            <div class="buy_writer">
                <div class="buy_writer_l fl"><span>详细说明：</span></div>
                <div class="buy_writer_r fl">
                	<textarea style="height:100px; width:97%; border-radius:5px; padding:5px; outline:none;" name="info[description]" id="description" placeholder="详细说明"></textarea></div>
            </div>
        </form>
        <div class="form-btn">
            <input type="button" value="立即帮我找货" class="sumbit" onClick="send_form()"/>
            <div class="contact-cs" onClick="showkf()">联系客服</div>
        </div>
    </div>
</div>
<?php
	include(('./statics/kefu/app/style1.php'));
?>
</body>
<script type="text/javascript" src="statics/js/diyUpload/js/webuploader.html5only.min.js"></script>
<script type="text/javascript" src="statics/js/diyUpload/js/diyUpload.js"></script>
<script>
$(function(){
	$('.webuploader-container').children().css({"width":"100%", "height":"100%"});
	$('.webuploader-pick').css({"width":"100%","height":"100%"});
});

$('#pro_img').diyUpload({
	uploadac:'lookSource',
	filename:'<?php echo randomtrade(4);?>',
	success:function( data ) {
		document.getElementById('diyFileUrl_'+data.id).value = data.result.url;
	},
	error:function( err ) {
		alert(err.error.code);return;
	},
	buttonText : '<img src="statics/js/diyUpload/images/take_photo.png" />',
	//最大上传的文件数量, 总文件大小,单个文件大小(单位字节);
	fileNumLimit:1,
	fileSizeLimit: 3145709,
	fileSingleSizeLimit:3145709,
	autoup:true,
	accept: {
		title:"Images",
		extensions:"jpg,jpeg,png",
		mimeTypes:"image/*"
	}
});

function send_form(){
	var goodstitle = $('#goodstitle').val();
	var contacter = $('#contacter').val();
	var id_card = $('#id_card').val();
	var phone = $('#phone').val();
	var address = $('#address').val();
	if (goodstitle == '') {
		tipsBox('请输入需要订购的商品名称!');
		return;
	}
	if (id_card == '') {
		tipsBox('请输入身份证号!');
		return;
	}
	var is_true = isCardNo(id_card);
	
	if (!is_true) {
		return;
	}
	if (contacter == '' || phone == '' || address == '') {
		tipsBox('请正确填写收货信息!');
		return;
	}
	var index = layer.load(2,{time:6*1000});
	$.post('index.php?m=wb_shop&c=index&a=lookSource&ajax=1',$('#myform').serialize(),function (data) {
		layer.close(index);
		if (data.status == 1) {
			tipsBox('提交成功');
			setTimeout(function () {
				window.location.href = 'index.php?m=wb_shop&a=lookSourceSucc';
			}, 2000);
			
		} else {
			tipsBox('提交失败,请稍后再试!');
		}
	}, 'json');
	
}
//check idcard
function isCardNo(card){  
   // 身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X  
   var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
   //console.log(reg.test(card));return false;
   if (reg.test(card) === false) {
	   tipsBox('身份证号格式错误!');
	   return false;
    }
	return true;
}
</script>
</html>