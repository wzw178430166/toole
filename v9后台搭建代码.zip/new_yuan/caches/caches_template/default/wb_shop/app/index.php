<?php defined('IN_drcms') or exit('No permission resources.'); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="statics/bar/app/css/appstyle.css">
<link rel="stylesheet" type="text/css" href="statics/bar/app/css/app_index.css">
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/TouchSlide.1.1.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/global.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<title><?php echo $thisCompany['name'];?>商城</title>
<style>
.hd { display:none;}
.hot_sell_flag {}
.home_product_price_l .home_product_price_l1 { height:20px; line-height:20px;}
.home_product_price_l1 span:last-child { color: #E44; margin-left:5px; font-size:0.9rem; font-weight:bolder; display:none;}
.home_product_box .home_product_pic { height:auto;}
.hot_sell_box_l p { height:15px; line-height:15px;}
.home_type { margin-bottom:5px;}
.home_product_pic .home_product_flag,.hot_sell_pic .hot_sell_flag {
	color: #E44;
    font-size: 0.8rem;
    font-weight: bold;
    text-align: center;
    right: 2%;
    top: 1px;
    left: initial;
    background: url('statics/bar/app/images/zk_icon.png') no-repeat center;
    background-size: 100%;
    height: 65px;
    width: 10%;
    border: 0;
}
.hot_sell_pic .hot_sell_flag { width:15%; height:50px; top:3px;}
.home_product_pic .home_product_flag span,.hot_sell_pic .hot_sell_flag span {
	position: absolute;
    width: 100%;
    bottom: 2px;
    left: 0;	
}
.hot_sell_pic .hot_sell_flag span { height:15px; line-height:15px; font-size:0.7rem;}
.home_coupon p { line-height:1.7rem}
.home_product .home_product_box { padding-top:1%;}
.hot_sell_box .hot_sell_pic { padding:3px;}
.hot_sell_box .hot_sell_pic img { width:100%; margin:0;}
/*地区仓库*/
.header_place{ width:22%; float:left; overflow:hidden; padding-left:2%; color:#fff; margin-top:1%;}
.header_place select{ width:100%; overflow:hidden; background-color:inherit; color:#fff;}
.header_place option{ border:none; resize:none; outline:none;}
.hot_icon {
	position: absolute;
    left: 0.3rem;
    top: 0.3rem;
    width: 20%;
	background-color: #FFB542;
    padding: 3px;
    border-radius: 4px;
	box-shadow: 0 0 4px 2px #FFC770;
}
.hot_icon img { width:100%;}
</style>
</head>

<body>
<!---header_start--->
<div class="header">
	<div class="header_logo fl">
    	<img src="statics/bar/app/images/logo.png">
    </div>
    <div class="header_place" style="border-left:1px solid #fff;">
    	<!--<select class="nobd">
        	<option>日本仓</option>
        </select>-->
        海外仓
    </div>
    <div class="header_search fr" style="width:50%; margin-right:5%;">
    	<img src="statics/bar/app/images/search.png">
        <form action="index.php" id="myform">
            <input type="hidden" name="m" value="wb_shop">
            <input type="hidden" name="a" value="lists">
            <input type="hidden" name="catid" value="<?php echo $catid;?>">
            <input type="search" placeholder="日本药妆" id="k" name="k" class="search nobd" style="width:80%;">
        </form>
    </div>
    <!--<div class="header_list fr">
    	<a href="index.php?m=wb_shop&a=classify"><img src="statics/bar/app/images/header_list.png"></a>
    </div>-->
</div>
<div style="height:50px;"></div>
<!----header_end--->
<div class="banner slideBox" id="slideBox">
	<div class="bd">
        <div class="tempWrap" style="overflow:hidden; position:relative;">
          <ul id="lunbo">
            <?php $adv=show_ad2(1,12,1,1)?>
            <?php if(empty($adv)) { ?>
            <li >暂无轮播图,请在后台->商城管理->轮播图片添加轮播</li>
            <?php } else { ?> 
            <?php $n=1;if(is_array($adv)) foreach($adv AS $r) { ?>
            	<?php if(empty($r['1']['imageurl'])) { ?>
                <?php continue;?>
                <?php } ?>
            
                <li> <?php if($r['1']['linkurl']) { ?>
                  <a href="<?php echo $r['1']['linkurl'];?>">
                  <?php } ?> 
                  <?php
                  while(strpos($r['1']['imageurl'],'%')!==false){
                        $r['1']['imageurl'] = urldecode($r['1']['imageurl']);
                    }
                  ?>
                  <img style=" width:100%"   src="<?php echo $r['1']['imageurl'];?>"> <?php if($r['1']['linkurl']) { ?>
                  </a>
                  <?php } ?> </li>
                  
             
            <?php $n++;}unset($n); ?>
            <?php } ?>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
      <div class="hd">
        <ul>
         <!--<li class="on">1</li>
          <li class="">2</li>-->
        </ul>
      </div>
	<!--<img src="statics/bar/app/images/banner.png">-->
</div>
<div class="home_type">
	<ul>
    	<li onclick="url_header('index.php?m=wb_shop&a=lists&catid=<?php echo $catid;?>')">
        	<!--<a href="index.php?m=wb_shop&a=lists&catid=<?php echo $catid;?>">-->
                <div class="home_type_box">
                    <img src="statics/bar/app/images/home_type_box1.png">
                    <p>人气优品</p>
                </div>
            <!--</a>-->
        </li>
        <li onclick="url_header('index.php?m=wb_shop&c=index&a=lookSource')">
        	<!--<a href="index.php?m=wb_shop&c=index&a=lookSource">-->
                <div class="home_type_box">
                    <img src="statics/bar/app/images/home_type_box2.png">
                    <p>商品预订</p>
                </div>
            <!--</a>-->
        </li>
        <li onclick="url_header('index.php?m=content&c=index&a=show&catid=7&id=6')">
        	<!--<a href="index.php?m=content&c=index&a=show&catid=7&id=6">-->
                <div class="home_type_box">
                    <img src="statics/bar/app/images/home_type_box3.png">
                    <p>购货须知</p>
                </div>
            <!--</a>-->
        </li>
        <li onclick="showkf()">
        	<!--<a href="index.php?m=wb_shop&c=index&a=lookSource">-->
                <div class="home_type_box">
                    <img src="statics/bar/app/images/home_type_box4.png">
                    <p>在线客服</p>
                </div>
            <!--</a>-->
        </li>
    </ul>
</div>
<div class="home_coupon" style=" display:none;">
	<p>红包<span>任性领<i>！</i></span></p>
    <ul>
    	<li>
        	<a href="index.php?m=coupon&cid=1"><img src="statics/bar/app/images/coupon1.jpg"></a>
        </li>
        <li>
        	<a href="index.php?m=coupon&cid=2"><img src="statics/bar/app/images/coupon2.jpg"></a>
        </li>
        <li>
        	<a href="index.php?m=coupon&cid=3"><img src="statics/bar/app/images/coupon3.jpg"></a>
        </li>
    </ul>
</div>
<div  onclick="url_header('index.php?m=wb_shop&a=show&catid=6&id=137')" class="home_discount" style="display:none;">
	<img src="statics/bar/app/images/discount.jpg">
</div>
<div class="home_product">
	<?php $n=1;if(is_array($posterarr)) foreach($posterarr AS $r) { ?>
	<div class="home_product_box" onclick="url_header('index.php?m=wb_shop&c=index&a=show&catid=<?php echo $posterData[$r]['catid'];?>&id=<?php echo $posterData[$r]['id'];?>')">
            <div class="home_product_pic">
                <img src="statics/bar/app/images/poster/posterImg_<?php echo $r;?>.jpg">
                <div class="hot_icon"><img src="<?php echo SPATH;?>bar/app/images/hot_icon.png"/></div>
                <div class="home_product_flag"><span><?php echo floor(($posterData[$r]['jiage']/$posterData[$r]['yuanjiage'])*10);?>折</span></div>
            </div>
        <p class="title"><?php echo $posterData[$r]['title'];?></p>
        <div class="home_product_price">
        	<div class="home_product_price_l fl">
            	<div class="home_product_price_l1">
                	<p>价格：<span>¥</span><?php echo number_format($posterData[$r]['jiage'],2);?></p>
                </div>
                <!--<div class="home_product_price_l2">-->
                <div class="home_product_price_l1">
                	<p>原价格：¥<del><?php echo number_format($posterData[$r]['yuanjiage'],2);?></del></p>
                </div>
            </div>
            <div class="home_product_price_r fr">
            	<a href="javascript:;">立即购买</a>
            </div>
        </div>
    </div>
    <?php $n++;}unset($n); ?>
    <!--<div class="home_product_box" onclick="url_header('index.php?m=wb_shop&a=show&catid=6&id=96')">
            <div class="home_product_pic">
                <img src="statics/bar/app/images/bwg_pro.jpg">
                <div class="home_product_flag"><span><?php echo floor((310/620)*10);?>折</span></div>
            </div>
        <p class="title">原装进口 象印焖烧杯450ml SW-HB45-NL</p>
        <div class="home_product_price">
        	<div class="home_product_price_l fl">
            	<div class="home_product_price_l1">
                	<p>价格：<span>¥</span>310.00<span>五折优惠</span></p>
                </div>
                <div class="home_product_price_l1">
                	<p>原价格：¥<del>620.00</del></p>
                </div>
            </div>
            <div class="home_product_price_r fr">
            	<a href="javascript:;">立即购买</a>
            </div>
        </div>
    </div>
     <div class="home_product_box" onclick="url_header('index.php?m=wb_shop&a=show&catid=6&id=125')">
            <div class="home_product_pic">
                <img src="statics/bar/app/images/hzy_pro.jpg">
                <div class="home_product_flag"><span><?php echo floor((465/620)*10);?>折</span></div>
            </div>
        <p class="title">原装进口 Shiseido资生堂 红色蜜露精华化妆液 200ml</p>
        <div class="home_product_price">
        	<div class="home_product_price_l fl">
            	<div class="home_product_price_l1">
                	<p>价格：<span>¥</span>465.00<span>五折优惠</span></p>
                </div>
                <div class="home_product_price_l1">
                	<p>原价格：¥<del>620.00</del></p>
                </div>
            </div>
            <div class="home_product_price_r fr">
            	<a href="javascript:;">立即购买</a>
            </div>
        </div>
    </div>-->
</div>
<img src="statics/bar/app/images/home_hot.png" class="home_hot">
<div class="hot_sell">
	<ul id="indexData">
    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=8873aca070af8665dfb7bbb6d3f70a3b&action=lists&catid=6&order=inputtime+DESC&num=30\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'6','order'=>'inputtime DESC','num'=>'30','limit'=>'30',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
    	<li>
        	<?php $goodsurl = 'index.php?m=wb_shop&c=index&a=show&catid='.$r['catid'].'&id='.$r['id'];?>
            <div class="hot_sell_box" onclick="url_header('<?php echo $goodsurl;?>')">
                    <div class="hot_sell_pic">
                        <img src="<?php echo $r['thumb'];?>">
                        <div class="hot_sell_flag"><span><?php echo floor(($r['jiage']/$r['yuanjiage'])*10);?>折</span></div>
                    </div>
                <u><?php echo $r['title'];?></u>
                <div class="hot_sell_box_">
                	<div class="hot_sell_box_l fl">
                    	<p style="<?php if(floatval($r['yuanjiage'])<=0) { ?>height:25px;line-height:25px;<?php } ?>">¥<span><?php echo number_format($r['jiage'],2);?></span></p>
                		<?php if(floatval($r['yuanjiage'])>0) { ?><p>¥<span><del><?php echo number_format($r['yuanjiage'],2);?></del></span></p><?php } ?>
                    </div>
                    <div class="hot_sell_box_r fr">
                    	<span onclick="url_header('<?php echo $goodsurl;?>')" class="hot_buy">立即抢购</span>
                    </div>
                </div>
            </div>
        </li>
        <?php $n++;}unset($n); ?>
        <!--<li>
            <div class="hot_sell_box">
                <a href="javascript:;">
                    <div class="hot_sell_pic">
                        <img src="statics/bar/app/images/hot_sell_pic.png">
                        <div class="hot_sell_flag"></div>
                    </div>
                </a>
                <u>面膜面膜面膜面膜面膜面膜面膜面膜面膜面膜</u>
                <div class="hot_sell_box_">
                	<div class="hot_sell_box_l fl">
                    	<p>¥<span>58.00</span></p>
                    </div>
                    <div class="hot_sell_box_r fr">
                    	<a href="javascript:;" class="hot_buy">立即抢购</a>
                    </div>
                </div>
            </div>
        </li>
        <li>
            <div class="hot_sell_box">
                <a href="javascript:;">
                    <div class="hot_sell_pic">
                        <img src="statics/bar/app/images/hot_sell_pic.png">
                        <div class="hot_sell_flag"></div>
                    </div>
                </a>
                <u>面膜面膜面膜面膜面膜面膜面膜面膜面膜面膜</u>
                <div class="hot_sell_box_">
                	<div class="hot_sell_box_l fl">
                    	<p>¥<span>58.00</span></p>
                    </div>
                    <div class="hot_sell_box_r fr">
                    	<a href="javascript:;" class="hot_buy">立即抢购</a>
                    </div>
                </div>
            </div>
        </li>
        <li>
            <div class="hot_sell_box">
                <a href="javascript:;">
                    <div class="hot_sell_pic">
                        <img src="statics/bar/app/images/hot_sell_pic.png">
                        <div class="hot_sell_flag"></div>
                    </div>
                </a>
                <u>面膜面膜面膜面膜面膜面膜面膜面膜面膜面膜</u>
                <div class="hot_sell_box_">
                	<div class="hot_sell_box_l fl">
                    	<p>¥<span>58.00</span></p>
                    </div>
                    <div class="hot_sell_box_r fr">
                    	<a href="javascript:;" class="hot_buy">立即抢购</a>
                    </div>
                </div>
            </div>
        </li>-->
    </ul>
</div>
<div class="home_warm">
	<div class="home_warm_">
    	<div class="home_warm_tips">
        	<ul>
            	<li><a href="javascript:;"><img src="statics/bar/app/images/header_warm_tips1.png">网站通知</a></li>
                <li><a href="javascript:;"><img src="statics/bar/app/images/header_warm_tips2.png">常见问题</a></li>
                <li><a href="javascript:;"><img src="statics/bar/app/images/header_warm_tips3.png">法律声明</a></li>
                <li><a href="javascript:;"><img src="statics/bar/app/images/header_warm_tips4.png">客服咨询</a></li>
            </ul>
        </div>
        <div class="home_pay">
        	<div class="home_payl fl">
            	<img src="statics/bar/app/images/home_pay1.png">付款方式
            </div>
            <div class="home_payr fl">
            	<ul>
                	<li><img src="statics/bar/app/images/home_pay2.png"></li>
                    <li><img src="statics/bar/app/images/home_pay3.png"></li>
                    <li><img src="statics/bar/app/images/home_pay4.png"></li>
                </ul>
            </div>
        </div>
        <a href="http://www.miitbeian.gov.cn/" target="_blank"><p>粤ICP备16024208号-2</p></a>
        <!--<p>Copyright&nbsp;©&nbsp;2013 - 2016 babazg</p>
        <p>All&nbsp;Rights&nbsp;Reserved</p>-->
    </div>
</div>
<div style="height:50px;"></div>
<!---footer_start--->
<div class="footer">
	<ul>
    	<li>
        	<a href="index.php">
        	<div class="footer_box">
            	<img src="statics/bar/app/images/home.png">
                <p>首页</p>
            </div>
            </a>
        </li>
        <li>
        	<a href="index.php?m=wb_shop&a=classify">
        	<div class="footer_box">
            	<img src="statics/bar/app/images/type.png">
                <p>分类</p>
            </div>
            </a>
        </li>
        <li>
        	<a href="index.php?m=wb_shop&a=goodscart">
        	<div class="footer_box">
            	<img src="statics/bar/app/images/shopping.png">
                <p>购物车</p>
            </div>
            </a>
        </li>
        <li>
        	<a href="index.php?m=member&c=index">
        	<div class="footer_box">
            	<img src="statics/bar/app/images/wode.png">
                <p>我的</p>
            </div>
            </a>
        </li>
    </ul>
</div>
<!---footer_end--->
<?php
	include(('./statics/kefu/app/style1.php'));
?>
</body>
<script>
$(function(){
	TouchSlide({
		slideCell: "#slideBox",
		titCell: ".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
		mainCell: ".bd ul",
		effect: "leftLoop",
		autoPage: true,//自动分页
		autoPlay: true //自动播放
	});
	setProImgSize();	
	window.onscroll = function() { myscroll(); }	
});

var page = 1;
var loaded =0;
var catid=6;
var gerUrl = 'index.php?m=wb_shop&a=lists_data&position=index&catid='+catid;
function get_infos(ac){
	page++;
	gerUrl += '&page='+page;
	loaded=1;
	//var index = layer.load(2, {time: 30*1000});
	creatLoading(6*1000);
	$.post(gerUrl,function(da){
		document.getElementById('loadBox').style.display = 'none';
		//layer.close(index);
		if(da.length<=0){
			$('#enddiv').show();		
		}else{
			loaded=0;
			$('#indexData').append(da);
			setProImgSize();
		}
	});	
}

function myscroll(){
	if(loaded!=1){
		var c=document.documentElement.clientHeight || document.body.clientHeight;
		var t=$(window).scrollTop();
		//console.log((t+c)+'---'+$('body').height());
		if(t+c >= ($('body').height())){ 
			loaded=1;
			window.setTimeout("get_infos()",300);
		}
	}

}
function setProImgSize() {
	var hot_width = $('.hot_sell_pic img').width();
	$('.hot_sell_pic img').height(hot_width);
}
function url_header(url) {
	//var e = event || window.event;
	var url = url !='' ?url:window.location.href;
	creatLoading(6*1000);
	window.location.href = url;
}

</script>
</html>