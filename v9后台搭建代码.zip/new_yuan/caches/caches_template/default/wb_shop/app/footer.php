<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.footer{
	background:#EAEAEA;
}
.home1{
	color:#fdfdfd;
}
.foot_nav ul li {
	width:20%;	
}
</style>
<div class="footer">
  <div class="foot_nav">
    <ul>
      <li><!--index.php?m=wb_shop&plat=159-->
        <div id="foot_ico" class="foot_ico">
          <a href="index.php" class="home1"> 首页 </a>
        </div>
      </li>
      <li>
        <div class="foot_ico">
          <a href="index.php?m=wb_shop&a=classify" class="home2">分类 </a>
        </div>
      </li>
      <li>
        <div class="foot_ico">
        <?php $module_ = get_siteid() == 1 ? 'wb_shop' : 'ku_shop';?>
          <a href="index.php?m=<?php echo $module_;?>&a=lists&catid=6" class="faxian">发现 </a>
        </div>
      </li>
      <li>
        <div class="foot_ico">
          <a  href="index.php?m=wb_shop&a=goodscart" class="home3"> 购物车 </a>
        </div>
      </li>
      <li>
        <div class="foot_ico">
          <a href="index.php?m=member&c=index" class="home4"> 我的 </a>
        </div>
      </li>
    </ul>
  </div>
</div>