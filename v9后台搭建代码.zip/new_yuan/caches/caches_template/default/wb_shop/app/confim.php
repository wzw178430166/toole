<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<?php $title = '订单结算';$no_wechat = 1; $no_alipay = 1;?>
<?php include template($this->config['style'],'header_common2'); ?>
<!--<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/style6.css" />-->
<link href="<?php echo SPATH;?>/h_ui/lib/Hui-iconfont/1.0.1/iconfont.css" rel="stylesheet" type="text/css" />
<!--<link href="<?php echo SPATH;?>wb_shop/h_ui/lib/Hui-iconfont/1.0.7/iconfont.css" rel="stylesheet" type="text/css" />-->
<style>
.h10 { height:10px;}
.h40 { height:40px;}
.h50 { height:50px;}
.ly_inp { border: none; padding: 18px 0; width: 100%; font-size: 13px; }
#yh_box { width: 90%; height: 100px; background-color: white; margin: 0 auto; text-align: center; border: 1px solid #dedede; box-shadow: 0 1px 10px; z-index: 9999; position: absolute; display: none; transition: 0.5s; }
.select { margin-top: 5px; display: none; }
.select select { width: 155px; height: 25px; }
.but { margin-top: 10px; }
.but input { width: 84px; border: 0; background-color: #FF4141; height: 30px; color: white; margin-right: 5px; }
.pay_ico3 {
	display: block;
    background: url('statics/wb_shop/images/xianz.png') no-repeat center;
    width: 50px;
    height: 50px;
    background-size: 40px;
    margin-left: 5px;
}
.load_address {
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    display: none;
    transition: left 0.5s;
    z-index: 99999;
    background-color: #fff;
}
.load_header { 
	width: 100%;
    height: 44px;
    line-height: 44px;
    border-bottom: 1px #ddd solid;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 100000;
    text-align: center;
    background-color: #fff;
}
.load_header a.close_btn {
	display: block;
    position: absolute;
    left: 15px;
    width: 25px;
    height: 44px;
    background: url(statics/wb_shop/images/close_btn.png) no-repeat center;
    background-size: 100%;
}
.address_add_btn_box { width:100%; height:40px; position:absolute; bottom:10px; background-color:#fff;}
.address_add_btn_box a.address_add_btn { display:block; width:80%; height:30px; line-height:30px; border-radius:4px; background-color:#d92b2b; color:#fff; margin:5px auto; text-align:center;}
.paytype_box { position:relative;}
.no_pay {
    width: 100%;
    height: 100%;
    position: absolute;
    background-color: #fff;
    opacity: 0.8;
    z-index: 1;
    border: 1px #BFBFBF dashed;
}
.yhq_box {
    width: 100%;
    height: 57px;
    margin: 0 auto;
    border-bottom: 1px solid #c8cacc;
    position: relative;
}
.addressBox {
	padding: 15px;
    font-size: 1rem;
    color: #333;
    /*background: url('statics/hy/images/hua_bg.png') repeat-x bottom;*/
}
.contactinfo { margin-bottom:5px; position:relative}
.addressinfo { font-size:0.8rem}
.addressItems {
	position: absolute;
    left: 100%;
	transition:left 0.4s;
    top: 0;
    background-color: #fff;
    width: 100%;
    height: 100%;
    z-index: 100001;
	color:#333;
	overflow-y: scroll;
	display:none;
}
.addressItems .itemNode {
	padding: 10px;
    border-bottom: 1px #D5D5D5 solid;
}
.addressItems .item_title {
	padding: 0 10px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    border: 1px #D9D9D9 solid;
}
.addressItems .item_title a.itemClose {
	display: block;
    position: absolute;
    width: 20px;
    height: 20px;
    margin-top: 10px;
    background: url('statics/wb_shop/images/close_btn.png') no-repeat center;
    background-size: 100%;	
}
.rc_d2_ck {
	height: 35px;
    background: url(statics/wb_shop/app/images/dp_icon.png) no-repeat center;
    background-size: 80%;		
}
.slr_price { width:100%;}
.contactinfo em { display:block; width:20px; height:20px; background:url('statics/wb_shop/app/images/edit_btn_icon.png') no-repeat center; background-size:20px; position:absolute; right:0;}
.addrItemAdd {
	position: fixed;
    bottom: 15px;
    width: 100%;
    height: 35px;
    line-height: 35px;
    text-align: center;	
}
.addrItemAdd font{ display:block; width:80%; height:100%; background-color: #d92b2b; border-radius:4px; margin: 0 auto; color: #fff; font-size: 0.8rem;}
.address-idCard { font-size:0.9rem; margin-top:10px;}
.layui-layer-dialog { width:85% !important; left:8% !important;}
</style>
<script>
try{ jstojava.mysetgoback('window.history.go(-1);'); }catch(e){}	
</script>
<body style="background:#f0f2f5;">
<!--public header start-->
<div class="header">
  <div class="header_box">
    <a href="javascript:;" onClick="window.history.go(-1);" class="header_fanhui">
    </a>
    <h2 class="header_title">订单结算</h2>
  </div>
</div>
<!--public header end-->
<form action="index.php?m=wb_shop&a=send" method="post" onSubmit="return sendConfim();" id="myform">
  <input type="hidden" name="orderid" value="<?php echo $orderid;?>" id="orderid"/>
  <input type="hidden" name="rmids" value="<?php echo $rmids;?>" id="rmids"/>
  <input type="hidden" name="goodsid" value="<?php echo $goodsid;?>">
  <input type="hidden" name="goodscatid" value="<?php echo $goodscatid;?>">
  <div class="main">
  <div class="h50"></div>
    <div class="order_clear1 djjfas">
    	<div class="addressBox" <?php if(!$address) { ?> style="text-align:center;"<?php } ?>>
            <?php $addrid = 0;?>
            <?php if($address) { ?>
            <?php $n=1;if(is_array($address)) foreach($address AS $r) { ?>
            <?php if(($mraddress && $mraddress == $r['id']) || $address) { ?>
            <?php $addrid = $mraddress ?: $r['id'];?>
            <?php $isHav = $r['id_card']!=''?1:0;?>
            <div class="selAddress" onClick="showAddress()" id="selAddress" data-isHav="<?php echo $isHav;?>">
                <div class="contactinfo"><span class="fl">收货人:<?php echo $r['contactname'];?></span><span class="fr"><?php echo $r['phone'];?></span></div>
                <div class="address-idCard">身份证: <?php echo $r['id_card'];?></div>
                <div class="addressinfo"><?php echo $r['sheng'];?><?php echo $r['shi'];?><?php echo $r['qu'];?><?php echo $r['address'];?></div>
            </div>
            <?php break;?>
            <?php } ?>
            
            <?php $n++;}unset($n); ?>
            <?php } else { ?>
            <a onClick="getAddressHtml('')" class="addAddrBtn" style="color:#333;">添加收货地址</a>
            <?php } ?>
            <input type="hidden" name="addressid" id="addressid" value="<?php echo $addrid;?>">
        </div>
        <div class="addressItems" id="addressItems">
            <div class="item_title">
                <a class="itemClose" onClick="hideAddress()"></a>
                <h2>选择地址</h2>
            </div>
            <div class="addrItemAdd" id="addrItemAdd"><font>添加地址</font></div>
            <?php $n=1;if(is_array($address)) foreach($address AS $r) { ?>
            <div class="itemNode" onClick="selAddr('<?php echo $r['id'];?>')" id="itemNode_<?php echo $r['id'];?>">
                <div class="contactinfo"><span class="fl">收货人:<?php echo $r['contactname'];?></span><em class="fr" onClick="getAddressHtml(<?php echo $r['id'];?>);"></em><span class="fr" style="margin-right:25px;"><?php echo $r['phone'];?></span></div>
                <div class="address-idCard">身份证: <?php echo $r['id_card'];?></div>
                <div class="addressinfo"><?php echo $r['sheng'];?><?php echo $r['shi'];?><?php echo $r['qu'];?><?php echo $r['address'];?></div>
            </div>
            <?php $n++;}unset($n); ?>
        </div>
    </div>
    
    <div class="order_clear2" style="display:none;">
    <?php if($attrGoods) { ?>
    <?php $n=1; if(is_array($attrGoods)) foreach($attrGoods AS $k => $goods) { ?>
      <div class="rc_div2">
        <div class="rc_d2_top">
          <div class="rc_d2_ck fl"></div>
          <div class="rc_d2_wz fl">
            <h2><?php echo $dp_info[$k]['name'];?></h2><div class="pim_dj5" style="margin: 0 0 0 17px;"></div>
          </div>
        </div><!--rc_d2_top end-->
        
        <div style="border:none" class="sl_list_box sl_list_box2">
        <?php $n=1; if(is_array($goods)) foreach($goods AS $kk => $rr) { ?>
        <?php $n=1; if(is_array($rr)) foreach($rr AS $att => $att2) { ?>
          <div class="slib">
            <div style="margin: 0 0 0px 19px;" class="sl_img_box fl"><img src="<?php echo $goodsinfo[$kk]['thumb'];?>" width="100%" class="slimg" /></div>
            <div class="sl_right sl_right2 fr">
              <div class="slr_title"><?php echo $goodsinfo[$kk]['title'];?></div>
              
              <div class="slr_oth2">
                <span><?php echo $attr[$att]['attShow'];?></span>
                <!--<span><?php echo $attr[$att]['size'];?></span>-->
              </div>
              <div class="slr_price">
                <div class="slr_pb fl" style="float:left; color:#FB3232; font-size:16px">
                  <span>¥&nbsp;</span>
                  <?php $cJiage = $buyWay[$kk.'_'.$att] == 'retail'?$goodsinfo[$kk]['retail_price']:$goodsinfo[$kk]['jiage'];?>
                  <span><?php echo number_format($cJiage,2);?></span>
                </div>
                <div class="slr_pb fr" style="font-size:16px"><span >&nbsp;x&nbsp;</span><span><?php echo $att2;?></span></div>
               </div>
             </div>
          </div>
          <?php
          	$noshui = array(100,150,149,96,125,146,73,147,81,130,128,148,141);
            /*if (!in_array($kk,$noshui)) {
            	$taxesJiage += ($cJiage*($taxes/100))*$att2;
            	$cJiage = $cJiage + ($cJiage*($taxes/100))*$att2;
            }*/
          	$amount += $cJiage*$att2;
            $count += $att2;
          ?>
          <?php $n++;}unset($n); ?>
          <?php $n++;}unset($n); ?>
        </div><!--sl_list_box2 end-->
      </div><!--rc_div2 end-->
    <?php $n++;}unset($n); ?>
    <?php } ?>
    </div><!--order_clear2 end-->
    
    <div class="order_clear2">
    </div>
    <div class="order_clear3">
      <div class="cm_info_title">支付方式</div>
      <div class="cfb_pay_box">
        <div class="apb_type" id="pay_sel">
          <div class="paytype_box" data-no="<?php if($no_alipay) { ?><?php echo $no_alipay;?><?php } else { ?>0<?php } ?>">
          <?php if(!$no_wechat) { ?><div class="no_pay"></div><?php } ?>
            <i class="pay_ico1 fl"></i>
            <div class="ptcenter fl">
              <p class="pc_word1">微信支付</p>
              <p class="pc_word3">使用微信立即线上支付</p>
            </div>
            <label>
            <div class="pth pthed fr" >
              <input type="radio" name="paytype" checked="checked" value="wechat">
            </div>
            </label>
          </div>
          <div class="paytype_box" data-no="<?php if($no_alipay) { ?><?php echo $no_alipay;?><?php } else { ?>0<?php } ?>" style=" display:none;">
          <?php if(!$no_alipay) { ?><div class="no_pay"></div><?php } ?>
            <i class="pay_ico2 fl"></i>
            <div class="ptcenter fl">
              <p class="pc_word1">支付宝支付</p>
              <p class="pc_word3">使用支付宝立即线上支付</p>
            </div>
            <label>
            <div class="pth fr">
              <input  type="radio" name="paytype" value="alipay">
            </div>
            </label>
          </div>
          
          <!--<div class="paytype_box">
            <i class="pay_ico3 fl"></i>
            <div class="ptcenter fl">
              <p class="pc_word1">线下交易</p>
              <p class="pc_word3">商家未开通在线支付</p>
            </div>
            <label>
            <div class="pth pthed fr">
              <input type="radio" name="paytype" value="offline" checked="checked">
            </div>
            </label>
          </div>-->
          
          <div class="yhq_box" style="height:35px" >
            <div class="ptcenter fl" style="padding:0; height:35px; line-height:35px;">
              <p class="pc_word1 fl">优惠券<span style="background-color:red;font-size: 12px;color: white;padding: 2px 5px;margin-left: 3px;"><?php echo count($coupon);?>张可用</span></p>
              <p class="select fl" id="sl_yh_">
                <select name="yh" id="sl_yh" onChange="useryh(this)">
                  <option value="0">请选择</option>
                  
                                <?php $n=1;if(is_array($coupon)) foreach($coupon AS $c) { ?>
                                    
                  <option value="<?php echo $c['money'];?>" data-gfid="<?php echo $c['id'];?>"><?php echo $c['title'];?></option>
                  
                                <?php $n++;}unset($n); ?>
                            
                </select>
                <input type="hidden" name="couponId" id="couponId" value="<?php echo $couponId;?>">
   				<input type="hidden" name="couponVal" id="couponVal" value="<?php echo $couponMoney;?>">
                <input type="hidden" id="is_use" value="0">
              </p>
            </div>
            <div class="fr zf" style="font-size:12px; line-height:35px; color:#797979" onClick="showyh()">
              <span id="status" style="margin-right:5px">未使用&gt;&gt;</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--<div class="order_clear3">
      <div class="cfb_pay_box">
        <div class="apb_type">
          <div class="paytype_box">
            <div class="ptcenter shif fl">
              <p class="pc_word1">买家留言：</p>
            </div>
            <div class="fl" style="width:70%;">
              <input type="text" name="buy_ly" id="buy_ly" class="ly_inp" placeholder="选填，可填写您和卖家达成一致的要求">
            </div>
          </div>
        </div>
      </div>
    </div>-->
    <?php if($taxesJiage || $yun_fei) { ?>
    <?php $amount += $taxesJiage+$yun_fei;?>
    <div class="rd2_oth_box2" style=" width:88%">
      <p class="rd2_bx_wd5 fl">+综合税</p>
      <p class="rd2_bx_wd4 fr"><span></span><span style="color:#808080"><?php if($taxesJiage) { ?><?php echo number_format($taxesJiage,2);?><?php } else { ?>0<?php } ?>元</span></p>
    </div>
    <div class="rd2_oth_box2" style=" width:88%">
      <p class="rd2_bx_wd5 fl">+运费</p>
      <p class="rd2_bx_wd4 fr"><span></span><span style="color:#808080"><?php if($yun_fei) { ?><?php echo number_format($yun_fei,2);?><?php } else { ?>0<?php } ?>元</span></p>
    </div>
    <?php } ?>
    <div class="h10"></div>
    <div class="h40"></div>
    <div class="sc_bottom">
      <div class="sc_bottom_box">
        <div class="scbleft scblefddd fl">
          <p class="p1">合计:&nbsp;&nbsp;<b class="ns2" id="z_jiage" data-count="<?php echo $amount;?>"><?php echo number_format($amount,2);?></b></p>
          <p class="p2">共 <?php echo $count;?> 件</p>
        </div>
        <div class="scbright fr">
          <input  type="hidden" value="<?php echo $amount;?>" name="money" id="money" data-val="<?php echo $amount;?>"/>
          <!--<input style=" border:none;font-size:18px;" class="scbr_btn" type="submit" value="去支付" Id="tj"/>-->
          <a class="scbr_btn" style=" border:none;font-size:15px;" onClick="$('#myform').submit()">去支付</a>
        </div>
      </div>
    </div>
  </div>
</form>
<div id="load_add_address" class="load_address">
	<div class="load_header">
    	<a href="javascript:;" class="close_btn" onClick="hide_load_add()"></a>
        <h2>添加收货地址</h2>
    </div>
    <div class="load_center" id="load_center"></div>
    <div class="address_add_btn_box">
    	<a href="javascript:;" onClick="address_add_()" class="address_add_btn" id="address_add_btn">保存</a>
    </div>
    
</div>
</body>
<script type="text/javascript" src="<?php echo JS_PATH;?>layer/1.9.3/layer.js"></script>
<script>
var hkTips = '根据海关总署令第104号文规定,个人物品类进境快件报关时,应当向海关提交进境快件收件人身份证。请尽快补充您的身份证,以免造成海关扣件。';
var topheight = window.screen.height;
var str_ = '';
$(function () {
	var topheight = window.screen.height;
	var marginL = '-' + $('#yh_box').width()/2 + 'px';
	$('#yh_box').css({left:'50%', marginLeft:marginL, top: topheight});
	$('#addressItems').css({"height":$(window).height()});
	$('#load_add_address').css({"left":$(window).width()});
	//getAddressHtml('');//获取地址添加页
	$(window).bind('hashchange', function() {
			//地址栏发生变化后触发
			var hashStr = location.hash.replace("#","");
			if ($('#addressItems').css('display') == 'none' && $('#load_add_address').css('display') == 'none') {
				goback();
				//window.location.href = $('#forward').val();
			}
			if (hashStr == '' && str_ == 'addr') {
				hideAddress();
			}
			
			if (hashStr == '' && str_ == 'address') {
				hide_load_add();
			}
			
		});
	
	//选择支付方式
	var pay_item = $('#pay_sel').find('.paytype_box');
	pay_item.each(function(i) {
        $(pay_item[i]).click(function () {
			if ($(this).attr('data-no') == '1') {
				$('.pth').removeClass('pthed');
				$('input[name="paytype"]:checked').attr('checked', false);
				$(this).find('.pth').addClass('pthed');
				$(this).find('input').attr('checked', 'checked');
			} else {
				layer.msg('商家未开通');
			}
			
		});
    });
	
	//add address btn
	$('#addrItemAdd').click(function () {
		getAddressHtml('');
	});
	
	var isHav = $('#selAddress').attr('data-isHav');
	if (Number(isHav)<=0) {
		layer.alert(hkTips);
	}
});

function getAddressHtml(id){
	$('#load_center').empty();
	var ac = id != ''?'address_edit&id='+id:'address_add';
	//alert(ac);
	creatLoading(6*1000);
	$.get('index.php?m=member&c=address&a='+ac, function (data) {
		if (data.length > 0) {
			closeLoading();
			$('#load_center').html(data);
			hideAddress();
			show_add_address();
		}
	});
	if (id) {
		var e = window.event || event;
		if ( e.stopPropagation ){ //如果提供了事件对象，则这是一个非IE浏览器 
			e.stopPropagation(); 
		}else{ 
			//兼容IE的方式来取消事件冒泡 
			window.event.cancelBubble = true; 
		}
	}
	
}

function sendConfim() {
	
	var address = $('#addressid').val();;
	if (!address) {
		layer.msg('请选择收货地址');
		return false;
	}
	var isHav = $('#selAddress').attr('data-isHav');
	if (Number(isHav)<=0) {
		layer.alert(hkTips);
		return false;
	}
	
	return true;

}

function useryh(obj) {
	var couponId  = $(obj).find('option:selected').attr('data-gfid');;
	var couponVal = $(obj).val();
	var y_jiage = $('#money').attr('data-val');
	var z_jiage_ = 0;
	if (couponVal>0) {
		z_jiage_ = Number(y_jiage) - Number(couponVal);
				
	} else {
		 z_jiage_ = y_jiage;
	}
	$('#couponId').attr('value',couponId);
	$('#couponVal').attr('value',couponVal);
	$('#z_jiage').text(Number(z_jiage_).toFixed(2));
	$('#money').attr('value', z_jiage_);
	
}

function showyh() {
	$('#couponId').attr('value',0);
	$('#couponVal').attr('value',0);
	$('#sl_yh').attr('value',0);
	if ($('#is_use').val() == 0) {
		$('#sl_yh_').show();
		var cancelhtml = '<a id="cancel_" style="color:#9c9c9c; font-size:14px">取消</a>';
		$('#status').html(cancelhtml);
		$('#is_use').attr('value', 1);
	} else {
		//alert(1);
		$('#sl_yh_').hide();
		var z_jiage = $('#money').attr('data-val');
		$('#z_jiage').text(Number(z_jiage).toFixed(2));
		$('#money').attr('value', z_jiage);
		var statusHtml = '未使用&gt;&gt;';
		$('#status').html(statusHtml);
		$('#is_use').attr('value', 0);
	}
	
	
}

function _useryh(){
	$('#sl_yh_').css({display:'none'});
	$('#gfid').attr('value', 0);
	$('#sl_yh').val(0);
	var z_jiage = $('#z_jiage').attr('data-count');
	$('#z_jiage').text(z_jiage + '.00');
	$('#money').attr('value', z_jiage);
	var statusHtml = '未使用&gt;&gt;';
		
}
function show_add_address () {
	$('#load_add_address').show();
	$('#load_add_address').css({"left":0});
	$('body').css({"overflow":"hidden","height":$(window).height()});
	str_ = 'address';
	location.hash = '#address';
}
function hide_load_add () {
	window.location.hash = '';
	//window.location.hash.replace('#','');
	$('#load_add_address').css({"left":$(window).width()});
	setTimeout(function () {
		$('#load_add_address').hide(); 
	}, 500);
	$('body').css({"overflow":"auto","height":"auto"});
}

function address_add_() {
	var contactname = $('#contactname').val();
	var id_card = $('#id_card').val();
	var phone = $('#phone').val();
	var address = $('#address').val();
	if (Number($('#addrid').val()) > 0) {
		id_card = id_card == $('#id_card').attr('data-msg')?$('#id_card').attr('data-val'):id_card;
		phone = phone == $('#phone').attr('data-msg')?$('#phone').attr('data-val'):phone;
	}
	if (contactname == '') {
		layer.msg('请输入联系人!');
		return;
	}
	if (id_card == '') {
		layer.msg('请输入身份证号码!');
		return;
	}
	//var is_true = IdentityCodeValid(id_card);
	var is_true = isCardNo(id_card);
	if (!is_true) {
		return;
	}
	if (phone == '') {
		layer.msg('请输入手机号码!');
		return;
	}
	var reg = new RegExp('^1[0-9]{10}');
	//alert(reg.test(phone));return;
	if (phone.length != 11 || !reg.test(phone)) {
		if (phone != $('#phone').attr('data-msg')) {
			layer.msg('请正确输入手机号码!');
			return;
		}
	}
	if (address == '') {
		layer.msg('请输入联系地址!');
		return;
	}
	var index = layer.load(0,{time: 100*1000});
	var action = Number($('#addrid').val()) > 0 ? 'address_edit' : 'address_add';
	
	//document.getElementById('address_add_btn').onclick = function(){ };
	var post_data = {
		"info[city]":$('#city').val(),
		"city-1":$('#city-1').val(),
		"city-2":$('#city-2').val(),
		"contactname":$('#contactname').val(),
		"id_card":id_card,
		"phone":phone,
		"tel":$('#tel').val(),
		"address":$('#address').val(),
		"zipcode":$('#zipcode').val(),
		"dosubmit":1,
		"addressid":$('#addrid').val()
	};
	$.ajax({
		type: "POST", data:post_data,
		url:'index.php?m=member&c=address&a='+action+'&ajax=1',
		success: function(data) {
			layer.close(index);
			var ja =  eval('(' + data + ')');
			if (ja.status == 1) {
				layer.msg('保存成功!', {time:10*1000});
				setTimeout(function () {
					hide_load_add();
					if (Number($('#addressid').val()) <= 0) {
						creatNewAddress(ja.msg.id);
					}
					if (action == 'address_add') {creatAddressItem(ja.msg.id);}
					//window.location.reload();
				}, 500);
			} else {
				if(ja.msg=='not found contactname'){
					
					layer.msg('请填写联系人');
				}else if(ja.msg=='not found address'){
					layer.msg('请填写联系地址');
				}else{
				    layer.msg(ja.msg);
				}
				document.getElementById('address_add_btn').onclick = function(){ address_add_() };
				return;
			}
			
		}
	});
	return false;
}
function creatNewAddress(addressid){
	var address = $('#city-1').find("option:selected").text()+$('#city-2').find("option:selected").text()+$('#address').val();
	//console.log($('#city-1').find("option:selected").text()+$('#city-2').find("option:selected").text()+$('#address').val());
	var html = '<div class="selAddress" onClick="showAddress()" id="selAddress"><div class="contactinfo"><span class="fl">收货人:'+$('#contactname').val()+'</span><span class="fr">'+$('#phone').val()+'</span></div><div class="addressinfo" style=" text-align:left;">'+address+'</div></div>';
	$('.addressBox').find('.addAddrBtn').remove();
	$('.addressBox').append(html);
	$('#addressid').attr('value',addressid);
}
function creatAddressItem(addressid){
	var address = $('#city-1').find("option:selected").text()+$('#city-2').find("option:selected").text()+$('#address').val();
	var html = '<div class="itemNode" onclick="selAddr('+addressid+')" id="itemNode_'+addressid+'"><div class="contactinfo"><span class="fl">收货人:'+$('#contactname').val()+'</span><em class="fr" onclick="getAddressHtml('+addressid+');"></em><span class="fr" style="margin-right:25px;">'+$('#contactname').val()+'</span></div><div class="addressinfo">'+address+'</div></div>';
	$('#addressItems').append(html);
}
</script>
<script>
		var screenHeight = $(window).height();
    	function showAddress(){
			$('#addressItems').show();
			setTimeout(function (){
				$('#addressItems').css({'left':0});
			},10);
			$('html').css({'height':'100%','overflow':'hidden'});
			$('body').css({'height':(Number(screenHeight)-45)+'px','overflow':'hidden'});
			str_ = 'addr';
			location.hash = '#addr';
		}
		function hideAddress(){
			window.location.hash = '';
			//window.location.hash.replace('#','')
			$('#addressItems').css({'left':'100%'});
			setTimeout(function (){
				$('#addressItems').hide();
			},400);
			$('html').css({'height':'auto','overflow':'auto'});
			$('body').css({'height':'auto','overflow':'auto'});
		}
		function selAddr(id){
			$('#selAddress').html($('#itemNode_'+id).html());
			$('#addressid').attr('value',id);
			$('#selAddress').find('em').remove();
			hideAddress();
		}
</script>
</html>