<?php defined('IN_drcms') or exit('No permission resources.'); ?>﻿<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<title><?php echo $title;?></title>
<meta name="keywords" content="<?php echo $this->
Company['keywords'];?>">
<meta name="description" content="<?php echo $this->
Company['description'];?>">
<link rel="stylesheet" type="text/css" href="<?php echo SPATH;?>wlj/app/header.css?<?php echo SYS_TIME;?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo SPATH;?>wlj/app/ui.css?<?php echo SYS_TIME;?>"/>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>global.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>documentTips.js"></script>
<style>
.clear { clear: both; float: none; }
.coudan_box{ display: none; position: relative}
	.animate{ transition: all .6s ;}
.wh0{ height: 0 !important;
    width: 0 !important;
    border: 0 !important;
    padding: 0;
    margin: 0;
    position: absolute;}
	.sort_box{ display:none; }
	.baylist{ margin-top: -45px;}
	.coudan_title {
    font-size: 14px;
    text-align: center;
    color: #717171;
    margin: 20px auto 10px auto;
}
.dropdown_list.carPrice li.order_on {
	border-color: #ff9000;
    color: #ff9000;	
}
.dropdown_list li.active { color:#ff9000}
.sort_box ul li { width:33.33%;}
.taxesRegula {
	padding: 10px 2%;
    margin: 0 auto;
    width: 90%;
    border: 1px #dcdcdc solid;
    border-radius: 4px;
    font-size: 0.7rem;
    color: #999;
    background-color: #fff;
    margin-top: 40px;
    box-shadow: 0 0 5px 1px #dcdcdc;
	text-align:justify;	
}
.buyCondition {
	position: absolute;
    top: -25px;
    font-size: 0.7rem;
    text-align: center;
    width: 100%;
    height: 25px;
    line-height: 25px;
    color: #fff;
	z-index:11;
	display:none;
}
.opc-box {
	width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    background-color: #333;
    opacity: 0.7;
    z-index: -1;	
}
.taxesTips { position:fixed; left:5%; bottom:20%; width:90%; line-height:20px; font-size:0.7rem; color:#fff; background-color:#333; text-align:center; padding:5px 0; border-radius:4px; display:none; z-index:999;}
.settlement_left { width:48%;}
</style>
</head>
<body>
<div class="aui-container">
  <div class="aui-page main">
    <div class="list_search">
      <button class="bar-button back-button" onclick="window.history.go(-1);" dwz-event-on-click="click"><i class="icon icon-back"></i></button>
      <div class="search_box">
        <input class="search_text" placeholder="快速搜索您需要的商品" id="sk">
        <button class="search_btn" onClick="sendSearch()"><i class="icon iconfont icon-search fc8"></i></button>
      </div>
    </div>
    <div class="sort_box pt1 pb1 nav_sort bb1" id="nav_sort">
      <ul class="clearfix" id="classTags">
        <li class="nav-item curr" onclick="classTag('container0',this,0)"> 物流设置 <i class="icon iconfont icon-jiantou"></i></li>
        <li class="nav-item" onclick="classTag('container1',this,1)"> 分类 <i class="icon iconfont icon-jiantou"></i></li>
        <li class="nav-item" onclick="classTag('container2',this,2)" style="border:0;"> 排序 <i class="icon iconfont icon-jiantou"></i></li>
        <!--<li class="nav-item" onclick="classTag('container3',this,3)"> 显示 <i class="icon iconfont icon-jiantou"></i></li>-->
      </ul>
    </div>
    <div class="dropdown" style="display:none ;">
      <div class="dropdown_box" id="container0" style="display: block;">
        <ul class="dropdown_list carClass pl1">
          <li>物流选择</li>
        </ul>
        <ul class="dropdown_list carPrice clearfix" id="selWuliu">
          <li class="curr2" data-val="EMS">日本EMS邮政</li>
          <!--<li><a href="#">日本邮局普通航空</a>
          </li>
          <li><a href="#">日本邮局(SAL)航空</a>
          </li>
          <li><a href="#">日本邮局海运邮件</a>
          </li>-->
        </ul>
        <div class="clear">
        </div>
        <ul class="dropdown_list carClass pl1">
          <li>快递箱选择</li>
        </ul>
        <ul class="dropdown_list carPrice clearfix" id="selBox">
          <li class="long curr2" data-g="400">小盒 400g(100*100*100)</li>
          <li class="long" data-g="500">大盒 500g(200*200*200)</li>
        </ul>
        <div class="clear">
        </div>
        <a href="#" class="buy_btn btc">确认</a>
      </div>
      <div class="dropdown_box" id="container1" style="display: none;">
        <ul class="dropdown_list carPrice clearfix">
          <li class="order_on" data-catid="0">全部商品</li>
          <?php $n=1;if(is_array($cates)) foreach($cates AS $r) { ?>
          <li data-catid="<?php echo $r['catid'];?>"><?php echo $r['catname'];?></li>
          <?php $n++;}unset($n); ?>
          <!--<li data-catid="2">健身减肥</li>
          <li data-catid="5">生活用品</li>
          <li data-catid="7">婴儿用品</li>
          <li data-catid="8">女性养护</li>
          <li data-catid="9">意大利品牌</li>-->
        </ul>
      </div>
      <div class="dropdown_box" id="container2" style="display: none;">
        <ul class="dropdown_list carClass pl1">
          <li data-key="default" class="active"><a href="#">综合排序</a>
          </li>
          <li data-key="jg" data-val="1">价格最低</li>
          <li data-key="jg" data-val="2">价格最高</li>
          <li data-key="wg" data-val="1">重量最低</li>
          <li data-key="wg" data-val="2">重量最高</li>
        </ul>
      </div>
      <div class="dropdown_box" id="container3" style="display: none;">
        <ul class="dropdown_list carClass pl1">
          <li><a href="#">全部</a>
          </li>
          <li><a href="#">只显示已选</a>
          </li>
          <li><a href="#">只显示未选</a>
          </li>
        </ul>
      </div>
      <div class="dropdown_bg">
      </div>
    </div>
    <div class="sort_selected clearfix" style="display: none;">
      <div class="s_selected_cont" style="display: block;">
        <span id="container0_s">奥迪</span><i class="delete">x</i>
      </div>
      <div class="s_selected_cont" style="display: block;">
        <span id="container1_s">3万以下</span><i class="delete">x</i>
      </div>
      <div class="s_selected_cont" style="display: block;">
        <span id="container2_s">三厢轿车</span><i class="delete">x</i>
      </div>
    </div>
    <div style="height:110px" id="top_ge">
    </div>
    <form id="orders_form" method="post" action="index.php?m=wb_shop&a=confim&forward=<?php echo urlencode('index.php?m=wlj');?>">
    <?php if($rmids) { ?><input type="hidden" name="goodsrmids" value="<?php echo $rmids;?>"><?php } ?>
      <div class="main_con baylist">
        <div class="main_con_goods">
          <ul>
            <?php $n=1; if(is_array($attrGoods)) foreach($attrGoods AS $k => $goods) { ?>
            <?php $n=1; if(is_array($goods)) foreach($goods AS $kk => $rr) { ?>         
            <?php $n=1; if(is_array($rr)) foreach($rr AS $att => $att2) { ?>
            <?php 
            	$thisg = $goodsinfo[$kk];
            	//$cJiage = $buyWay[$kk.'_'.$att] == 'retail'?$goodsinfo[$kk]['retail_price']:$goodsinfo[$kk]['jiage'];
            	$cJiage = $siteid == 1?$goodsinfo[$kk]['jiage']:$goodsinfo[$kk]['retail_price'];
            	$goodsinfo[$kk]['weight'] = str_replace(array('g','ml'),'',$goodsinfo[$kk]['weight']);
            	
            	$amount += $cJiage*$att2;
            	$count += $att2;
            ?>
            
            <!--<input type="text" name="attribute[<?php echo $thisg['catid'];?>_<?php echo $thisg['id'];?>][<?php echo $att;?>]" value="<?php echo $att2;?>" class="wh0">-->
            
            
            <?php $r['weight'] = str_replace(array('g','ml'),'',$r['weight']);?>
            <li>
              <section class="aui-crl">
              	<span class="circle" style="display: none;"></span>
              	<img src="<?php echo $goodsinfo[$kk]['thumb'];?>">
              </section>
              <div style="padding-left: 10px;">
                <h2><?php echo $goodsinfo[$kk]['title'];?></h2>
                <p class="aui-o"> <?php echo $attr[$att]['attShow'];?> 重量：<?php echo $goodsinfo[$kk]['weight'];?> </p>
                <p class="money">
                  <em class="aui-redd">￥<?php echo number_format($cJiage,2);?></em>
                  <input class="add" type="button" value="">
                  <input class="num cbNumber" type="number" name="attribute[<?php echo $thisg['catid'];?>_<?php echo $thisg['id'];?>][<?php echo $att;?>]" value="<?php echo $att2;?>" data-jiage="<?php echo $cJiage;?>" data-g="<?php echo $goodsinfo[$kk]['weight'];?>" data-taxesClass="<?php echo $goodsinfo[$kk]['taxes_class'];?>" readonly>
                  <input class="del" type="button" value="">
                </p>
              </div>
            </li>
          
            <?php $n++;}unset($n); ?>
            <?php $n++;}unset($n); ?>
            <?php $n++;}unset($n); ?> 
          </ul>
          
        </div>
      </div>
      <div class="taxesRegula" id="taxesRegula">产品仅限个人自用：商品为海外产地直销商品，无中文标签，仅限个人自用不得进行再销售，若产生损失和纠纷，均由您个人承担</div>
      <div id="main_con_end"></div>
      <div class="main_con coudan_box" id="coudan_box">
        <p class="coudan_title">-------------&nbsp;&nbsp;凑一下，更划算&nbsp;&nbsp;-------------</p>
        <div class="main_con_goods">
          <ul id="cdGoods">
            
          </ul>
          <input type="hidden" name="orderCd" value="1">
          <input type="hidden" name="taxes" id="taxInput" value="0">
          <input type="hidden" name="yun_fei" id="yfInput" value="0">
        </div>
      </div>
      <div style="height:1px">
      </div>
      <!--内容信息 end-->
      <div style="height:115px;"></div>
      <!--结算信息 start-->
      <div class="settlement t-line">
      	<div class="buyCondition" id="buyCondition"><div class="opc-box"></div>国家海关规定多件商品的总价不得超过1000元,请您分多次购买</div>
        <div class="settlement_left">
          <font>目前价格：</font><font id="jiage">￥0</font><br>
          <font>商品数量：</font><font id="goodsCount"></font>件<br>
          总重量： <span id="g">0</span>g(箱重<span id="xiang_g">0</span>g)<br/>
          预计物流费用： <span id="wl">0</span><br/>
          综合税费： <span id="tax">0</span><br/>
          合计： <font class="money zongji" id="money">0</font>
        </div>
        <div class="settlement_right">
          <a href="javascript:;" onclick="checkAttribute()" id="settBtn">去结算</a>
           <a href="javascript:;" onclick="coudan()">去凑单</a>
        </div>
      </div>
      <!--结算信息 end-->
    </form>
  </div>
</div>
<audio controls style="display: none;"></audio>
</body>
</html>
<script type="text/javascript" src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script>
var siteid = '<?php echo get_siteid();?>';
var buyCondition = 0;
var buyLimitTips = '国家海关规定单笔交易同种商品不得5件以上，请您多次购买';
var taxesClass = {};
var ins = {'jiage':<?=$amount?>,'g':0,'wl':0,'tax':0,'tax_bili':0,'xiang_g':0,'xiang_num':0,'xiang_jiage':0,'qudao':0};
function set(){
	ins.xiang_jiage = 140 * 0.06;
	ins.xiang_num = 1;
	ins.xiang_g = 400;
	ins.tax_bili = 0.15;
	compute();
}

/*getTaxesClass*/
function getTaxesClass(){
	$.get('index.php?m=wpm&c=wb_shop&a=getTaxClass&ajax=1',function(data){
		if (data.status == 1) {
			taxesClass = data.info;
		}
		set();
	},'json');
}

/*$('.add').click(function(){
	var obj = $(this).next();
	$(obj).val( Number($(obj).val())+1 );
	$(obj).parent().parent().prev().find('.circle').addClass('cur');
	ins.jiage += Number($(obj).attr('data-jiage'));
	ins.g += Number($(obj).attr('data-g'));
	console.log(ins);
	compute();
});
$('.del').click(function(){
	var obj = $(this).prev();
	var i = Number($(obj).val())-1;
	if(i<=0){   i = 0;	$(obj).parent().parent().prev().find('.circle').removeClass('cur'); }
	$(obj).val( i );
	ins.jiage = (ins.jiage-Number($(obj).attr('data-jiage')))<0? 0 : (ins.jiage-Number($(obj).attr('data-jiage')));
	ins.g = (ins.g-Number($(obj).attr('data-g')))<0? 0 : (ins.g-Number($(obj).attr('data-g')));
	compute();
});*/
$('.circle').click(function(){
	return;
	if( $(this).hasClass('cur') ){
		$(this).removeClass('cur');
		$(this).parent().next().find('.num').val(0);
	}else{
		$(this).addClass('cur');
		$(this).parent().next().find('.num').val(1);
	}
});
function bindAddDelBtn(){
	var addBtn = $('.add');
	addBtn.each(function(i){
		$(addBtn[i]).click(function(){
			var obj = $(this).next();
			if (siteid==1&&$(obj).val()>=5) {
				tipsBox(buyLimitTips);
				return;
			}
			$(obj).val( Number($(obj).val())+1 );
			$(obj).parent().parent().prev().find('.circle').addClass('cur');
			ins.jiage += Number($(obj).attr('data-jiage'));
			ins.g += Number($(obj).attr('data-g'));
			console.log(ins);
			compute();
		});
	});
	
	var delBtn = $('.del');
	delBtn.each(function(i){
		$(delBtn[i]).click(function(){
			var obj = $(this).prev();
			if (Number($(obj).val())>0) {
				var i = Number($(obj).val())-1;
				if(i<=0){   i = 0;	$(obj).parent().parent().prev().find('.circle').removeClass('cur'); }
				$(obj).val( i );
				ins.jiage = (ins.jiage-Number($(obj).attr('data-jiage')))<0? 0 : (ins.jiage-Number($(obj).attr('data-jiage')));
				ins.g = (ins.g-Number($(obj).attr('data-g')))<0? 0 : (ins.g-Number($(obj).attr('data-g')));
				compute();
			}
			
		});	
	});
}
function compute(){
	var i = 0,wuliu = 0;
	//ins.tax = Math.ceil( ins.jiage * ins.tax_bili /2)*2;
	ins.tax = taxesCount();
	$('#tax').html( ins.tax );
	$('#taxInput').attr('value',ins.tax);
	$('#jiage').html( '￥'+ ins.jiage);
	
	if(ins.jiage>0){
		buyCondition=1;
		$('#jiage').addClass('redd');
		//$('.settlement').addClass('redd_border');
		if (1>2&&siteid==1&&ins.jiage>1000) {$('#buyCondition').show();buyCondition=0;}
		if (siteid==2&&ins.jiage<1000) {tipsBox('单笔交易不得少于1000元');buyCondition=0;}
		$('#settBtn').css({'backgroundColor':(buyCondition==1?'#f23030':'#C3C3C3')});
	}else{
		$('#jiage').removeClass('redd');
		$('.settlement').removeClass('redd_border');
		$('#buyCondition').hide();
		$('#settBtn').css({'backgroundColor':'#C3C3C3'});
		buyCondition=0;
	}
	
	$('#g').html(ins.g+ins.xiang_g);
	$('#xiang_g').html(ins.xiang_g);//箱重
	wuliu = com_wuliu();
	wuliu = ins.jiage>=1000?0:wuliu;
	$('#wl').html('￥'+ wuliu );
	$('#yfInput').attr('value',wuliu);
	i = ins.jiage + ins.tax + wuliu;
	$('#money').html('￥'+ i);
}

/*taxes count*/
function taxesCount(){
	var result = g_result = 0;
	var count = 0;
	var gCount = 0;
	var cbNumberItem = $('input[type="number"]');
	cbNumberItem.each(function(i){
		if ($(this).val() >= 1) {
			var dataCount = Number($(this).val());
			var dataPrice = $(this).attr('data-jiage');
			var dataTaxesClass = $(this).attr('data-taxesClass');
			var data_g = Number($(this).attr('data-g'));
			g_result += dataCount*data_g;
			result += Number((dataPrice*dataCount)*taxesClass[dataTaxesClass].tax_rate);
			count += Number($(this).val());
		}
	});
	result = 1>3&&ins.jiage>1000 ? Number(result.toFixed(2)) : 0;
	ins.g = g_result;
	$('#goodsCount').text(count);
	return result;
}
/**/
/*yunfei count*/
function wuliuCount(){
	
}

function com_wuliu(){
	var wuliu=0;
	var g = ins.g + ins.xiang_g; 
	var wuliufeiyong = new Array(
{"0":1400,"500":1400,"600":1540,"700":1680,"800":1820,"900":1960,"1000":2100,"1250":2400,"1500":2700,"1750":3000,"2000":3300,"2500":3800,"3000":4300,"3500":4800,"4000":5300,"4500":5800,"5000":6300,"5500":6800,"6000":7300,"7000":8100,"8000":8900,"9000":9700,"10000":10500,"11000":11300,"12000":12100,"13000":12900,"14000":13700,"15000":14500,"16000":15300,"17000":16100,"18000":16900,"19000":17700,"20000":18500,"21000":19300,"22000":20100,"23000":20900,"24000":21700,"25000":22500,"26000":23300,"27000":24100,"28000":24900,"29000":25700,"30000":26500},
{"0":1400,"500":1400,"600":1540,"700":1680,"800":1820,"900":1960,"1000":2100,"1250":2400,"1500":2700,"1750":3000,"2000":3300,"2500":3800,"3000":4300,"3500":4800,"4000":5300,"4500":5800,"5000":6300,"5500":6800,"6000":7300,"7000":8100,"8000":8900,"9000":9700,"10000":10500,"11000":11300,"12000":12100,"13000":12900,"14000":13700,"15000":14500,"16000":15300,"17000":16100,"18000":16900,"19000":17700,"20000":18500,"21000":19300,"22000":20100,"23000":20900,"24000":21700,"25000":22500,"26000":23300,"27000":24100,"28000":24900,"29000":25700,"30000":26500}
);
	var i = ins.qudao;
	var wuliufeiyong_ = wuliufeiyong[ins.qudao];
	for(d in wuliufeiyong_){
		if(!wuliu) wuliu = wuliufeiyong_[d];
		if(g>= Number(d)){
			if(g>Number(d)){var offset_=Number(d)+1;}else if(g==Number(d)){var offset_=Number(d);}
			//console.log(offset_);
			wuliu = wuliufeiyong_[offset_];
		}else{
			break;
		}
	}
	console.log(g+'|'+d);
	wuliu = Math.ceil(wuliu * 0.062);//0.0618
	if (wuliu<90) {wuliu=90;}
	return wuliu;
} 
</script>
<script>
//function $('.carPrice').cl
function classTag(target,tab,id){
	if($('#'+target).css('display')=='none'){
		$('.dropdown').show();
		$('.dropdown_box').hide();
		$('#'+target).show();
		$('.nav-item').removeClass('curr');
		$(tab).addClass('curr');
	}else{
		hide_dropdown();
	}
}
function hide_dropdown(){
	$('.dropdown').hide();
	$('.dropdown_box').hide();
	$('.nav-item').removeClass('curr');
}
$('.dropdown_bg').click(function(){ hide_dropdown();});
$('.buy_btn').click(function(){ hide_dropdown();});
</script>
<script>
window.onload = function(){
	<?php if($_GET['runCd']) { ?>coudan();<?php } ?>
	getGoods();//get goods list
	setSearchItem();//set searchItem
	getTaxesClass();
	//window.onscroll = function() { myscroll(); }
	
	//wuliu sel
	var selBox = $('#selBox li');
	selBox.each(function(i){
		$(selBox[i]).click(function(){
			$(selBox).removeClass('curr2');
			$(this).addClass('curr2');
			var dataWeight = $(this).attr('data-g');
			ins.xiang_g = Number(dataWeight);
			compute();
		});
	});
};
//send form
function checkAttribute(){
	if (buyCondition == 0) {return;}
	var cbNumber = $('.cbNumber');
	var is_selGoods = 0;
	cbNumber.each(function(i){
		if ($(this).val() <=0){
			$(this).removeAttr('name');
		} else {
			is_selGoods = 1;	
		}
	});
	if (is_selGoods) {
		$('#orders_form').submit();
	} else {
		layer.msg('请先挑选产品吧~');
	}
}
	document.getElementById('coudan_box').addEventListener("webkitAnimationEnd", function(){ //动画结束时事件 
		alert('dsfasd');
		$('#coudan_box').removeClass('animate');
	
	}, false); 
function coudan(){
	var tem_top = $(window).scrollTop();
	var it = document.getElementById('main_con_end').getBoundingClientRect().top;	
	$('body').animate({ scrollTop:(it-50)});	
	$('#nav_sort').css({'display':'block','opacity':1,'height':0});
	$('#nav_sort').animate({'height':'45px'});
	
	$('#coudan_box').css('top', tem_top+$(document.body).height());
	$('#coudan_box').show();
	$('#coudan_box').addClass('animate');
	$('#coudan_box').css('top',0);
	
    $('.baylist').css('margin-top','0'); $('body').scrollTop( $('body').scrollTop()+150);
	
	/**/
	$('#taxesRegula').hide();
	window.onscroll = function() { myscroll(); }
}
var page=1;
var loaded =0;
var getDataUrl = 'index.php?m=wb_shop&c=index&a=lists_data&ajax=1&position=listOf';
//get goods list
function getGoods(ac){
	var reg=new RegExp("(^|&|/?)page=[0-9]*");
	if (getDataUrl.match(reg)) {
		getDataUrl = getDataUrl.replace(reg,'');
	}
	if (ac == 'scroll') { page++;}
	getDataUrl += '&page='+page;
	var index = layer.load(3);
	$.get(getDataUrl,function(data){
		layer.close(index);
		if (data.length > 0) {
			loaded=0;
			$('#cdGoods').append(data);
			bindAddDelBtn();//shop btn bind
		} else {
			layer.msg(ac == 'scroll'?'已经到底了':'没有找到相关产品');
		}
	});
	hide_dropdown();
}
function setSearchItem(){
	var container2Item = $('#container2 ul li');
	container2Item.each(function(i){
		$(container2Item[i]).click(function(){
			$(container2Item).removeClass('active');
			$(this).addClass('active');
			var dataKey = $(this).attr('data-key');
			var dataVal = $(this).attr('data-val');
			updateUrl(dataKey,dataVal);
			$('#cdGoods').empty();
			getGoods();
		});
	});
	
	var container1Item = $('#container1 ul li');
	container1Item.each(function(i){
		$(container1Item[i]).click(function(){
			$(container1Item).removeClass('order_on');
			$(this).addClass('order_on');
			var dataVal = $(this).attr('data-catid');
			updateUrl('class',dataVal);
			$('#cdGoods').empty();
			getGoods();
		});
	});
}
function updateUrl(dataKey,dataVal){
	var reg=new RegExp("(^|&|/?)jg=[0-9]*");
	if (getDataUrl.match(reg)) {
		getDataUrl = getDataUrl.replace(reg,'');
	}
	var reg=new RegExp("(^|&|/?)wg=[0-9]*");
	if (getDataUrl.match(reg)) {
		getDataUrl = getDataUrl.replace(reg,'');
	}
	var reg=new RegExp("(^|&|/?)class=[0-9]*");
	if (dataKey == 'class' && getDataUrl.match(reg)) {
		getDataUrl = getDataUrl.replace(reg,'');
	}
	if (dataKey == 'default' || dataVal == 0) {page=1;}
	if (dataKey != 'default' && dataVal != 0) { getDataUrl += '&'+dataKey+'='+dataVal;}
}
function sendSearch(){
	page=1;
	var sk = $('#sk').val();
	if (sk == '') {
		layer.msg('请输入搜索关键词!');
	}
	getDataUrl = delUrlParam('k',getDataUrl);
	if (sk != '') {getDataUrl += '&k='+encodeURI(sk);}
	//console.log(getDataUrl);return;
	$('#cdGoods').empty();
	getGoods();
}
function myscroll(){
	if(loaded!=1){
		var c=document.documentElement.clientHeight || document.body.clientHeight;
		var t=$(window).scrollTop();
		//$('#sk').attr('value',(t+c)+'---'+$('.main').height());
		//console.log((t+c)+'---'+$('.main').height());
		if(t+c >= ($('.main').height())){ 
			loaded=1;
			window.setTimeout("getGoods('scroll')",300);
		}
	}

}
</script>