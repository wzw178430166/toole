<?php defined('IN_drcms') or exit('No permission resources.'); ?><style>
.attbox {
	min-height: 675px;
	position: absolute;
	right: 0;
	top: 0px;
	width: 100%;
	padding-left: 50%;
	z-index: 999;
}
.J-offerdetail {
	display: block;
	width: 80%;
	float: right;
	background-color: #FFF;
	z-index: 99999;
	box-shadow: 0px -3px 34px 1px #292929;
}
.attbg {
	background-color: #000;
	opacity: 0.6;
	width: 100%;
}
.attbox_left {
	display: block;
	width: 20%;
	float: left;
	z-index: 99998;
	height: 2000px;
}
.stg_word { margin-left:0; font-size:0.8rem;}
.stg_cinp { width:auto; float:left; padding:0 8px;}
.attrValue {
	/*padding: 10px 0;*/
    overflow: hidden;	
}
.attr-note { color:#81838e; display:block; line-height:20px; margin-bottom:5px;}
.attrValue a {
	display: block;
    float: left;
	width:auto;
	text-align:center;
    padding: 0 15px;
    font-size: 0.7rem;
    color: #AAAAAA;
    height: 27px;
    border: 1px #AAAAAA solid;
    line-height: 27px;
    background-color: #fff;
	margin-right:9px;
	margin-bottom:10px;
	border-radius:4px;
}
.attrValue a.sel {
	border-color: #FF3334;
	color:#FF3334;
}
.stg_att { font-size:0.8rem;}
.select_num { float:left;}
</style>
<div id="attbox" class="hide attbox" >
  <div  class="main" id="attbox_main">
  <!--<form id="orders_form"   style=" background-color:#EFEDED" class="J-offerdetail hide" method="post" action="index.php?m=wb_shop&a=confim&forward=<?php echo urlencode('index.php?m=wb_shop&a=show&catid='.$catid.'&id='.$id);?>">-->
  <form id="orders_form"   style=" background-color:#EFEDED" class="J-offerdetail hide" method="post" action="index.php?m=wb_shop&a=listOfGoods&forward=<?php echo urlencode('index.php?m=wb_shop&a=show&catid='.$catid.'&id='.$id);?>">
    <input type="hidden" name="goodsid" value="<?php echo $id;?>" id="goodsid">
    <input type="hidden" name="goodscatid" value="<?php echo $catid;?>" id="goodscatid">
    <input type="hidden" name="yun_fei" value="<?php echo $yun_fei;?>" id="yun_fei">
    <input type="hidden" name="plat" value="<?php if($dp_id) { ?><?php echo $dp_id;?><?php } else { ?><?php echo $plat;?><?php } ?>" id="dp_id">
    <div class="select_attributes">
      <div class="satt_goods_box">
        <div class="stg_div">
          <i class="stg_remove" onClick="catt(1)"></i>
          <div class="stg_imgbox fl"><img src="<?php echo $thumb;?>" width="100%" /></div>
          <div class="stg_word fr">
            <div  style="    margin: 0 0  8px 0"> <span> <?php echo $rs['title'];?></span></div>
          </div>
          <div class="clear"></div>
          <div class="stg_word fl">
            <div class="stg_price"> <span>￥</span> <span><?php echo number_format($jiage,2);?></span> </div>
            <?php if($yuanjiage) { ?>
            <div class="item">
              <label class="ui-label" >原价&nbsp;:&nbsp;</label>
              <del class="price-origin">￥<?php echo number_format($yuanjiage,2);?></del> 
            </div>
            <?php } ?>
          </div>
        </div>
      </div>
    <div class="stg_att" id="attrInfo"> 
      	
    </div>
    <div class="stg_att" id="attrCount" style="margin-top:20px;">
      
      <div class="stg_cont" style="line-height:27px;">
     	 <span style="display:none;">(库存:<em id="shopKc" data-val="0" data-attrid="0">0</em>)</span>
         <span class="attr-note">数量</span>
        <div class="select_num" style="margin:0px; background:#FFF;">
        	<a href="javascript:void(0);" class="btn_reduce" onClick="combosub(2,this)"></a>
          	<input type="number" name=""  class="text iptCount"  id="combo_2" min="1" max=""  value="1" onChange="enterChangeCount(this)">
          	<a href="javascript:void(0);" class="btn_add" onClick="comboadd(2,this)"></a> </div>
      </div>
    </div>
    </div>
    <div class="sc_bottom">
      <div class="sc_bottom_box">
        <div id="gwc"  class="satt_btn" style=" background-color:#636161; width:40%; float:left" onClick="add_cart('<?php echo urlencode('index.php?m=wb_shop&c=index&a=show&catid='.$catid.'&typeid=1&id='.$id.'&plat='.intval($_GET['plat']));?>')">加入购物车</div>
        <div class="satt_btn" style=" width:40%;float:left" onClick="send()">立即提交</div>
      </div>
    </div>
    <input type="hidden" name="buyWay" value="pf"/>
  </form>
  <div class="attbox_left" id="attbox_left" onClick="catt(1)"></div>
</div>
<div class="attbg"></div>
</div>
<script>
getAttrInfo();//初始化属性json
var timeOut;
var buyCondition = 0;
var total=0; 
var total_amount=0;
var amount = single_price = '<?php echo $jiage;?>';
function showattribute(id){
	for(var i=1;document.getElementById('attributetab_'+i);i++){
		$('#attributetab_'+i).removeClass('color_title');
	}
	$('#attributetab_'+id).addClass('color_title');
	$('.attribute_box').hide();	
	$('#attribute_'+id).show();
}
function combosub(id,obj){
	var num = Number($('#combo_'+id).val());
	if(num>1){
		$('#combo_'+id).attr('value',num-1);
	}
}
function comboadd(id,obj){
	var num = Number($('#combo_'+id).val());
	if (num>=5) {
		tipsBox('国家海关规定单笔交易同种商品不得5件以上，请您多次购买');
		return;
	}
	var kc = Number($('#shopKc').attr('data-val'));
	var result = num<kc?num+1:num;
	$('#combo_'+id).attr('value',result);
}
//输入修改数量
function enterChangeCount(obj){
	var num = Number($('#combo_2').val());
	var kc = Number($('#shopKc').attr('data-val'));
	var result = num<kc?num:kc;
	$('#combo_2').attr('value',result);
}

function check_order(bianshiid,name){
	var num=0; 
	var iptCount = $('#attribute_'+bianshiid+' .iptCount');
	for(var i=0,len=$(iptCount).length;i<len;i++){
		num += Number($(iptCount[i]).val());
	}
	if(document.getElementById('order_'+bianshiid)){
		if(num==0){
			$('#order_'+bianshiid).remove();	
		}else{
			$('#order_'+bianshiid+' .num').html(num);	
		}
	}else{
		var str = '<tr id="order_'+bianshiid+'"><td>27</td><td>'+name+'</td><td class="num">'+num+'</td></tr>';	
		$('.buylist').append(str);
		
	}
	$('#total').html(total);
	total_amount = total*amount;
	$('#total_amount').html(total_amount.toFixed(2));
	//下边2种方法都行
	$('#sl').val(total);
	$('#z_jiage').attr('value',total_amount.toFixed(2));
	
	
	if($('#tongji-ordre').find('ul').length<=0){
		$('#J-goPay').addClass('gol-disbtn');
		$('#J-goPay').click(function(){ return false;});
		$('#J-addCart').unbind('click');
		$('#tongji-tip').show();
		$('#tongji-ordre').hide();
	}else{
		$('#J-goPay').removeClass('gol-disbtn');
		$('#J-goPay').unbind('click');
		$('#J-goPay').click(function(){ $('#orders_form').submit(); });
		$('#J-addCart').unbind('click');
		$('#J-addCart').click(function(){ add_cart();});
		$('#tongji-ordre').show();
		$('#tongji-tip').hide();
	}

}
function send(){
	
	if( $('#orders_form').css('display')=='none' ){ 
		catt();
	}else{
		
		if(1||Number($('#shopKc').attr('data-val')) > 0){ 
			/*layer.alert('凑单更划算~', {
			  skin: 'layui-layer-molv' //样式类名 自定义样式
			  ,closeBtn: 1  // 是否显示关闭按钮
			  ,anim: 1 //动画类型
			  ,btn: ['凑单','关闭'] //按钮
			  ,icon: 6  // icon
			  ,yes:function(){
				$('#orders_form').submit();
			  }
			  ,btn2:function(){
				layer.msg('已取消');
			 }});*/
			 var totalMoney = Number(single_price)*Number($('#combo_2').val());
			 if (1>3&&single_price<1000&&totalMoney>1000) {
				tipsBox('国家海关规定多件商品的总价不得超过1000元,请您分多次购买');
				return;
			 }
			$('#orders_form').submit();
			
		}else{ 
			layer.msg('库存不足');
		}
	}
}

function add_cart($f){ 
	
	if (Number($('#shopKc').attr('data-val')) <= 0) {
		layer.msg('库存不足!');
		return;
	}
	//alert($f);die;
	//var f = 'index.php?m=wb_shop&a=show&catid=1&id=115&plat=3';
	var index = layer.load(2);
	$.ajax({
		cache: true,
		type: "POST",
		url:'index.php?m=wb_shop&a=add_cart&plat=<?php echo $dp_id;?>',
		data:$('#orders_form').serialize().replace(/\&count.*/,'')+'&ajax=1&count='+parseInt($('#pro_num').val()),
		async: false,
		error: function(request) {
			layer.close(index);
			layer.msg('操作失败,请稍后再试');
			return false;
		},
		success: function(data) { 
			var da = data;
			setTimeout(function(da){
				layer.close(index);
				var json_data =  eval('(' + data + ')');
				if(json_data.status==1){
					try{ getgoodscart(); }catch(e){ }
					layer.msg('已加入购物车');
					var tt = Number($('#cartCount').attr('data-val')) + Number($('#combo_2').val());
					$('#cartCount').text(tt);
					$('#cartCount').attr('data-val',tt);
					setTimeout(function(){catt(1);},800);
				}else if(json_data.status==-1){
					try{ show_login(); }catch(e){
						/*layer.msg(json_data.msg, {time:2000});
						setTimeout(function () {
							window.location.href='index.php?m=member&a=login&forward='+$f;	
						}, 2000);*/
						//cartInfo set cookie
						setCartCookie();
						layer.msg('已加入购物车');
						var tt = Number($('#cartCount').text()) + Number($('#combo_2').val());
						$('#cartCount').text(tt);
						$('#cartCount').attr('data-val'.tt);
						setTimeout(function(){catt(1);},800);
					}
				}else{
					layer.msg(json_data.msg);
				}
				return false;
		},300)},
	});	
	return false;
}
function setCartCookie(){
	var cartArr = getcookie('cart')?getcookie('cart'):'{}';
	var date = new Date();
	var dp_id = $('#dp_id').val();
	var goodsid = $('#goodsid').val();
	var goodscatid = $('#goodscatid').val();
	var goodstitle = "<?php echo $rs['title'];?>";
	//var yun_fei = $('#yun_fei').val();
	var attrId = $('#shopKc').attr('data-attrid');
	var attrCount = $('#combo_2').attr('value');
	var jsonIndex = goodsid+'_'+attrId;
	var proIndex = goodscatid+'_'+goodsid;
	cartArr = JSON.parse(cartArr);
	var jsonData = {
		"cid":date.getTime(),
		"productid":goodsid,
		"productcatid":goodscatid,
		"producttitle":goodstitle,
		//"yun_fel":yun_fei,
		"plat":dp_id,
		
	};
	//.attribute[proIndex][attrId]
	if ($.isEmptyObject(cartArr[jsonIndex])) {
		var attrValue = '{"'+proIndex+'":{"'+attrId+'":"'+attrCount+'"}}';
		attrValue = JSON.parse(attrValue);
		jsonData.attribute = attrValue;
		cartArr[jsonIndex] = jsonData;
	} else {
		var attrExist = cartArr[jsonIndex].attribute[proIndex][attrId];
		var cartItem = cartArr[jsonIndex];
		var countResult = Number(attrExist)+Number(attrCount);
		var attrValue = '{"'+proIndex+'":{"'+attrId+'":"'+countResult+'"}}';;
		attrValue = JSON.parse(attrValue);
		cartItem.attribute = attrValue;
		//console.log(cartItem);
	}
	setcookie('cart',JSON.stringify(cartArr));
}
var AttrJsonData = {};
function getAttrInfo(){
	$.get('index.php?m=wb_shop&c=index&a=getAttributeInfo&gid=<?php echo $id;?>&gcatid=<?php echo $catid;?>',function(data){
		if (data.status == 1) {
			//creathtml
			var attribute_ = data.attribute['attVal'];
			var attrJson = data.attrJson;
			var attText = data.attText;
			var attribute_html = '';
			for(var i in attribute_){
				attribute_html += '<span class="attr-note">'+attText[i]+'</span><div class="attrValue" id="attrValue_'+i+'">';
				var attrValue = attribute_[i];
				var nn=1;
				for(var ii in attrValue){
					var sel = nn==1?'sel':'';
					attribute_html += '<a href="javascript:;" class="attrTtem '+sel+'" onClick="setAttr(this,'+i+')" data-val="'+attrValue[ii]+'">'+attrValue[ii]+'</a>';
					nn++;
				}
				attribute_html += '</div>';
			}
			$('#attrInfo').empty();
			$('#attrInfo').append(attribute_html);
			
			if ($.isEmptyObject(AttrJsonData)) {
				//setJson
				for(var i in attrJson){
					AttrJsonData[i] = attrJson[i];
				}
			}
			setAttr();//默认选中属性
			//console.log(AttrJsonData);
		} else {
			layer.msg('网络错误,请刷新再试!');	
		}
	},'json');
}
function setAttr(obj,attId){
	var selItem = '';
	var selText = '';
	var attrInputName = 'attribute[<?php echo $catid;?>_<?php echo $id;?>]';
	$('#attrValue_'+attId+' a').removeClass('sel');
	$(obj).addClass('sel');
	var currAttVal = $(obj).attr('data-val');
	var attItem = $('#attrInfo a.sel');
	attItem.each(function(i) {
        var attVal = $(attItem[i]).attr('data-val');
		selItem += attVal+'|';
		selText += attVal+'、';
    });
	var shopAttId = AttrJsonData[selItem].id;
	attrInputName += '['+shopAttId+']';
	$('#combo_2').attr('name',attrInputName);
	//$('#combo_2').attr('max',AttrJsonData[selItem].kc);
	//$('#shopKc').attr('data-val',AttrJsonData[selItem].kc);
	$('#shopKc').attr('data-val',999);
	$('#shopKc').attr('data-attrId',AttrJsonData[selItem].id);
	$('#shopKc').text(AttrJsonData[selItem].kc);
	$('#selectedAtt').text('已选择: '+selText);
	//console.log(shopAttId);
	//alert(shopAttId);
}
countCart();
//countCart
function countCart() {
	$.get('index.php?m=wb_shop&c=index&a=getCartCount&id=<?php echo $id;?>&catid=<?php echo $catid;?>&ajax=1',function(data){
		
		if (data.status == 1 && data.count > 0) {
			$('#cartCount').text(data.count);
			$('#cartCount').attr('data-val',data.count);
		} else {
			var result = countCookieCart();
			$('#cartCount').text(result);
			$('#cartCount').attr('data-val',result);
		}
	},'json');
}
function countCookieCart(){
	var cartArr = getcookie('cart')?getcookie('cart'):'{}';
	cartArr = JSON.parse(cartArr);
	var result = 0;
	for(var i in cartArr){
		var attribute = cartArr[i].attribute;
		for(var ii in attribute){
			var att = attribute[ii];
			for(var at in att){
				result += Number(att[at]);
			}
		}
	}
	return result;
}
</script>