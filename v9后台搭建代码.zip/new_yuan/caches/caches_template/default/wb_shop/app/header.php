<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
$title = $title? $title : $TYPE[$typeid]['typename'];
?>
<!--<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/style6.css" />-->

<div class="header" style="background: #929190;">
  <div class="header_box">
  <a href="javascript:goback()" class="header_fanhui" id="header_fanhui"></a>
    <h2 class="header_title <?php if($_GET['yl']) { ?>fl<?php } ?>" ><?php echo $title;?></h2>
  </div>
</div>
<script>
try{ jstojava.mysetgoback('goback()'); }catch(e){}	
function goback(){
	history.back();
}
</script>