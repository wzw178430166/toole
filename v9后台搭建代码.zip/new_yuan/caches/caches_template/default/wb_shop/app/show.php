<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php
$description = '巴巴优品';
$appid = pc_base::load_config('system','wx_appid');
$appSecret = pc_base::load_config('system','wx_appSecret');
$link = get_url();
if(is_weixin() && $appid){
    pc_base::load_app_func('global','weixin');
    $timestamp = time().'';
    $wxnonceStr = 'barbar8api';
    $jsapi_ticket = wx_get_jsapi_ticket($appid,$appSecret,'shop');
    $url = get_url();
    $wxOri = sprintf("jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s",$jsapi_ticket, $wxnonceStr, $timestamp,$url);
    $wxSha1 = sha1($wxOri);
}
$url = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
$ll_url = $_SERVER['HTTP_REFERER'];
//var_dump($shop_attribute);die;
?>
<?php include template('wb_shop','header_common2'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/style6.css" />
<style>
.shopcontent {
	display: none;
	transition: top 0.5s;
	position: absolute;
	z-index: 10;
	background: #FFFFFF;
	width: 100%
}
.showb_but {
	border-top: 1px solid #DEDADA;
	font-size: 15px;
	text-align: center;
	height: 40px;
	line-height: 40px;
}
#snct_list li {
	width: 48.5%;
	float: left;
	background: #ffffff;
	border: 1px solid #E4E3E3;
	margin-bottom: 10px;
}
.bd li img {
	max-height: 320px;
}
.act-link {
	color: #f15353;
	margin-top: 8px;
	font-size: 13px;
	line-height: 18px;
}
.gds_title {
	height: 100%;
	display: inline-block;
	font-size: 16px;
	margin-right: 30px;
}
.prod-price {
	font-size: 24px;
	font-family: 'Helvetica';
	color: #f15353;
	margin-top: 10px;
	font-weight: bold;
}
.mod-popup {
	display: none;
	position: fixed;
	z-index: 9999;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
}
.mod-popup-bg {
	background: rgba(0,0,0,0.8);
	position: absolute;
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
	z-index: 999;
}
.mod-popup-prompt .popup-container {
	position: absolute;
	width: 280px;
	top: 30%;
	left: 50%;
	margin-left: -140px;
	-webkit-border-radius: 2px;
	-webkit-box-shadow: 0 1px 4px rgba(0,0,0,0.3);
	background: #fff;
	z-index: 99999;
}
.popup-comment .popup-container {
	padding: 0 15px;
	-webkit-box-sizing: border-box;
}
.popup-comment .popup-container .rate-star {
	display: -webkit-box;
	-webkit-box-pack: justify;
	-webkit-box-align: center;
	margin: 10px 0;
}
.popup-comment .popup-container .textarea {
	display: block;
	width: 100%;
	height: 70px;
	padding: 10px;
	color: #333;
	background: #fff;
	-webkit-border-radius: 2px;
	border: 1px solid #e5e5e5;
	-webkit-box-sizing: border-box;
	-webkit-appearance: none;
	resize: none;
}
.popup-comment .popup-container .prompt {
	text-align: right;
	color: #999;
}
.btn {
	display: block;
	width: 60px;
	-webkit-box-sizing: border-box;
	font-size: 14px;
	height: 30px;
	line-height: 30px;
	text-align: center;
	color: #fff;
	-webkit-border-radius: 2px;
	border: 0;
	float: left;
	-webkit-box-flex: 1;
	margin: 11px 5px;
	width: 115px;
}
.btn-unable {
	background-color: #f80;
}
.btn {
	display: block;
	width: 60px;
	-webkit-box-sizing: border-box;
	font-size: 14px;
	height: 30px;
	line-height: 30px;
	text-align: center;
	color: #fff;
	-webkit-border-radius: 2px;
	border: 0;
	float: left;
	-webkit-box-flex: 1;
	margin: 11px 5px;
	width: 115px;
}
.comment-input-wrap {
	margin: 5px auto 10px 1%;
	position: relative;
	width: 97%;
}
.comment-input-wrap .input-text {
	padding-left: 35px;
	color: #ccc;
	border-color: #e6e6e6;
	background: url('http://www.e8online.com/statics/index4/app/images/tou3.png') no-repeat 7px 5px;
	background-size: 24px auto;
}
.input-text {
	background: #fff;
	-webkit-border-radius: 2px;
	border: 1px solid #d5d5d5;
	height: 37px;
	-webkit-box-sizing: border-box;
	font-size: 14px;
	line-height: 24px;
	padding: 7px 5px;
	color: #999;
	position: relative;
}
.btn-sec-w, .btn-cancel, .btn-sec-g, .btn-sec-lg {
	border: 1px solid #d5d5d5;
	color: #d5d5d5;
}
.header {
	z-index: 999
}
</style>
<style>
.cpmo { /* height: 100px; */
position: relative; background: #fff; margin: 10px auto; width: 90%; }
.cpmo .cpt2 { font-size: 0.9rem; width: 100%; margin: 0 auto; color:#333;}
.cpmo .cpt1 { padding-top: 5px; font-size: 1rem; color: #f15353; color: #f24b48; float:left; margin-right:15px;}
.xinxin { height: 40px; line-height: 40px; color: #999; padding: 0px 5%; background: #fff; font-size: 0.8rem; }
.xinxin img { margin-top: 16px; }
.cptit { height: 40px; line-height: 40px; text-indent: 15px; background: #EFEDED; font-size: 15px;/* margin-top: 10px; */
}
.hot_commodities { width: 98%; margin: 0 auto; margin-top: 10px; }
.hot_comm_cont { width: 100%; margin: 0 auto; }
.hot_comm_cont ul li { width: 48%; float: left; background: #ffffff; border: 1px solid #E4E3E3; margin-bottom: 12px; }
.hcc_bot { width: 94%; margin: 4px auto; }
.hccb_word { color: #333; line-height: 14px; font-size: 12px; width: 96%; margin: 0 auto; height: 30px; overflow: hidden; display: block; }
.hccb_line { border-bottom: 1px solid #E4E3E3; margin: 6px auto; }
.hccb_price { color: #e60b0b; width: 94%; margin: 0 auto; font-size: 14px; line-height: 25px; }
.look_same { width: 50px; height: 18px; line-height: 18px; text-align: center; border: 1px solid #999; border-radius: 3px; display: inline-block; font-size: 12px; color: #999; }
#snct_list li:nth-of-type(odd) { margin-right: 0; }/*奇数行*/
#snct_list li:nth-of-type(even) { float: right; }
/*热门商品 end*/
.ndae52 { height: 50px; }
.pjdd_02 { /*border-bottom: 1px solid #e5e5e5;*/ padding-bottom: 10px; margin-bottom: 5px; }
.ui-label { font-size: .12rem; line-height: .12rem; height: .12rem; display: inline-block; vertical-align: middle; color: #968896; }
.price-origin { font-weight: lighter; font-size: .12rem; color: #888; }
.bd_show li img { max-height:300px;}
.header_title {
	width: 60%;
    margin: 0 auto;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;	
}
#cartCount {
	position: absolute;
    right: 10px;
    top: 0;
    height: 15px;
    line-height: 15px;
   /* width: 15px;*/
   padding:0 5px;
    background-color: #D92B2B;
    border-radius: 30px;
    text-align: center;
	font-size:0.7rem;
}
.spmf_name { text-indent:inherit;}
.space_line {
    height: 15px;
}
.J_comment { position:fixed; left:0; top:0; width:100%; height:100%; background-color:#fff; display:none; z-index:1000; overflow-y: scroll;}
.J_comment .comment-title { position: fixed; width:100%; text-align:center; background-color:#fff; height: 44px; line-height:45px; border-bottom:1px #c8cacc solid;}
.comment-title-arrow { position:absolute; left:0; top:0; width:30px; height:44px; background:url('statics/images/icon/un_color/arrow_l_icon.png') no-repeat center;background-size:65%;}
.space_line { height:15px;}
.shop_comment_box { width:95%;}
.comment-header {
	height: 25px;
    line-height: 25px;
    font-size: 0.9rem;
    margin-bottom: 5px;	
}
.comment-item { padding:0 0.8rem;}
.comment_item {
	padding-bottom: 0.8rem;
    border-bottom: 1px solid #dcdcdc;	
}
.comment_time {
	font-size: 0.7rem;
    padding-top: 0.4rem;
	color:#999;
}
.comment-user { height:39px; line-height:39px; padding:0.7rem 0; font-size:0.7rem;}
.comment-header-img img{ width:1.7rem;}
.comment_header_img img { width:2.2rem;}
.comment_item_content { color:#333; font-size: 0.95rem;}
.empty-comment-tips { font-size:0.7rem; text-align:center; color:#333; padding:5px 0;}
.slideBox_show { border-bottom:0;}
.logTaxDesc {
	height: auto;
    line-height: initial;
    text-indent: 1rem;
    padding-bottom: 5px;
    font-size: 0.7rem;
    text-align: justify;	
}
</style>
<body>
<!--public header start--> 

<?php include template('wb_shop','header'); ?> 

<!--public header end-->
<div style="height:48px;"></div>
<div class="main main_show" id="content_box">
  <div class="shop_content"> 
    <!--轮播 start-->
    <div id="slideBox_show" class="slideBox_show" style="max-height:320px;">
      <div class="bd_show">
        <div class="tempWrap" style="overflow:hidden; position:relative;">
          <ul id="lunbo_show">
            <?php if($d_cptu) { ?>
            <?php $n=1;if(is_array($d_cptu)) foreach($d_cptu AS $r) { ?>
            <li><img height="320px" src="<?php echo IMG_PATH;?>bg_h.gif" onload="delayimg(this,'1')"  data-src="<?php echo $r['url'];?>"/></li>
            <?php $n++;}unset($n); ?>
            <?php } else { ?>
            <li><img height="320px" src="<?php echo IMG_PATH;?>bg_h.gif" onload="delayimg(this,'1')" data-src="<?php echo $thumb;?>"/></li>
            <?php } ?>
          </ul>
        </div>
      </div>
      <!--轮播按钮-->
      <div class="hd_show">
        <ul>
          <?php $n=1;if(is_array($d_cptu)) foreach($d_cptu AS $r) { ?>
          <li class="on"><?php echo $n;?></li>
          <?php $n++;}unset($n); ?>
        </ul>
      </div>
    </div>
    <script type="text/javascript">
           TouchSlide({
                slideCell: "#slideBox_show",
                titCell: ".hd_show ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
                mainCell: ".bd_show ul",
                effect: "leftLoop",
                autoPage: true,//自动分页
                autoPlay: false //自动播放
            });
        </script> 
    <!--轮播 end-->
    <div class="clear"></div>
    <div class="cpmo">
      <p class="cpt2"><?php echo $rs['title'];?></p>
      <p class="cpt2" style=" font-size: 14px;color: #f15353;font-size: 14px;line-height: 18px;"><?php echo $rs['discription'];?></p>
      <p class="cpt1 pink"> <?php if(intval($jiage)!=0) { ?>
        ￥<?php echo number_format($jiage,2);?>
        <?php } else { ?> <font style="font-size:15px;">暂无价格</font> <?php } ?> </p>
        <?php if($yuanjiage) { ?><p class="cpt1 pink" style="height:1.3rem; line-height:1.5rem; font-size:0.7rem;"><del>￥<?php echo number_format($yuanjiage,2);?></del></p><?php } ?>
    </div>
    <!--<div style="margin-left: 26px;" class="item"> <?php if($yuanjiage) { ?>
      <label class="ui-label">原价&nbsp;:&nbsp;</label>
      <del class="price-origin">￥<?php echo number_format($yuanjiage,2);?></del> <?php } ?> </div>-->
    <section id="s-adds">
      <div class="mui-flex" id="J_indPanel" style="margin: 10px auto; width: 90%;">
        <div class="postage cell" style="    width: 33%;    float: left;    color: #7B7A7A;   font-size: 0.7rem;">运费 : <?php if($yun_fei) { ?><?php echo number_format($yun_fei,'2');?><?php } else { ?>免运费<?php } ?></div>
        <!--<div class="sales cell" style=" width: 33%;  float: left;  color: #7B7A7A; font-size: 14px;  text-align: center;
">月销量 <?php echo $yue_xl;?> 件</div>-->
        <div class="delivery cell" style="   width: 33%;   float: left;   color: #7B7A7A;   font-size: 0.7rem;   text-align: right;"><?php echo $area;?></div>
      </div>
    </section>
    
    <div class="xinxin" style="border: 1px solid #e5e5e5;" onClick="catt()"> <span class="fl" style="color: #444343;" id="selectedAtt">选择：颜色分类/套餐类型</span> <span class="fr"><img src="<?php echo SPATH;?>wb_shop/images/iconfont-jiantou.png" width="17"></span> </div>
    <!---进口税 start-->
     <!--<div class="xinxin"> <span class="fl" style="color: #444343;">综合税费：<?php if(1>3 && in_array($id,$noshui)) { ?>商家承担<?php } else { ?>预计<?php echo $jkMoney;?>元(税率:<?php echo $tax_rate*100;?>%)<?php } ?></span></div>-->
     <div class="xinxin" style="height:30px; line-height:30px;"> <span class="fl" style="color: #444343;">有关运费、税费说明:</span></div>
     <div class="xinxin logTaxDesc"> <span class="fl" style="color: #444343;">运费以下单时物流计算为准，包括箱子重量(400g、500g), 满1000元包邮; 该商品的税率<?php echo $tax_rate*100;?>%,平台不收取税费,若产生税费本人自理。</span></div>
    <!---进口税 end-->
    
    <!----------------商品评价-------------------->
    <div class="cptit space_line"></div>
    <div class="shop_comment yin">
      <div class="shop_comment_box"> 
      	
        <div class="pjdd_02">
          <div class="comment-header">商品评价</div>
          <?php if($comments) { ?>
          <div class="spm_faces">
            <div class="spmf_name fl" style="text-align:left">
            	<span class="comment-header-img"><img src="<?php echo SPATH;?>images/icon/color/header_icon.png"></span>
                <span class="comment-name"><?php echo substr_replace($comments['username'],'****',3,4);?></span>
            </div>
          </div>
          <div class="comm_content"> <?php echo $comments['content'];?></div>
          <div class="comm_other"> <span><?php echo date('Y-m-d', $comments['creat_at']);?>&nbsp;&nbsp;</span><span><?php echo $snapshot['attribute'];?></span> </div>
          <a href="javascript:;" onClick="checkComment()" class="comm_more_link"> 查看更多评价 </a>
          <?php } else { ?>
          <div style="text-align:center; font-size:0.8rem;">暂无评价</div>
          <?php } ?> 
        </div>
        </div>
    </div>
    <div class="showb_but yin" onClick="showb()">点击查看图文详情</div>
    <div class="cptit yin" >猜你喜欢</div>
    <div class="hot_commodities yin">
      <div class="hot_comm_cont">
        <ul id="snct_list">
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fd5ec70c1a9fbe44be09313819bc3566&action=lists&catid=6&order=listorder+desc%2Cinputtime+DESC&thumb=1&num=4\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>'6','order'=>'listorder desc,inputtime DESC','thumb'=>'1','num'=>'4','limit'=>'4',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
          
          <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
          <li> <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>">
            <div class="hcc_img"><img src="<?php echo $r['thumb'];?>" width="100%"></div>
            </a>
            <div class="hcc_bot"> <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>">
              <p class="hccb_word"> <span class="ndae52"><?php echo str_cut($r['title'],65);?></span> </p>
              <div class="hccb_line"></div>
              </a>
              <p class="hccb_price"> <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>"> <span class="hccb_price"> <?php if(intval($r['jiage']) > 0) { ?>
                ￥<?php echo number_format($r['jiage'],2);?>
                <?php } else { ?>
                暂无价格
                <?php } ?> </span> </a> <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>" class="look_same fr"> 去购买 </a> </p>
            </div>
          </li>
          <?php $n++;}unset($n); ?>
        </ul>
      </div>
    </div>
    <div class="clear yin" ></div>
    <div class="shopcontent" id="shopcontent" style="padding-bottom:50px;">
      <div id="shopcontent_con" > <?php echo $content;?> </div>
    </div>
    <div class="clear"></div>
    <div class="shop_bottom  ">
      <div class="shop_bottom_box">
        <div class="sbx_left fl" style="opacity:0.9"> 
        	<a href="index.php?m=wb_shop&a=goodscart&plat=<?php echo $plat;?>" class="sbx_kefu fpiwt02 fl" style=" line-height: 5.1;background-size: 25px !important;background-position-y: 2px; position:relative;"> 购物车 <font id="cartCount" data-val="0">0</font></a>
            <a href="javascript:add_favorite('<?php echo $rs['title'];?>')" id="favorite" class="sbx_coll fr" style="line-height: 5.1; background-size:21px !important;"> 收藏 </a> 
        </div>
        <a  href="javascript:catt()" class="add_che fl"> 加入购物车 </a>  
        <a href="javascript:<?php if(intval($jiage) > 0) { ?>catt()<?php } else { ?>:;<?php } ?>" class="buy_now fl"> <?php if(intval($jiage) > 0) { ?>立即购买<?php } else { ?>敬请期待<?php } ?> </a> 
      </div>
    </div>
  </div>
</div>
<div style="height:58px;"></div>
<input type="hidden" id="forward_" value="<?php echo urlencode('index.php?m=wb_shop&a=show&catid='.$catid.'&id='.$id);?>">
<!--footer end-->
<!---commentBox start-->
<div class="J_comment" id="J_comment">
	<div class="comment-title"><div class="comment-title-arrow" onClick="hideComment()"></div><span>商品评价</span></div>
    <div style="height:45px;"></div>
    <div class="comment-item" id="J_commentItem"></div>
</div>
<!---commentBox end-->
</body>
<?php include template('wb_shop','attribute'); ?>
<?php include template('wb_shop','footer_common'); ?>
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script>
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
    text: $(qrcodes[i]).attr('mlink')
}); 
}
</script>
<script>

var screen_height = $(window).height();//window.screen.height;
var scrollTop_, content_loading,goback;
var attbox_time;
window.onload = function(){
	var width = document.body.clientWidth>640? 640 : parseInt(document.body.clientWidth);
	var li = $('#lunbo_show').find('li');
	$('#lunbo_show').css('width',(width*li.length)+'px');
	li.css('width',width+'px');
	AutoImage('content',width-30,0);
	$('#attbox').css('height',$(window).height());
	$('#orders_form').css('min-height',window.screen.height);
	$('#shopcontent').css({'min-height':window.screen_height,'top':screen_height});
	//window.onscroll=function(){ de_onscroll(); };
	setLikeGoodsSize();
	$('#J_comment').scroll(function(){
		myscroll();
	});
}

function setLikeGoodsSize(){
	var pkd =$(document.body).width(); //浏览器当前窗口可视区域宽度
	var ztgd =$(document).height();
	var tkd =0.4753*pkd; 
  	$(".hcc_img img").css('width',tkd+'px');
	$(".hcc_img img").css('height',tkd+'px');
	$(".select_attributes").css('height',ztgd+'px');
}

function catt(ac){
	 
	//js禁止页面滚动,禁止网页滚动 {只对鼠标滚动事件有效,手机手指滚动事件无效}
	$('body').attr('onmousewheel',"return false;");
	//手机端禁止页面滚动 有效果不过效果不理想
	$('body').scroll(function (){
	   return false;
		});


	if(ac&&ac!=99){
		$('#attbox').hide();
		//$('#content_box').show();
		$('#orders_form').hide();
		//$('body').attr('style','background: #fff');
		//$('#gwc').attr('style','display:none')
		window.onscroll=function(){ de_onscroll(); };
		$('body').css('overflow','hidden')
	}else{
		$('#attbox').css('top',$(window).scrollTop()+'px');
		$('#attbox').show();
		var st;
		var scrollTop = $(window).scrollTop();
		var scroll=function(e){
			//clearTimeout(st);
			//st=setTimeout(function(){
			$(window).scrollTop(scrollTop);
			//},5);
		}
		window.onscroll=scroll;
		$('body').css('overflow','auto');
		//$('#content_box').hide();
		$('#orders_form').show();	
		//$('body').attr('style','background: #f0f2f5')
		//$('.header').attr('style','display:blick')
		if(ac==99){$('#gwc').attr('style','display:blick')}
	}	
}
 function add_favorite(title) {
	$.post('./api.php?op=add_favorite&title='+encodeURIComponent(title)+'&url='+encodeURIComponent(location.href)+'&bianhao=<?php echo $bianhao;?>&pcatid=<?php echo $catid;?>&pid=<?php echo $id;?>&can_cancel=1', function(data){
		data = eval('(' + data + ')');
		if(data.status==2)	{
			layer.msg('收藏成功',{time:1000});
			$("#favorite").addClass('sbx_colled');

		}else if(data.status==1){
			layer.msg('已取消收藏',{time:1000});
			$("#favorite").removeClass('sbx_colled');
		} else {
			//也可以直接在这里写一个window.href='';跳转到登录页面
			layer.msg('请先登录',{time:1500});
			setTimeout(function(){
				window.location.href = 'index.php?m=member&a=login&forward='+$('#forward_').val();
			},1500);
		}
	});
}

get_favorite('<?php echo $title;?>');

function get_favorite(title){
	$.post('./api.php?op=add_favorite&ac=get_favorite&title='+encodeURIComponent(title)+'&url='+encodeURIComponent(location.href)+'&bianhao=<?php echo $bianhao;?>&pcatid=<?php echo $catid;?>&pid=<?php echo $id;?>&can_cancel=1', function(data){
		data = eval('(' + data + ')');
		if(data.status==1)	{
			$("#favorite").addClass('sbx_colled');
		}
	});	
}

function showb(){
	scrollTop_ = $(window).scrollTop();
	goback =  $('#header_fanhui').attr('href');
	$('#header_fanhui').attr('href','javascript:hideb()');
	$('#shopcontent').show();	
	$(window).scrollTop(0);
	$('#shopcontent').css({'top':'50px'});
	//$('#search_header').css({'top':'0px'}); 	
	$('body').css({'height':$('#search_box').height()-50,'overflow':'hidden'});
	$('table').removeAttr('style');
}
function hideb(){
	$('body').css({'height':'auto','overflow':'auto'});
	$('#shopcontent').css({'top':screen_height});
	$('#header_fanhui').attr('href',goback);
	$(window).scrollTop(scrollTop_); 
	window.setTimeout(function(){ $('#shopcontent').hide(); },300);
	
}

/*var more_lock=0;
function de_onscroll(){
	console.log($(window).scrollTop()+'---'+window.screen.height);
	if($(window).scrollTop()>=window.screen.height){
		if(more_lock==0){
			showb();
		}else{
			//more_lock=0;
		}
	}
}*/

/*comment*/
var page = 1;
var loaded = 0;
var move = 0;
var c=document.documentElement.clientHeight || document.body.clientHeight;
var commentid = '<?php echo $commentid;?>';
//checkComment
function checkComment(){
	$('body').css({"overflow":"hidden","height":"100%"});
	$('html').css({"height":"100%"});
	$('#J_comment').show();
	var J_commentItemHtml = $('#J_commentItem').html();
	if (J_commentItemHtml.length <= 0) {
		getMoreComment();
	}
}
//hideComment
function hideComment(){
	$('#J_comment').hide();
	$('body').css({"overflow":"auto","height":"auto"});
	$('html').css({"height":"auto"});
}
//getMoreComment
function getMoreComment(){
	$.get('index.php?m=wb_shop&c=index&a=getComments_ajax&ajax=1&page='+page+'&commentid='+commentid,function(data){
		if (data.length > 0) {
			loaded=0;
			$('#J_commentItem').append(data);
		} else {
			$('#J_commentItem').append('<div class="empty-comment-tips">已经到底了~</div>');
		}
	});
	page++;
}

function myscroll(){
	if(loaded!=1){
		var t=$('#J_comment').scrollTop();
		move = t+c;
		console.log((t+c)+'----'+$('#J_commentItem').height()+'---'+loaded);
		console.log(t+c >= ($('#J_commentItem').height()+40));
		if(move >= ($('#J_commentItem').height()+40)){ 
			loaded=1;
			c++;
			window.setTimeout("getMoreComment()",300);
		}
	}

}
/*comment*/

//浏览历史(只对商品)
function ll_lishi(){
	$.post('?m=wb_shop&a=ll_lishi&ajax=1',{'plat':'<?php echo $_GET["plat"];?>','catid':'<?php echo $_GET["catid"];?>','id':'<?php echo $_GET["id"];?>','y_n':'<?php echo $y_n;?>'},function(data){
          
		/*if(data==0){
		layer.msg('记录浏览历史失败');
			}*/
		})
}
ll_lishi();

//商品浏览数据
function recode(){
	$.post('?m=wb_shop&a=fw_datas&ajax=1',{'plat':'<?php echo $_GET["plat"];?>','url':'<?php echo $url;?>','ll_url':'<?php echo $ll_url;?>','gid':'<?php echo $id;?>','gcatid':'<?php echo $catid;?>'},
		function(data) { }
	);	
	
}
if(getCookie('show_t')<Date.parse(new Date())-1800000||!getCookie('show_t')){
	
setCookie('show_t',Date.parse(new Date()));
recode();
}


</script>
<script type="text/javascript">   
 var pkd =$(document.body).width(); //浏览器当前窗口可视区域宽度
  var ztgd =$(document).height(); 
 var tkd =0.4753*pkd; 
  $(".hcc_img img").css('width',tkd+'px');
$(".hcc_img img").css('height',tkd+'px');
$(".select_attributes").css('height',ztgd+'px');
</script>
<script>
wx.config({
  debug: false,
  appId: "<?php echo $appid;?>",
  timestamp: '<?php echo $timestamp;?>',
  nonceStr: '<?php echo $wxnonceStr;?>',
  signature: '<?php echo $wxSha1;?>',
  jsApiList: ['onMenuShareAppMessage','onMenuShareTimeline','onMenuShareQQ']
});
wx.ready(function(){
    wx.onMenuShareAppMessage({//分享给好友
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link;?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
            //layer.msg('分享成功!');
        },
    });
    wx.onMenuShareTimeline({//分享到朋友圈
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link; ?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
            //layer.msg('分享成功!');
        },
    });
    wx.onMenuShareQQ({
        title: '<?php echo $description;?>', // 分享标题
        desc: '<?php echo $title;?>', // 分享描述
        link: '<?php echo $link; ?>',//window.location.href, // 分享链接
        imgUrl: '<?php echo $thumb;?>', // 分享图标
        success: function () {
           //layer.msg('分享成功!');
        },
    });
});
</script>
</html>>