<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common2'); ?>
<style>
.hong {
	background-color: #e3393c !important;
}
.enddiv { text-align:center; font-size:13px; color:#626262; display:none; margin-top:10px;}
</style>
    <link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/number.css" />
    <body style="background:#ffffff;">
    <!--header start--> 
    <?php $title='产品列表'?>
    <?php include template('wb_shop','header'); ?>
    <input type="hidden" id="forward" value="<?php echo urlencode(siteurl(1).'/index.php?m=wb_shop&c=index&a=lists&catid=6');?>">
    <!--header end-->
    <div style="height:50px"></div>
    <div class="main">
      <div class="sn_center">
        <div class="snc_box">
          <ul id="snc_ul">
            <li> <a  href="javascript:;" onClick="listorder(this)" class="snc_link snc_now" data-order="all" data-index="0">综合</a> </li>
            <li> <a href="javascript:;" onClick="listorder(this)" class="snc_link" data-order="xl" data-index="1">销量</a> </li>
            <li> <a href="javascript:;" onClick="listorder(this)" class="snc_link" data-order="jg" data-index="1">价格</a> </li>
            <li> <a onClick="showb()" class="snc_link">筛选</a> </li>
          </ul>
          <!--<div class="order" style=" color:#0796D0;float:left; height:45px;display:none; margin-left: 33%;"  >
            <div onClick="listorder(this, 1,'zheng')" style="  margin-bottom: 3px;">正序</div>
            <div onClick="listorder(this, 1)" >倒序</div>
          </div>
          <div class="order" style="color:#0796D0;margin:0 0 0 57%; display:none">
            <div onClick="listorder(this, 3,'zheng')"style="  margin-bottom: 3px;height:44px">正序</div>
            <div  onclick="listorder(this, 3)" >倒序</div>
          </div>-->
        </div>
      </div>
      <div style="height:25px;"></div>
      <div class="shop_list" style="padding-bottom: 20px;">
        <ul id="shop_ul">
      
        </ul>
        <div class="enddiv" id="enddiv"><?php if(isset($_GET['k'])) { ?>没有找到"<?php echo $_GET['k'];?>"相关产品<?php } else { ?>暂无商品<?php } ?></div>
      </div>
    </div>
    <?php include template('wb_shop','list_search', 'first'); ?> 
    <script type="text/javascript" src="<?php echo SPATH;?>wb_shop/js/list.js"></script> 
    </body>
    </html><?php include template('wb_shop','footer_common'); ?>
    <script>
 function add_favorite(title,pcatid,pid,obj) {
	$.post('./api.php?op=add_favorite&title='+encodeURIComponent(title)+'&url='+encodeURIComponent('http://www.weiweibb.com/index.php?m=wb_shop&a=show&catid='+pcatid+'&id='+pid)+'&bianhao=<?php echo $bianhao;?>&pcatid='+pcatid+'&pid='+pid+'&can_cancel=1', function(data){
		data = eval('(' + data + ')');
		if(data.status==2)	{
			layer.msg('收藏成功',{time:1000});
			$(obj).addClass('sbx_colled');
			$(obj).children().remove();

		}else if(data.status==1){
			layer.msg('已取消收藏',{time:1000});
			$(obj).removeClass('sbx_colled'); 
			$(obj).append('<img style="    margin-top: 3px;" src="http://www.weiweibb.com/statics/wb_shop/images/gz_off.png " width="22px">');
			
		} else {
			layer.msg('请登录!',{time:1500});
			setTimeout(function(){
				window.location.href = 'index.php?m=member&c=index&a=login&forward='+$('#forward').val();
			},1500);
		}
	});
}
</script>
<script>
$(function(){
	get_infos();
	window.onscroll = function() { myscroll(); }
	
})
var page = 0;
var loaded =0;
var catid="<?php echo $catid;?>";
var gerUrl = 'index.php?m=wb_shop&a=lists_data&catid='+catid;
var tem = '';
function get_infos(ac){
	if (ac == 'reset') {
		page = 0;
		$('#shop_ul').html('');
		gerUrl = 'index.php?m=wb_shop&a=lists_data&catid='+catid;
	}
	var param_ = '';
	tem = "<?php echo $_GET['k'];?>";
	if (tem) { param_ += '&k=' + tem;}
	tem = getUrlParam('xl');
	if (tem) { param_ += '&xl=' + tem;}
	tem = getUrlParam('jg');
	if (tem) { param_ += '&jg=' + tem;}
	tem = getUrlParam('ks');
	if (tem) { param_ += '&ks=' + tem;}
	tem = getUrlParam('js');
	if (tem) { param_ += '&js=' + tem;}
	tem = getUrlParam('class');
	if (tem) { param_ += '&class=' + tem;}
	page++;
	gerUrl += param_ +'&page='+page;
	loaded=1;
	var index = layer.load(2, {time: 30*1000});
	$.post(gerUrl,function(da){
		layer.close(index);
		//console.log(da);return;
		if(da.length<=0){
			$('#enddiv').show();		
		}else{
			$('#enddiv').hide();
			loaded=0;
			$('#shop_ul').append(da);	
		}
	});	
}
function myscroll(){
	if(loaded!=1){
		var c=document.documentElement.clientHeight || document.body.clientHeight;
		var t=$(window).scrollTop();
		//console.log((t+c)+'---'+$('.main').height());
		if(t+c >= ($('.main').height()+50)){ 
			loaded=1;
			window.setTimeout("get_infos()",300);
		}
	}

}
</script>
<script>
var url = window.location.href;
function listorder(obj, id){
	var order = $(obj).attr('data-order');
	var orderVal = $(obj).attr('data-index');
	var reg = new RegExp('&xl=[0-9A-Za-z]*');
	url = url.replace(reg, '');
	var reg = new RegExp('&jg=[0-9A-Za-z]*');
	url = url.replace(reg, '');
	orderVal = orderVal == 1 ? 2 : 1;
	if (order != 'all') {
		url += '&'+order+'='+orderVal;
	} else {
		var reg = new RegExp('&ks=[0-9A-Za-z]*');
		url = url.replace(reg, '');
		var reg = new RegExp('&js=[0-9A-Za-z]*');
		url = url.replace(reg, '');
		var reg = new RegExp('&class=[0-9A-Za-z]*');
		url = url.replace(reg, '');
	}
	$(obj).attr('data-index',orderVal);
	window.history.pushState({status:'watting'},'',url);
	get_infos('reset');
}
</script>