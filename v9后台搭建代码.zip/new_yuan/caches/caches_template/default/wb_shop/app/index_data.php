<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
<li>
	<?php $goodsurl = 'index.php?m=wb_shop&c=index&a=show&catid='.$r['catid'].'&id='.$r['id'];?>
    <div class="hot_sell_box" onclick="url_header('<?php echo $goodsurl;?>')">
            <div class="hot_sell_pic">
                <img src="<?php echo $r['thumb'];?>">
                <div class="hot_sell_flag"><span><?php echo floor(($r['jiage']/$r['yuanjiage'])*10);?>折</span></div>
            </div>
        <u><?php echo $r['title'];?></u>
        <div class="hot_sell_box_">
            <div class="hot_sell_box_l fl">
                <p style="<?php if(floatval($r['yuanjiage'])<=0) { ?>height:25px;line-height:25px;<?php } ?>">¥<span><?php echo number_format($r['jiage'],2);?></span></p>
                <?php if(floatval($r['yuanjiage'])>0) { ?><p>¥<span><del><?php echo number_format($r['yuanjiage'],2);?></del></span></p><?php } ?>
            </div>
            <div class="hot_sell_box_r fr">
                <span class="hot_buy">立即抢购</span>
            </div>
        </div>
    </div>
</li>
<?php $n++;}unset($n); ?>