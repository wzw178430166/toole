<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title = '我的购物车';?>
<?php include template('wb_shop','header_common2'); ?>
<style>
.goodsrmids{opacity:0;height:0;position:absolute}.width{width:100%!important}.scbr_link{text-align:center;font-size:14px;color:#7a7a7a;background:url(statics/wb_shop/images/goodsCart_close.png) no-repeat center center;background-size:auto 18px!important;width:34px;height:30px;display:block;line-height:27px}.sl_img_box{margin-top:0;width:24%}.sl_list_box2 .sl_right2{width:63%}.dpInfoTitle{height:35px;line-height:35px;padding:0 10px;font-size:.8rem;color:#333;background-color:#fff;padding-left:0}.cartGoods{padding:0}.cartGoodsItem{width:100%;overflow:hidden;padding:5px 0;font-size:.7rem;color:#333}.goodsItemStatus{width:12%;float:left}.goodsItemImg{width:26%;float:left}.goodsItemImg img{width:90%}.goodsItemInfo{width:62%;float:left}.ItemInfoTitle{height:30px; line-height:15px;overflow:hidden}.ItemInfoPrice{font-size:.8rem;color:#ff620a; /*float:left;*/ height:20px; line-height:20px;}.dpIcon{display:block;width:20px;height:100%;float:left;margin-right:5px;background:url(statics/wb_shop/app/images/dp_icon.png) no-repeat center;background-size:100%}.dpEditBtn{font-size:.7rem;padding-left:10px;height:15px;line-height:15px;margin-top:10px;border-left:1px solid #d3d3d3;color:#333; display:none;}.goodsBox{width:95%}.goodsEdit{display:block;width:100%;overflow:hidden}.editboxLeft{width:75%;overflow:hidden;float:left}.countEdit{width:37%;height:20px;float: left;border: 1px solid #D6D6D6;border-radius: 3px;}.editBtn{width:28%;height:20px}.editBtn,.editInput{display:block;float:left}.editInput{width:44%;height:100%;border-left: 1px solid #D6D6D6;margin-left: -1px;border-right: 1px solid #D6D6D6;margin-right: -1px;}.editInput input{width:100%;height:100%;border:0;text-align:center}.editboxRight{width:25%;height:70px;line-height:70px;float:left;text-align:center;background-color:#d92b2b;color:#fff}.sub_{background:url(statics/wb_shop/app/images/sub_btn.png) no-repeat center;background-size:35%}.add_{background:url(statics/wb_shop/app/images/add_btn.png) no-repeat center;background-size:35%}.dpInfoTitle a,.goodsItemStatus span{display:block;width:100%;height:4.7rem;background:url(statics/wb_shop/images/cdg.png) center no-repeat;background-size:45%}.dpInfoTitle a{width:12%;height:35px;float:left}.dpInfoTitle a.sel,.goodsItemStatus span.sel{background:url(statics/wb_shop/images/cdged.png) center no-repeat;background-size:45%}.goodsItemStatus input{display:none;}.del-btn { float:right; width:20px; height:20px; background:url('statics/wb_shop/images/del.png') no-repeat center; background-size:20px;}
.buyCondition {
	position: relative;
    /*top: -25px;*/
    font-size: 0.7rem;
    text-align: center;
    width: 100%;
    height: 25px;
    line-height: 25px;
    color: #fff;
	display:none;
}
.opc-box {
	width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    background-color: #333;
    opacity: 0.7;
    z-index: -1;	
}
</style>
<body style="background:#f0f2f5;">
<!--public header start--> 
<?php $title='购物车'?>
<div class="header">
  <div class="header_box"> <a href="javascript:;" onClick="goback();" class="header_fanhui"></a>
    <h2 class="header_title">购物车</h2>
  </div>
</div>
<!--public header end-->
<div style="height:53px"></div>
<img src="statics/wb_shop/images/cdged.png" style="height:0;width:0;"/>
<div class="main">
<div class="buyCondition" id="buyCondition"><div class="opc-box"></div>国家海关规定多件商品的总价不得超过1000元,请您分多次购买</div>
<?php $forward_ = urlencode('index.php?m=wb_shop&c=index&a=goodscart');?>
<form id="myform" action="index.php?m=wb_shop&a=confim&forward=<?php echo $forward_;?>" method="post">
  <input type="hidden" id="forward" value="<?php echo $forward_;?>">
  <?php if(empty($goodscart_)) { ?> <img class="wddimg" src="<?php echo SPATH;?>wb_shop/images/gwcwu.png" style="width: 60%;  margin: 10px auto;  display: block;"/> <a href="index.php?m=member&a=favorite&plat=<?php echo $_GET['plat'];?>"  style="text-align: center;margin-left:7%"class="ce_link2">看收藏</a> <a href="index.php?m=wb_shop&plat=<?php echo $_GET['plat'];?>" style="text-align: center;"class="ce_link2">去逛逛</a> <?php } else { ?>
    <!--goodscart start-->
    <?php $n=1; if(is_array($goodscart)) foreach($goodscart AS $k => $r) { ?>
    <?php //$cart_key = explode('_',$k);?>
    <div class="dpInfo" id="dp_<?php echo $k;?>" data-goods="<?php echo count($r);?>">
    	<div class="dpInfoTitle">
        	<a href="javascript:;" id="dpAllSel_<?php echo $k;?>" onClick="selcart(this,'dp',<?php echo $k;?>)" data-sel="0"></a>
        	<em class="dpIcon"></em>
        	<font class="fl"><?php echo $dp_info[$k]['name'];?></font>
            <span class="dpEditBtn fr" onClick="changeEdit(this,'<?php echo $k;?>')" data-switch="off">编辑</span>
        </div>
        <div class="cartGoods">
        	<?php $n=1;if(is_array($r)) foreach($r AS $rr) { ?>
        	<div class="cartGoodsItem">
            	<div class="goodsItemStatus" onClick="selcart(this,'single',<?php echo $k;?>)" data-sel="0">
                	<input type="checkbox" name="goodsrmids[]" value="<?php echo $rr['productcatid'];?>_<?php echo $rr['productid'];?>_<?php echo $rr['cid'];?>" data-cid="<?php echo $rr['cid'];?>">
                    <span></span>
                </div>
                <div class="goodsItemImg"><img src="<?php echo $proInfo[$rr['productid']]['thumb'];?>"></div>
                <div class="goodsItemInfo">
                	<div class="goodsBox goodsItemInfoBox_<?php echo $k;?>">
                    	<div class="ItemInfoTitle"><?php echo $proInfo[$rr['productid']]['title'];?></div>
                        <div class="ItemInfoAttr">
                            <?php $n=1;if(is_array($goodsAttr[$rr['cid']])) foreach($goodsAttr[$rr['cid']] AS $att) { ?>
                            <span><?php echo $attr[$att]['attShow'];?></span><span style="float: right; display:none;">x<em id="cAttrCountText_<?php echo $rr['cid'];?>"><?php echo $attrCount[$rr['cid']][$att];?></em></span>
                            <?php $proCount = $attrCount[$rr['cid']][$att];$attid=$att;?>
                            <?php $n++;}unset($n); ?>
                        </div>
                        <?php $cJiage = $rr['buyWay'] == 'retail'?$proInfo[$rr['productid']]['retail_price']:$proInfo[$rr['productid']]['jiage'];?>
                        <div class="ItemInfoPrice" id="price_<?php echo $rr['cid'];?>" data-val="<?php echo $cJiage;?>">￥<?php echo number_format($cJiage,2);?></div>
                        <div class="countEdit">
                            <a class="editBtn sub_" onClick="editCount('sub',<?php echo $rr['cid'];?>)"></a>
                            <span class="editInput"><input type="text" name="attribute[<?php echo $rr['productcatid'];?>_<?php echo $rr['productid'];?>][<?php echo $attid;?>]" value="<?php echo $proCount;?>" id="cAttrCountVal_<?php echo $rr['cid'];?>" data-cookieN="<?php echo $rr['productid'];?>_<?php echo $attid;?>" data-pro="<?php echo $rr['productcatid'];?>_<?php echo $rr['productid'];?>" data-attid="<?php echo $attid;?>" onChange="enterChangeCount(<?php echo $rr['cid'];?>)"></span>
                            <a class="editBtn add_" onClick="editCount('add',<?php echo $rr['cid'];?>)"></a>
                        </div>
                        <div class="del-btn" onClick="delCart('<?php echo $rr['cid'];?>')"></div>
                    </div>
                    <!--<div class="goodsEdit goodsItemEditBox_<?php echo $k;?>" style="display:none;">
                    	<div class="editboxLeft">
                        	<div class="countEdit">
                            	<a class="editBtn sub_" onClick="editCount('sub',<?php echo $rr['cid'];?>)"></a>
                                <span class="editInput"><input type="text" name="attribute[<?php echo $rr['productcatid'];?>_<?php echo $rr['productid'];?>][<?php echo $attid;?>]" value="<?php echo $proCount;?>" id="cAttrCountVal_<?php echo $rr['cid'];?>" data-cookieN="<?php echo $rr['productid'];?>_<?php echo $attid;?>" data-pro="<?php echo $rr['productcatid'];?>_<?php echo $rr['productid'];?>" data-attid="<?php echo $attid;?>"></span>
                            	<a class="editBtn add_" onClick="editCount('add',<?php echo $rr['cid'];?>)"></a>
                            </div>
                        </div>
                        <div class="editboxRight" onClick="delCart('<?php echo $rr['cid'];?>')">删除</div>
                    </div>-->
                </div>
            </div>
            <?php $n++;}unset($n); ?>
        </div>
    </div>
    <?php $n++;}unset($n); ?>
    <!--goodscart end-->
    <div class="sc_bottom">
      <div class="sc_bottom_box">
        <div onClick="allSelect(this)" id="allSelect" data-sel="0" class="rc_d2_ck rc_d2_ck2 fl" style=" display:none;">
          <div class="cdg" style="height:50px;">
            <input type="radio" id="da_qx"  />
          </div>
          全选 </div>
        <div class="scbleft fl">
          <p class="p4"><span>合计：</span><span class="money" id="z_jia" data-val="0">0.00</span></p>
          <p class="p3"><span>&nbsp;&nbsp;&nbsp;数量：</span><span id="z_sl" data-val="0">0</span>件<font>( 不含运费和关税 )</font></p>
        </div>
        <div class="scbright fr">
          <!--<input style=" border:none" class="scbr_btn"  type="button" onClick="send_form('buy')" value="去结算"/>-->
          <input style=" border:none; background-color:#C3C3C3;" class="scbr_btn"  type="button" onClick="send_form('gpay')" value="去结算"/>
        </div>
        <?php if($_GET['me']) { ?>
        <div class="scbright fr">
          <input style=" border:none;background-color: #FF7524;" class="scbr_btn"  type="button" onClick="send_form('cd')" value="去凑单"/>
        </div>
        <?php } ?>
      </div>
    </div>
    <?php } ?> 
</form>


 <?php if(1>3 && $_GET['me']) { ?>
  <a onClick="showwlj()" style="width: 30px; height: 30px; display: block; border: 1px #FF0004 solid">show</a>
  <?php } ?>


</div>
<div style="height:60px"></div>


<?php include template('wb_shop','footer_common'); ?>
</body>
</html>
<script>
var buyLimitTips = '国家海关规定单笔交易同种商品不得5件以上，请您多次购买';
var buyCondition = 0;
var goodsItem = $('.cartGoodsItem');
var goodsCount=goodsItem.length;
var siteid = "<?php echo get_siteid();?>";
//输入修改数量
function enterChangeCount(cid){
	var num = Number($('#cAttrCountVal_'+cid).val());
	if (siteid == 1 && num>5) {
		tipsBox(buyLimitTips);
		num=5;
	} 
	var result = num>0?num:1;
	$('#cAttrCountVal_'+cid).attr('value',result);
	checkMoneyCount();
}
function send_form (ac) {
	if (buyCondition == 0) {return false;}
	var is_sel = false;
	//var goodsrmids = $('.goodsrmids');
	var goodsrmids = $('input[name="goodsrmids[]"]');
	//console.log(goodsrmids);return false;
	for (var i=0,len=$(goodsrmids).length;i<len;i++) {
		
		if ($(goodsrmids[i]).is(':checked')) {
			is_sel = true;
		} else {
			var gcid = $(goodsrmids[i]).attr('data-cid');
			$('#cAttrCountVal_'+gcid).removeAttr('name');
			$(goodsrmids[i]).removeAttr('name');
		}
		//console.log($(goodsrmids[i]).is(':checked'));
	}
	//return false;
	if (!is_sel) {
		layer.msg('请选择商品!');
		return false;
	}
	if (ac != 'buy') {var runCd = ac == 'cd'?'&runCd=1':'';$('#myform').attr('action','index.php?m=wb_shop&c=index&a=listOfGoods'+runCd+'&forward='+$('#forward').val())}
	$('#myform').submit();
	//return true;
}

function changeEdit (obj,sk) {
	$('.goodsItemInfoBox_'+sk).hide();
	$('.goodsItemEditBox_'+sk).hide();
	if ($(obj).attr('data-switch') == 'off') {
		$('.goodsItemEditBox_'+sk).show();
	} else {
		$('.goodsItemInfoBox_'+sk).show();
	}
	$(obj).attr('data-switch',$(obj).attr('data-switch') == 'off'?'on':'off');
	$(obj).text($(obj).attr('data-switch') == 'off'?'编辑':'完成');
}
function selcart(obj,type,dpid){
	var dpId = dpid;
	if (type == 'single') {
		if ($(obj).attr('data-sel') == 0) {
			$(obj).find('span').addClass('sel');
			$(obj).find('input').attr('checked','checked');
		} else {
			$(obj).find('span').removeClass('sel');
			$(obj).find('input').attr('checked',false);
			//$('#allSelect').attr('data-sel',0);
		}
		$(obj).attr('data-sel',$(obj).attr('data-sel') == 0?1:0);
		
	} else {
		var dpSel = $(obj).attr('data-sel');
		if (dpSel == 0) {
			$('#dp_'+dpid).find('input[name="goodsrmids[]"]').attr('checked','checked');
			$('#dp_'+dpid+' .goodsItemStatus').find('span').addClass('sel');
			dpSel = 1;
		} else {
			$('#dp_'+dpid).find('input[name="goodsrmids[]"]').attr('checked',false);
			$('#dp_'+dpid+' .goodsItemStatus').find('span').removeClass('sel');
			dpSel = 0;
		}
		$('#dp_'+dpid+' .goodsItemStatus').attr('data-sel','data-sel',dpSel);
	}
	checkMoneyCount();//
	checkSelectStyle(dpId);
}

function checkSelectStyle(dpid){
	var allSel=allDpSel= 0;
	var selGoodds = $('input[name="goodsrmids[]"]:checked');//selectAllGoods
	var selGoodsLength = selGoodds.length;
	if (dpid > 0) {
		var dpGoodsCount = $('#dp_'+dpid).attr('data-goods');
		var selDpGoodds = $('#dp_'+dpid).find('input[name="goodsrmids[]"]:checked');//selectAllGoods
		var selDpGoodsLength = selDpGoodds.length;
		if (dpGoodsCount>selGoodsLength) {//unDpselect
			allDpSel = 0;
			$('#dpAllSel_'+dpid).removeClass('sel');
		} else {
			allDpSel = 1;
			$('#dpAllSel_'+dpid).addClass('sel');
		}
		$('#dpAllSel_'+dpid).attr('data-sel',allDpSel);
	}
	
	if (goodsCount>selGoodsLength) {//unallselect
		allSel = 0;
		$('#allSelect .cdg').removeClass('cdged');
	} else {
		allSel = 1;
		$('#allSelect .cdg').addClass('cdged');
	}
	$('#allSelect').attr('data-sel',allSel);
}

function allSelect(obj){
	if ($(obj).attr('data-sel') == 0) {
		$('.dpInfoTitle a').addClass('sel');
		$('.goodsItemStatus span').addClass('sel');
		$('.goodsItemStatus input').attr('checked','checked');
		$(obj).find('.cdg').addClass('cdged');
	} else {
		$('.dpInfoTitle a').removeClass('sel');
		$('.goodsItemStatus span').removeClass('sel');
		$('.goodsItemStatus input').attr('checked',false);
		$(obj).find('.cdg').removeClass('cdged');
	}
	$('.dpInfoTitle a').attr('data-sel',$(obj).attr('data-sel') == 0?1:0);
	$('.goodsItemStatus').attr('data-sel',$(obj).attr('data-sel') == 0?1:0);
	$(obj).attr('data-sel',$(obj).attr('data-sel') == 0?1:0);
	checkMoneyCount();
}
//sum Money and count
function checkMoneyCount(){
	var money = count = 0;
	var goodsrmids = $('input[name="goodsrmids[]"]:checked');
	if (goodsrmids.length > 0) {
		goodsrmids.each(function(i) {
			var goodsrmid = $(goodsrmids[i]).attr('data-cid');
			var itemCount = Number($('#cAttrCountVal_'+goodsrmid).val());
			count += itemCount;
			money += Number($('#price_'+goodsrmid).attr('data-val'))*itemCount;
		});
	}
	money = money.toFixed(2);
	$('#z_sl').text(count);
	$('#z_jia').text(money);
	$('#buyCondition').hide();
	if (money>0) {
		buyCondition = 1;
		if (1>3&&siteid == 1 && money > 1000) {$('#buyCondition').show();buyCondition=0;}
		if (siteid==2 && money<1000) {tipsBox('单笔交易不得少于1000元');buyCondition=0;}
		if (buyCondition==1) {$('.scbr_btn').css({'backgroundColor':'#D92B2B'});}else{$('.scbr_btn').css({'backgroundColor':'#C3C3C3'});}
	} else {
		buyCondition = 0;
		$('.scbr_btn').css({'backgroundColor':'#C3C3C3'});
	}
}

function editCount(ac,cid){
	var count = $('#cAttrCountVal_'+cid).val();
	var auth = getcookie('auth');
	if (ac == 'sub') {
		if (count > 1) {
			count--;
		}
	} else {
		count++;
		if (siteid == 1 && count >5) {
			tipsBox(buyLimitTips);
			return;
		}
	}
	$('#cAttrCountVal_'+cid).attr('value',count);
	$('#cAttrCountText_'+cid).text(count);
	
	if (!auth) {
		var cartNum = $('#cAttrCountVal_'+cid).attr('data-cookieN');
		var pro = $('#cAttrCountVal_'+cid).attr('data-pro');
		var attId = $('#cAttrCountVal_'+cid).attr('data-attid');
		cartCookieEdit(cartNum,pro,attId,count);
	}
	checkMoneyCount();
}
function delCart(rmid){
	layer.confirm('是否删除该产品?',{btn:["删除",'取消']},function(){
		if (!rmid) {
			layer.msg('参数错误!');
			return;	
		}
		var auth = getcookie('auth');
		if (!auth) {
			var cartJson = getcookie('cart');
			var cartCname = $('#cAttrCountVal_'+rmid).attr('data-cookieN');
			cartJson = JSON.parse(cartJson);
			if (cartCname) {
				delete cartJson[cartCname];
				setcookie('cart',JSON.stringify(cartJson));
				layer.msg('删除成功',{time:1500});
				setTimeout(function(){
					window.location.reload();
				},1500);
			} else {
				layer.msg('删除失败');
			}
			//console.log(cartJson[cartCname]);
			//delete cartJson[rmid];
		} else {
			$.get('index.php?m=wb_shop&c=index&a=del_cart&rmids='+rmid,function(data){
				if (data.status == 1) {
					layer.msg('删除成功',{time:1500});
					setTimeout(function(){
						window.location.reload();
					},1500);
				} else {
					layer.msg('删除失败',{time:1500});
				}
			},'json');
		}
		
	});
}
function cartCookieEdit(cartAttrN,pro,attid,num){
	var cartJson = getcookie('cart');
	cartJson = JSON.parse(cartJson);
	var newJosnData = '{"'+pro+'":{"'+attid+'":"'+num+'"}}';
	newJosnData = JSON.parse(newJosnData);
	cartJson[cartAttrN].attribute = newJosnData;
	//console.log(cartJson);return;
	setcookie('cart',JSON.stringify(cartJson));
}
</script>