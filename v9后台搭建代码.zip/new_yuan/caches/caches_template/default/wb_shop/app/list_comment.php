<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $n=1;if(is_array($comments)) foreach($comments AS $r) { ?>
<div class="comment_item <?php if($n == count($comments)) { ?>no_border_bottom<?php } ?>">
  <div class="comment-user">
  	<span class="comment_header_img"><img src="<?php echo SPATH;?>images/icon/color/header_icon.png"></span>
    <span class="comment_name"><?php echo substr_replace($r['username'],'****',3,4);?></span>
  </div>
  <div class="comment_item_content"><?php echo $r['content'];?></div>
  <div class="comment_time"><span class="fl"><?php echo date('Y-m-d', $r['creat_at']);?></span></div>
</div>
<?php $n++;}unset($n); ?>