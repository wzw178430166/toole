<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php if($data) { ?>
<?php if($userid) { ?>
    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=de1ada532d42c0d6caf9b1d81997bce3&sql=SELECT+%2A+FROM+%60drcms_favorite%60+WHERE+userid%3D%24userid&return=favorite\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_favorite` WHERE userid=$userid LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$favorite = $a;unset($a);?>
    <?php $n=1;if(is_array($favorite)) foreach($favorite AS $favorite_r) { ?>
      <?php $favorite_id[] = $favorite_r['pid']; ?>
    <?php $n++;}unset($n); ?>
<?php } ?>
<?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
<li class="sl_li">
<div class="sl_list_box">
  <div class="sl_img_box sl_img_box2 fl"> 
  <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>" class="js_cell" data-id="show"> 
    <img src="<?php echo $r['thumb'];?>" width="100%" class="slimg"/>
  </a> 
  <?php if($_GET['re']=='1') { ?> <i class="hot"></i> 
  <?php } elseif ($_GET['zhe']=='1') { ?> <i class="zhe"></i> 
  <?php } elseif ($_GET['new']) { ?> <i class="new"></i> 
  <?php } elseif ($_GET['cu']) { ?> <i class="cu"></i> 
  <?php } ?> 
  </div>
  <div class="sl_right fr">
    <a href="index.php?m=wb_shop&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>">
        <div class="slr_title"><?php echo $r['title'];?></div>
    </a>
    <div class="slr_oth">
      <?php if($r['yuanjiage']) { ?>
      <div class="slr_price"style=" float:none; font-size:14px;color:#C0748D" >
        <span  >&nbsp;原价格 : </span>
        <span><del>￥<?php echo $r['yuanjiage'];?><del></span>
      </div>
      <?php } ?>
      <div class="slr_price" > 
        <?php if(floatval($r['jiage'])==0) { ?> <span style="font-size:13px;">暂无价格</span>
        <?php } else { ?> <span>￥</span><span><?php echo number_format($r['jiage'],'2');?></span>
        <?php } ?> </div>
      <div  class="<?php if(in_array($r['id'],$favorite_id)) { ?>sbx_colled <?php } ?>   fr" catid="<?php echo $r['catid'];?>" id="<?php echo $r['id'];?>" onClick="add_favorite('<?php echo $r['title'];?>','<?php echo $r['catid'];?>','<?php echo $r['id'];?>',this)" style="width: 22px;text-decoration: none;color: #565555;float: right;line-height: 20px;font-size: 14px;margin: 4% auto;height: 20px;display: block;"  > <?php if(!in_array($r['id'],$favorite_id)) { ?> <img src="<?php echo SPATH;?>wb_shop/images/gz_off.png" width="22px" style="    margin-top: 3px;"> <?php } ?> </div>
    </div>
  </div>
</div>
</li>
<?php $n++;}unset($n); ?>
<?php } ?>