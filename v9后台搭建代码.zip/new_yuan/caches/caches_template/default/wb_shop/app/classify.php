<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title=$titlename= '商品分类';?>
<?php include template('wb_shop','header_common2'); ?>
<!--新添加css--->
<link rel="stylesheet" href="statics/wb_shop/css/app_shop_lists.css" type="text/css">
<style>
body { background-color:#fff;}
.sousuo { background-color:#F3F3F3;}
.sousuo_order .order_on { background-color:#F3F3F3;}
.order_content { display:none; width:71%;}
.classlfy dt { font-size:0.8rem;}
.classlfy a { color:#333;}
.classlfy dd { padding-top:5px;}
.classlfy dd p { width:100%; overflow:hidden; padding:0;}
.classlfy dd p img { width:95%;}
.classlfy dd span {
    font-size: 0.8rem;
    height: 35px;
    margin-top: 3px;
    line-height: 17px;
}
</style>
</head>
<body>

<?php include template('wb_shop','header'); ?>
	<div class="shop">
		<div class="sousuo">
        <form action="" method="get">
        	<input type="hidden" name="m" value="<?php echo $module;?>">
            <input type="hidden" name="c" value="index">
            <input type="hidden" name="a" value="lists">
            <input type="hidden" name="catid" value="6">
			<div><input type="search" name="k" placeholder="输入关键字查找"/></div>
        </form>
		</div>
		<div class="sousuo_content">
			<ul class="sousuo_order" id="cate_ul">
				<li class="order_on" data-catid="0">全部商品</li>
                <?php $n=1;if(is_array($categoryinfo)) foreach($categoryinfo AS $r) { ?>
				<li data-catid="<?php echo $r['catid'];?>"><?php echo $r['catname'];?></li>
                <?php $n++;}unset($n); ?>
			</ul>
			<div class="order_content" id="shop_0" style="display:block;">
				<!--<div><img src="statics/wb_shop/images/tp25.png" class="img" /></div>-->
				<dl class="classlfy">
					<dt>
						全部商品
					</dt>
                    <?php $owhere = $siteid == 1?'1':'`is_auth`=1';?>
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=92e5d9ceff354278fd0fba945b353d1f&action=lists&catid=%24catid&where=%24owhere&num=100&return=all_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$all_data = $content_tag->lists(array('catid'=>$catid,'where'=>$owhere,'num'=>'100','limit'=>'100',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <?php $nn=1;?>
                    <?php $n=1;if(is_array($all_data)) foreach($all_data AS $r) { ?>
                    <a href="index.php?m=<?php echo $module;?>&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>">
					<dd class="<?php if($nn%2 == 0) { ?>fr<?php } else { ?>fl<?php } ?>">
						<p><img src="<?php echo $r['thumb'];?>"/></p>
						<span><?php echo $r['title'];?></span>
					</dd>
                    </a>
                    <?php $nn++;?>
                    <?php $n++;}unset($n); ?>
				</dl>
                
				
			</div>
            <?php $n=1;if(is_array($categoryinfo)) foreach($categoryinfo AS $r) { ?>
			<div class="order_content" id="shop_<?php echo $r['catid'];?>">
				<dl class="classlfy">
					<dt>
						<?php echo $r['catname'];?>
					</dt>
                    <?php 
                    	$owhere = '`classify` = '.$r['catid'];
                        $siteid == 2 && $owhere .= ' AND `is_auth`=1';
                    ?>
                    
                    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=a3aa7f62d9a6f1414728cdb0be88e17e&action=lists&catid=%24catid&owhere=%24owhere&num=100&return=data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$data = $content_tag->lists(array('catid'=>$catid,'owhere'=>$owhere,'num'=>'100','limit'=>'100',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                    <?php $nn=1;?>
                    <?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
                    <a href="index.php?m=<?php echo $module;?>&c=index&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>">
					<dd class="<?php if($nn%2 == 0) { ?>fr<?php } else { ?>fl<?php } ?>">
						<p><img src="<?php echo $r['thumb'];?>"/></p>
						<span><?php echo $r['title'];?></span>
					</dd>
                    </a>
                    <?php $nn++;?>
                    <?php $n++;}unset($n); ?>
					<!--<dd class="center_dd">
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
					<dd>
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>-->
				</dl>
				<!--<dl class="classlfy">
					<dt>
						数码通讯
					</dt>
					<dd>
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
					<dd class="center_dd">
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
					<dd>
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
				</dl>
				<dl class="classlfy">
					<dt>
						厨卫生活
					</dt>
					<dd>
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
					<dd class="center_dd">
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
					<dd>
						<p><img src="statics/jhc/app/images/tp26.png" alt="" /></p>
						<span>平板电脑2</span>
					</dd>
				</dl>-->
			</div>
            <?php $n++;}unset($n); ?>
			
		</div>
	</div>
<?php include template('wb_shop','footer_common'); ?>
</body>
<script>
$(function(){
	var cate_ul_item = $('#cate_ul li');
	var classlfyPWidth = $('.classlfy dd p').width();
	var classlfyImgWidth = $('.classlfy dd p img').width();
	$('.classlfy dd p').css({"height":classlfyPWidth});
	$('.classlfy dd p img').css({"height":classlfyImgWidth});
	$(cate_ul_item).each(function(i) {
		$(cate_ul_item[i]).click(function(){
			$(cate_ul_item).removeClass('order_on');
			$(this).addClass('order_on');
			var dataCatid = $(this).attr('data-catid');
			$('.order_content').hide();
			$('#shop_'+dataCatid).show();
		});
	});
	$('.classlfy').css({"height":$(window).height()-45});
	//console.log(classlfyImg);
	/*classlfyImg.each(function(i) {
		var imgWidth = $(this).width();
		console.log(imgWidth);
		$(this).css({'height':imgWidth+'px'});
		$('.classlfy dd p img').css({'height':imgWidth+'px'});
		//console.log($(this));
		//$(this).parent().css({'height':$(this).parent().width()+'px'});
		//if (imgWidth != imgHeight) {
			//$(this).css({'marginTop':'-10px'});
		//}
	});*/
});
</script>
</html>