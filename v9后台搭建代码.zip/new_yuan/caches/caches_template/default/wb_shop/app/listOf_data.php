<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $n=1;if(is_array($data)) foreach($data AS $r) { ?>
<?php $r['weight'] = str_replace(array('g','ml'),'',$r['weight']);?>
<li>
  <section class="aui-crl"><span class="circle" style="display: none;"></span><img src="<?php echo $r['thumb'];?>"></section>
  <div style=" padding-left: 10px;">
    <h2><?php echo $r['title'];?></h2>
    <p class="aui-o"> 重量:<?php echo $r['weight'];?> </p>
    <p class="money">
      <em class="aui-redd">￥<?php if($siteid==1) { ?><?php echo $r['jiage'];?><?php } else { ?><?php echo $r['retail_price'];?><?php } ?></em>
      <input class="add" type="button" value="">
      <input class="num cbNumber" type="number" name="attribute[<?php echo $r['catid'];?>_<?php echo $r['id'];?>][<?php echo $cdAttribute[$r['id']]['id'];?>]" value="0" data-jiage="<?php echo $r['jiage'];?>" data-g="<?php echo $r['weight'];?>" data-taxesClass="<?php echo $r['taxes_class'];?>" readonly>
      <input class="del" type="button" value="">
    </p>
  </div>
</li>
<?php $n++;}unset($n); ?>