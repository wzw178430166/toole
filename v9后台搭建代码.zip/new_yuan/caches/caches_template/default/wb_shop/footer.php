<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php if($common_member['dz_'] && in_array($_GET['plat'],array(537))) { ?>
<?php $footer_ = 'tmp_info_pc/1/footer_'.intval($_GET['plat']);?>
<?php include template('wb_shop', $footer_, 'first'); ?>
<?php } else { ?>
<div class="footer">
  <div class="footer-copyright">
    <div class="container" style=" position:relative;">
      <p class="footer-nav">
        <a href="javascript:;" >免责条款</a>
        <a href="javascript:;" >隐私保护</a>
        <a href="javascript:;" >咨询热点</a>
        <a href="javascript:;" >联系我们</a>
        <a href="javascript:;" >公司简介</a>
        <a href="javascript:;" >批发方案</a>
        <a href="javascript:;" >配送方式</a>
      </p>
      
      <span style="color:#909090;"> 联系电话: <?php echo $this->Company['tel'];?> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $this->Company['mp'];?> </span>
      
      <a href="http://www.miitbeian.gov.cn/" target="_blank"><p class="footer-link">
      	粤ICP备16024208号
        <!--<a href="<?php echo siteurl(1);?>" target="_blank" title="买否网">唐剑网络</a>
        | <a href="<?php echo siteurl(1);?>" target="_blank" title="免费开独立网店">免费开独立网店</a>-->
      </p>
      </a>
      
      <!--二维码-->
      <div class="qrcode" mlink="<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $plat;?>">
          <canvas width="120" height="120"></canvas>
      </div>
      <input type="hidden" id="link1" readonly  class="input-text" value="<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $plat;?>">
      <!--二维码-->
    </div>
    
  </div>
</div>

<div class="QQbox" id="divQQbox" style="width: 170px; ">
  <div class="Qlist" id="divOnline" onmouseout="hideMsgBox(event);" style="display: none; " onmouseover="OnlineOver();">
    <div class="t"></div>
    <div class="infobox">我们营业的时间<br>
      9:00 - 18:00</div>
    <div class="con">
    <?php 
    	$default_db = pc_base::load_model('default_model');
        $default_db->load('kefu');
        $kefu_info = $default_db->select(array('userid'=>intval($_GET['plat']), 'type'=>'qq'));
    ?>
      <ul>
      	<?php $n=1;if(is_array($kefu_info)) foreach($kefu_info AS $r) { ?>
        <li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $r['type_item'];?>&site=qq&menu=yes" target="_blank"><img src="http://wpa.qq.com/pa?p=1:123456:4" height="16" border="0" alt="<?php echo $r['type'];?>" /> <?php echo $r['type_item'];?></a>
        </li>
        <?php $n++;}unset($n); ?>
       <!-- <li><a href="http://wpa.qq.com/msgrd?v=3&uin=3108232830&site=qq&menu=yes" target="_blank"><img src="http://wpa.qq.com/pa?p=1:234567:4" height="16" border="0" alt="QQ" /> 3108232830</a>
        </li>-->
       
        <li> 服务热线: <?php echo $this->Company['tel']?></li>
      </ul>
    </div>
    <div class="b"></div>
  </div>
  <div id="divMenu" onmouseover="OnlineOver();" style="display: block; "><img src="statics/wb_shop/tmp_info_pc/images/qq_1.gif" class="press" alt="在线咨询"></div>
</div>
<script type="text/javascript" src="<?php echo JS_PATH;?>ex/jquery.qrcode.js"></script>
<script>
document.getElementById('link1').select();
var qrcodes = $(".qrcode");
for(var i=0,len=$(qrcodes).length;i<len;i++){
$(qrcodes[i]).qrcode({ 
    render: "image", //table方式 
     size: 180,
    text: $(qrcodes[i]).attr('mlink')
}); 
}
</script>
<script type="text/javascript">
//<![CDATA[
var tips; var theTop = 120/*这是默认高度,越大越往下*/; var old = theTop;
function initFloatTips() {
tips = document.getElementById('divQQbox');
moveTips();
};
function moveTips() {
var tt=50;
if (window.innerHeight) {
pos = window.pageYOffset
}
else if (document.documentElement && document.documentElement.scrollTop) {
pos = document.documentElement.scrollTop
}
else if (document.body) {
pos = document.body.scrollTop;
}
pos=pos-tips.offsetTop+theTop;
pos=tips.offsetTop+pos/10;
if (pos < theTop) pos = theTop;
if (pos != old) {
tips.style.top = pos+"px";
tt=10;
//alert(tips.style.top);
}
old = pos;
setTimeout(moveTips,tt);
}
//!]]>
initFloatTips();
function OnlineOver(){
document.getElementById("divMenu").style.display = "none";
document.getElementById("divOnline").style.display = "block";
document.getElementById("divQQbox").style.width = "170px";
}
function OnlineOut(){
document.getElementById("divMenu").style.display = "block";
document.getElementById("divOnline").style.display = "none";
}
if(typeof(HTMLElement)!="undefined")    //给firefox定义contains()方法，ie下不起作用
{   
      HTMLElement.prototype.contains=function(obj)   
      {   
          while(obj!=null&&typeof(obj.tagName)!="undefind"){ //通过循环对比来判断是不是obj的父元素
   　　　　if(obj==this) return true;   
   　　　　obj=obj.parentNode;
   　　}   
          return false;   
      };   
}  
function hideMsgBox(theEvent){ //theEvent用来传入事件，Firefox的方式
　 if (theEvent){
　 var browser=navigator.userAgent; //取得浏览器属性
　 if (browser.indexOf("Firefox")>0){ //如果是Firefox
　　 if (document.getElementById('divOnline').contains(theEvent.relatedTarget)) { //如果是子元素
　　 return; //结束函式
} 
} 
if (browser.indexOf("MSIE")>0){ //如果是IE
if (document.getElementById('divOnline').contains(event.toElement)) { //如果是子元素
return; //结束函式
}
}
}
/*要执行的操作*/
document.getElementById("divMenu").style.display = "block";
document.getElementById("divOnline").style.display = "none";
}
</script>
<?php } ?>