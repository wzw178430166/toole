<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename = '订单确认';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="http://test.yide.cy073.com/statics/yide/css/style.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="http://test.yide.cy073.com/statics/yide/css/order_form.css"/>
<link rel="stylesheet" type="text/css" href="http://test.yide.cy073.com/statics/yide/css/order_detail.css"/>
<style>
body{ background-color:#fff;}
.main .step { 
	background: url('<?php echo SPATH;?>wb_shop/tmp_info_pc/images/long_2.jpg') no-repeat; 
}
.main .information_title { width:1200px;}
.main .information_content { min-height:auto;}
table {
    border-collapse: collapse;
    border-spacing: 0;
	margin: 0 auto;
}
.pay_box {padding: 10px 0;}
.pay_box p {
	font-size: 13px;
    font-weight: bold;
    color: #686868;
    margin-bottom: 15px;
}
.pay_box .pay_way {
	padding: 5px 23px;
    height: 20px;
    line-height: 18px;
    float: left;
    margin: 0 10px;
    color: #686868;
    border: 2px #ddd solid;
	cursor: pointer;
}
.pay_box .pay_sel_ {
	border:2px #e4393c solid;
	background:url('<?php echo SPATH;?>wb_shop/tmp_info_pc/images/selected-icon.png') no-repeat 100% 100%;
	background-size:15%;	
}
.unit-sku { overflow:hidden;}
.pay_box .no_pay {
	border: 2px #c1c1c1 dashed;
    background-color: #fff;
    opacity: 0.5;	
}
.main .settlement .settlement_text { width:auto;}
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="main">
   <div class="step">
    <a >我的购物车</a>
    <a >填写核对订单</a>
    <a class="a_on">订单提交成功</a>
  </div>
  <div class="information_title">填写并核对订单信息</div>
  <form action="index.php?m=wb_shop&a=send&plat=<?php echo $_GET['plat'];?>" method="post">
  <input type="hidden" name="orderid" value="<?php echo $orderid;?>" />
  <input type="hidden" name="rmids" value="<?php echo $rmids;?>" />
  
  <div class="information_content">
    <span class="span">收货人信息</span>
    <a href="javascript:void(0)" onClick="$('#address_edit').show();$('#adid').attr('value', '')">
    	<span class="span information_content_site">新增收货地址</span>
    </a>
    <div class="p_b" id="addcheckbox">
   
    <?php $n=1;if(is_array($address)) foreach($address AS $r) { ?>
      <?php $nn = $n?>
      <label id="address<?php echo $r['id'];?>" class="save <?php if($member->memberinfo['addressid']==$r['id']) { ?><?php $m=$r['id'];?>cur<?php } ?>" data-id="<?php echo $r['id'];?>">
        <input type="radio" value="<?php echo $r['id'];?>" name="addressid" value="<?php echo $r['id'];?>" itmeid="<?php echo $n;?>" onClick="checkaddress(this)" <?php if($member->        memberinfo['addressid']==$r['id']) { ?>checked<?php } ?> />
        
        &nbsp;&nbsp;<strong><?php echo $r['name'];?></strong>&nbsp;&nbsp;<?php echo $r['sheng'];?><?php echo $r['shi'];?><?php echo $r['qu'];?><?php echo $r['address'];?>&nbsp;&nbsp;
        <?php echo $r['contactname'];?>&nbsp;&nbsp;
        <?php if(!empty($r['phone'])) { ?>
        <?php echo preg_replace('/(1[358]{1}[0-9])[0-9]{4}([0-9]{4})/i','$1****$2',$r['phone']);?>
        <?php } elseif (!empty($r['tel'])) { ?>
        <?php echo preg_replace('/(0[0-9]{2,3}[-]?[2-9])[0-9]{3,4}([0-9]{3}[-]?[0-9]?)/i','$1****$2',$r['tel']);?>
        <?php } ?> 
        <span  id="edit<?php echo $r['id'];?>" class="edits">
        	<a href="javascript:void(0)" onClick="address_edit_show('<?php echo $r['id'];?>')">编辑</a>
        	&nbsp;
        	<a href="javascript:void(0)" onClick="address_delete('<?php echo $r['id'];?>')" id="adcancel_<?php echo $r['id'];?>">删除</a>
        	&nbsp;&nbsp;
        </span>
      </label>
      <?php $n++;}unset($n); ?> 
      </div>
    <div class="clear"></div>
  </div>

  <div style="display:none;" id="address_edit">
      <table width="852" height="302" class="table_content">
        <tr>
          <td align="center"><sup>*</sup>选择地区</td>
          <td>
          <?php echo menu_linkage(1,'region');?>
          </td>
        </tr>
        <tr>
          <td align="center"><sup>*</sup>详细地址</td>
          <td><input type="text" class="input-text" style="width:345px;height:20px;" id="address"/></td>
        </tr>
        <tr>
          <td align="center">邮政编码</td>
          <td><input type="text" class="td_width input-text" id="zipcode"/></td>
        </tr>
        <tr>
          <td align="center"><sup>*</sup>收货人</td>
          <td><input type="text" class="td_width input-text" id="contactname"/></td>
        </tr>
        <tr>
          <td align="center"><sup>*</sup>手机</td>
          <td><input type="text" class="td_width input-text" id="phone"/>
            或 固定电话
            <input type="text" class="input-text" style="width:130px;height:20px;" id="tel"/>
            <span style="color:#a9a9a9;"> 两者至少填写一项</span></td>
        </tr>

        <tr>
          <td></td>
          <td><input  value='保存地址' type="button" onClick="address_add();return false;"/>
            <input value='取消' type="button" onClick="$('#address_edit').hide();return false"/></td>
        </tr>
      </table>
      <input type="hidden" name="id" id="adid">
      <input value='1' type="hidden" name="dosubmit"/>
      </div>
  <div class="pay_box" id="pay_box">
  	<p>选择支付方式</p>
  	<input type="hidden" name="paytype" id="paytype" value="offline">
    <div class="pay_way no_pay" data-val="alipay" data-pay="<?php echo $no_apliy;?>">
        支付宝支付
    </div>
    <div class="pay_way no_pay" data-val="wechat" data-pay="<?php echo $no_apliy;?>">
        微信支付
    </div>
    <div class="pay_way pay_sel_" data-val="offline">
        线下交易
    </div>
  </div>
  <script>
  window.onload = function () {
	$('#pay_box .pay_way').each(function(i) {
        $(this).click(function () {
			if ($(this).attr('data-pay') == 0) {
				alert('商家未开通!');
			} else {
				$('#pay_box .pay_way').removeClass('pay_sel_');
				$(this).addClass('pay_sel_');
				$('#paytype').attr('value', $(this).attr('data-val'));
			}
			
		});
    });  
  };
  </script>
  <div class="receipt">
    <div class="receipt_title">商品清单</div>
    <table align="center" width="1200" class="receipt_tabletop">
      <tr >
        <td class="receipt_name"width="30%">货品</td>
        <td class="receipt_name"width="15%">单价(元)</td>
        <td class="receipt_name"width="10%">数量</td>
        <td class="receipt_name"width="15%">优惠(元)</td>
        <td class="receipt_name"width="15%">金额(元)</td>
      </tr>
    </table>
	<?php $amount=0;?>
    <?php $n=1; if(is_array($goodsinfo)) foreach($goodsinfo AS $k => $g_info) { ?>
    <div>
      <div class="zone-store fd-clr">
        <div class="fd-left left-area">
          <a target="_blank"  href="javascript:void(0)" class="store-name text-medium"><?php echo $dp_info[$k]['name'];?></a>
        </div>
      </div>
      <?php $n=1;if(is_array($g_info)) foreach($g_info AS $g) { ?>
      <input type="hidden" name="goodsid[]" value="<?php echo $g['id'];?>" />
      <div  class="zone-goods fd-clr">
        <div class="goods-image">
          <div class="img-vertical">
            <a target="_blank" href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $g['id'];?>&plat=<?php echo $_GET['plat'];?>" class="img-wrap"><img alt="<?php echo $g['title'];?>" src="<?php echo $g['thumb'];?>"></a>
          </div>
        </div>
        <div class="gouwucheinbox">
          <div class="description text-medium">
            <a title="<?php echo $g['title'];?>" target="_blank" href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $g['id'];?>&plat=<?php echo $_GET['plat'];?>"><?php echo $g['title'];?></a>
          </div>
          <table cellspacing="0" cellpadding="0" class="singles">
            <colgroup>
            <col class="col-sku-primary">
            <col class="col-sku-secondary">
            <col class="col-quantity">
            <col class="col-delete">
            <col class="col-unitprice">
            <col class="col-rebate">
            <col class="col-amount">
            </colgroup>
            <tbody>
            <tr class="single">
             
              <td rowspan="<?php echo $att_con;?>" class="td-sku-primary" width="">
              <?php $count=0;?>
              <?php $n=1; if(is_array($attribute[$g['id']])) foreach($attribute[$g['id']] AS $k => $att) { ?>
              <?php $att_con=count($att)?>
              <?php $n=1;if(is_array($att)) foreach($att AS $att2) { ?>
              <?php $count += $g['attribute'][$att2['id']];?>
               <dl class="unit-sku">
                  <dt class="w45 fl"><?php echo $k;?>：</dt>
                  <dd class="w70 fl"><?php echo $att2['size'];?></dd>
                  <dd class="w70 fl" style="color:#ff7100;">X<?php echo $g['attribute'][$att2['id']];?></dd>
                </dl>
                 <?php $n++;}unset($n); ?>
              <?php $n++;}unset($n); ?>
                </td>
             
              <td class="td-quantity quantity-wrap22" width="18%"  align="center"><span class="ipt-wp" style="width:100%; text-align:center;"><?php echo $g['jiage'];?> </span></td>
              <td class="td-delete" style="border-top: 1px dotted rgb(255, 255, 255); border-right: 1px dotted rgb(255, 255, 255);" width="12%" align="center"><?php echo $count;?></td>
              <td class="td-unitprice" width="18%" style="padding:0;"><div class="unitprice">
                  <span class="effective" style="width:100%; text-align:center;">
                  <em style="width:100%; text-align:center;">--</em>
                  </span>
                </div></td>
                <?php 
                	$itemMoney = $g['jiage']*$count;
                    $amount += $itemMoney;
                ?>
                <td class="td-amount" width="18%" ><div class="amount-wrap">
                  <em class="amount" style="width:100%; text-align:center;">
                  <?php echo number_format($itemMoney,2);?></em>
                </div>
                <div class="save-wrap">
                
                </div></td>
            </tr>
              </tbody>
            
          </table>
        </div>
      </div>
      <?php $n++;}unset($n); ?> 
      </div>
    <?php $n++;}unset($n); ?> 
    
    <!---->
    
  </div>
  <div class="settlement">
    <span class="settlement_count" style="display: none;">货品种类：<?php echo $z_zl;?>种 数量总计：<?php echo $count;?>件</span>
    <div class="settlement_text">
      <p><span style="margin-right:10px; font-size:13px; font-weight:bold;">运费: <font size="+1" style="color:red;"><?php if($yun_fei) { ?><?php echo $yun_fei;?><?php } else { ?>0<?php } ?>元</font></span><b>应付总额（含运费）：</b><font size="+1" style="color:red;"><?php echo number_format($amount,2);?>元</font></p>
      <p class="sub_text">
      <input type="hidden" name="money" value="<?php echo $amount;?>">
        <input type="submit" class="sub" style="" value="">
      </p>
    </div>
  </div>
  </form>
</div>
</div>
<script>

function address_edit_show(id) {
	$.ajax({
		type: "GET",
		url:'index.php?m=member&c=address&a=init&ajax=1&id=' + id,
		dataType: "json",
		success: function(data){
			//console.log($("#region-1").val(data.shi));return false;
			//console.log($('#region-1').sel);return false;
			//var ja =  eval('(' + data + ')');
			$("#region-1").val(data.sheng).attr('selected', true);
			if (data.shi > 1) {
				$("#region-2").val(data.shi).attr('selected', true);
			}
			$('#address').attr('value', data.address);
			$('#zipcode').attr('value', data.zipcode);
			$('#contactname').attr('value', data.contactname);
			$('#phone').attr('value', data.phone);
			$('#tel').attr('value', data.tel);
			$('#adid').attr('value', data.id);
		}
		
	});
	
	$('#address_edit').show();
}

/*payment*/
var payment_item = $('#payment').children('.item');
var payment_input = $(payment_item).find('.hookbox');
$(payment_input).click(function(){
	$(payment_item[$(this).attr('itmeid')]).addClass('item-selected').siblings().removeClass('item-selected');
	if($(this).attr('itmeid')==3){ $('#cf').show();}else{$('#cf').hide() ;}
});
/*address*/
var address_item;
var address_input;
address_init();
var address_size;

function address_init(){
	address_item = $('#addcheckbox').find('.save');
	address_input = $(address_item).find('input');	
	address_size = $(address_item).size();
}
function checkaddress(obj){
	address_init();
	address_item.removeClass('cur');
	$(obj).parents().addClass('cur');
	$('#customadd_').removeClass('cur');
}
$('#customadd_').click(function(){ address_init(); $(address_item).removeClass('cur'); $('#customadd_').addClass('cur'); });

function checkadty(ac){
	var yun = 15;
	var amount = Number($('#payPriceId').html().replace('￥',''));
	switch(ac){
		case 3: $('#freightPriceId').html('￥'+yun.toFixed(2));
			break;
		default: $('#freightPriceId').html('￥0.00');
	}	
}

$(function(){
	$('.save').hover(function(){
		$('#edit'+$(this).attr('data-id')).css('visibility','visible');	
	},function(){
		$('#edit'+$(this).attr('data-id')).css('visibility','hidden');	
	}
	);
});

function address_delete(id){
	if(!id) return;
	$('#adcancel_'+id).html('<img src="<?php echo IMG_PATH;?>msg_img/loading.gif"/>');	
	$.ajax({
		type: "POST", data:{'id':id},
		url:'index.php?m=member&c=address&a=address_delete&ajax=1',
		success: function(data) { 
			var da = data;
			setTimeout(function(da){
				var json_data =  eval('(' + data + ')');
				if(json_data.status!=1){alert(json_data.msg);return;}
				$('#address'+id).slideUp();
				$('#address'+id).remove();
				address_init();
				if(address_size<=0){ $('#customadd_').addClass('cur'); $('#customadd_').find('input').attr('checked','checked')}
		},300)},
	});	
	return false;
}
function address_add(){
	/*var sheng = '';
	for(var i=1;document.getElementById('sheng-'+i);i++){
		sheng += ':'+$('#sheng-'+i).val();
	}
	sheng = '&sheng='+sheng.substr(1);
	*/
	if ($("#adid").val() != '') {
		
		$.ajax({
			type: "POST",
			dataType: "json",
			data: 'address='+$('#address').val()+'&zipcode='+$('#zipcode').val()+'&contactname='+$('#contactname').val()+'&phone='+$('#phone').val()+'&tel='+$('#tel').val()+'&dosubmit=1'+'&region='+$('#region').val()+'&addressid='+$("#adid").val(),	
			url:'index.php?m=member&c=address&a=address_edit&ajax=1',
			success: function(data){
				//console.log(data);return false;
				if (data.status == 1) {
					location.reload();
				}
			}
		
		});
	} else {
		$.ajax({
			type: "POST", 
			data: 'address='+$('#address').val()+'&zipcode='+$('#zipcode').val()+'&contactname='+$('#contactname').val()+'&phone='+$('#phone').val()+'&tel='+$('#tel').val()+'&dosubmit=1'+'&region='+$('#region').val(),
			url:'index.php?m=member&c=address&a=address_add&ajax=1',
			success: function(data) {
				
				var ja =  eval('(' + data + ')');
				if(ja.status!=1){alert(ja.msg); return;}
				
				//var html = '<tr class="content_xinxi" id="address'+ja.msg.id+'"><td class="add_title">'+ja.msg.contactname+'</td><td style="">'+ja.msg.address+'</td><td style="">'+ja.msg.phone+'</td><td align="center"><a href="javascript:void(0)">修改</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" onClick="address_delete('+ja.msg.id+');return false">删除</a></td></tr>';
				
				
				var html = '<label id="address'+ja.msg.id+'" class="save " data-id="'+ja.msg.id+'"><input type="radio" value="'+ja.msg.id+'" name="addressid" itmeid="1" onclick="checkaddress(this)"> &nbsp;&nbsp;<strong></strong>&nbsp;&nbsp;'+ja.msg.address+'&nbsp;&nbsp;'+ja.msg.contactname+'<span id="edit'+ja.msg.id+'" class="edits" style="visibility: hidden;"><a href="javascript:void(0)">编辑</a>&nbsp;<a href="javascript:void(0)" onclick="address_delete('+ja.msg.id+')" id="adcancel_'+ja.msg.id+'">删除</a> &nbsp;&nbsp;</span> </label>';
				
				$('#addcheckbox').append(html);
				$('#address_edit').hide();
				$('#address_edit .input-text').each(function(index, element) {
				   $(this).val(''); 
				});
				
			}
		});	
	}
	
	
	return false;
}
</script>
<?php include template('wb_shop', 'footer'); ?>
</body>
</html>