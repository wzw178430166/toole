<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="header-nav">
  
  <div class="block">
    <span class="fl gotoindex" style="margin-right:15px;"> <?php if($thisCompany['shortname']) { ?>
    <?php echo $thisCompany['shortname'];?>
    <?php } else { ?>
    <?php echo $thisCompany['name'];?>
    
    <?php } ?>
    欢迎你！ </span>
    <p class="header-login-info">
      <a href="index.php?m=member&c=index&a=login&plat=<?php echo $_GET['plat'];?>">
      登录
      </a>
      &nbsp;&nbsp;|&nbsp;&nbsp;
      <a  href="index.php?m=member&c=index&a=register&plat=<?php echo $_GET['plat'];?>">
      免费注册
      </a>
    </p>
    <?php if($thisCompany['name'] || $thisCompany['shortname']) { ?>
    <a href="javascript:;" class="fl nav-mobile" style="">
    <i class="iconfont">&#xe615;</i>手机
    <?php if($thisCompany['shortname']) { ?>
    <?php echo $thisCompany['shortname'];?>
    <?php } else { ?>
    <?php echo $thisCompany['name'];?>
    
    <?php } ?>
    <style>
        	.nav-mobile-sub .qrcode img { width:116px; height:116px; margin-top:0}
        </style>
    <div class="nav-mobile-sub" style="width:116px; height:116px">
      <!--二维码-->
      <div class="qrcode" mlink="<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $plat;?>" style="position:initial; width:116px; height:116px; right:0; top:0">
        <canvas width="116" height="116"></canvas>
      </div>
      <input type="hidden" id="link1" readonly  class="input-text" value="<?php echo siteurl(3);?>/index.php?m=wb_shop&plat=<?php echo $plat;?>">
      <!--二维码-->
    </div>
    </a>
    <?php } ?>
    <ul class="ul-quick-menu">
      <li class="li-my menu-item">
        <a href="index.php?m=member&plat=<?php echo $plat;?>"  class="menu-hd my_user">
        个人中心<b></b>
        </a>
        <div class="menu-bd">
          <a href="index.php?m=wb_shop&c=index&a=order&plat=<?php echo $_GET['plat'];?>">
          我的订单
          </a>
           <a href="index.php?m=member&a=favorite&plat=<?php echo $_GET['plat'];?>">
          我的收藏
          </a>
          
        </div>
      </li>
      <li class="li-sep"></li>
      <li class="li-home">
        <a href="index.php?m=member&plat=<?php echo $plat;?>">
        我的账户
        </a>
      </li>
       <li class="li-home">
        <a href="javascript:;">
        客服热线 : 020-81533173
        </a>
      </li>
      
    </ul>
  </div>
</div>
<div class="header-main">
  <div class="block">
    <div class="header-logo header-logo-index">
    <?php $plat = $plat ?:intval($_GET['plat']);?>
      <a href="index.php?m=wb_shop&plat=<?php echo $plat;?>">
      <!--<img src="statics/wb_shop/tmp_info_pc/images/logo.gif" alt="">-->
      <img src="<?php echo $this->Company['logourl']?>" alt="">
      </a>
    </div>
    <div class="header-banner w-icon w-icon-28" id="ECS_CARTINFO">
      <a href="index.php?m=wb_shop&a=goodscart&plat=<?php echo $plat;?>" style="margin-left:10px">
      购物车
      </a>
    </div>
    <style>
        	.mallSearch-form button { 
				background-image: url(statics/wb_shop/tmp_info_pc/images/index_search_icon.png);
				background-repeat: no-repeat;
				background-position: center;
				background-size: 40%;
			}
			.header-banner {
				background-image: url(statics/wb_shop/tmp_info_pc/images/goodscart_icon.png);
				background-repeat: no-repeat;
				background-position: 8px center;
    			background-size: 35%;
			}
        </style>
    <div class="mall-search">
      <form action="" method="get"  class="mallSearch-form" onsubmit="return checkSearchForm();">
      	<input  type="hidden" name="m" value="wb_shop"/>
        <input  type="hidden" name="c" value="index"/>
        <input  type="hidden" name="a" value="lists"/>
        <input  type="hidden" name="catid" value="1"/>
        <input  type="hidden" name="plat" value="<?php echo $plat;?>"/>
        <div class="mallSearch-input-wp">
          <input type="text" name="keywords" id="keyword" class="mallSearch-input" value="" >
          <label for="mq"></label>
        </div>
        
        <button type="submit" class="search_btn"></button>
        <script type="text/javascript">
                    
		<!--
		function checkSearchForm()
		{
			if(document.getElementById('keyword').value)
			{
				return true;
			} else {
				alert("请输入搜索关键词！");
				return false;
			}
		}
		-->
                    
                </script>
      </form>
      <!--<ul class="ul-hot-query">
        <li class="first highlight"><a href="search.php?keywords=%E5%A5%B3%E5%8C%85" target="_blank">女包</a></li>
        <li class=""><a href="search.php?keywords=%E9%9D%A2%E8%86%9C" target="_blank">面膜</a></li>
        <li class=" highlight"><a href="search.php?keywords=MK" target="_blank">MK</a></li>
        <li class=""><a href="search.php?keywords=%E5%8D%A1%E4%B9%90%E6%AF%94" target="_blank">卡乐比</a></li>
        <li class=" highlight"><a href="search.php?keywords=new+balance" target="_blank">new balance</a></li>
        <li class=""><a href="search.php?keywords=%E9%9B%B7%E6%9C%8B" target="_blank">雷朋</a></li>
        <li class=" highlight"><a href="search.php?keywords=%E9%98%B2%E6%99%92" target="_blank">防晒</a></li>
     </ul>-->
    </div>
  </div>
</div>
<div class="header-menu">
  <div class="main-nav clearfix block"> 
    <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=f4717aec6137ca5ac231fc2c99b83aac&sql=SELECT+%2A+FROM+%60drcms_pro_category%60&return=cates\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_pro_category` LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$cates = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    <div class="main-nav-list">
      <a href="index.php" class="cur">
      首页
      </a>
      <?php $n=1;if(is_array($cates)) foreach($cates AS $r) { ?>
      <a href="index.php?m=wb_shop&a=lists&catid=6&classify=<?php echo $r['catid'];?>" >
      <?php echo $r['catname'];?>
      </a>
      <?php $n++;}unset($n); ?>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(function(){
    $(".cate-tree-item,.menu-item").hover(function(){
      $(this).addClass("hover");
    },function(){
      $(this).removeClass("hover");
    });
    //鼠标经过离开分类
      $(".cate-tree-item").on("mouseenter mouseleave",function(e){
        var index = $(this).index();
        if(e.type == "mouseenter"){
          toggleCatePanel(index, true);
        }else if(e.type == "mouseleave"){
          toggleCatePanel(index, false);
        }
      });
      //鼠标经过离开分类面板
      $(".cate-panel").on("mouseenter mouseleave",function(e){
        var index = $(this).index();
        if(e.type == "mouseenter"){
          toggleCatePanel(index, true);
        }else if(e.type == "mouseleave"){
          toggleCatePanel(index, false);
        }
      });
      //显示隐藏分类树方法
      function toggleCatePanel(i, show){
        var $panel = $(".cate-panel").eq(i);
        if(show){
          $panel.show();
        }else{
          $panel.hide();
        }
      }
      //首页之外其它页面分类树显示
      $(".cate-tree-all,.cate-tree").hover(function(){
        if(!$(".cate-tree").hasClass("cate-tree-index")){//如果是首页不做任何反应
            if($.trim($(".ul-cate-tree").html()).length != 0){//如果分类里有内容
                $(".cate-tree").removeClass("none");
            }
        }
      },function(){
        if(!$(".cate-tree").hasClass("cate-tree-index")){//如果是首页不做任何反应
          $(".cate-tree").addClass("none");
        }
      });
    });
  //禁止鼠标滚动事件冒泡
  $.fn.extend({
    "preventScroll":function(){
        $(this).each(function(){
            var _this = this;
            if(navigator.userAgent.indexOf('Firefox') >= 0){   //firefox
                _this.addEventListener('DOMMouseScroll',function(e){
                    _this.scrollTop += e.detail > 0 ? 60 : -60;
                    e.preventDefault();
                },false);
            }else{
                _this.onmousewheel = function(e){
                    e = e || window.event;
                    _this.scrollTop += e.wheelDelta > 0 ? -60 : 60;
                    return false;
                };
            }
        })
    }
});
$(".cate-panel .left-part").preventScroll();
</script>