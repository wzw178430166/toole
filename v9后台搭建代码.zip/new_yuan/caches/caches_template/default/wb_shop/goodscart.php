<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename='我的购物车';?>
<?php include template('wb_shop', 'header_common'); ?>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/shopping_flow.js"></script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/showdiv.js"></script>
<script type="text/javascript" src="statics/js/layer/1.9.3/layer.js"></script>
<style>
.fl { float:left;}
fr { float:right;}
.hide { display: none; }
.show { display: table-row-group; }
.hidden { visibility: hidden; }
.visible { visibility: visible; }
.cart-empty { height: 98px; border: 1px solid #ddd; margin-top: 25px; }
.cart-empty .message { height: 98px; padding-left: 410px; background: #f3f3f3 url('<?php echo SPATH;?>index/images/gouwuche/cart-empty-bg.png') no-repeat 330px 22px; }
.cart-empty .message p { line-height: 98px; }
.cart-empty a, .cart-empty a:visited, .cart-empty a:hover { color: #005ea7; }
.main .step { width: 1080px; height: 32px; margin-top: 20px; font-size: 15px; background: url('<?php echo SPATH;?>index/images/long_1.jpg') no-repeat; }
.count_box { position:relative; display:inline-block;}
.count_box span { 
	font-size: 40px;
    display: block;
    float: left;
    height: 27px;
    line-height: 21px;
    margin-right: 5px;
}
.count_box span.change-count-right {
	font-size: 30px;
    line-height: 27px;
    margin: 0;
    margin-left: 5px;
	float:right;	
}

/*new goodscart*/
.main { width:1080px;;}
.main .step {
    width: 1080px;
    height: 32px;
    margin-top: 20px;
    font-size: 15px;
    background: url('statics/wb_shop/images/long_1.jpg') no-repeat;
}
.main .step a {
    width: 352px;
    height: 32px;
    line-height: 32px;
    display: block;
    float: left;
    text-align: center;
    color: #FFF;
    font-weight: bold;
}
.main .step .a_on {
    color: #696969;
}
.receipt_tabletop {
    height: 32px;
    line-height: 32px;
}
.receipt_name {
    background: #f1f1f1;
    text-align: center;
}
.zone-store {
    height: 48px;
    line-height: 48px;
    padding: 0 22px;
}
.zone-goods {
    border-top: 1px solid #eee;
    padding: 0 22px 10px;
	overflow:hidden;
}
.fd-left {
    float: left;
}
.zone-store .left-area {
    height: 48px;
}
.zone-store .store-name {
    display: inline-block;
    margin-left: 5px;
    vertical-align: middle;
    font-weight: bold;
    color: #656565;
}
.zone-goods .opt {
    float: left;
    width: 30px;
    padding-top: 20px;
}
.zone-goods .goods-image {
    float: left;
    height: 82px;
    padding-top: 20px;
    width: 92px;
    margin-right: 10px;
}
.zone-goods .gouwucheinbox {
    float: left;
    width: 904px;
}
.img-vertical {
    display: table;
    font-size: 0;
    overflow: hidden;
    text-align: center;
}
.zone-goods .goods-image .img-vertical {
    border: 1px solid #eee;
    height: 80px;
    width: 80px;
}
.img-vertical .img-wrap {
    display: table-cell;
    vertical-align: middle;
}
.img-vertical img {
    vertical-align: middle;
}
.zone-goods .goods-image img {
    max-height: 80px;
    max-width: 80px;
}
.text-medium {
    color: #222;
    font-family: "微软雅黑", "黑体", "文泉驿正黑体", "华文细黑";
    font-size: 14px;
}
.zone-goods .description {
    float: left;
    font-size: 12px;
    padding-top: 20px;
}
.zone-goods .panel-remove {
    display: inline;
    float: right;
    padding-top: 13px;
}
.icon-delete, .icon-collect, .icon-new, .icon-modify, .icon-modify-quit {
    background: url('statics/wb_shop/images/common.png') no-repeat scroll -100px center rgba(0, 0, 0, 0);
    display: inline-block;
    height: 14px;
    line-height: 45px;
    overflow: hidden;
    text-indent: -999px;
    width: 15px;
}
.zone-goods .panel-remove .icon-collect {
    margin-right: 16px;
    background-position: -41px -121px;
}
.icon-delete {
    background-position: -68px -121px;
    width: 11px;
}
.zone-goods .panel-modify {
    clear: both;
    position: relative;
    z-index: 101;
}
.zone-goods .singles {
    border-left: 1px dotted #fff;
    margin-left: 7px;
    margin-top: -13px;
	clear:both;
}

.zone-goods .col-sku-primary {
    width: 150px;
}
.zone-goods td.td-sku-primary {
    width: 130px;
    padding-left: 20px;
    vertical-align: top;
}
.zone-goods td.td-sku-primary .unit-sku {
    margin-top: 13px;
    color: #8a8a8a;
    font-size: 12px;
}
.w45 {
    width: 45px;
}
.w70 {
    width: 70px;
}
.unit-sku dt {
    float: left;
}
.zone-goods .td-quantity, .zone-goods .td-amount {
    height: 46px;
}
.mod-counts22 {
    width: 153px;
}
.mod-counts22 .a-reduce, .mod-counts22 .a-add {
    float: left;
    width: 25px;
    height: 25px;
    border: 1px solid #ccc;
    font-weight: bold;
    font-family: "Microsoft Yahei";
    text-align: center;
}
.mod-counts22 .a-reduce {
    border-radius: 2px 0 0 2px;
    font-size: 20px;
}
.mod-counts22 .ipt-wp {
    float: left;
    width: 60px;
    height: 25px;
    border: 1px solid #ccc;
    border-left: 0;
    border-right: 0;
}
.mod-counts22 .iptCount {
    width: 60px;
    height: 23px;
    line-height: 23px;
    padding: 0;
    border: 0;
    text-align: center;
}
.mod-counts22 .a-add {
    border-radius: 0 2px 2px 0;
    font-size: 16px;
}
.icon-delete {
    background-position: -68px -121px;
    width: 11px;
}
.zone-goods .single .td-unitprice {
    padding-right: 20px;
    vertical-align: middle;
}
.zone-goods .unitprice span {
    display: block;
}
.zone-goods .unitprice .effective {
    color: #555;
    font-size: 14px;
    line-height: 21px;
}
.zone-goods .td-rebate .rebate {
    text-align: center;
}
.zone-goods .single .amount {
    color: #fc1900;
    display: block;
    font-size: 16px;
    font-weight: 700;
    text-align: right;
}
.main .settlement {
    width: 1080px;
    height: 135px;
    position: relative;
    border-top: 1px solid #eee;
    background: #FAFAFA;
}
.main .settlement .settlement_count {
    position: absolute;
    top: 23px;
    left: 23px;
    color: #000;
    font-weight: 100;
}
.main .settlement .settlement_text {
    width: 232px;
    height: 112px;
    position: absolute;
    top: 25px;
    right: 0px;
    padding-right: 20px;
}
.main .settlement .settlement_text p {
    text-align: right;
	font-weight:100;
}
.main .settlement .settlement_text b {
    font-weight: bold;
}
.main .settlement .settlement_text .sub_text {
    color: #225a7d;
    line-height: 35px;
    height: 35px;
    text-align: right;
    margin-top: 20px;
    vertical-align: top;
}
.main .settlement .settlement_text .sub_text .sub {
    width: 98px;
    height: 32px;
    background: url(statics/wb_shop/images/order_form_submit.jpg) no-repeat;
    border: none;
}
/*new goodscart*/
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
<div class="blank"></div>
 <div id="ur_here">
当前位置: <a href=".">首页</a> <code>&gt;</code> 购物流程 
</div>
</div>
<div class="blank"></div>
<div class="main">
  <form id="myform" action="index.php?m=wb_shop&a=confim&plat=<?php echo $_GET['plat'];?>" onSubmit="return send_form()" method="post">
  <input type="hidden" name="orderid" value="<?php echo $orderid;?>" />
    <div class="step">
      <a>我的进货单</a>
      <a class="a_on">填写核对订单</a>
      <a class="a_on">订单付款成功</a>
    </div>
    <?php if(empty($goodscart)) { ?>
    <div class="cart-inner cart-empty">
      <div class="message">
        <p>进货单内暂时没有商品，您可以
          <a href="<?php echo siteurl($siteid);?>index.php?m=wb_shop&plat=<?php echo $_GET['plat'];?>">去首页</a>
          挑选喜欢的商品<!-- ，或<a href="###" class="btn-takeout">取出之前寄存的商品</a> --></p>
      </div>
    </div>
    <?php } else { ?> 
    
    <!---->
    <table align="center" width="1080" class="receipt_tabletop" cellspacing="0" style="margin-top:20px;">
      <tbody>
        <tr>
          <td class="receipt_name" width="410">货品</td>
          <td class="receipt_name" width="170" style="text-align:left">尺码</td>
          <td class="receipt_name" width="135">数量</td>
          <td class="receipt_name" width="170">单价(元)</td>
          <td class="receipt_name" width="135">优惠(元)</td>
          <td class="receipt_name" width="135">总金额(元)</td>
          <td class="receipt_name" width="135">操作</td>
        </tr>
      </tbody>
    </table>
    <?php $n=1; if(is_array($carts)) foreach($carts AS $k => $g_info) { ?>
    <div id="shangpu_<?php echo $k;?>">
      <div class="zone-store fd-clr">
        <div class="fd-left left-area">
          <span class="lang-checkbox">
          <input type="checkbox" id="lang-checkbox-cart-<?php echo $k;?>" autocomplete="off" data-selMoney="0" onChange="change('shangpu',<?php echo $k;?>,this)">
          </span>
          <label for="lang-checkbox-cart-<?php echo $k;?>" >
          <a target="_blank"  class="store-name text-medium"><?php echo $dp_info[$k]['name'];?></a>
          </label>
          <a  class="doit-alitalk doit-alitalk-on" ></a>
        </div>
      </div>
      <?php $n=1; if(is_array($g_info)) foreach($g_info AS $i => $g) { ?>
      <div  class="zone-goods fd-clr" id="zone-goods-<?php echo $i;?>">
        <div class="opt">
          <span class="lang-checkbox">
          <input type="checkbox" id="lang-checkbox-goods-<?php echo $i;?>" autocomplete="off" name="goodsrmids[]" data-shang="<?php echo $k;?>" value="<?php echo $g['catid'];?>_<?php echo $g['id'];?>_<?php echo $i;?>" onChange="change('attribute',<?php echo $i;?>,this)">
          <label for="lang-checkbox-goods-<?php echo $i;?>"></label>
          </span>
        </div>
        <div class="goods-image">
          <div class="img-vertical">
            <a target="_blank" href="index.php?m=wb_shop&a=show&catid=<?php echo $g['catid'];?>&id=<?php echo $g['id'];?>&plat=<?php echo $_GET['plat'];?>" class="img-wrap"><img alt="<?php echo $goodsinfo_[$g['id']]['title'];?>" src="<?php echo $goodsinfo_[$g['id']]['thumb'];?>"></a>
          </div>
        </div>
        <div class="gouwucheinbox">
          <div class="description text-medium">
            <a title="<?php echo $g['title'];?>" target="_blank" href="index.php?m=wb_shop&a=show&catid=<?php echo $g['catid'];?>&id=<?php echo $g['id'];?>&plat=<?php echo $_GET['plat'];?>"><?php echo $goodsinfo_[$g['id']]['title'];?></a>
          </div>
          <div class="panel-remove">
            <i class="icon-delete"></i>
            <a title="删除该货品" href="javascript:;" class="icon_a" onClick="del_cart('<?php echo $i;?>');">删除</a>
          </div>
          <div class="panel-modify"><span class="icon-modify" style="visibility: hidden;">修改</span></div>
          <table cellspacing="0" cellpadding="0" class="singles">
            <colgroup>
            <col class="col-sku-primary">
            <col class="col-opt">
            <col class="col-sku-secondary">
            <col class="col-quantity">
            <col class="col-delete">
            <col class="col-unitprice">
            <col class="col-rebate">
            <col class="col-amount">
            </colgroup>
            <tbody>
            <?php $n=1; if(is_array($g['attribute'])) foreach($g['attribute'] AS $att => $att2) { ?>
            <tr class="single attribute_list_<?php echo $att2['id'];?>" id="attribute_<?php echo $att2['id'];?>" <?php if($n==1) { ?>data-first="1"<?php } ?>>
              <td  class="td-sku-primary"><dl class="unit-sku hidden <?php if($n==1) { ?>visible<?php } ?>">
                  <!--<dt class="w45 fl">颜色：</dt>-->
                  <dd class="w70 fl"><?php echo $attribute[$att]['attribute'];?></dd>
                </dl></td>
              <td class="td-opt"><span class="lang-checkbox" >
                <input type="checkbox" style=" opacity:0; width:0; height:0;" id="lang-checkbox-single-<?php echo $att;?>" autocomplete="off" class="lang-checkbox-single" data-id="<?php echo $att;?>" data-cartid="<?php echo $i;?>" value="<?php echo $att2;?>" name="attribute[<?php echo $g['catid'];?>_<?php echo $g['id'];?>][<?php echo $att;?>]">
                </span></td>
              <td class="td-sku-secondary" style="border-top: 1px dotted rgb(255, 255, 255); width:139px;"><dl class="unit-sku">
                  <!--<dt class="w45 fl">尺码：</dt>-->
                  <dd class="w45 fl"><?php echo $attribute[$att]['size'];?></dd>
                </dl></td>
              <td class="td-quantity quantity-wrap22" style="width:165px;"><div class="mod-counts22">
                  <a class="a-reduce" href="javascript:void(0)" onClick="combosub(this,<?php echo $i;?>,<?php echo $att;?>)">-</a>
                  <span class="ipt-wp">
                  <input id="combo_<?php echo $att;?>" class="iptCount" type="text" value="<?php echo $att2;?>" data-cid="<?php echo $i;?>" onChange="enterChangeCount(this,'<?php echo $att;?>','<?php echo $i;?>')">
                  </span>
                  <a class="a-add" href="javascript:void(0)" onClick="comboadd(this, <?php echo $i;?>,<?php echo $att;?>)">+</a>
                </div></td>
              <td class="td-delete" style="border-top: 1px dotted rgb(255, 255, 255); border-right: 1px dotted rgb(255, 255, 255);"><a href="javascript:void(0)" onClick="combodel(<?php echo $i;?>,<?php echo $att;?>)" class="icon-delete">删除</a></td>
              <td class="td-unitprice" style="width:90px;"><div class="unitprice">
                  <span class="effective">
                  <em id="singleMoney_<?php echo $i;?>" data-val="<?php echo $goodsinfo_[$g['id']]['jiage'];?>">
                  <?php echo number_format($goodsinfo_[$g['id']]['jiage'],2);?></em>
                  </span>
                </div></td>
              <td class="td-rebate" style="width:54px;"><div class="rebate"> -- </div></td>
              <td class="td-amount" style="width:125px;"><div class="amount-wrap">
                  <em class="amount" id="cartMoney_<?php echo $i;?>">
                  <?php
                  	$count += $att2;
                    $jiage = $goodsinfo_[$g['id']]['jiage']*$att2; 
                    $amount += $jiage;
                ?>
                  <?php echo number_format($jiage,2);?> </em>
                </div>
                <div class="save-wrap">
                </div></td>
            </tr>
            <?php $n++;}unset($n); ?>
              </tbody>
            
          </table>
        </div>
      </div>
      <?php $n++;}unset($n); ?> </div>
    <?php $n++;}unset($n); ?>
    
    <?php } ?> 
    <!---->
    
    <div class="settlement">
      <span class="settlement_count"><!--货品种类：$goodscount种--> 数量总计：<em><?php echo $count;?></em>件</span>
      <div class="settlement_text">
        <p><b>应付总额（含运费）：</b><font size="+1" style="color:red;"><em id="z_jia" data-val="0">0</em>元</font></p>
        <p class="sub_text">
          <input type="submit" class="sub" value="">
        </p>
      </div>
    </div>
  </form>
  
  <?php if($_GET['me']) { ?>
  <a onClick="showwlj()" style="width: 30px; height: 30px; display: block; border: 1px #FF0004 solid">show</a>
  <?php } ?>
</div>

<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script type="text/javascript">

function send_form () {
	var is_sel = false;
	//var goodsrmids = $('.goodsrmids');
	var goodsrmids = $('input[name="goodsrmids[]"]');
	//console.log(goodsrmids);return false;
	for (var i=0,len=$(goodsrmids).length;i<len;i++) {
		
		if ($(goodsrmids[i]).is(':checked')) {
			is_sel = true;
		}
	}
	if (!is_sel) {
		alert('请选择商品!');
		return false;
	}
	//$('#formCart').submit();
	//return false;
	return true;
}
function del_cart(id){
	if(window.confirm('确定要删除这这件商品吗?')){
		$.post('?m=wb_shop&c=index&a=del_cart&ajax=1&rmids='+id,function(data){
			if (data.status == 1) {
				alert(data.msg);
				location.reload();
			} else {
				alert('删除失败!');
			}
		}, 'json');	
	}
	return false;
}
var mreload_timer;
function mreload(time){
	mreload_timer = window.setTimeout(function(){ location.reload();},time);
}
function change(ac,id,obj){
	var result = $('#z_jia').attr('data-val');
	switch(ac){
		case 'shangpu':
			var itemResult = 0;
			var ipCount = $('#shangpu_'+id+' .iptCount');
			ipCount.each(function(){
				console.log($(this).val()+'----'+$('#singleMoney_'+$(this).attr('data-cid')).attr('data-val'));
				var pro_count = $(this).val();
				var singleMoney = $('#singleMoney_'+$(this).attr('data-cid')).attr('data-val');
				itemResult += Number(pro_count)*Number(singleMoney);
			});
			var selMoney = $('#lang-checkbox-cart-'+id).attr('data-selMoney');
			if($('#lang-checkbox-cart-'+id).is(':checked')){
				$('#shangpu_'+id).find(':checkbox').each(function(){ $(this).prop('checked','checked'); });
				result = Number(result) - Number(selMoney) + Number(itemResult);
			}else{
				$('#shangpu_'+id).find(':checkbox').each(function(){ $(this).removeAttr('checked'); });
				result -= itemResult;
				itemResult = 0;
			}
			$('#lang-checkbox-cart-'+id).attr('data-selMoney',itemResult);
			$('#z_jia').attr('data-val',Number(result));
			$('#z_jia').text(Number(result));
		 break;
		
		case 'attribute':
		    //取消全选(店铺)(xin)
			var singleMoney = $('#singleMoney_'+id).attr('data-val');//单价
			var pro_count = $('#zone-goods-'+id+' .iptCount').attr('value');//数量
			var itemResult = Number(singleMoney)*Number(pro_count);
		    $('#lang-checkbox-goods-'+id).parent().parent().parent().parent().find(':checkbox').eq(0).prop('checked',false);	
			var selMoney = $('#lang-checkbox-cart-'+$(obj).attr('data-shang')).attr('data-selMoney');
			//$('#lang-checkbox-cart-'+$(obj).attr('data-shang')).attr('data-selMoney',Number(selMoney) - Number(itemResult));
			//var moneyTem = Number(selMoney) <= 0 ? Number(itemResult) : Number(selMoney) - Number(itemResult);
			console.log(selMoney+'--'+moneyTem);
			
			if($('#lang-checkbox-goods-'+id).is(':checked')){
				$('#zone-goods-'+id).find(':checkbox').each(function(){ $(this).prop('checked','checked'); });
				var moneyTem = Number(selMoney) <= 0 ? Number(itemResult) : Number(selMoney) + Number(itemResult);
			}else{
				$('#zone-goods-'+id).find(':checkbox').each(function(){ $(this).removeAttr('checked'); });
				var moneyTem = Number(selMoney) <= 0 ? Number(itemResult) : Number(selMoney) - Number(itemResult);	
			}
			result = Number(result) - Number(selMoney) + Number(moneyTem);
			$('#lang-checkbox-cart-'+$(obj).attr('data-shang')).attr('data-selMoney',moneyTem);
			$('#z_jia').attr('data-val',Number(result));
			$('#z_jia').text(Number(result));
		 break;	
	}
}
function combosub(obj,rmids,id,name){
	var num = Number($('#combo_'+id).val());
	var singleMoney = $('#singleMoney_'+rmids).attr('data-val');
	var tmp = 0;
	if($(obj).parent().parent().parent().find('[type="checkbox"]').prop('checked')==false){
		if(num>1){
			window.clearTimeout(mreload_timer);
			tmp = num-1;
			$('#combo_'+id).attr('value',tmp);
			//$.post('index.php?m=shop&c=index&a=checkcon_cart',{'rmids':rmids,'attribute_id':id,'num':$('#combo_'+id).val()},function(){ mreload(300); });
			$.post('index.php?m=wb_shop&c=index&a=checkcon_cart',{'rmids':rmids,'attribute_id':id,'num':tmp});	
			//window.location.reload();
			//check_order(bianshiid,name);
			$('#lang-checkbox-single-'+id).attr('value',tmp);
			$('#cartMoney_'+rmids).text((Number(singleMoney)*tmp)+'.00');
		}
	} else {
		layer.msg('请取消选择再修改!');	
	} 
}
function comboadd(obj,rmids,id,name){
	
	if($(obj).parent().parent().parent().find('[type="checkbox"]').prop('checked')==false){
		window.clearTimeout(mreload_timer);
		var num = Number($('#combo_'+id).val());
		var singleMoney = $('#singleMoney_'+rmids).attr('data-val');
		var tmp = 0;
		tmp = num+1;
		$('#combo_'+id).attr('value',tmp);
		/*$.post('index.php?m=shop&c=index&a=checkcon_cart',{'rmids':rmids,'attribute_id':id,'num':$('#combo_'+id).val()},function(){ mreload(300); });*/	
		$.post('index.php?m=wb_shop&c=index&a=checkcon_cart',{'rmids':rmids,'attribute_id':id,'num':tmp});
		//window.location.reload();
		//check_order(bianshiid,name);
		$('#lang-checkbox-single-'+id).attr('value',tmp);
		$('#cartMoney_'+rmids).text((Number(singleMoney)*tmp)+'.00');
	} else {
		layer.msg('请取消选择再修改!');	
	}
}
//输入更新数量
function enterChangeCount(obj,attid,rmids){
	var singleMoney = $('#singleMoney_'+rmids).attr('data-val');
	$('#lang-checkbox-single-'+attid).attr('value',$(obj).val());
	$.post('index.php?m=wb_shop&c=index&a=checkcon_cart',{'rmids':rmids,'attribute_id':attid,'num':$(obj).val()});
	$('#cartMoney_'+rmids).text((Number(singleMoney)*Number($(obj).val()))+'.00');
}
function send(){
	var b = $('.lang-checkbox-single');
	var value='';
	for(var i=0,len=$(b).length;i<len;i++){
		if($(b[i]).is(':checked')){
			value = $('#combo_'+$(b[i]).attr('data-id')).val()
			$(b[i]).val(value);	
			$('#lang-checkbox-single-'+$(b[i]).attr('data-id')).attr('checked','checked');
		}
	}
	
	if($('#myform').serialize()){
		return true;	
	}else{
		alert('请先选择商品');
		return false;		
	}
	
}
</script>
</html>
