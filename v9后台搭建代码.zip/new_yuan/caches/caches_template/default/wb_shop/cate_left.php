<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $client_ip = $_SERVER['REMOTE_ADDR'];$plat=intval($_GET['plat']);?>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=cf917835d27452102f273c0dcfa08ea3&sql=SELECT+%2A+FROM+%60drcms_ll_lishi%60+WHERE+ip%3D%27%24client_ip%27&return=ll_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_ll_lishi` WHERE ip='$client_ip' LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$ll_data = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
<?php if ($ll_data):?>
<?php 
	$gids = array();
    foreach($ll_data as $k=> $r) {
    	$r['goods_id'] = string2array($r['goods_id']);
        foreach ($r['goods_id'] as $y => $n) {
        	$gids[] = $y;
            $ll_data[$k]['gid'] = $y;
        }
    }
    $id_str = implode(',', $gids)
?>
<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=058ae363c4d57d6f5cc11ed3a3e8da9a&sql=SELECT+%2A+FROM+%60drcms_wb_shop%60+WHERE+id+in%28%24id_str%29&num=4&return=goods_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("SELECT * FROM `drcms_wb_shop` WHERE id in($id_str) LIMIT 4");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$goods_data = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
<?php 
/*foreach ($goods_data as $r) {
	$goods_data_[$r['id']] = $r;
}
foreach ($ll_data as $k => $r) {
	$ll_data[$k]['info'] = $goods_data_[$r['gid']];
}*/
?>
<?php endif;?>
<div id="category_tree">
<div class="tit">所有商品分类</div>
<dl class="clearfix" style=" overflow:hidden;" >
<div class="box1 cate" id="cate">
  <?php $n=1;if(is_array($cates)) foreach($cates AS $r) { ?>
  <!--存在二级分类-->
  <h1 <?php if($r['child']) { ?>onclick="tab('<?php echo $n-1;?>')"<?php } ?>   style="border-top:none"   >
    <span class="f_l"><img src="statics/wb_shop/tmp_info_pc/images/btn_fold.gif" style="padding-top:10px;padding-right:6px;cursor:pointer;"></span>
  </h1>
  <a   style="border-top:none"  href="index.php?m=wb_shop&a=lists&catid=1&l=3&classify=<?php echo $r['catid'];?>&plat=<?php echo $plat;?>" class="  f_ll" ><?php echo $r['catname'];?></a>
  <?php if($r['child']) { ?>
  <ul style="display:none" class="sub-tree">
    <a class="over_2" href="category.php?id=6"><?php echo $r['catname'];?></a>
    <div class="clearfix">
    </div>
    <a class="over_2" href="category.php?id=7"><?php echo $r['catname'];?></a>
    <div class="clearfix">
    </div>
    <a class="over_2" href="category.php?id=8"><?php echo $r['catname'];?></a>
    <div class="clearfix">
    </div>
  </ul>
  <?php } ?>
  <div style="clear:both"></div>
  <?php $n++;}unset($n); ?>
</div>
<div style="clear:both"></div>
</div>
<div class="blank"></div>
<script type="text/javascript">
obj_h4 = document.getElementById("cate").getElementsByTagName("h4")
obj_ul = document.getElementById("cate").getElementsByTagName("ul")
obj_img = document.getElementById("cate").getElementsByTagName("img")
function tab(id)
{
		if(obj_ul.item(id).style.display == "block")
		{
			obj_ul.item(id).style.display = "none"
			obj_img.item(id).src = "statics/wb_shop/tmp_info_pc/images/btn_fold.gif"
			return false;
		}
		else(obj_ul.item(id).style.display == "none")
		{
			obj_ul.item(id).style.display = "block"
			obj_img.item(id).src = "statics/wb_shop/tmp_info_pc/images/btn_unfold.gif"
		}
}
</script>

<?php if($_GET['a'] == 'show') { ?>
<style>
.dp_js, .dp_lx, .dp_ewm, .dp_spfl {
    border: 1px solid #dddddd;
}
.dp_js {
    height: auto;
    background: #fff;
	margin-bottom:10px;
}
.info-wrap ul {
    width: 190px;
    margin: 10px auto;
}
.info-wrap ul li {
    height: 25px;
    line-height: 25px;
}
.info-wrap ul li.rlt {
    overflow: visible;
    padding-top: 3px;
    line-height: 15px;
}
.red_xin {
    width: 15px;
    height: 13px;
    display: block;
    float: left;
    overflow: hidden;
    background: url(statics/wb_shop/images/common.png) no-repeat -41px -121px;
}
.info-wrap li.favorable_rate {
    position: relative;
}
.info-wrap .c_blue {
    color: #005ac0;
}
.info-wrap li.d-line {
    height: 7px;
    line-height: 7px;
    background: none;
    border-bottom: 1px dashed #ddd;
}
.info-wrap li#adr_map {
    position: relative;
    line-height: auto;
    line-height: 18px;
    height: auto;
}
.info-wrap li.favorable_btn {
    margin-top: 10px;
}
.info-wrap li#adr_map .adr_box {
    max-height: 36px;
    overflow: hidden;
}
.info-wrap li#adr_map .adr_box em {
    width: 152px;
}
.info-wrap li .enter_btn {
    width: 60px;
    padding-left: 30px;
    height: 25px;
    display: block;
    float: right;
    color: #999;
    background: url(statics/wb_shop/images/dpzx.png) no-repeat;
    cursor: pointer;
}
.info-wrap li .col-store {
    background-position: -220px 0;
}
.info-wrap li .int-store {
    background-position: -310px 0;
}
.mr10 {
    margin-right: 10px;
}
</style>
<div class="dp_js info-wrap"> <strong> <a href="" title=""></a> </strong>
    <ul>
      <li class="rlt zd9"> 
      <a target="_blank" id="xy_show">
            <i class="red_xin"></i>
            <i class="red_xin"></i>
      </a> 
      </li>
      <li class="favorable_rate zd3">
        <em class="c_blue" style="font-size:11px;font-style: inherit;" id="good_rate"><?php echo $thisCompany['name'];?></em></li>
        <label>开店时间：</label>
        <?php echo date('Y-m-d', $thisCompany['addtime']);?>
         
        <li>联系电话：<?php echo $thisCompany['phone'];?></li>
        <li class="d-line"></li>
      
      <li class="favorable_btn">
            <a href="javascript:;" class="enter_btn int-store ss_btn" target="_blank">进入店铺</a>
       
      </li>
    </ul>
  </div>
<?php } ?>
<div class="box" id='history_div'>
  <div class="box_1">
    <h3><span>浏览历史</span></h3>
    <div class="boxCenterList clearfix" id='history_list'>
    <?php if($goods_data) { ?>
    <?php $n=1;if(is_array($goods_data)) foreach($goods_data AS $r) { ?>
      <ul class="clearfix">
        <li class="goodsimg">
          <a href="index.php?m=wb_shop&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank"><img src="<?php echo $r['thumb'];?>" alt="<?php echo $r['title'];?>" class="B_blue" /></a>
        </li>
        <li class="htext">
          <a href="index.php?m=wb_shop&a=show&catid=<?php echo $r['catid'];?>&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank" title="<?php echo $r['thumb'];?>"><?php echo $r['title'];?></a>
          <br />
          本店售价：<font class="f1">￥<?php echo number_format($r['jiage'], 2);?>元</font><br />
        </li>
      </ul>
      <?php $n++;}unset($n); ?>
      <?php } else { ?>
      暂无浏览记录
      <?php } ?>
    </div>
  </div>
</div>
<div class="blank5"></div>