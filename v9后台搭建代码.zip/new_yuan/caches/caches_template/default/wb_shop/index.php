<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop', 'header_common'); ?>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/index.js"></script>
<style>
.AreaL table { width:100%;}
.li_empty { text-align:center; margin-top:15px; font-size:15px;}
</style>
<body class="index_page" style="min-width:1200px;">
<?php include template('wb_shop', 'header'); ?>
<script type="text/javascript">
  $(function(){
      //如果是首页，让分类树直接显示
      $(".cate-tree").each(function(){
        var _this = $(this);
        _this.removeClass("none").addClass("cate-tree-index");
      });
  });
</script>
<script type="text/javascript" src="statics/wb_shop/tmp_info_pc/js/jquery.SuperSlide.js"></script><div class="main-banner-wp">
  <div class="block">
    <div class="main-banner" id="slideBox">
    <?php $adv=show_ad2(1,28,1,1)?>
    <?php if(empty($adv)) { ?>
      <div class="li_empty">暂无轮播图,请在后台->商城管理->轮播图片添加轮播</div>
    <?php } else { ?>
        <ul class="main-banner-hd hd">
        	
            <?php $n=1;if(is_array($adv)) foreach($adv AS $r) { ?>
            <?php if($r['1']['imageurl']) { ?>
            <li>
            	<a href="<?php if($r['1']['linkurl']) { ?><?php echo uu($r['1']['linkurl'],$plat);?><?php } else { ?>javascript:;<?php } ?>">
                	<img src="<?php echo $r['1']['imageurl'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['1']['name'];?>">
                    <span></span>
                </a>
            </li>
            <?php } ?>
            <?php $n++;}unset($n); ?>
        </ul>
        <?php } ?>
        <div class="bd">
        <ul class="main-banner-bd">
        	
            <?php $n=1;if(is_array($adv)) foreach($adv AS $r) { ?>
            <?php if($r['1']['imageurl']) { ?>
            <li>
                <a href="<?php if($r['1']['linkurl']) { ?><?php echo uu($r['1']['linkurl'],$plat);?><?php } else { ?>javascript:;<?php } ?>" target="_blank">
                    <img src="<?php echo $r['1']['imageurl'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['1']['name'];?>">
                </a>
            </li>
            <?php } ?>
            <?php $n++;}unset($n); ?>
        </ul>
        </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $("#slideBox").slide({
    effect : "fold",
    autoPlay : true,
    mainCell : ".bd ul"
  });
  $(function(){
    $("#slideBox").hover(function(){
        $(this).find(".hd").stop().animate({opacity:1});
    },function(){
        $(this).find(".hd").stop().animate({opacity:0});
    });
  })
</script><div class="indexw_content">
<div class="block clearfix" >
<div class="AreaL">
 
<div id="mallNews"    class="  box_1">
    <h3><span>站内快讯</span></h3>
    <div class="NewsList tc  " style="border-top:none">
        <ul>
          <?php if($news) { ?>
          <?php $n=1;if(is_array($news)) foreach($news AS $r) { ?>
          <li>
            <a href="javascript:;" title="<?php echo $r['title'];?>"><?php echo $r['title'];?></a>
          </li>
          <?php $n++;}unset($n); ?>
          <?php } else { ?>
          <li>
          	<a href="javascript:;">暂无站内资讯</a>
          </li>
          <?php } ?>
        
        </ul>
    </div>
</div>
<div  class="blank"></div>  
<table cellpadding="0" cellspacing="0">
    <tr>
        <td>
        <?php $adv1=show_ad2(3,28,1,2)?>
        	<?php if($adv1) { ?>
            <?php $n=1;if(is_array($adv1)) foreach($adv1 AS $r) { ?>
            <a href="<?php if($r['1']['linkurl']) { ?><?php echo uu($r['1']['linkurl'],$plat);?><?php } else { ?>javascript:;<?php } ?>" target='_blank'>
            	<img src="<?php echo $r['1']['imageurl'];?>" width='240' height='140' border='0' />
            </a>
            <?php break;?>
            <?php $n++;}unset($n); ?>
            <?php } ?>
        </td>
    </tr>
</table>
</div>
<div class="Arear">
    <div class="sale_box clearfix">
          <h3><em>特价商品</em></h3>
          <div class="clearfix body">
          <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=c1e3a5535d5884d356a189da60af43cb&action=lists&catid=6&num=4&return=special_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$special_data = $content_tag->lists(array('catid'=>'6','num'=>'4','limit'=>'4',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
          <?php $n=1;if(is_array($special_data)) foreach($special_data AS $r) { ?>
          	<div class="goodsItem">
              <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank">
              	<img src="<?php echo $r['thumb'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['title'];?>" class="goodsimg" />
              </a>
              <br />
              <p class="name">
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['title'];?></a>
              </p>
              <div class="info">
                <p class="price"> ￥<?php echo number_format($r['jiage'], 2);?>元 </p>
                <p class="market">￥<?php echo number_format($r['yuanjiage'], 2);?>元</p>
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" class="buy" target="_blank">立即购买</a>
              </div>
            </div>
            <?php $n++;}unset($n); ?>
          </div>
        </div>
 
<div class="blank" style="height:1px;"></div>
 
</div> 
  <div class="goodsBox_1">
  
  
  
    <div class="xm-box">
        <h4 class="title">
          <a class="more" href="index.php?m=wb_shop&a=lists&catid=6&l=3&plat=<?php echo $plat;?>&new=1">更多</a>
          <em>新品上架</em>
        </h4>
        <div id="show_new_area" class="clearfix body">
        <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=169f8e7ad092e4c0213c4fd064402dda&action=lists&catid=6&order=inputtime+DESC&num=5&return=new_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$new_data = $content_tag->lists(array('catid'=>'6','order'=>'inputtime DESC','num'=>'5','limit'=>'5',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <?php $n=1;if(is_array($new_data)) foreach($new_data AS $r) { ?>
          <div class="goodsItem">
              <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank">
              <img src="<?php echo $r['thumb'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['title'];?>" class="goodsimg" /></a>
              <br />
              <p class="name">
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['title'];?></a>
              </p>
              <div class="info">
                <p class="price"> ￥<?php echo number_format($r['jiage'], 2);?>元 </p>
                <p class="market">￥<?php echo number_format($r['yuanjiage'], 2);?>元</p>
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" class="buy" target="_blank">立即购买</a>
              </div>
            </div>
          <?php $n++;}unset($n); ?>
        </div>
      </div>
<div class="blank"></div>
  <div class="xm-box">
    <h4 class="title"><a class="more" href="index.php?m=wb_shop&a=lists&catid=6&l=3&plat=<?php echo $plat;?>&rx=1">更多</a><em>热卖商品</em> </h4>
    <div id="show_hot_area" class="clearfix body">
    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=0c9a0a793c11003f71d2d70f00c1833d&action=lists&catid=6&order=inputtime+DESC&num=5&return=hot_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$hot_data = $content_tag->lists(array('catid'=>'6','order'=>'inputtime DESC','num'=>'5','limit'=>'5',));}?>
    	<?php $n=1;if(is_array($hot_data)) foreach($hot_data AS $r) { ?>
          <div class="goodsItem">
              <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank">
              <img src="<?php echo $r['thumb'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['title'];?>" class="goodsimg" /></a>
              <br />
              <p class="name">
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['title'];?></a>
              </p>
              <div class="info">
                <p class="price"> ￥<?php echo number_format($r['jiage'], 2);?>元 </p>
                <p class="market">￥<?php echo number_format($r['yuanjiage'], 2);?>元</p>
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" class="buy" target="_blank">立即购买</a>
              </div>
            </div>
      <?php $n++;}unset($n); ?>
      <?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
    </div>
  </div>
<div class="blank"></div>
  <div class="xm-box">
    <h4 class="title"><a class="more" href="index.php?m=wb_shop&a=lists&catid=6&l=3&plat=<?php echo $plat;?>&jp=1">更多</a><em>精品推荐</em> </h4>
    <div id="show_best_area" class="clearfix body">
    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"content\" data=\"op=content&tag_md5=fbf125a8cd6d8c958e220a0d3a029dc7&action=lists&catid=6&order=inputtime+DESC&num=5&return=jp_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}$content_tag = pc_base::load_app_class("content_tag", "content");if (method_exists($content_tag, 'lists')) {$jp_data = $content_tag->lists(array('catid'=>'6','order'=>'inputtime DESC','num'=>'5','limit'=>'5',));}?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
        <?php $n=1;if(is_array($jp_data)) foreach($jp_data AS $r) { ?>
          <div class="goodsItem">
              <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" target="_blank">
              <img src="<?php echo $r['thumb'];?>" alt="<?php echo $this->Company['name'];?>_<?php echo $r['title'];?>" class="goodsimg" /></a>
              <br />
              <p class="name">
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" title="<?php echo $r['title'];?>" target="_blank"><?php echo $r['title'];?></a>
              </p>
              <div class="info">
                <p class="price"> ￥<?php echo number_format($r['jiage'], 2);?>元 </p>
                <p class="market">￥<?php echo number_format($r['yuanjiage'], 2);?>元</p>
                <a href="index.php?m=wb_shop&a=show&catid=6&id=<?php echo $r['id'];?>&plat=<?php echo $plat;?>" class="buy" target="_blank">立即购买</a>
              </div>
            </div>
          <?php $n++;}unset($n); ?>
    </div>
  </div>
<div class="blank"></div>
</div> 
</div>
  
 </div>
<div class="bottom_ad">
            
</div>
<div class="resetClear"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
</html>
