<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename = '用户信息';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<style>
.fl { float:left;}
.box_1 .userCenterBox .userMenu a { margin-bottom: 5px; font-size: 14px; }
.baseinfo_list { padding:15px;}
.baseinfo_list_box { width:50%; margin:0;}
.item {
	display: block;
    margin-bottom: 20px;
    line-height: 30px;
	overflow:hidden;	
}
.item span.label {
    float: left;
    height: 18px;
    line-height: 18px;
    padding: 6px 0;
    width: 100px;
    text-align: right;
}
.btn-5{
    background-color: #f5fbef;
    background-image: -moz-linear-gradient(top,#f5fbef,#eaf6e2);
    background-image: -webkit-gradient(linear,left top,left bottom,color-stop(0,#f5fbef),color-stop(1,#eaf6e2));
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5fbef', endColorstr='#eaf6e2', GradientType='0');
    -ms-filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5fbef', endColorstr='#eaf6e2');
    background-image: linear-gradient(to bottom,#f5fbef 0,#eaf6e2 100%);
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    display: inline-block;
    height: 18px;
    line-height: 18px;
    border: 1px solid #bfd6af;
    padding: 2px 14px 3px;
    color: #323333;
}
.itxt {
    line-height: 18px;
    border: 1px solid #ccc;
    padding: 5px;
    float: none;
    font-family: "Microsoft YaHei";
    font-size: 12px;
}
.itxt{
    height: 18px;
    width: 127px;
    padding: 5px 23px 5px 5px;
}
/*新增地址box*/
</style>
<body>
;
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 用户信息 </div>
</div>
<div class="blank"></div>
<div class="tt01">
  <div class="tt01_box"> <?php include template("member", "member_left"); ?>
    <div class="member_right">
      <div class="news_order">
        <p class="order_title"><font>用户信息</font></p>
        <div class="baseinfo_list">
        	<div class="baseinfo_list_box">
            	<div class="item">
                    <span class="label">用户名：</span>
                    <div class="fl">
                        <div><strong><?php echo $memberinfo['username'];?></strong></div>
                    </div>
                </div>
                <div class="item">
                    <span class="label">昵称：</span>
                    <div class="fl">
                        <input type="text" class="itxt" id="nickname" value="<?php echo $memberinfo['nickname'];?>">
                    </div>
                </div>
                <div class="item">
                    <span class="label">邮箱：</span>
                    <div class="fl">
                    	<input type="text" id="email" class="itxt" value="<?php echo $memberinfo['email'];?>">
                    </div>
                </div>
                <div class="item">
                    <span class="label">&nbsp;</span>
                    <div class="fl">
                    	<a href="javascript:void(0)" class="btn-5" onClick="updateUserInfo()">提交</a>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <!--news_order end-->
    </div>
  </div>
</div>

<div class="blank"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script>
function updateUserInfo () {
	if ($('#nickname').val() == '') {
		layer.msg('昵称不能为空!');
		return;
	}
	if ($('#email').val() == '') {
		layer.msg('邮箱不能为空!');
		return;
	}
	var index = layer.load(1,{time: 100*1000});
	$.post('index.php?m=member&a=baseinfo_edit&ajax=1', {"nickname":$('#nickname').val(), "email":$('#email').val(), "dosubmit":1}, function (data) {
		layer.close(index);
		layer.msg(data.msg);
		if (data.status == 1) {
			setTimeout(function () {
				window.location.reload();
			}, 2000);
			
		}
	}, 'json');
}
</script>
</html>