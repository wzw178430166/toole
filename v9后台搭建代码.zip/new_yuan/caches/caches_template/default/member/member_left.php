<?php defined('IN_drcms') or exit('No permission resources.'); ?><div class="member_left">
    <h2><?php if($thisCompany['name']) { ?><?php echo $thisCompany['name'];?>商城<?php } else { ?>会员中心<?php } ?></h2>
    <ul>
        <li class="order_"><a href="index.php?m=wb_shop&c=index&a=order&plat=<?php echo $_GET['plat'];?>">我的订单</a></li>
        <li class="goodscart_"><a href="index.php?m=wb_shop&a=goodscart&plat=<?php echo $_GET['plat'];?>" target="_blank">我的购物车</a></li>
        <li class="address_"><a href="index.php?m=member&c=address&plat=<?php echo $_GET['plat'];?>">地址管理</a></li>
        <li class="collect_"><a href="index.php?m=member&a=favorite&plat=<?php echo $_GET['plat'];?>">我的收藏</a></li>
        <li class="baseinfo_"><a href="index.php?m=member&a=baseinfo_edit&plat=<?php echo $_GET['plat'];?>">用户信息</a></li>
        <li class="avatar_"><a href="index.php?m=member&a=account_manage_avatar&t=2&plat=<?php echo $_GET['plat'];?>">头像修改</a></li>
        <li class="pass_"><a href="index.php?m=member&a=account_manage_password&plat=<?php echo $_GET['plat'];?>">密码修改</a></li>
    </ul>
</div>