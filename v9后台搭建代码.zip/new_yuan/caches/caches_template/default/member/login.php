<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common'); ?>
<style>
.col-log{ width:1040px; overflow:hidden; margin:35px auto; background-color:#fff; padding:50px 80px;}
.col-log .col-log_l{ width:646px; height:430px;}
.col-log .col-log_r{ width:300px; padding:40px; border:1px solid #ccc; margin-top:80px;}
.col-log_r .col-text{ width:295px; height:40px; border:1px solid #ccc; margin-bottom:15px;}
.col-text img{ width:20px; height:20px; padding:10px; float:left;}
.col-text .nobd{ width:250px; height:40px; line-height:40px; float:left;}
.col-for .fl{ margin-left:10px;}
.col-for .fl input{ margin-right:5px;}
.col-log_r .login{ width:100%; height:40px; line-height:40px; text-align:center; background-color:#E3201A; color:#fff; letter-spacing:4px; margin:30px 0px; border-radius:5px; cursor:pointer;}
</style>
<body>
<!---header_start--->
<?php include template('wb_shop','header'); ?>
<!---header_end--->
<div style="width:100%; overflow:hidden; background-color:#f5f5f5;">
    <div class="col-log">
    	<div class="col-log_l fl">
        	<img src="<?php echo SPATH;?>ku/images/login_pic.png">
        </div>
        <div class="col-log_r fl">
        	<p style="font-size:25px; color:#565656; margin-bottom:25px;">用户登录</p>
            <form method="post" action="" id="myform">
            <input type="hidden">
                <div class="col-text">
                    <img src="<?php echo SPATH;?>ku/images/login_man.png">
                    <input type="text" id="username" name="username" placeholder="请输入手机号" class="nobd">
                </div>
                <div class="col-text">
                    <img src="<?php echo SPATH;?>ku/images/login_pass.png">
                    <input type="password" id="password" name="password" placeholder="登录密码" class="nobd">
                </div>
                <div class="col-for">
                    <div class="col-for_ fl">
                        <input type="checkbox" name="savePassword" value="1" checked="checked">记住密码
                    </div>
                    <!--<div class="col-for_ fr">
                    	<a href="javascript:;" style="color:#009fd9;">忘记密码？</a>
                    </div>-->
                </div>
                <input type="hidden" name="dosubmit" value="1">
                <input type="button" class="login nobd" value="登录" onClick="sendForm()">
            </form>
            <p>还没有账号？立即申请<a href="index.php?m=member&c=index&a=register" style="color:#009fd9;">注册</a></p>
        </div>
    </div>
</div>
<!---footer_start---->
<?php include template('wb_shop','footer'); ?>
<!---footer_end---->
</body>
<script>
function sendForm(){
	var forward_ = "<?php echo $_GET['forward'];?>"
	var username = $('#username').val();
	var password = $('#password').val();
	if (username == '' || password == '') {
		layer.msg('账号和密码不能为空');
		return;
	}
	var index = layer.load(2);
	var url = 'index.php?m=member&a=login&ajax=1&ifram=1';
	$.post(url, $('#myform').serialize(), function (data) {
		layer.close(index);
		layer.msg(data.msg);
		//return;
		if(data.status==1){
			var url = forward_ != '' ? forward_ : 'index.php';
			 window.location.href = url;
		}
		
	}, 'json');
}
</script>
</html>