<?php defined('IN_drcms') or exit('No permission resources.'); ?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>商家登录</title>
</head>

<body>
</body>
</html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="robots” content=" nofollow”="">
<title>商家登录</title>
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>member/css/drag.css">
<script src="statics/js/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="statics/js/layer/1.9.3/layer.js" type="text/javascript"></script>
<script>
if(window.parent.document.getElementById('iframe_box')){
	window.top.location.reload();
}
</script>
</head>
<style>
body { color:#333; font-family: "Microsoft YaHei";}
#header {
    width: 100%;
    height: 90px;
    background: #fff;
    position: fixed;
    top: 0;
    z-index: 3;
    font-size: 15px;
    border-bottom: 1px solid #ddd;
}
.header {
    width: 1000px;
    height: 90px;
    margin: 0 auto;
}
.header_left {
    width: 100px;
    height: 65px;
    float: left;
    margin-right: 100px;
}
.login-content {
    width: 444px;
    height: auto;
    margin: 181px auto 80px;
    box-shadow: 0px 0px 15px 5px rgba(194, 193, 170, 0.5);
    border-radius: 8px;
    padding: 35px 62px;
    box-sizing: border-box;
    border: 1px solid #ccc;
	transition: ease .5s;
	display:none;
}
.forget {
	transform:rotateY(90deg);
	-moz-transform:rotateY(90deg); /* Firefox 4 */
	-webkit-transform:rotateY(90deg); /* Safari and Chrome */
	-o-transform:rotateY(90d  eg); /* Opera */	
}
.login-words {
    color: #888686;
    height: 27px;
}
.login-words h2 {
    float: left;
    width: 100px;
	font-weight:normal;
	margin:0;
}
.login {
    margin-top: 30px;
}
#box2 div.int {
    width: 320px;
    position: relative;
    overflow: hidden;
    zoom: 1;
    margin-top: 20px;
    height: 40px;
}
#box2 div label {
    position: absolute;
    top: 7px;
    left: 6px;
    width: 28px;
}
#box2 div input[type="text"], #box2 div input[type="password"] {
    float: left;
    width: 320px;
    height: 40px;
    border: 1px solid #dcdcdc;
    color: #333;
    padding-left: 38px;
    box-sizing: border-box;
    border-radius: 4px;
	outline:0;
}
.login_btn {
	margin: 25px auto 0;
    width: 240px;
    height: 40px;	
}

.login_btn_ {
    color: #fff;
    font-size: 18px;
    width: 240px;
    height: 40px;
    border: 1px solid #62b900;
    cursor: pointer;
    letter-spacing: 1px;
    text-align: center;
    border-radius: 4px;
    background: #62b900;
	outline:none;
}
.login_btn .unlogin {
	background-color: #ededed;
    color: #999;
    border-color: #ededed;
    cursor: initial;	
}
.login_pwd {
    height: 30px;
    line-height: 30px;
    margin-top: 10px;
}
.login_pwd a {
    color: #999;
    font-size: 12px;
	text-decoration:none;
}
.login_pwd a.remember_pwd {
    float: left;
    padding-left: 16px;
	background: url('statics/images/icon/un_color/checkbox_ok_icon.png') no-repeat left center;
	background-size:13px;
}
.login_pwd a.remember_pwd.null { background: url('statics/images/icon/un_color/checkbox_null_icon.png') no-repeat left center; background-size:13px;}
.login_pwd a.forget_pwd {
    float: right;
}
#drag { margin-top:20px; width:320px; }
#drag .drag_text { width:320px;}
.send-code{
	text-decoration: none;
    font-size: 0.9rem;
    color: #fff;
    display: block;
    float: right;
    width: 80px;
    height: 36px;
    line-height: 36px;
    background-color: #62B900;
    text-align: center;
    border-radius: 4px;
    margin-top: 2px;	
}
</style>
<body>
<div id="header">
    <div class="header">
        <div class="header_left">
            <a href="http://www.veigou.com/">
                <img src="<?php echo SPATH;?>wpm/images/b2c_logo.jpg"  height="54">
            </a>
        </div>
        <div class="header_center">
            <ul>
                
            </ul>
        </div>
        <div class="header_right">
            <ul>
               
            </ul>
        </div>
    </div>
</div>
<form method="post" name="login" id="lgForm">
<div class="login-content" style="display:block" id="login_box">
    <div class="login-words">
        <h2>登录</h2>
    </div>
    <div class="login">
		<div id="box2">
			<div class="int">
				<label for="username"><img src="<?php echo SPATH;?>images/icon/un_color/people_icon.png" width="25" height="25"></label>
				<input type="text" id="username" class="required" value="" placeholder="您的手机号码/用户名" name="username">
			</div>
			<div class="int">
				<label for="password"><img src="<?php echo SPATH;?>images/icon/un_color/password_icon.png" width="25" height="25"></label>
				<input type="password" id="password" class="required" value="" placeholder="输入密码" name="password" maxlength="20">
			</div>
            <div id="drag"></div>
            <input type="hidden" id="checkCode" value="0">
            <div class="login_pwd">
				<a class="remember_pwd" href="javascript:void(0);" onClick="changelgStatus()">记住密码</a>
				<input type="hidden" id="savePassword" value="1">
				<a class="forget_pwd" href="javascript:;" onClick="rotateBox('forget')">忘记密码？</a>
			</div>
			<div class="login_btn">
				<input type="button" value="登录" id="login_btn" class="login_btn_ unlogin" onClick="send_();">
			</div>
		</div>
    </div>
</div>
<div class="login-content forget" id="forget_box">
    <div class="login-words">
        <h2>忘记密码</h2>
    </div>
    <div class="login">
		<div id="box2">
			<div class="int">
				<label for="username"><img src="<?php echo SPATH;?>images/icon/un_color/people_icon.png" width="25" height="25"></label>
				<input type="text" id="forget_username" class="required" value="" placeholder="您的手机号码/用户名" name="username">
			</div>
            <div class="int">
				<label for="code"><img src="<?php echo SPATH;?>images/icon/un_color/code_icon.png" width="25" height="25"></label>
				<input type="text" id="forget_code" class="required" value="" placeholder="请输入短信验证码" maxlength="20" style=" width:220px;">
                <a href="javascript:;" id="btn" class="send-code">发送</a>
			</div>
			<div class="int">
				<label for="password"><img src="<?php echo SPATH;?>images/icon/un_color/password_icon.png" width="25" height="25"></label>
				<input type="password" id="forget_password" class="required" value="" placeholder="请输入新密码" name="password" maxlength="20">
			</div>
            <div class="login_pwd">
				<a class="forget_pwd" href="javascript:;" onClick="rotateBox('login')">立即登录</a>
			</div>
			<div class="login_btn">
				<input type="button" value="保存" id="login_btn" class="login_btn_" onClick="send_forget()">
			</div>
		</div>
    </div>
</div>
</form>
</body>
<script type="text/javascript" src="<?php echo SPATH;?>member/js/drag.js"></script>
<script>
window.onload = function () {
	var login_type_a = $('#login_type a');
	login_type_a.each(function(i) {
		$(login_type_a[i]).click(function () {
			$(login_type_a).removeClass('sel_');
			$(login_type_a[i]).addClass('sel_');
			$('#login_url').attr('value', $(this).attr('data-login'));
			$('#redirect_url').attr('value', $(this).attr('data-redirect')); 
		});
    });
	
	$('#drag').drag();
	
};
function changelgStatus() {
	var savePassword = $('#savePassword').val();
	if (savePassword == 1) {
		savePassword = 0;
		$('.remember_pwd').addClass('null');
	} else {
		savePassword = 1;
		$('.remember_pwd').removeClass('null');
	}
	$('#savePassword').attr('value',savePassword);
}
function send_() {
	var checkCode = $('#checkCode').val();
	if (checkCode == 0) {return;}
	var username = $('#username').val();
	var password = $('#password').val();
	var code = $('#code').val();
	if (username == '' || password == '') {
		layer.msg('账号和密码不能为空');
		return;
	}
	if (code == '') {
		layer.msg('验证码不能为空');
		return;
	}
	if (checkCode == 0) {
		layer.msg('请滑动验证!');
		return;
	}
	var index = layer.load(2);
	var url = 'index.php?m=member&a=login&ajax=1&ifram=1';
	$.post(url, {'username':username,'password':password,'code':code,'savePassword':$('#savePassword').val(),'admin':1,'dosubmit':1}, function (data) {
		layer.close(index);
		layer.msg(data.msg);
		//return;
		if(data.status==1){
			 window.location.href = 'index.php?m=wpm'
		}
		
	}, 'json');
}
function send_forget(){
	var phone = $('#forget_username').val();
	var password = $('#forget_password').val();
	var code = $('#forget_code').val();
	if (phone == '') {
		layer.msg('请输入手机号码!');
		return;
	}
	if (phone == '') {
		layer.msg('请输入短信验证码!');
		return;
	}
	if (password == '') {
		layer.msg('请输入新密码!');
		return;
	}
	//console.log(phone+'---'+password+'---'+code);return;
	var url = 'index.php?m=member&a=forget_password_ajax&ajax=1';
	var index = layer.load(2,{time:6*1000});
	$.post(url, {'phone':phone,'password':password,'code':code,'admin':1}, function (data) {
		layer.close(index);
		if (data.status == 1) {
			layer.msg('密码重置成功!',{time:1500});
			setTimeout(function(){window.location.reload();},1500);
		} else if(data.status == -2) {
			layer.msg('手机号码不存在!');
		} else if(data.status == -3) {
			layer.msg('验证码不正确!');
		}
	}, 'json');
}

function rotateBox(ac){
	$('.login-content').css({'transform':'rotateY(90deg)','webkitTransform':'rotateY(90deg)','OTransform':'rotateY(90deg)','MozTransform':'rotateY(90deg)'});
	setTimeout(function(){
		$('#'+ac+'_box').css({'transform':'rotateY(0deg)','webkitTransform':'rotateY(0deg)','OTransform':'rotateY(0deg)','MozTransform':'rotateY(0deg)'});
	},600);
	setTimeout(function(){
		$('.login-content').hide();
		$('#'+ac+'_box').show();
	},500);
}
</script>
<script language="JavaScript">
/**/
var interval = null;
var btn = document.getElementById ('btn');
var time_s = "<?php echo pc_base::load_config('system','sms_time');?>";
	//alert(time_s);
btn.onclick = function (){
	sendcode();
}

function sendcode() {
	if(!interval){
		var phone = $.trim($('#forget_username').val());
		if(phone==''){ 
			layer.msg('请填写手机号码');
			$('#username_').focus();
			return;
		}
		btn.style.backgroundColor = 'rgb(204, 204, 204)';
		btn.style.borderColor = '#ccc';
		btn.disabled = "disabled";
		btn.style.cursor = "wait";
		btn.value = "发送中";	
		//btn.onclick = function(){};
		//time_s = 40;
		
		//sendcode_affter();
		$.ajax({
		type: "get",
		dataType: "json", 
		url:'index.php?m=member&a=public_sendsms_ajax',
		data:'phone='+phone,// 你的formid
		success: function(da){
				if(da.status=='1'){
					sendcode_affter();			
				}else{
					sendcode_huanyuan();
					if(da.msg){ layer.msg(da.msg); }	
					
				}
			},
		error: function(request) {
				layer.msg('网络错误');
				sendcode_huanyuan();
			},
		});
	}
}

/**/
function sendcode_huanyuan(){
	clearInterval (interval);
	interval = null;
	btn.style.cursor = "pointer";
	btn.removeAttribute ('disabled');
	btn.value = "重发验证码";
	btn.style.backgroundColor = '#06A204';
	btn.onclick = function(){ sendcode(); }
}
function sendcode_affter(){

	if (time_s<=0){
		sendcode_huanyuan();
	}else{
		btn.innerHTML = "已发送("+time_s+")";
		time_s --;
		interval = window.setTimeout('sendcode_affter()',1000);	
	}
}
</script>
</html>