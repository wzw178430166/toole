<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename='我的头像';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<style>
.col-avatar { float: right; }
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 我的头像 </div>
</div>
<div class="blank"></div>
<div class="tt01">
	<div class="tt01_box">
    	<?php include template("member", "member_left"); ?>
        <div class="member_right">
        	<div class="news_order">
            <p class="order_title"><font>我的头像</font></p>
        	<!---avatarUpload start-->
            <div id="memberArea" class="main" style="margin-bottom:15x;">
              <div class="w1200 center"> 
                <div class="rightm">
                  <div class="clear"></div>
                  <!--<div class="item_t">
                    <h2><span style="color:#e43739;font-size: 26px;">我的头像</span></h2>
                    <div class="line line2"></div>
                  </div>-->
                  
                  <div class="qh_box" style="display:block; margin-top:20px;">
                    <div class="content qhb_div2" style="width: 803px;">
                      <script language="javascript" type="text/javascript" src="<?php echo $phpsso_api_url;?>/statics/js/swfobject.js"></script>
                      <script type="text/javascript">
                                var flashvars = {
                                    'upurl':"<?php echo $upurl;?>&callback=return_avatar&"
                                }; 
                                var params = {
                                    'align':'middle',
                                    'play':'true',
                                    'loop':'false',
                                    'scale':'showall',
                                    'wmode':'window',
                                    'devicefont':'true',
                                    'id':'Main',
                                    'bgcolor':'#ffffff',
                                    'name':'Main',
                                    'allowscriptaccess':'always'
                                }; 
                                var attributes = {
                                    
                                }; 
                                swfobject.embedSWF("<?php echo $phpsso_api_url;?>/statics/images/main.swf", "myContent", "490", "434", "9.0.0","<?php echo $phpsso_api_url;?>/statics/images/expressInstall.swf", flashvars, params, attributes);
            
                                function return_avatar(data) {
                                    if(data == 1) {
                                        window.location.reload();
                                    } else {
                                        alert('failure');
                                    }
                                }
                            </script>
                      <ul class="col-right col-avatar" id="avatarlist">
                        <?php $n=1; if(is_array($avatar)) foreach($avatar AS $k => $v) { ?>
                        <li>
                          <img src="<?php echo $v;?>" height="<?php echo $k;?>" width="<?php echo $k;?>" onerror="this.src='<?php echo $phpsso_api_url;?>/statics/images/member/nophoto.gif'"><br />
                          <?php echo L('avatar');?><?php echo $k;?> x <?php echo $k;?> </li>
                        <?php $n++;}unset($n); ?>
                      </ul>
                      <div class="col-auto">
                        <div id="myContent">
                          <p>Alternative content</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <span class="o1"></span><span class="o2"></span><span class="o3"></span><span class="o4"></span>
                </div>
              </div>
            </div>
            <div class="clear"></div>
            <!---avatarUpload end--->
            </div>
        </div>
    </div>
</div>
<?php include template('wb_shop', 'footer'); ?>
</body>
</html>