<?php defined('IN_drcms') or exit('No permission resources.'); ?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="keywords" content="<?php echo $this->Company['keywords'];?>">
<meta name="description" content="<?php echo $this->Company['description'];?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="stylesheet" type="text/css" href="<?php echo SPATH;?>member/css/style.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo SPATH;?>member/css/common.css"/>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo SPATH;?>js/global.js"></script>
<!--<script type="text/javascript" src="<?php echo JS_PATH;?>jquery1.42.min.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>jquery.SuperSlide.js"></script>
<script type="text/javascript" src="<?php echo JS_PATH;?>Validform_v5.3.2_min.js"></script>-->
<title><?php echo $title;?></title>
</head>