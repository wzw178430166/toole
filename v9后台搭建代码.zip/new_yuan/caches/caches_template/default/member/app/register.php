<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php 
	$rg = 1;
?>
<?php include template('member','login'); ?>
