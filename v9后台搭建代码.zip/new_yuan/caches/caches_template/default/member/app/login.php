<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common2'); ?>
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/style6.css" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>wb_shop/css/app_login.css" />
<style>
.fs {
    background-color: #06A204;
    border: 1px #06A204 solid;
    color: #fff;
}
form{ display: none;}
.wechatLogin {
	width: 100%;
    height: 40px;
    background-color: #62b900;
    text-align: center;
    line-height: 40px;
    color: #fff;
    margin-top: 20px;	
}
</style>
<body style="background:#f0f2f5;">
<!--public header start-->
<div class="header">
  <div class="header_box">
    <a href="" onClick="window.history.go(-1);" class="header_fanhui">
    </a>
    <h2 class="header_title"> <?php if($rg) { ?>
      用户注册
      <?php } else { ?>
      用户登录
      <?php } ?> </h2>
  </div>
</div>
<!--public header end-->
<div style="height:45px;"></div>
<form style=" <?php if(!$rg) { ?> display:block;<?php } ?>" action="index.php?m=member&c=index&a=init&forward=<?php echo urlencode($_GET['forward']);?>" method="post" id="form_1">
  <div class="main">
    <div class="login">
      <div class="login_box">
        <div class="login_cont">
          <p>
            <input name="username" id="username" class="login_inp" type="text" placeholder="请输入您的手机号码" />
          </p>
          <p>
            <input name="password" id="password" class="login_inp" type="password" placeholder="请输入您的密码" />
          </p>
          <input type="hidden" name="forward" value="<?php echo $forward;?>" >
          <!--id="modelid" 用 ajax获取(都是ajax登录注册什么的)-->
          <input type="hidden"  name="modelid" id="modelid" value="15"/>
          <input style="border:none" type="button" class="login_btn" name="dosubmit" value="立即登录" onClick="loginsend()"/>
          <div class="login_bt">
            <a href="index.php?m=member&c=index&a=forget_password&no_check=1" class="lbt_word fl">
            忘记密码？
            </a>
            
            <!--<a href="index.php?m=member&c=index&a=register&wpm=1&plat=<?php echo $_GET['plat'];?>&k=<?php echo $_GET['k'];?>" class="lbt_word fr">没有账号？立即注册</a></div>-->
            <a onClick="goregister('<?php echo get_siteid();?>')" class="lbt_word fr">
            没有账号？立即注册
            </a>
          </div>
          <?php if(is_weixin() && get_siteid() != 3) { ?><div class="wechatLogin" onClick="goweixin()">微信登录</div><?php } ?>
        </div>
      </div>
    </div>
  </div>
</form>
<form  style=" <?php if($rg) { ?> display:block;<?php } ?>" action="" method="post" onSubmit="sregister(); return false;" id="myform">
  <div  class="main" >
    <div class="login">
      <div class="login_box">
        <div class="login_cont">
          <p>
            <input id="username_" name="username" class="login_inp" type="number" value="" placeholder="请输入您的手机号码" />
          </p>
          <p>
            <input class="login_inp" type="text" placeholder="请输入验证码" style="width:60%; float:left;" id="login_inp_"/>
            <a  class="fs" id="btn"  href="javascript:;">
            发送
            </a>
          </p>
          <p>
            <input id="Pwd_A" name="password" class="login_inp" type="password" placeholder="请输入您的密码" />
          </p>
          <p>
            <input id="Pwd_B"   class="login_inp" type="password" placeholder="请再次输入您的密码" />
          </p>
          <?php if(isset($_GET['i']) && $_GET['i']) { ?><input type="hidden" name="i" value="<?php echo $_GET['i'];?>"><?php } ?>
          <?php if(isset($_GET['k']) && $_GET['k']) { ?><input type="hidden" name="k" value="<?php echo $_GET['k'];?>"><?php } ?>
          <input type="hidden" name="forward" id="forward" value="<?php echo $forward;?>" >
          <input type="hidden" name="dosubmit" value="1"/>
          <input type="hidden"  name="ifram" id="ifram" value="1"/>
         <div class="login_bt">
            <input style=" border:none" type="button" class="login_btn" value="同意协议并注册" id="registerbut" onClick="sregister()" />
            <!--<div class="ckbox ckbox2">
              <input type="checkbox" class="ckbox_inp" />
            </div>
            <a href="" class="useyx">
            《使用条款和协议》
            </a>-->
          </div>
          <div onClick="$('#myform').attr('style','display:none');$('#form_1').attr('style','display:block');
           $('.header_title').text('商家登录');
           " style="margin-top: 5px; text-align:center;" class="eb_bott">
            <a  style="color: rgb(84, 187, 187);" class="ebt_word">
            已有帐号？立即登录吧！
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
<?php $siteurl =  get_url();$siteid = get_siteid();?>
</body>
</html><?php include template('wb_shop','footer_common'); ?>
<script language="JavaScript">
/**/
var interval = null;
var btn = document.getElementById ('btn');
var time_s = "<?php echo pc_base::load_config('system','sms_time');?>";
	//alert(time_s);
btn.onclick = function (){
	sendcode();
}
function sendcode() {
	if(!interval){
		var phone = $.trim($('#username_').val());
		if(phone==''){ 
			layer.msg('请填写手机号码');
			$('#username_').focus();
			return;
		}
		btn.style.backgroundColor = 'rgb(204, 204, 204)';
		btn.style.borderColor = '#ccc';
		btn.disabled = "disabled";
		btn.style.cursor = "wait";
		btn.value = "发送中";	
		//btn.onclick = function(){};
		//time_s = 40;
		
		//sendcode_affter();
		$.ajax({
		type: "get",
		dataType: "json", 
		url:'index.php?m=member&a=public_sendsms_ajax',
		data:'phone='+phone,// 你的formid
		success: function(da){
				if(da.status=='1'){
					sendcode_affter();			
				}else{
					sendcode_huanyuan();
					if(da.msg){ layer.msg(da.msg); }	
					
				}
			},
		error: function(request) {
				layer.msg('网络错误');
				sendcode_huanyuan();
			},
		});
	}
}

/**/
function sendcode_huanyuan(){
	clearInterval (interval);
	interval = null;
	btn.style.cursor = "pointer";
	btn.removeAttribute ('disabled');
	btn.value = "重发验证码";
	btn.style.backgroundColor = '#06A204';
	btn.onclick = function(){ sendcode(); }
}
function sendcode_affter(){

	if (time_s<=0){
		sendcode_huanyuan();
	}else{
		btn.innerHTML = "已发送("+time_s+")";
		time_s --;
		interval = window.setTimeout('sendcode_affter()',1000);	
	}
}

function loginsend(){
	if(!$('#username').val()){
		alert("账号不能为空");
		return false;
	}else if(!$('#password').val()){
		alert("密码不能为空");
		return false;
	}
	var index = layer.load(6*1000);
	var url = '/index.php?m=member&a=login&ajax=1&ifram=1';
	$.post(url,{ 'username':$('#username').val(),'password':$('#password').val(),'modelid':$('#modelid').val(),'wd':$('#wd').val(),'forward':$('#forward').val(),'dosubmit':'dosubmit','ajax':'1'},function(data){
		layer.close(index);
		try{
			if(data.status==1){
				 loginseccess(data.forward_);
			}else{
				layer.msg(data.msg);
			}
		}catch(err){
			layer.msg(data.msg);
		}
	
	},'json');
	return false;
}
function loginseccess(forward_){
	var wpm = "<?php echo $_GET['wpm'];?>";
	//console.log(forward_);return;
	var url = forward_ != '' ? forward_ : (wpm == 1 ? 'index.php?m=wpm' :'index.php');
	//console.log(url);return;
	window.location.href = url;
}
var fhhd = '<?php echo $_GET["fhhd"];?>';
function sregister(){
	//alert(siteid+'---'+"<?php echo $siteurl;?>");return;
	var siteid = "<?php echo $siteid;?>";
	if($.trim($('#username_').val())==''){ layer.msg("账号不能为空"); return;}
	if($.trim($('#Pwd_A').val().length)<6){ layer.msg("密码不得小于6位数"); return;}
	if($.trim($('#Pwd_A').val())==''){ layer.msg("密码不能为空"); return;}
	if($.trim($('#Pwd_B').val())!==$('#Pwd_A').val()){ layer.msg("密码不一致"); return;}
	
	var myDate = new Date();
	var nowtime = myDate.getTime();
	if(getCookie('inputtime')){
		var canuptime = (10*1000 - nowtime + Number(getCookie('inputtime')))/1000;
		if((canuptime/60) >0.99){
			showloadbox('',1);
			alert('请在 '+parseInt(canuptime/60)+' 分钟后再操作');
			return;
		}else if(canuptime>0){
			showloadbox('',1);
			alert('请在 '+parseInt(canuptime)+' 秒后再操作');	
			return;
		}
	}
	
	document.getElementById('registerbut').onclick = function(){ return false; };
	var index = layer.load(2,{time:8*1000});
	$.ajax({
		cache: true,
		type: "POST",
		url:'index.php?m=member&a=register&siteid=1&ifram=1&ajax=1',
		data:$('#myform').serialize(),// 你的formid
		dataType:'json',
		error: function(request) {
			layer.close(index);
			alert("操作失败,请稍后再试");
			document.getElementById('registerbut').onclick = function(){ sregister(); };
		},
		success: function(data) {
			layer.close(index);
			if(data.status == -1){
				layer.msg('账号已注册过!');
			}else if (data.status == 1) {
				layer.msg('注册成功!',{time:1500});
				setTimeout(function (){
					var forward_ = "<?php echo $_GET['forward'];?>"
					var url = forward_ ? "<?php echo urldecode($_GET['forward']);?>" : "<?php echo siteurl(1);?>";
					window.location.href= url;
				},1500);
				
			} else {
				layer.msg(data.msg);
			}
			
			document.getElementById('registerbut').onclick = function(){ sregister(); };
		}
	});	
}
function goweixin(){
	var forward;
	forward = '<?php echo urlencode($_GET[forward]);?>';
	//forward = forward? forward : 'index?m=member';//getCookie('r2') ;
	
	window.location.href='index.php?m=member&c=wxapi&forward2='+forward+'<?php if(isset($_GET[i]) && $_GET[i]) { ?>&i=<?php echo $_GET['i'];?><?php } ?>';
}
function goregister(siteid){
	if (siteid == 1) {
		$('#myform').attr('style','display:block');
		$('#form_1').attr('style','display:none');
		$('.header_title').text('商家注册')	
	} else if (siteid == 2) {
		window.location.href = 'index.php?m=member&c=index&a=register';
	}
}
</script>