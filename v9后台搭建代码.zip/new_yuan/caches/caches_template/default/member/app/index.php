<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $title='会员中心';?>
<?php include template('member','header_common',$this->style); ?>
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>shop_tmp/index6/css/style6.css?<?php echo SYS_TIME;?>" />
<link type="text/css" rel="stylesheet" href="<?php echo SPATH;?>member/app/css/index.css" />
<link rel="stylesheet" media="(min-width:640px)" href="<?php echo SPATH;?>wb_shop/css/small.css" />
<script type="text/javascript" src="<?php echo SPATH;?>js/layer/1.9.3/layer.js" charset="UTF-8"></script>
<style>
body{
	padding-top:0px;
}
.main{
	padding-top:0px;
	position:relative;
	width:100%;
}
.unMemberBtn {
	font-size: 0.8rem;
    padding: 0 10px;
    color: #fff !important;
}

</style>
<div class="main">
  <div class="member_center">
    <div class="mc_infotop_box">
      <div class="mc_info">
      <!--index.php?m=member&a=account_manage_avatar&t=2&plat=<?php echo $_GET['plat'];?>-->
        <a href="javascript:;">
        <div class="mc_info_tx fl">
        	<?php $headimg = $userid&&is_weixin()?$memberinfo['headimgurl']:get_memberavatar($memberinfo['userid'],1,90);?>
          <img src="<?php if($headimg) { ?><?php echo $headimg;?><?php } else { ?>/phpsso_server/statics/images/member/nophoto.gif<?php } ?>" />
        </div>
        </a>
        
        <div class="mc_info_mes fl" style=" margin:15px 0 0 0">
          <?php if($userid) { ?><a href="javascript:;" onClick="url_header('index.php?m=wb_shop&a=baseinfo_edit')"><h2>用户名:<?php if($memberinfo['nickname']) { ?> <?php echo $memberinfo['nickname'];?> <?php } else { ?> <?php echo $memberinfo['username'];?> </h2></a><?php } ?>
          <?php } else { ?>
          <h2><a href="javascript:;" onClick="url_header('index.php?m=member&c=index&a=login')" class="unMemberBtn">登录</a>/<a class="unMemberBtn" href="javascript:;" onClick="url_header('index.php?m=member&c=index&a=login&rg=1')">注册</a></h2>
          <?php } ?>
          
        </div>
        <?php if($userid) { ?><a href="javascript:;" onClick="url_header('index.php?m=wb_shop&a=baseinfo_edit')"><div class="mc_info_onck fl"><i class="mc_dj"></i></div></a><?php } ?>
      </div>
      <div class="mc_lb">
        <div class="mclb_box">
          <div class="mclb_left fl">
            <div onClick="url_header('index.php?m=member&a=favorite');" class="mclb_ygwz">
              <!-- <h3><?php echo $number;?>4</h3>-->
              <h3><?php echo $sc_shu;?></h3>
              <h2>收藏商品</h2>
            </div>
          </div>
          <div class="mclb_left fr">
            <div class="mclb_ygwz" onClick="url_header('index.php?m=wb_shop&a=liulan');">
              <h3><?php echo $ll_shu;?></h3>
              <h2>浏览记录</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="clear"></div>
    <div class="my_order_box">
      <div class="mclist_box" style="width:94%;">
        <div class="mclbox_img fl">
          <img src="<?php echo SPATH;?>member/app/images/ico22.jpg" />
        </div>
        <div class="mclbox_wz fl">
          <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&c=index&a=order')">
          <h2>我的订单</h2>
          <h5>查看更多订单</h5>
          <span class="mclbox_link" style="right:4px;"></span>
          </a>
        </div>
      </div>
      <div class="mrb_box">
        <ul>
          <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&c=index&a=order')">
          <li class="mrb_box_li">
            <h5><?php if($suo_dds) { ?><?php echo $suo_dds;?><?php } else { ?>0<?php } ?></h5>
            <h5>所有订单</h5>
          </li>
          </a>
          <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&c=index&a=order&status=1')">
          <li class="mrb_box_li">
            <h5><?php if($dfk_dds) { ?><?php echo $dfk_dds;?><?php } else { ?>0<?php } ?></h5>
            <h5>待付款</h5>
          </li>
          </a>
          <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&c=index&a=order&status=2')">
          <li class="mrb_box_li">
            <h5><?php if($dsh_dds) { ?><?php echo $dsh_dds;?><?php } else { ?>0<?php } ?></h5>
            <h5>待发货</h5>
          </li>
          </a>
          <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&c=index&a=order&status=99')">
          <li class="mrb_box_li">
            <h5><?php if($ywc_dds) { ?><?php echo $ywc_dds;?><?php } else { ?>0<?php } ?></h5>
            <h5>已完成</h5>
          </li>
          </a>
        </ul>
      </div>
    </div>
    <div class="clear"></div>
    <div class="mc_thlist">
    <a href="javascript:;" onClick="url_header('index.php?m=member&c=address')">
      <div class="mclist_box">
        <div class="mclbox_img fl">
          <img src="<?php echo SPATH;?>member/app/images/ico23.jpg" />
        </div>
        <div class="mclbox_wz fl">
          <h2>收货地址</h2>
          <span class="mclbox_link"></span>
        </div>
      </div>
     </a>
      <div class="clear"></div>
      <a href="javascript:;" onClick="url_header('index.php?m=coupon&a=coupon_list')">
          <div class="mclist_box">
            <div class="mclbox_img fl">
              <img src="<?php echo SPATH;?>member/app/images/ico24.jpg" />
            </div>
            <div class="mclbox_wz fl">
              
              <h2>优惠券</h2>
              <span class="mclbox_link"></span>
              
            </div>
          </div>
      </a>
      <div class="clear"></div>
    </div>
    <div class="clear"></div>
    <div class="mc_thlist">
    <a href="javascript:;" onClick="url_header('index.php?m=wb_shop&a=baseinfo_edit')">
      <div class="mclist_box">
            <div class="mclbox_img fl">
                <img src="<?php echo SPATH;?>member/app/images/ico30.jpg" />
            </div>
            <div class="mclbox_wz fl">
                <h2>个人信息修改</h2>
                <span class="mclbox_link"></span>
            </div>
      </div>
    </a>
      <div class="clear"></div>
    <a href="javascript:;" onClick="url_header('index.php?m=member&a=account_manage_password&om=1')">
      <div class="mclist_box">
        <div class="mclbox_img fl">
          <img src="<?php echo SPATH;?>member/app/images/ico31.jpg" />
        </div>
        <div class="mclbox_wz fl">
          <h2>密码修改</h2>
          <span class="mclbox_link"></span>
        </div>
      </div>
    </a>
      <div class="clear"></div>
      <a href="javascript:;" onClick="url_header('index.php?m=member&a=logout')">
      <div class="mclist_box">
        <div class="mclbox_img fl">
          <img src="<?php echo SPATH;?>member/app/images/ico32.jpg" />
        </div>
        <div class="mclbox_wz fl">
          <h2>安全退出</h2>
          <span class="mclbox_link"></span>
        </div>
      </div>
      </a>
      <div class="clear"></div>
    </div>
  </div>
</div>
<?php include template('wb_shop','footer',$this->style); ?>
</body>
<script>
/*function url_header(url) {
	//var e = event || window.event;
	var url = url !='' ?url:window.location.href;
	creatLoading(6*1000);
	window.location.href = url;
}
function creatLoading(time){
	time = time?time:8000;
	var width= document.documentElement.clientWidth || document.body.clientWidth;
	var height = document.documentElement.clientHeight || document.body.clientHeight;
	var loadLeft = (width/2) + 'px';
	var loadTop = (height/2) + 'px';
	var html_ = document.createElement('div');
	html_.innerText = '加载中...';
	html_.setAttribute('class','loadBox');
	html_.setAttribute('id','loadBox');
	html_.style.width = '65px';
	html_.style.height = '30px';
	html_.style.lineHeight = '31px';
	html_.style.paddingLeft = '20px';
	html_.style.position = 'fixed';
	html_.style.marginLeft = '-32px';
	html_.style.marginTop = '-15px';
	html_.style.left = loadLeft;
	html_.style.top = loadTop;
	html_.style.background = "url('statics/wpm/images/load_icon.gif') no-repeat 0 50%";
	html_.style.fontSize = '0.7rem';
	html_.style.color = '#FFC600';
	if (document.getElementById('loadBox')) {
		document.getElementById('loadBox').style.display = 'block';
	} else {
		document.body.appendChild(html_);
	}
	setTimeout(function(){
		document.getElementById('loadBox').style.display = 'none';
	},time);
}*/
</script>
</html>