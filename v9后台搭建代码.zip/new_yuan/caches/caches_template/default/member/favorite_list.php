<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename = '我的收藏';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<style>
.fl { float:left;}
.box_1 .userCenterBox .userMenu a { margin-bottom: 5px; font-size: 14px; }
.favorite_list { padding:15px; overflow:hidden;}
.favorite_box { width:100%;}
.favorite_box_item {
	width: 25%;
    float: left;
	position:relative;	
}
.favorite_box_item p.goods_img { width:100%; text-align:center;}
.favorite_box_item p.goods_img img { width:70%;}
.favorite_box_item p.goods_title {
	padding: 0 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;	
}
.favorite_box_item span.goods_money { padding:0 20px; color:red}
.black_bg { width:100%; height:162px; background-color:#333; opacity:0.7; display:none; position:absolute; top:0; left:0;}
.del_icon { display:block; width:20px; height:20px; background:url('statics/wb_shop/images/del_icon.png') no-repeat center; background-size:20px; position:absolute; right:5px; top:5px; z-index:999}
.empty_box { text-align:center; width:100%; margin:10px 0;}
/*新增地址box*/
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 我的收藏 </div>
</div>
<div class="blank"></div>
<div class="tt01">
  <div class="tt01_box"> <?php include template("member", "member_left"); ?>
    <div class="member_right">
      <div class="news_order">
        <p class="order_title"><font>我的收藏</font></p>
        <div class="favorite_list">
        	<div class="favorite_box">
            <?php if($favoritelist) { ?>
            <?php $n=1;if(is_array($favoritelist)) foreach($favoritelist AS $r) { ?>
            	<div class="favorite_box_item" id="favo_<?php echo $r['id'];?>">
                	<p class="goods_img"><img src="<?php echo $goodsinfo[$r['pid']]['thumb'];?>"></p>
                    <p class="goods_title">
                    	<a href="<?php echo $r['url'];?>">
                        <?php echo $goodsinfo[$r['pid']]['title'];?>
                        </a>
                    </p>
                    <span class="goods_money">￥<?php echo number_format($goodsinfo[$r['pid']]['jiage'], 2);?></span>					<a class="del_icon" href="javascript:;" onClick="del_favorite('<?php echo $r['id'];?>')"></a>
                    <div class="black_bg"></div>
                </div>
            <?php $n++;}unset($n); ?>
            <?php } else { ?>
            <div class="empty_box">暂无收藏记录</div>
            <?php } ?>
            </div>
        </div>
      </div>
      <!--news_order end-->
    </div>
  </div>
</div>

<div class="blank"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script>
window.onload = function () {
	var favo_item = $('.favorite_box_item');
	favo_item.each(function(i) {
        $(favo_item[i]).mousemove(function () {
			$(this).find('.black_bg').fadeIn();
			$(this).find('.del_icon').fadeIn();
		});
		$(favo_item[i]).mouseleave(function () {
			$(this).find('.black_bg').fadeOut();
			$(this).find('.del_icon').fadeOut();
		});
    });
	
};
function del_favorite (id) {
	if (!id) { return;}
	var index = layer.load(1,{time: 100*1000});
	$.get('index.php?m=member&a=favorite&ajax=1&id='+id, function (data) {
		layer.close(index);
		layer.msg(data.msg);
		if (data.status == 1) {
			$('#favo_'+id).fadeOut();
			/*setTimeout(function () {
				window.location.reload();
			}, 2000);*/
		}
	}, 'json');
}
</script>
</html>