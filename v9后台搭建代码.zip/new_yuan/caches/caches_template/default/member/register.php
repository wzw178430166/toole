<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php include template('wb_shop','header_common'); ?>
<style>
.col-reg{ width:1200px; overflow:hidden; margin:35px auto; background-color:#fff; padding:40px 0px;}
.col-reg_line{ width:100%; overflow:hidden; color:#cccccc;}
.col-reg_line li{ text-align:center; float:left; width:33.3%; border-bottom:3px solid #cccccc; height:30px; line-height:30px;}
.col-reg_line .active{ border-bottom:3px solid #ee0a3b; color:#ee0a3b;}
.col-reg_box{ width:90%; padding:60px 5%;}
.col-reg .col-reg_box{ width:80%; padding:60px 10%;}
.col-reg_box .col-reg_box_1{ width:100%; overflow:hidden;}
.col-reg_box_1 .col-reg_box_1l{ width:65%; overflow:hidden; padding-right:8%; border-right:1px solid #eee; padding-top:25px;}
.col-reg_box_1l .col-reg_box_1l_line{ width:100%; overflow:hidden; margin-bottom:20px;}
.col-reg_box_1l_line .col-reg_box_1l_line_{ float:left; margin-right:10px; height:30px; line-height:30px; width:75px;}
.col-reg_box_1l_line_ i{ float:right; font-style:normal;}
.col-reg_box_1l_line span{ color:#ee0a3b; margin:0px 5px;}
.col-reg_box_1l_line .nobd{ width:290px; height:30px; line-height:30px; border:1px solid #eee; border-radius:5px; float:left; margin-right:15px; padding-left:10px;}
.col-reg_box_1l_line p{ float:left; height:30px; line-height:30px;}
.col-reg_box_1l_line img{ vertical-align:sub; margin-right:5px;}
.col-reg_box_1l_line .submit{ width:150px; height:32px; line-height:32px; text-align:center; background-color:#ff8800; color:#fff; cursor:pointer;}
.col-reg_box_1l_line .next{ width:300px; height:35px; line-height:35px; text-align:center; background-color:#009fd9; color:#fff; border-radius:5px; cursor:pointer;}
.col-reg_box_1l_line .col-reg_box_1l_id{ width:160px; height:99px; border:1px solid #eee; border-radius:5px; float:left; margin-right:10px;}
.col-reg_box_1l_line .col-reg_box_1l_id img{ width:146px; height:89px; display:block;}
.col-reg_box_1 .col-reg_box_1r{ width:200px; overflow:hidden; margin-left:50px; padding-bottom:10px; padding-top:25px;}
.col-reg_box_1r .login{ width:100px; height:30px; line-height:30px; text-align:center; background-color:#ff8800; color:#fff; border-radius:5px; margin:15px auto; display:block;}
.col-reg_box_1r .service{ overflow:hidden; padding:20px 0px; border-top:1px dotted #eee; border-bottom:1px dotted #eee;}
.col-reg_box_1r .service p{ margin-bottom:10px;}
.col-reg_box_1r .service span{ color:#ff8800;}
.col-reg_box_1r .service img{ width:20px; height:20px; vertical-align:sub; margin-right:10px;}
.col-reg_box .col-reg_box_2{ width:80%; overflow:hidden; padding:0px 10%;}
.col-reg_box_2 .col-reg_box_2t{ width:100%; overflow:hidden; text-align:center; margin-bottom:30px;}
.col-reg_box_2 .col-reg_box_2b{ width:100%; overflow:hidden;}
.col-reg_box_2 .col-reg_box_2b li{ width:33.3%; float:left; text-align:center;}
.col-reg_box_2 .col-reg_box_2b img{ width:93px; height:93px; display:block; margin-bottom:10px;}
.col-reg_box_2 .col-reg_box_2b p{ color:#808080;}
.form-tips { display:none;}
</style>
<body>
<!---header_start--->
<?php include template('wb_shop','header'); ?>
<!---header_end--->
<div style="width:100%; overflow:hidden; background-color:#f5f5f5;">
    <div class="col-reg">
    	<div class="col-reg_line">
        	<ul>
            	<li class="active">①注册账号</li>
                <li>②完善资料</li>
                <li>③注册完成</li>
            </ul>
        </div>
        <div class="col-reg_box">
        	<div class="col-reg_box_1">
            	<div class="col-reg_box_1l fl">
                    <form method="post" action="" id="register_form">
                        <div class="col-reg_box_1l_line">
                        	<div class="col-reg_box_1l_line_">
                            	<i><span>*</span>手机号码</i>
                            </div>
                            <input type="text" class="nobd" name="username" id="username" onBlur="checkUsername(this)">
                            <p class="form-tips succ_tips"><img src="<?php echo SPATH;?>ku/images/iconfont-gouxuan.png" style="width:17px; height:17px;">手机号码用于登录，密码找回</p>
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_">
                            	<i><span>*</span>设置密码</i>
                            </div>
                            <input type="password" class="nobd" name="password" id="password" onBlur="checkPassword(this)">
                            <p class="form-tips error_tips"><img src="<?php echo SPATH;?>ku/images/iconfont-zhuyi.png">密码由6-20位任意字符组成</p>
                            <p class="form-tips succ_tips"><img src="<?php echo SPATH;?>ku/images/iconfont-gouxuan.png" style="width:17px; height:17px;"></p>
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_">
                            	<i><span>*</span>确认密码</i>
                            </div>
                            <input type="password" name="repassword" id="repassword" class="nobd" onBlur="checkPassword(this)">
                            <p class="form-tips error_tips"><img src="<?php echo SPATH;?>ku/images/iconfont-zhuyi.png">请再次输入密码</p>
                            <p class="form-tips succ_tips"><img src="<?php echo SPATH;?>ku/images/iconfont-gouxuan.png" style="width:17px; height:17px;"></p>
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_">
                            	<i><span>*</span>手机验证码</i>
                            </div>
                            <input type="text" name="code" id="code" class="nobd" style="width:150px; margin-right:5px;">
                            <a class="submit nobd fl" id="btn">获取短信验证</a>
                        </div>
                        <div class="col-reg_box_1l_line">
                        	<div class="col-reg_box_1l_line_r" style="margin-left:85px; margin-bottom:20px;">
                            	<input type="checkbox" checked="checked" style="background-color:#009fd9; margin-right:5px;">我已阅读并同意<a href="javascript:;" style="color:#009fd9;">《唐剑云掌天下服务协议》</a>
                            </div>
                        </div>
                        <div class="col-reg_box_1l_line">
                        	<div class="col-reg_box_1l_line_r" style="margin-left:85px; margin-bottom:20px;">
                            	<input type="button" value="下一步" class="next nobd" onClick="send_register()">
                            </div>
                        </div>
                        <input type="hidden" name="dosubmit" value="1">
                    </form>
                </div>
                <div class="col-reg_box_1r fr">
                	<p style="text-align:center;">已有海外巴巴账号</p>
                    <a href="index.php?m=member&a=login" class="login nobd">立即登录</a>
                    <div class="service">
                    	<p style="font-size:15px; margin-bottom:15px; text-align:center;"><img src="<?php echo SPATH;?>ku/images/login_service.png"><span>成为会员获得以下服务</span></p>
                        <p>1.采购<span>进口低价</span>优质名品</p>
                        <p>2.成本0，轻松做海淘代销，<span>利润高</span></p>
                        <p>3.精选海外优质名品，保证<span>100%原装正货</span></p>
                        <p>4.报关关税不用愁，<span>海外直邮到您家</span></p>
                        <p>5.提供成熟的货物存储管理系统，发货收款<span>更轻松</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-reg_box" style="display:none;">
        	<div class="col-reg_box_1">
            	<div class="col-reg_box_1l fl">
                    <form method="#" action="#">
                        <div class="col-reg_box_1l_line">
                        	<div class="col-reg_box_1l_line_">
                            	<i><span>*</span>真实姓名</i>
                            </div>
                            <input type="text" class="nobd">
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_">
                            	<i><span>*</span>身份证号码</i>
                            </div>
                            <input type="text" class="nobd">
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_">
                            	<i><span>*</span>邮箱地址</i>
                            </div>
                            <input type="text" class="nobd">
                        </div>
                        <div class="col-reg_box_1l_line">
                            <div class="col-reg_box_1l_line_" style="height:inherit;">
                            	<i><span>*</span>身份证原件<u style="float:right; text-decoration:none;">正反面</u></i>
                            </div>
                            <div class="col-reg_box_1l_id">
                            	<img src="<?php echo SPATH;?>ku/images/id_zheng.png">
                            </div>
                            <div class="col-reg_box_1l_id">
                            	<img src="<?php echo SPATH;?>ku/images/id_fan.png">
                            </div>
                        </div>
                        <div class="col-reg_box_1l_line">
                        	<div class="col-reg_box_1l_line_r" style="margin-left:85px; margin-bottom:20px;">
                            	<input type="submit" value="完成注册" class="next nobd">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-reg_box_1r fr">
                	<p style="text-align:center;">已有海外巴巴账号</p>
                    <a href="index.php?m=member&a=login" class="login nobd">立即登录</a>
                    <div class="service">
                    	<p style="font-size:15px; margin-bottom:15px; text-align:center;"><img src="<?php echo SPATH;?>ku/images/login_service.png"><span>成为会员获得以下服务</span></p>
                        <p>1.采购<span>进口低价</span>优质名品</p>
                        <p>2.成本0，轻松做海淘代销，<span>利润高</span></p>
                        <p>3.精选海外优质名品，保证<span>100%原装正货</span></p>
                        <p>4.报关关税不用愁，<span>海外直邮到您家</span></p>
                        <p>5.提供成熟的货物存储管理系统，发货收款<span>更轻松</span></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-reg_box" style="display:none;">
        	<div class="col-reg_box_2">
            	<div class="col-reg_box_2t">
                	<p style="font-size:20px;"><img src="<?php echo SPATH;?>ku/images/iconfont-gouxuan.png" style="width:30px; height:30px; margin-right:10px; vertical-align: bottom;">恭喜您，申请成功</p>
                    <p style="color:#808080; height:40px; line-height:40px;">稍后我们的客户人员会电话联系您，确认信息后，即可完成</p>
                </div>
                <div class="col-reg_box_2b">
                	<ul>
                    	<li>
                        	<div class="col-reg_box_2b_">
                            	<img src="<?php echo SPATH;?>ku/images/col-reg_box_2b_1.png">
                                <p>轻松做海淘代购没，利润高</p>
                            </div>
                        </li>
                        <li>
                        	<div class="col-reg_box_2b_">
                            	<img src="<?php echo SPATH;?>ku/images/col-reg_box_2b_2.png">
                                <p>精选优品，保证100%原装正货</p>
                            </div>
                        </li>
                        <li>
                        	<div class="col-reg_box_2b_">
                            	<img src="<?php echo SPATH;?>ku/images/col-reg_box_2b_3.png">
                                <p>成熟的货物存储管理系统</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!---footer_start---->
<?php include template('wb_shop','footer'); ?>
<!---footer_end---->
</body>
</html>
<script>
$('.col-reg_line ul li').click(function(){
	$(this).addClass('active').siblings().removeClass('active');
	var _index = $(this).index();
	$('.col-reg_box').eq(_index).show().siblings('.col-reg_box').hide();
	});
$('.col-reg_box').eq(0).show().siblings('.col-reg_box').hide();
</script>
<script language="JavaScript">
function send_register(){
	var i = "<?php echo $_GET['i'];?>";
	var k = "<?php echo $_GET['k'];?>";
	if($.trim($('#username').val())==''){ layer.msg("手机号码不能为空"); return;}
	if($.trim($('#password').val().length)<6){ layer.msg("密码不得小于6位数"); return;}
	if($.trim($('#password').val())==''){ layer.msg("密码不能为空"); return;}
	if($.trim($('#repassword').val())!==$('#password').val()){ layer.msg("密码不一致"); return;}
	if($.trim($('#code').val())==''){ layer.msg("请输入验证码!"); return;}
	var index = layer.load(2, {time:10*1000});
$.ajax({
		cache: true,
		type: "POST",
		dataType:"json",
		url:'index.php?m=member&a=register&ajax=1&ifram=1&i='+i+'&k='+k,
		data:$('#register_form').serialize(),// 你的formid
		error: function(request) {
			showloadbox('',1);
			alert("操作失败,请稍后再试");
			document.getElementById('registerbut').onclick = function(){ sregister(); };
		},
		success: function(data) { 
			layer.close(index);
			setTimeout(function(){
				if(data.status == 1){
					layer.msg('注册成功', {time:2000});
					var urls = "index.php?m=member&c=index";
					setTimeout(function() {
						window.location.href= urls;
					}, 2000);
					
				}else{
					if(data.status==2){
						layer.msg('该手机号码已注册', {time:2000});
					}else{
						layer.msg(data.msg, {time:2000});
					}
				}
				document.getElementById('registerbut').onclick = function(){ sregister(); };
		},80)},
	});	
}

function checkUsername(obj){
	
	var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
	var phone = $.trim($(obj).val());
	if (phone != '' && myreg.test(phone)) {
		$(obj).parent().find('.succ_tips').show();
	} else {
		$(obj).parent().find('.succ_tips').hide();
	}
}
function checkPassword(obj){
	var password = $.trim($(obj).val());
	$(obj).parent().find('.form-tips').hide();
	if (password  != '' && password.length>=6) {
		$(obj).parent().find('.succ_tips').show();
	} else {
		$(obj).parent().find('.error_tips').show();	
	}
}
</script>
<script language="javascript" type="text/javascript">
var interval = null;
var btn = document.getElementById ('btn');
var time_s = "<?php echo pc_base::load_config('system','sms_time');?>";
btn.onclick = function (){
	sendcode();
}
function sendcode(){
	if(!interval){
		var phone = $.trim($('#username').val());
		if(phone==''){ 
			layer.msg('请填写手机号码');
			$('#username').focus();
			return;
		}
		btn.style.backgroundColor = 'rgb(204, 204, 204)';
		btn.disabled = "disabled";
		btn.style.cursor = "wait";
		btn.innerHTML = "发送中";	
		//btn.onclick = function(){};
		//time_s = 40;
		
		//sendcode_affter();
		$.ajax({
		type: "get",
		dataType: "json", 
		url:'index.php?m=member&a=public_sendsms_ajax',
		data:'phone='+phone,// 你的formid
		success: function(da){
				if(da.status=='1'){
					sendcode_affter();			
				}else{
					sendcode_huanyuan();
					if(da.msg){ layer.msg(da.msg); }	
					
				}
		 	},
		error: function(request) {
				layer.msg('网络错误');
				sendcode_huanyuan();
			},
		});
	}
}
function sendcode_huanyuan(){
	clearInterval (interval);
	interval = null;
	btn.style.cursor = "pointer";
	btn.removeAttribute ('disabled');
	btn.innerHTML = "重发验证码";
	btn.style.backgroundColor = '#06A204';
	btn.onclick = function(){ sendcode(); }
}
function sendcode_affter(){

	if (time_s<=0){
		sendcode_huanyuan();
	}else{
		btn.innerHTML = "已发送("+time_s+")";
		time_s --;
		interval = window.setTimeout('sendcode_affter()',1000);	
	}
}

function checkUserName () {
	var url = '';
	var username = $('#username').val();
	if (username  == '' || username.length != 11) { 
		layer.msg('请正确输入手机号码');
		return;
	}
	if ($('#is_register').val() == 1 && username == $('#is_register').attr('data-tips')) { 
		layer.msg('该账号已被注册!');
		return;
	}
	
	url = 'index.php?m=member&c=index&a=checkUserName_ajax&ajax=1&username=' + username;	
	$.get(url, function (data) {
		if (data.status == 1) {
			layer.msg(data.msg);	
			$('#username').focus();
			$('#is_register').attr('value', 1);
			$('#is_register').attr('data-tips', username);
		}
	}, 'json');
}
</script>