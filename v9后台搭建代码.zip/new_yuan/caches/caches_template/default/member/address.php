<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename = '地址管理';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<style>
.fl { float:left;}
.box_1 .userCenterBox .userMenu a { margin-bottom: 5px; font-size: 14px; }
.m, .mb, .mc, .mt, .sm, .smb, .smc, .smt { overflow: hidden; zoom: 1; }
.mod-main { padding: 10px; background-color: #fff;}
.mod-comm { padding: 10px 20px 20px; }
.mod-main .mt { display: inline-block; display: block; padding: 10px; }
.mod-comm .mt { padding: 10px 0; }
.btn-5, .btn-6, .btn-7, .btn-8 { background-color: #f5fbef; background-image: -moz-linear-gradient(top, #f5fbef, #eaf6e2); background-image: -webkit-gradient(linear, left top, left bottom, color-stop(0, #f5fbef), color-stop(1, #eaf6e2));  filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5fbef', endColorstr='#eaf6e2', GradientType='0');
 -ms-filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5fbef', endColorstr='#eaf6e2');
background-image: linear-gradient(to bottom, #f5fbef 0, #eaf6e2 100%); -webkit-border-radius: 2px; -moz-border-radius: 2px; border-radius: 2px; display: inline-block; height: 18px; line-height: 18px; border: 1px solid #bfd6af; padding: 2px 14px 3px; color: #323333; }
a.add-btn { display: inline-block; vertical-align: middle; font-weight: 700; padding: 0 14px; height: 28px; line-height: 28px; font-size: 14px; margin: 0 10px 0 0; }
.ftx-03, .ftx03 { color: #999; }
.ftx-02, .ftx02 { color: #71b247; }
.mod-main .mc { overflow: visible; }
.mod-comm .mc { line-height: 20px; }
.m, .sm { margin-bottom: 10px; }
.easebuy-m { border: 2px solid #e6e6e6; margin: 0 0 10px; }
.easebuy-m .smt { padding-left: 10px; line-height: 35px; height: 35px; position: relative; display: inline-block; display: block; overflow: visible; }
.mt h2, .smt h3 { font-family: "microsoft yahei"; }
.easebuy-m .smt h3 { float: left; color: #666; background-color: #fff; }
.easebuy-m .smt .alias-edit { display: inline-block; background-image: url(statics/wb_shop/images/sprite-t-icon.png); background-repeat: no-repeat; }
.easebuy-m .smt .alias-edit { width: 12px; height: 12px; background-position: -51px 0; margin: 0 10px; }
.ml10 { margin-left: 10px; }
.ftx-04, .ftx04 { color: #ff6c00; }
.easebuy-m .smt h3 .ftx-04 { margin: 0 0 0 10px; font-size: 12px; background: #ffaa45; padding: 2px; color: #fff; font-weight: 400; float: initial;}
.easebuy-m .smt .extra { float: right; margin: 0 10px 0 0; }
.easebuy-m .smt .extra a { color: #005ea7; margin: 0 0 0 20px; }
.easebuy-m .smt .extra .del-btn { margin-top: 10px; display: inline-block; width: 13px; height: 13px; text-indent: 99em; background: url(statics/wb_shop/images/close.png) no-repeat; overflow: hidden; vertical-align: middle; }
.easebuy-m .smc { padding: 10px; line-height: 22px; width: 788px; }
.easebuy-m .smc .new-items { position: relative; width: 788px; overflow: hidden; }
.easebuy-m .smc .item-lcol { width: 450px; float: left; }
.easebuy-m .smc .item span { float: left; width: 70px; color: #999; text-align: right; }
.easebuy-m .smc .item-lcol .fl { width: 360px; }
.easebuy-m .smc .item-rcol { width: 320px; float: left; padding-left: 10px; height: 100%; }
.easebuy-m .smc .item-rcol .extra { position: absolute; right: 0; bottom: 0; }
.ftx-05, .ftx05 { color: #005ea7; }
.thickdiv {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 10000001;
    width: 100%;
    height: 100%;
    background: #000;
    border: 0;
    filter: alpha(opacity=15);
    opacity: .15;
	display:none;
}
.thickdiv {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 10000001;
    width: 100%;
    height: 100%;
    background: #000;
    border: 0;
    filter: alpha(opacity=15);
    opacity: .15;
}
.thickbox {
    position: fixed;
    z-index: 10000002;
    overflow: hidden;
    padding: 0;
    border: 4px solid rgba(0,0,0,.1);
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
	display:none;
}
.thicktitle {
    height: 27px;
    padding: 0 10px;
    border-bottom: 1px solid #C4C4C4;
    background: #F3F3F3;
    line-height: 27px;
    font-family: arial,"\5b8b\4f53";
    font-size: 14px;
    font-weight: 700;
    color: #333;
}
.thicktitle {
    height: 27px;
    padding: 0 10px;
    border-bottom: 1px solid #C4C4C4;
    background: #F3F3F3;
    line-height: 27px;
    font-family: arial,"\5b8b\4f53";
    font-size: 14px;
    font-weight: 700;
    color: #333;
}
.thickcon {
    overflow: auto;
    background: #fff;
    padding: 10px;
}
.thickcon {
    overflow: auto;
    background: #fff;
    padding: 10px;
}
#edit-cont {
    padding: 20px;
}
.form .item {
    display: inline-block;
    display: block;
    margin-bottom: 20px;
    line-height: 30px;
}
#edit-cont .item {
    margin: 0 0 5px;
    line-height: 22px;
}
.form .item span.label {
    float: left;
    height: 18px;
    line-height: 18px;
    padding: 6px 0;
    width: 100px;
    text-align: right;
}
#edit-cont .item .label {
    float: none;
    display: block;
    vertical-align: middle;
    color: #999;
    text-align: left;
	margin:0;
}
#edit-cont .item .label {
    float: none;
    display: block;
    vertical-align: middle;
    color: #999;
    text-align: left;
}
.form em {
    color: #e4393c;
}
.form .text {
    line-height: 18px;
    border: 1px solid #ccc;
}
.form .itxt, .form .text {
    height: 18px;
    width: 127px;
    padding: 5px 23px 5px 5px;
}
.form .itxt, .form .text {
    height: 18px;
    width: 127px;
    padding: 5px 23px 5px 5px;
}
#edit-cont .item .text {
    height: 18px;
    line-height: 18px;
    padding: 6px;
    width: 220px;
    margin-right: 5px;
    vertical-align: middle;
}
#edit-cont .item .text {
    height: 18px;
    line-height: 18px;
    padding: 6px;
    width: 220px;
    margin-right: 5px;
    vertical-align: middle;
}
.hide {
    display: none;
}
#edit-cont .item .error-msg {
    color: #c00;
    line-height: 32px;
}
.clear, .clr {
    display: block;
    overflow: hidden;
    clear: both;
    height: 0;
    line-height: 0;
    font-size: 0;
}
#edit-cont .item .text1 {
    width: 484px;
}
#edit-cont .item .text {
    height: 18px;
    line-height: 18px;
    padding: 6px;
    width: 220px;
    margin-right: 5px;
    vertical-align: middle;
}
#edit-cont .item .text1 {
    width: 484px;
}
#edit-cont .item .extra-span {
    margin: 26px 5px 0;
    display: block;
}
#edit-cont .btns {
    margin: 10px 0 0;
}
.btn-10, .btn-11, .btn-12, .btn-9 {
    background-color: #F7F7F7;
    background-image: -moz-linear-gradient(top,#F7F7F7,#F3F2F2);
    background-image: -webkit-gradient(linear,left top,left bottom,color-stop(0,#F7F7F7),color-stop(1,#F3F2F2));
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#F7F7F7', endColorstr='#F3F2F2', GradientType='0');
    -ms-filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#F7F7F7', endColorstr='#F3F2F2');
    background-image: linear-gradient(to bottom,#F7F7F7 0,#F3F2F2 100%);
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    border-radius: 2px;
    display: inline-block;
    height: 18px;
    line-height: 18px;
    border: 1px solid #ddd;
    padding: 2px 14px 3px;
    color: #323333;
}
a.save-btn {
    height: 28px;
    line-height: 28px;
    padding: 0 14px;
    font-size: 14px;
}
.thickclose {
	position: absolute;
    right: 10px;
    top: 5px;
    width: 15px;
    height: 15px;
    text-align: center;
    line-height: 15px;
    border-radius: 3px;
    background: url(statics/wb_shop/images/bg_thickbox.gif) no-repeat 0 -16px;
    background-size: 15px;
}
.pc-select-city { padding:5px;}
/*新增地址box*/
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 地址管理 </div>
</div>
<div class="blank"></div>
<div class="tt01">
  <div class="tt01_box"> <?php include template("member", "member_left"); ?>
    <div class="member_right">
      <div class="news_order">
        <p class="order_title"><font>地址管理</font></p>
        <div id="addressList" class="mod-main mod-comm">
          <div class="mt"> 
          <a onClick="edit_add_box()" class="e-btn add-btn btn-5" href="javascript:;"> 新增收货地址 </a> 
          <span class="ftx-03"> 您已创建 <span id="addressNum_top" class="ftx-02"> <?php echo count($address);?> </span> 个收货地址，最多可创建 <span class="ftx-02">8</span>个</span> </div>
          <div class="mc">
          <?php $n=1;if(is_array($address)) foreach($address AS $r) { ?>
            <div class="sm easebuy-m " id="address_<?php echo $r['id'];?>">
              <div class="smt">
                <h3> <?php echo $r['contactname'];?> <?php if($memberinfo['addressid'] == $r['id']) { ?><span class="ftx-04 ml10">默认地址</span><?php } ?></h3>
                <div class="extra"> <a onClick="del_address('<?php echo $r['id'];?>');" class="del-btn" href="#none">删除</a> </div>
              </div>
              <div class="smc">
                <div class="items new-items">
                  <div class="item-lcol">
                    <div class="item"> <span class="label">收货人：</span>
                      <div class="fl"> <?php echo $r['contactname'];?> </div>
                      <div class="clr"></div>
                    </div>
                    <div class="item"> <span class="label">所在地区：</span>
                      <div class="fl"> <?php echo $r['sheng'];?><?php echo $r['shi'];?> </div>
                      <div class="clr"></div>
                    </div>
                    <div class="item"> <span class="label">地址：</span>
                      <div class="fl"> <?php echo $r['address'];?> </div>
                      <div class="clr"></div>
                    </div>
                    <div class="item"> <span class="label">手机：</span>
                      <div class="fl"> <?php echo substr_cut($r['phone'], 3, 2);?> </div>
                      <div class="clr"></div>
                    </div>
                    <div class="item"> <span class="label">固定电话：</span>
                      <div class="fl"> <?php echo $r['tel'];?> </div>
                      <div class="clr"></div>
                    </div>
                    <div class="item"> <span class="label">邮政编码：</span>
                      <div class="fl"> <?php echo $r['zipcode'];?> </div>
                      <div class="clr"></div>
                    </div>
                  </div>
                  <div class="item-rcol">
                    <div class="extra"> 
                    <?php if($r['id'] != $memberinfo['addressid']) { ?>
                    <a class="ml10 ftx-05" href="javascript:set_mr('<?php echo $r['id'];?>');"> 设为默认 </a>
                    <?php } ?>
                    <a class="ml10 ftx-05" href="javascript:;" onClick="edit_add_box('<?php echo $r['id'];?>');"> 编辑 </a> </div>
                  </div>
                  <div class="clr"></div>
                </div>
              </div>
            </div>
            <?php $n++;}unset($n); ?>
          </div>
          <div class="mt"> <a onClick="edit_add_box()" class="e-btn add-btn btn-5" href="javascript:;"> 新增收货地址 </a> <span class="ftx-03"> 您已创建 <span id="addressNum_top" class="ftx-02"> <?php echo count($address);?> </span> 个收货地址，最多可创建 <span class="ftx-02">8</span>个</span> </div>
        </div>
      </div>
      <!--news_order end--> 
    </div>
  </div>
</div>
<div class="thickdiv" id="thickdiv" style="width: 100%;"></div>
<div class="thickbox" id="thickbox" style="left: 50%; top: 50%; width: 762px; height: 460px; margin-left:-380px; margin-top:-230px; background-color:#fff;">
  <div class="thickwrap" style="width: 760px;">
    <div class="thicktitle"><span>添加收货地址</span></div>
    <div class="thickcon" style="width: 740px; padding-left: 10px; padding-right: 10px;">
      <div id="addressDiagDiv">
        <title>收货地址</title>
        <div class="m" id="edit-cont">
          <div class="mc">
            <div class="form">
              <div class="item"> <span class="label"><em>*</em>收货人：</span>
                <div class="fl">
                  <input id="contactname" name="contactname" type="text" class="text">
                  <span id="consigneeNameNote" class="error-msg hide"></span> </div>
                <div class="clr"></div>
              </div>
              <div class="item"> <span class="label"><em>*</em>所在地区：</span>
                <div class="fl"> 
                	<?php echo menu_linkage(1, 'city');?>
                	<span class="error-msg" id="areaNote"></span> 
                </div>
                <div class="clr"></div>
              </div>
              <div class="item"> <span class="label"><em>*</em>详细地址：</span>
                <div class="fl"> <span style="float: left;margin-right: 5px;line-height:32px;" id="areaName"></span>
                  <input id="address" name="address" type="text" class="text text1" >
                </div>
                <span class="error-msg" id="consigneeAddressNote"></span>
                <div class="clr"></div>
              </div>
              <div class="item">
                <div class="fl"> <span class="label"><em>*</em>手机号码：</span>
                  <input id="phone" name="phone" type="text" maxlength="11" class="text">
                </div>
                <div class="fl"><span class="extra-span ftx-03">或</span></div>
                <div class="fl"> <span class="label">固定电话：</span>
                  <input id="tel" type="text" class="text">
                  <span class="error-msg hide" id="consigneeMobileNote"></span> <span class="clr"></span> </div>
                <div class="clr"></div>
              </div>
              <div class="item"> <span class="label"><em>*</em>邮政编码：</span>
                <div class="fl">
                  <input id="zipcode" name="zipcode" type="text" class="text">
                  <span id="consigneeNameNote" class="error-msg hide"></span> </div>
                <div class="clr"></div>
              </div>
              <input type="hidden" id="id" value="">
              <div class="btns"> <a href="javascript:;" onClick="edit_address();" class="e-btn btn-9 save-btn">保存收货地址</a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a href="javascript:;" class="thickclose" onClick="$('#thickdiv').fadeOut();$('#thickbox').fadeOut();"></a></div>
</div>
<div class="blank"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script src="<?php echo SPATH;?>js/layer/1.9.3/layer.js"></script>
<script>
var mr_span = '<span class="ftx-04 ml10">默认地址</span>';

function edit_add_box (id) {
	if (id) {
		var info = new Array();
		var index = layer.load(1,{time: 100*1000});
		$.get('index.php?m=member&c=address&a=get_address_ajax&id='+id, function (data) {
			layer.close(index);
			info = data.info;
			$('#id').attr('value', id);
			$('#contactname').attr('value', info['contactname']);
			$('#city').attr('value', info['city']);
			$('#address').attr('value', info['address']);
			$('#phone').attr('value', info['phone']);
			$('#tel').attr('value', info['tel']);
			$('#zipcode').attr('value', info['zipcode']);
			$('#city-1').show();
			$('#city-2').show();
			$("#city-1 option[value='"+info['sheng']+"']").attr("selected", true);
			//$("#city-2 option[value='"+info['shi']+"']").attr("selected", true);
			get_link(info['sheng'],info['shi']);
			$('#city-1').change(function(){
				get_link(info['sheng'],'');	
			});
		}, 'json');
	} else {
		$('#id').attr('value', '');
	}
	$('#thickdiv').fadeIn();
	$('#thickbox').fadeIn();
	
}
function get_link(pid,id){
	$.get('index.php?m=member&c=address&a=get_nodeAddress_ajax&ajax=1&pid='+pid,function(data){
		if (data.status == 1) {
			var option_ = '<option value="-1">请选择</option>';
			
			var info = data.info;
			for(var i in info){
				var selected_ ='';
				//console.log(id+'--'+info[i].linkageid);
				if (id == info[i].linkageid && id != '') {
					//console.log(id+'--'+info[i].linkageid);
					selected_ = 'selected="selected"';
				}
				option_ += '<option value="'+info[i].linkageid+'" '+selected_+'>'+info[i].name+'</option>';
			}
			//alert(option_);
			$('#city-2').empty();
			$('#city-2').append(option_);
		} 	
	},'json');
}
function edit_address  () {
	var url = '';
	var msg = '';
	var id = $('#id').val();
	var contactname = $('#contactname').val();
	var city = $('#city').val();//城市
	var address = $('#address').val();
	var phone = $('#phone').val();
	var tel = $('#tel').val();
	var zipcode = $('#zipcode').val();
	if (contactname == '' || city == '' || phone == '' || zipcode == '') {
		layer.msg('请完整填写收货信息！');
		return;
	}
	var json_  = {
		"contactname":contactname,
		"city":city,
		"city-1":$('#city-1').val(),
		"city-2":$('#city-2').val(),
		"address":address,
		"phone":phone,
		"tel":tel,
		"zipcode":zipcode,
		"dosubmit":1
		
	};
	var index = layer.load(1,{time: 100*1000});
	if (id) {
		msg = '修改';
		url = 'index.php?m=member&c=address&a=address_edit&ajax=1&addressid='+id;
	} else {
		msg = '添加';
		url = 'index.php?m=member&c=address&a=address_add&ajax=1';
	}
	$.post(url, json_, function (data) {
		layer.close(index);
		if (data.status == 1) {
			layer.msg(msg + '成功', {time:2000});
			setTimeout(function () {
				window.location.reload();
			}, 2000);
		} else {
			layer.msg(data.msg);
			return;
		}
	}, 'json');
}
function set_mr(id) {
	if (confirm('是否要设置为默认地址?')) {
		var index = layer.load(1,{time: 100*1000});
		$.get('index.php?m=member&c=address&a=set_mr_address&ajax=1&id='+id, function (data) {
			layer.close(index);
			layer.msg(data.msg);
			if (data.status == 1) {
				$('.easebuy-m .smt h3 .ftx-04').remove();
				$('#address_'+ id +' .smt h3').append(mr_span);
				setTimeout(function () {
					window.location.reload();
				}, 2000);
			}
		}, 'json');
	}
}
function del_address (id) {
	if (id == '') { return;}
	if (confirm('是否要删除该地址?')) {
		$.get('index.php?m=member&c=address&a=address_delete&ajax=1&id='+id, function (data) {
			layer.msg(data.msg);
			if (data.status == 1) {
				$('#address_' + id).fadeOut();
			}
		}, 'json');
	}
}
</script>
</html>