<?php defined('IN_drcms') or exit('No permission resources.'); ?><?php $titlename='会员中心';?>
<?php include template('wb_shop', 'header_common'); ?>
<link href="<?php echo SPATH;?>member/css/member_pc_style.css" rel="stylesheet" type="text/css"/>
<style>
.box_1 .userCenterBox .userMenu a { margin-bottom:5px; font-size:14px;}
.cai_like ul li { width:25%; float:left; text-align:center;}
.cai_like ul li p img { width:50%;}
.cai_like ul li p.words { padding:0 15px;}
.cai_like ul li p.words font {
	display: block;
    width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
.cai_like ul li p.words span em { color:red;}
</style>
<body>
<?php include template('wb_shop', 'header'); ?>
<div class="block box">
  <div class="blank"></div>
  <div id="ur_here"> 当前位置: <a href=".">首页</a> <code>&gt;</code> 用户中心 </div>
</div>
<div class="blank"></div>
<div class="tt01">
	<div class="tt01_box">
    	<?php include template("member", "member_left"); ?>
        <div class="member_right">
        	<div class="news_order">
                	<p class="order_title"><font>最新订单列表</font><a href="index.php?m=wb_shop&c=index&a=order&plat=<?php echo $_GET['plat'];?>">更多订单&gt;&gt;</a></p>
                    <table border="0" cellspacing="0">
                    	<tbody>
                            <tr>
                                <th align="left">订单号</th>
                                <th align="left" width="350">商品名称</th>
                                <th>价格</th>
                                <th>订单金额</th>
                                <th>日期</th>
                                <th>状态</th>
                                <!--<th>操作</th>-->
                            </tr>
                            <?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=64c857e95e46b4c4e9ba520a2210c1f0&sql=select+%2A+from+drcms_wb_shop_order+where+userid%3D%24userid+AND+status+%3C%3E98&num=5&return=shop_data\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from drcms_wb_shop_order where userid=$userid AND status <>98 LIMIT 5");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$shop_data = $a;unset($a);?><?php if(defined('IN_ADMIN') && !defined('HTML')) {echo '</div>';}?>
                            <?php $n=1;if(is_array($shop_data)) foreach($shop_data AS $r) { ?>
                            <tr class="tr_list <?php if($n%2 !=0) { ?>bg<?php } ?>">
                                <td class="left_al"><?php echo $r['orderid'];?></td>
                                <td class="left_al"><?php echo $r['goodstitle'];?></td>
                                <td class="red_font">￥<?php echo number_format($r['money'], 2);?></td>
                                <td class="red_font">￥<?php echo number_format($r['amount'], 2);?></td>
                                <td><?php echo date('Y-m-d H:i:s', $r['addtime']);?></td>
                                <td class="red_font">
                                       <?php if($r['status']==99) { ?>
                                         订单成功
                                       <?php } elseif ($r['status']==1) { ?>
                                         未付款
                                       <?php } elseif ($r['status']==2) { ?>
                                         已付款
                                       <?php } elseif ($r['status']==3) { ?>
                                         待收货
                                       <?php } elseif ($r['status']==4) { ?>
                                         退款中
                                       <?php } elseif ($r['status']==5) { ?>
                                       <?php } elseif ($r['status']==98) { ?>
                                         已取消
                                       <?php } ?>
                                </td>
                            </tr>
                            <?php $n++;}unset($n); ?>
                        </tbody>
                    </table>
                </div><!--news_order end-->
                <div class="news_order cai_like">
                	<p class="order_title cai_title"><font>最新收藏</font><a href="index.php?m=member&a=favorite&plat=<?php echo $_GET['plat'];?>">更多收藏>></a></p>
                    <div class="dp_type_btn" id="collect_btn">
                    	<a href="javascript:;" class="sel">商品收藏</a>
                        <a href="javascript:;">店铺收藏</a>
                    </div>
                  	<ul class="collect_box" id="dp_box_1">
                    	<?php if(defined('IN_ADMIN')  && !defined('HTML')) {echo "<div class=\"admin_piao\" pc_action=\"get\" data=\"op=get&tag_md5=56bfec3cfd76ab8db52c1188c70e8778&sql=select+%2A+from+drcms_favorite+where+userid%3D%24userid&return=goods_favorite\"><a href=\"javascript:void(0)\" class=\"admin_piao_edit\">编辑</a>";}pc_base::load_sys_class("get_model", "model", 0);$get_db = new get_model();$r = $get_db->sql_query("select * from drcms_favorite where userid=$userid LIMIT 20");while(($s = $get_db->fetch_next()) != false) {$a[] = $s;}$goods_favorite = $a;unset($a);?>
                        <?php 
                        	foreach ($goods_favorite as $k=>$r) {
                            	$this->default_db->load('wb_shop');
                                $goodsinfo_ = $this->default_db->get_one(array('id'=>$r['pid']));
                                if ($goodsinfo_['dp_id'] == $_GET['plat']) {
                                	$goodsinfo[$r['pid']] = $goodsinfo_;
                                } else {
                                	unset($goods_favorite[$k]);
                                }
                            	//$goodsid[$r['pid']] = $r['pid'];
                           }
                
                        ?>
                        <?php if($goods_favorite) { ?>
                        <?php $n=1; if(is_array($goods_favorite)) foreach($goods_favorite AS $k => $v) { ?>
                    	<li>
                        	<p><img src="<?php echo $goodsinfo[$v['pid']]['thumb'];?>"></p>
                            <p class="words">
                            	<font><?php echo $v['title'];?></font>
                                <span>
                                	<em>￥<?php echo number_format($goodsinfo[$v[pid]]['jiage'], 2);?></em>起
                               	</span>
                            </p>
                        </li>
                        <?php if($k>5) { ?>
                        <?php break;?>
                        <?php } ?>
                        <?php $n++;}unset($n); ?>
                        <?php } else { ?>
                        <li>暂无商品收藏</li>
                        <?php } ?>
                    	
                    </ul>
                    <ul class="collect_box" id="dp_box_2" style="display:none;">
                    	<?php if($dp_info) { ?>
                    	<?php $n=1;if(is_array($dp_info)) foreach($dp_info AS $r) { ?>
                    	<li>
                        	<p><img src="<?php echo $goodsinfo[$v['pid']]['thumb'];?>"></p>
                            <p class="words"><font><?php echo $r['shopname'];?></font><span>上新<em>￥<?php echo $shop_count[$r['dp_id']];?></em>款</span></p>
                        </li>
                        <?php $n++;}unset($n); ?>
                        <?php } else { ?>
                        <li>暂无店铺收藏</li>
                        <?php } ?>
                    </ul>
                </div><!--cai_like end-->
        </div>
    </div>
</div>
<div class="blank"></div>
<div class="blank"></div>
<?php include template('wb_shop', 'footer'); ?>
</body>
<script>
	window.onload = function () {
		var collect_btn = $('#collect_btn').find('a');
		collect_btn.each(function(i) {
            $(collect_btn[i]).click(function () {
				$(collect_btn).removeClass('sel');
				$(this).addClass('sel');
				$('.collect_box').hide();
				$('#dp_box_'+(i+1)).show();
			});
        });
	};
</script>
</html>