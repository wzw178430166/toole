<?php
return array (
  'ticket' => 'kgt8ON7yVITDhtdwci0qedzHD6aro_WziqmH5LRJ85omggs-sPSNzWQLEHCW0WupqUc4juPtMn4NBjLOPLXddA',
  'time' => 1528794364,
);
?>