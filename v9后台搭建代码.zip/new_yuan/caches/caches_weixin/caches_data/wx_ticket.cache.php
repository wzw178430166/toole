<?php
return array (
  'ticket' => 'kgt8ON7yVITDhtdwci0qedzHD6aro_WziqmH5LRJ85qFJkKhmOLdEzSO9ApkW-2S3f7vIxL55pCFOWhxuPZDhg',
  'time' => 1506157906,
);
?>