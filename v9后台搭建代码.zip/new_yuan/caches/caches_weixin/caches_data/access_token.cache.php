<?php
return array (
  'token' => 'xGZr3LNtGaDmBFlZm8gVplGYXGKRIh3UY8urdnIZB9X-5IzgFJTRg1kQaIsOaCwBp25XzpjMwxBaIyk2zTQ-L29HOnrEOzOAjIj2Lq-qLXhv1nxYtpKSwoX-50lTrZ6_ZAVjAJARSN',
  'time' => 1506157906,
);
?>