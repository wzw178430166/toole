<?php
return array (
  'token' => 'D1A1H1pjlX0PlGLrz80IuYCAm2RaLmGNpjeHLsBgWDA0ow5woiiS_Rx_kWYnumnUkaCWBkrCD7cRnML1LvAPlSeQj547rGXYdJ9yojaygMB1zTvqwUDRBdAxdY_LsguwMOSjADATVZ',
  'time' => 1512499422,
);
?>