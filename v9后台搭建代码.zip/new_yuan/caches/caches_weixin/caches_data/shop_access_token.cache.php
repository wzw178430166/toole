<?php
return array (
  'token' => '10_7i6GOofv0LcPZquVWrnuKjrW6nfrUYL4N6Ydh4dnEoDCzw-I1VEXr7aj7KKAvd4oA5aNT2YUMVxAxA4e1mygUy8NCc1vTs_aAYJdpVXV9jGIANx41k6nIr5DhzqOCN-F1u6jfXh1Iyu3boTIEVJaADAWNB',
  'time' => 1528794364,
);
?>