<?php
return array (
  'fulltextenble' => '1',
  'relationenble' => '1',
  'suggestenable' => '1',
  'sphinxenable' => '0',
  'sphinxhost' => '10.228.134.102',
  'sphinxport' => '9312',
);
?>