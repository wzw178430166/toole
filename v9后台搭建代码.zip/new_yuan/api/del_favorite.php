<?php
/**
 * 收藏url，必须登录
 * @param url 地址，需urlencode，防止乱码产生
 * @param title 标题，需urlencode，防止乱码产生
 * @return {1:成功;-1:未登录;-2:缺少参数}
 */
defined('IN_drcms') or exit('No permission resources.');


$_GET['callback'] = safe_replace($_GET['callback']);
//判断是否登录	
$drcms_auth = param::get_cookie('auth');
if($drcms_auth) {
	$auth_key = md5(pc_base::load_config('system', 'auth_key').$_SERVER['HTTP_USER_AGENT']);
	list($userid, $password) = explode("\t", sys_auth($drcms_auth, 'DECODE', $auth_key));
	$userid = intval($userid);
	if($userid >0) {

	} else {
		exit(trim_script($_GET['callback']).'('.json_encode(array('status'=>-1)).')');
	} 
} else {
	exit(trim_script($_GET['callback']).'('.json_encode(array('status'=>-1)).')');
}

$id = (int)$_POST['id'];
$favorite_db = pc_base::load_model('favorite_model');
		
//根据url判断是否已经收藏过。
$is_exists = $favorite_db->delete(array('id'=>$id, 'userid'=>$userid));


//exit(trim_script($_GET['callback']).'('.json_encode(array('status'=>1)).')');
exit(json_encode(array('status'=>1)));
?>