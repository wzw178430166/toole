<?php
include drcms_PATH."api/taobao_sdk/TopSdk.php";

function smsset(){
	return array(
		//'appkey'=>'23311714',
		//'secret'=>'9f6e0371ff060c07a5146bc86463a70f',
		//'secret'=>'c6fc8e635df73c787fc8eb10f4aaf7fb',
		'appkey'=>'23817644',
		'secret'=>'3efe3a803fd53ec7bfb9dfe4a9f79b4b',
	);	
}
/**
 * 发送邮件
 * @param $toemail 收件人email
 * @param $subject 邮件主题
 * @param $message 正文
 * @param $from 发件人
 * @param $cfg 邮件配置信息
 * @param $sitename 邮件站点名称
 */
function sendsms_register($code,$phone){
	$smsset = smsset();
	
	$c = new TopClient;
	$c->appkey = $smsset['appkey'];
	$c->secretKey = $smsset['secret'];
	$req = new AlibabaAliqinFcSmsNumSendRequest;
	$req->setExtend("123456");
	$req->setSmsType("normal");
	$req->setSmsFreeSignName("注册验证");
	//$req->setSmsFreeSignName("身份验证");
	$req->setSmsParam("{\"code\":\"$code\",\"product\":\"巴巴优品\"}");
	$req->setRecNum($phone);
	$req->setSmsTemplateCode("SMS_35365115");
	//$req->setSmsTemplateCode("SMS_5053541");
	$resp = $c->execute($req);

	return $resp;
}

function sendsms_buytoadmin($arr,$phone){
	$smsset = smsset();
	
	$dianhua = $arr['dianhua'];
	$qian = $arr['qian'];
	$taochan = $arr['taochan'];
	
	$c = new TopClient;
	$c->appkey = $smsset['appkey'];
	$c->secretKey = $smsset['secret'];
	$req = new AlibabaAliqinFcSmsNumSendRequest;
	$req->setExtend("123456");
	$req->setSmsType("normal");
	$req->setSmsFreeSignName("身份验证");
	$req->setSmsParam("{\"code\":\"$dianhua\",\"product\":\"$taochan\",\"item\":\"$qian\"}");
	$req->setRecNum($phone);
	$req->setSmsTemplateCode("SMS_5053537");
	$resp = $c->execute($req);

	return $resp;		
}
?>