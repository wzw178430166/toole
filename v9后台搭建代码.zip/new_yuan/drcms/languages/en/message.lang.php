<?php
$LANG['send_message'] = 'Send message';
$LANG['all_send_message'] = 'Group message';
$LANG['message'] = 'Message';
$LANG['send'] 	= 	'Send';
$LANG['sendto'] 	= 	'Send to';
$LANG['subject'] 	= 	'Subject';
$LANG['content'] 	= 	'Content';
$LANG['setting'] 	= 	'Setting';
$LANG['touserid'] 	= 	'Recipient';
$LANG['fromuserid'] 	= 	'Sender';
$LANG['send_time'] 	= 	'Sending Time';
$LANG['reply'] 	= 	'Reply';
$LANG['is_reply'] 	= 	'Reply';
$LANG['remove_all_selected'] 		= 	'Remove all selected';
$LANG['user_noempty']				= 	'Recipient is required';
$LANG['username']					= 	'Username ';
$LANG['time']						= 	'Time';
$LANG['see_info']					= 	'Infomation';
$LANG['no_empty']					= 	'is required';
$LANG['before_select_operation']	=	'Please select before execute'; 

$LANG['no_thisuser']				=	'The user does not exist.'; 
$LANG['connecting']					=	'Connecting, please wait'; 

$LANG['group']						=	'Base on user groups'; 
$LANG['role']						=	'Base on roles'; 
$LANG['send_num']					=	'Per number of sending'; 

$LANG['select']['send_from_id']		= 	'Sender';
$LANG['select']['send_to_id'] 		= 	'Recipient';
$LANG['not_myself']					=	'Cannot send message to yourself or unregistered user.'; 
$LANG['sendtime']					=	'Sending time';
$LANG['show_m']						=	'Show';
$LANG['details']					=	'Details';
$LANG['message_sender']				=	'Sender';
$LANG['query_type']					=	'Search type';
$LANG['to']							=	'To';
$LANG['message_not_exist']			=	'The message does not exist.';
$LANG['mass_failure']				=	'Group SMS sending failed, please check';
?>