<?php
defined('IN_drcms') or exit('No permission resources.');
pc_base::load_sys_class('model', '', 0);
class default_model extends model {
	public function __construct($setting=null) {
		$this->db_config = pc_base::load_config('database');
		$this->db_setting = $setting? $setting : 'default';
		parent::__construct();
	}
	
	public function load($table){
		if(!$table){
			return false;
		}else{
			$this->table_name = $this->db_config[$this->db_setting]['tablepre'].$table;	
		}
	}
	public function load_no($table){
		if(!$table){
			return false;
		}else{
			$this->table_name = $table;	
		}
	}
	
	public function load_data(){
		
		$this->table_name = $this->table_name.'_data';	

	}
	public function setting($setting){
		if(!$setting){
			return false;
		}else{
			$this->__construct($setting);
			return $this->db_setting;
		}
	}
	

}
?>