<?php
defined('IN_drcms') or exit('No permission resources.');
pc_base::load_sys_class('model', '', 0);
class hits_model extends model {
	public $table_name = '';
	public function __construct() {
		$this->db_config = pc_base::load_config('database');
		$this->db_setting = 'default';
		$this->table_name = 'hits';
		parent::__construct();
	}
	
	public function load_site($siteid){
		$this->table_name = 'hits_'.$siteid;
		parent::__construct();
	}
	public function create($siteid){
		$sql = "CREATE TABLE `".$this->table_name."` (  `hitsid` char(30) NOT NULL,  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',  `views` int(10) unsigned NOT NULL DEFAULT '0',  `yesterdayviews` int(10) unsigned NOT NULL DEFAULT '0',  `dayviews` int(10) unsigned NOT NULL DEFAULT '0', `weekviews` int(10) unsigned NOT NULL DEFAULT '0',  `monthviews` int(10) unsigned NOT NULL DEFAULT '0',  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',  PRIMARY KEY (`hitsid`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;";	
		$this->query($sql);
	}	
}
?>